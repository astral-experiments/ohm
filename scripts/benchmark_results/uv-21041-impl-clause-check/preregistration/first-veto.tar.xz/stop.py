"""Only the genuine uv_metadata child is traced, using three source/ELF-bound conditional sites."""
import gdb,os,struct,json,collections,hashlib,traceback
from pathlib import Path
out=Path('/tmp/evidence');spec=json.loads((out/'request.json').read_bytes());accepted=set(spec['target_indices']);calls=collections.Counter();contexts=[];positive=[];watched=set(spec['watch_for_green']);pending={};faults=[];exitcode=[]
gdb.execute('set python print-stack full');gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set disable-randomization off');gdb.execute('set debuginfod enabled off');gdb.execute('unset environment LD_LIBRARY_PATH');gdb.execute('set print thread-events off');gdb.execute('set startup-with-shell on')
gdb.events.exited.connect(lambda ev:exitcode.append(ev.exit_code if hasattr(ev,'exit_code')else None))
gdb.execute('catch load librustc_driver-fa217dfcec654979.so')
gdb.execute('run')
inf=gdb.selected_inferior();pid=inf.pid;driver=Path(spec['driver'])
maps=[l.split(None,5)for l in Path('/proc/'+str(pid)+'/maps').read_text().splitlines()]
maps=[r for r in maps if len(r)==6 and Path(r[-1]).is_absolute()and Path(r[-1]).resolve()==driver.resolve()]
zero=[int(r[0].split('-')[0],16)for r in maps if int(r[2],16)==0];assert len(zero)==1,('driver mapping',maps)
base=zero[0];assert hashlib.sha256(driver.read_bytes()).hexdigest()==spec['driver_sha256']
st=driver.stat();assert maps and all(int(r[4])==st.st_ino and int(r[3].split(':')[0],16)==os.major(st.st_dev) and int(r[3].split(':')[1],16)==os.minor(st.st_dev) for r in maps)
want=spec['argv'];seen=[s.decode()for s in Path('/proc/'+str(pid)+'/cmdline').read_bytes().split(b'\0')[:-1]];assert seen==want and Path('/proc/'+str(pid)+'/exe').resolve()==Path(want[0]).resolve(),('original argv',len(seen),len(want),[(i,a,b)for i,(a,b)in enumerate(zip(seen,want))if a!=b][:2],str(Path('/proc/'+str(pid)+'/exe').resolve()))
def word(p):return int.from_bytes(inf.read_memory(p,8).tobytes(),'little')
def reg(n):return int(gdb.parse_and_eval('$'+n))&((1<<64)-1)
def mark_chain(sp):
 cur=sp+0x90;chain=[]
 for _ in range(256):
  nxt=word(cur);index=word(cur+8)&0xffffffff;assert index<spec['maximum'];chain.append(index)
  if not nxt:return chain
  assert cur<nxt and nxt-cur<2**22 and nxt%8==0,(hex(cur),hex(nxt))
  cur=nxt
 raise ValueError('overlong native MarkFrame chain')
# The first two callbacks are reached only with a prior graph edge in rbx.
# The return join also receives the separate empty promotion whose rbx is UINT_MAX.
class Mark(gdb.Breakpoint):
 def __init__(self,name,offset):
  self.category=name;super().__init__('*'+hex(base+offset),internal=True,temporary=False)
 def stop(self):
  try:
   category=self.category;sp=reg('rsp');tid=gdb.selected_thread().ptid;current=word(sp+0x98)&0xffffffff;child=reg('ebx')&0xffffffff
   if category=='force-return':
    if reg('al')&255:return False
    reason='force-declined';key=inf.read_memory(sp+0x40,16).tobytes().hex();kind=word(sp+0x50)&0xffff;pending[tid]=(sp,current,child,reason,[kind,key]);return False
   if category=='after-positive-force':
    color=reg('r13d')&0xffffffff
    if child in watched:positive.append(dict(failures_before=len(contexts),thread=list(tid),chain=mark_chain(sp),child=child,color=color))
    if color!=0xfffffffe:return False
    pending[tid]=(sp,current,child,'forced-red',None);return False
   chain=mark_chain(sp);assert chain[0]==current
   if tid in pending:
    ps,pc,cc,reason,key=pending.pop(tid);assert (ps,pc,cc)==(sp,current,child)
   elif child==0xffffffff:reason='promotion-refused';key=None
   else:
    assert reg('r13d')&0xffffffff==0xfffffffe,(tid,current,child,hex(reg('r13d')))
    reason='previously-red';key=None
   calls[reason]+=1
   # The program only persists previous-index chains from this one enrolled compiler.
   contexts.append(dict(sequence=len(contexts),chain=chain,child=child,reason=reason,force_key=key,thread=list(tid)))
   assert len(contexts)<100000
   return False
  except BaseException:
   faults.append(traceback.format_exc());return True
gdb.execute('delete breakpoints')
# ELF PT_LOAD has +0x1000 VA delta for executable .text in this exact binary.
for name,offset,expected in [('force-return',0x4c28642,'84c0'),('after-positive-force',0x4c288de,'74d2'),('failure-join',0x4c288b2,'bbffffffff')]:
 with driver.open('rb')as f:f.seek(offset-0x1000);source=f.read(len(expected)//2).hex()
 assert source==expected and inf.read_memory(base+offset,len(expected)//2).tobytes().hex()==expected,(name,source)
 Mark(name,offset)
gdb.execute('continue')
if faults:raise RuntimeError(faults)
assert not pending and exitcode==[0] and contexts,(pending,exitcode)
p={'original_pid':pid,'argv_sha256':hashlib.sha256(json.dumps(seen,separators=(',',':')).encode()).hexdigest(),'driver_sha256':spec['driver_sha256'],'base':hex(base),'counts':dict(calls),'rows':contexts,'positive_force_colors':positive,'observed_root_indices':sorted(k for k in accepted if any(k in r['chain']for r in contexts)),'compiler_exit':exitcode[0]}
with (out/'native-marks.json').open('x')as f:json.dump(p,f,sort_keys=True,separators=(',',':'));f.write('\n')
