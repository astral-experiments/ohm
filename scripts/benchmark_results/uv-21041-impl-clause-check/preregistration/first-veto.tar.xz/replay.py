"""From the sealed compact files, reopen every original native event and validate all 49 paid owners and their prices."""
from pathlib import Path
from collections import Counter,defaultdict
import bisect,gzip,hashlib,json,sys
F=Path(__file__).resolve().parent
def d(b):return hashlib.sha256(b).hexdigest()
def j(n):return json.loads((F/n).read_bytes())
def gz(n):return gzip.decompress((F/n).read_bytes())
def main():
 a=j('accepted.json');plan=j('registration.json');rd=j('findings.json');valid=j('clause-validation.json');terms=j('clauses.json');assert a['registration']==d((F/'registration.json').read_bytes())and rd['accepted_raw']==d((F/'accepted.json').read_bytes())and valid['true_source_comparison']==d((F/'clauses.json').read_bytes())and valid['source']==a['source_compiler']
 r=gz('original-marks.json.gz');s=gz('original-request.json.gz');assert d(r)==a['raw_sha256']and d(s)==a['request_sha256'];raw=json.loads(r);rq=json.loads(s);rr=raw['rows'];assert raw['compiler_exit']==0 and len(rq['argv'])==a['argc']==983 and raw['argv_sha256']==d(json.dumps(rq['argv'],separators=(',',':')).encode());assert len(rr)==sum(a['raw_counts'].values())and raw['driver_sha256']==rq['driver_sha256']==j('elf.json')['roles']['candidate']['driver_sha256'];z=json.loads(gz('cases.json.gz'));assert d((F/'cases.json.gz').read_bytes())==rd['payload']==valid['original_49_paths'];cases=z['cohort'];assert sorted(rq['target_indices'])==sorted(int(x)for x in plan['members'])==sorted(a['observed_indices'])and len(cases)==len(plan['members'])==49
 branch=defaultdict(list);by=defaultdict(list);paired=set()
 for i,x in enumerate(rr):
  assert i==x['sequence'];branch[tuple(x['thread']),tuple(x['chain'])].append(i);by[x['chain'][0]].append(i)
 def steps(i):
  out=[]
  while i is not None:
   v=rr[i];ch=tuple(v['chain']);cid=v['child'];thread=tuple(v['thread']);out.append([i,ch[0],cid,v['reason']])
   if cid==0xffffffff or v['reason']=='previously-red':break
   rr0=branch.get((thread,(cid,)+ch),[]);p=bisect.bisect_left(rr0,i)-1
   if p<0:break
   sub=rr0[p];siblings=[e for e in branch[thread,ch]if rr[e]['child']==cid];pd=bisect.bisect_left(siblings,i)-1
   if pd>=0 and siblings[pd]>=sub:break
   i=sub
  return out
 dcount=Counter();prices=defaultdict(lambda:[0,0]);roots=Counter();deep=Counter();earlier=set()
 for c in cases:
  mc=c['registration'];i=mc['native_A_node'];assert mc==plan['members'][str(i)]and i not in paired;paired.add(i)
  path=steps(by[i][0]);q=[[a['row'],a['root'],a['child'],a['reason']]for a in c['first']];assert q==path and q[-1][2]==41525 and q[-1][3]=='previously-red';leaf=c['leaf'];assert leaf==dict(z['native_keys_and_results']['41525'],A_node=41525)and leaf['B_nodes']==[42704]and leaf['A']!=leaf['B']and leaf['A']!='0'*32!=leaf['B']and leaf['key']==terms['stable_DefPathHash'];earlier.add(c['earlier_positive_force_observed_red']);roots[mc['kind']]+=1;deep[path[-1][1]]+=1
  other=bool(set(c['direct_unstable_nodes']['changed positive result'])-{41525});dcount[other]+=1;prices[other]=[a+b for a,b in zip(prices[other],c['original_parent_nonoverlap_Ir_by_history'])]
 assert dict(roots)=={'typeck_root':28,'mir_borrowck':21}and dict(dcount)=={False:39,True:10}and prices[False]==[424116242,423422794]and prices[True]==[169980618,170229736];assert earlier=={1278}and rr[1278]['child']==41525 and rr[1278]['reason']=='forced-red'and all(c['first'][-1]['row']>1278 for c in cases)
 h=valid['A_B_independent_cold_hygiene'];assert h['A']==h['B']==h['cold']and len(valid['hostile_checks'])==7
 sr=terms['physical_reads'];assert sr['A']['record']['line']==736 and sr['B']['record']==sr['cold']['record']and sr['B']['record']['line']==776 and sr['B']['record']['lo']-sr['A']['record']['lo']==677 and all(q['record']['text']=='rkyv::Archive'and q['record']['length']==13 for q in sr.values())
 pr={'actual_sources':a['source_compiler'],'real_mark_returns':len(rr),'native_previous_force_red_row':1278,'paid_provider_calls':dict(roots),'immediate_native_reader_A_indices':dict(deep),'distinct_source_owners':len({q['registration']['unique_source_identity']for q in cases}),'same_exact_first_cause':leaf['kind']+' '+leaf['key'],'previous_parent_prices_after_excluding_10_with_other_positive_direct_inputs':prices[False],'all_49_prior_parent_prices':[a+b for a,b in zip(prices[False],prices[True])],'differing_diagnostic_source_bytes':677,'physically_validated_negative_cases':7,'no_current_performance_claim':True};print(json.dumps(pr,indent=1,sort_keys=True));return pr
if __name__=='__main__':main()
