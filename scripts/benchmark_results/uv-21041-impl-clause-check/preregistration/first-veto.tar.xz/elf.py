"""Attach the three previously established green-check sites to the candidate's actual driver."""
from pathlib import Path
import hashlib,json,re,runpy,struct,subprocess
H=Path(__file__).resolve().parent;J=H.parent;S=J.parent/'trait-selection-21041';old=json.loads((S/'mark-elf.json').read_bytes());lab=runpy.run_path(str(J/'lab.py'));sha=lab['sha'];put=lambda p,o:p.write_text(json.dumps(o,indent=1,sort_keys=True)+'\n')
def analyze(d):
 sym=oldname;tab=subprocess.check_output(['nm','-nS','--defined-only',d],text=True).splitlines();v,=[line.split()for line in tab if line.endswith(' '+sym)];entry=int(v[0],16);size=int(v[1],16)
 asm=subprocess.check_output(['objdump','-w','-d','--disassemble='+sym,d],text=True);ins=[];relocs=set()
 for line in asm.splitlines():
  m=re.match(r'^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2}\s+)+)\s*(\S+)(?:\s+(.*))?$',line)
  if not m:continue
  pc=int(m[1],16);raw=bytes.fromhex(m[2]);op=m[3];args=m[4] or ''
  if op.startswith('j')or op.startswith('call'):
   direct=re.fullmatch(r'([0-9a-f]+) <([^>]+)>',args)
   if direct:
    dst=int(direct[1],16);args=('internal+'+str(dst-entry))if entry<=dst<entry+size else 'external '+direct[2]
   elif '%rip' in args:
    off=re.search(r'#\s*([0-9a-f]+)\s+<',args);assert off, args;dst=int(off[1],16);relocs.add(dst);args=('GOT',dst)
   else:assert args.startswith('*'),(op,args)
  elif '%rip' in args:
   # Non-call RIP data operands do not control the three hooks. Keep symbol/delta in the audit below.
   args=re.sub(r'-?0x[0-9a-f]+\(%rip\).*','<RIP>(%rip)',args)
  ins.append([pc-entry,op,args,raw.hex()])
 assert len(ins)>200
 with d.open('rb')as f:
  head=f.read(64);off=struct.unpack_from('<Q',head,32)[0];w,N=struct.unpack_from('<HH',head,54);assert head[:6]==b'\x7fELF\x02\x01'and w==56;f.seek(off);loads=list(struct.iter_unpack('<IIQQQQQQ',f.read(w*N)))
 resolved={};p=subprocess.Popen(['readelf','-Wr',d],stdout=subprocess.PIPE,text=True)
 for line in p.stdout:
  bits=line.split()
  if len(bits)<5 or not re.fullmatch('[0-9a-f]{16}',bits[0]):continue
  a=int(bits[0],16)
  if a not in relocs:continue
  assert a not in resolved and bits[2]in('R_X86_64_GLOB_DAT','R_X86_64_JUMP_SLOT') and bits[-1]=='0';resolved[a]=bits[4]
 assert p.wait()==0 and set(resolved)==relocs
 for row in ins:
  if isinstance(row[2],tuple):row[2]='indirect '+resolved[row[2][1]]
 return entry,ins,asm,loads
def run():
 global oldname
 assert sha(S/'mark-elf.json')==json.loads((S/'candidate-mark-01/request.json').read_bytes())['origin_elf']
 ost=json.loads((S/'mark-structure.json').read_bytes());oldname=ost['sources']['b9']['symbol'];old_off=old['candidate_sites'];rel={k:v-ost['sources']['b9']['entry']for k,v in old_off.items()};assert rel==ost['original_relative_sites']
 roles={};layout={};sources={};raw={}
 for role in ('parent','candidate'):
  sdk,rev,receipt=lab['sdk_for'](role);d,=(sdk/'lib').glob('librustc_driver-*.so');entry,ins,asm,loads=analyze(d);(H/(role+'.asm')).write_text(asm);sites={};got={}
  for label,off in rel.items():
   pc=entry+off;t,=[s for s in loads if s[0]==1 and s[1]&1 and s[3]<=pc<pc+5<s[3]+s[5]];filepos=t[2]+pc-t[3];withraw=bytes.fromhex(old['expected_bytes'][label])
   with d.open('rb')as f:f.seek(filepos);assert f.read(len(withraw))==withraw,(role,label,hex(pc))
   sites[label]=pc;got[label]=pc-filepos
  assert set(got.values())=={0x1000}
  roles[role]={'source':rev,'sdk_receipt':receipt,'driver':str(d),'driver_sha256':sha(d),'entry':entry,'symbol':oldname,'sites':sites,'expected_bytes':old['expected_bytes'],'executable_segment_virtual_minus_file':got,'instruction_count':len(ins),'got_targets':{x[0]:x[2] for x in ins if isinstance(x[2],str)and x[2].startswith('indirect ')}}
  assert len(roles[role]['got_targets'])>=18;layout[role]=[x[:3]for x in ins];raw[role]=[x[3]for x in ins];sources[role]={p:hashlib.sha256(subprocess.check_output(['git','-C',S/'source01/checkout','show',rev+':'+p])).hexdigest()for p in ('compiler/rustc_middle/src/dep_graph/graph.rs','compiler/rustc_middle/src/dep_graph/dep_node.rs','compiler/rustc_middle/src/queries.rs')}
 assert roles['parent']['driver_sha256']==old['driver']and roles['parent']['sites']==old_off
 if layout['parent']!=layout['candidate']:
  put(H/'different.json',[[a,b]for a,b in zip(layout['parent'],layout['candidate'])if a!=b]);raise ValueError('different code layout or operations, see different.json')
 assert sources['parent']==sources['candidate'];put(H/'elf.json',{'roles':roles,'mark_sources':sources,'parent_ELF_proof':sha(S/'mark-elf.json'),'checks':'Every whole-function instruction offset/op/register/stack displacement/direct branch target matched. All indirect call targets were verified via real ELF relocations. For other RIP constants the addressing form matches. Both byte patterns were independently read at the three hooks in the executable PT_LOAD segment.','common_normalized_instructions_sha256':hashlib.sha256(json.dumps(layout['parent'],separators=(',',':')).encode()).hexdigest(),'raw_identical':sum(a==b for a,b in zip(raw['parent'],raw['candidate'])),'raw_total':len(raw['parent']),'reader':sha(H/'elf.py')});print(sha(H/'elf.json'),roles['candidate']['sites'],roles['candidate']['instruction_count'])
if __name__=='__main__':run()
