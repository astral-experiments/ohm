"""Decode the one observed changed external query's complete term and its attached real source span."""
from pathlib import Path
from functools import lru_cache
import gzip,hashlib,json,runpy,subprocess,sys
F=Path(__file__).resolve().parent;J=F.parent;H=J/'provider-mechanism';T=J.parent/'trait-selection-21041';m=runpy.run_path(str(H/'owners.py'));lab=m['lab'];read=m['j'];sh=m['sh'];S=m['sig'];sha=m['sha'];q=read(F/'named-direct.json');node=q['exact_named_changed'][0];sdk,commit,receipt=lab['sdk_for']('candidate');group=lab['work']/'candidate-1';sem={};tree={};printlog='verbose'in sys.argv
class Term:
 def __init__(self,ph,p):
  self.ph=ph;self.data=p.read_bytes();self.h=m['C']['root'](self.data);self.deps={n:(a,hash_,ext,private)for n,a,hash_,ext,private in m['C']['deps'](self.data,self.h)};self.absolute=p;self.tyrefs=[];self.lookup={};self.last='';self.stage=''
  self.ctx=group/('A'if ph=='A'else'B')
 def body(self):
  md=self.h['stable_crate_id'];idx=node['A_index' if self.ph=='A'else'B_index'];facts=self.resolve(0,node['key'][16:]);assert facts['index']==idx and facts['stable']==md and facts['path']==tuple(tuple(z)for z in node['unmoved_DefKey_path'])
  def val(key):
   rows=S.di.rows(self.data,self.h['tables'][key]);return int.from_bytes(rows[idx],'little')if idx<len(rows)else 0
  assert val('inferred_outlives_of')==0;st=val('explicit_clauses_of');r=S.Reader(self.data,st);assert (r.byte(),r.u(),r.u())==(0,1,0);pred_at=r.u()-128;span,seg=m['layout']['span'](self.data,r.p);assert seg[0][1]==val('type_of')and self.data[r.p]&3==3
  w=S.Reader(self.data,pred_at);assert (w.u(),w.u())==(0,0);trait=self.did(w);args=self.args(w);pol=w.u();assert pol==0;v={'generic_parent':None,'bound_vars':[],'kind':'trait','trait':trait,'args':args,'polarity':'positive','inferred_outlives':[],'extra_self_trait_clause':False};shape={'position':st,'end':seg[0][1],'bytes':self.data[st:seg[0][1]].hex(),'native_predicate_position':pred_at,'native_predicate_end':w.p,'type_extent':self.tyrefs,'defined_by':facts,'raw_span':span,'span_chasing':seg,'record':self.coordinates(span),'source_metadata':str(self.absolute),'metadata_sha256':sha(self.data),'resolved_foreign_inventory':{str(k):x for k,x in self.lookup.items()}}
  return v,shape
 @lru_cache(None)
 def lib(self,cn):
  if not cn:p=self.absolute
  else:
   a,cr,extra,_=self.deps[cn];plat=sdk/'lib/rustlib/x86_64-unknown-linux-gnu/lib';f=list(plat.glob('lib*'+extra+'.rmeta'))
   if not f:f=list(self.ctx.glob('debug/**/lib*'+extra+'.rmeta'))
   assert f and len({sha(p.read_bytes())for p in f})==1,(cn,a,extra,f);p=f[0]
  b=p.read_bytes();h=m['lib_tables'](b);ids,rev,row,path=m['mapped'](b,h);self.lookup[cn]={'file':str(p),'sha256':sha(b),'stable':h['stable_crate_id'],'n_defs':len(ids),'crate':p.name.split('-')[0][3:]};return h['stable_crate_id'],('uv_pypi_types' if cn==0 else p.name.split('-')[0][3:]),ids,rev,path
 def resolve(self,cn,h):
  s,n,ids,rev,fn=self.lib(cn);ix=rev[h];assert ids[ix].hex()==h
  return {'crate':n,'stable':s,'local':h,'index':ix,'path':fn(ix)}
 def did(self,r):
  cn=r.u();v=self.resolve(cn,r.raw(8).hex());return [v['crate'],v['stable'],v['local'],v['path']]
 def args(self,r):
  n=r.u();assert n<=5,(n,r.p,self.last,self.stage);v=[]
  for _ in range(n):
   k=r.u();assert k==1,(k,r.p,self.last,self.stage);v.append(['type',self.ty(r)])
  return v
 def ty(self,r):
  start=r.p;k=r.u()
  if k>=128:
   to=k-128;assert 0<=to<start;self.tyrefs.append([start,to]);return self.ty(S.Reader(self.data,to))
  if k==10:return ['slice',self.ty(r)]
  if k==3:return ['Uint',r.u()]
  if k==7:return ['str']
  assert k==5,(k,r.p,self.last,self.stage);self.stage='ADT';d=self.did(r);self.last=d[0:3];assert d;vflags=[]
  vlen=r.u();assert 0<vlen<=8,(vlen,r.p,d)
  for vi in range(vlen):
   variant=self.did(r);opt=r.u();assert opt in (0,1);ctor=(r.u(),self.did(r))if opt else None
   symbol=m['sym'](r.symbol());dis=r.u();assert dis==1,(dis,r.p,d);offset=r.u();fields=[];fldlen=r.u();assert 0<=fldlen<=10,(r.p,fldlen,d)
   for fl in range(fldlen):
    fid=self.did(r);name=m['sym'](r.symbol());vis=r.u();assert vis in (0,1);visible=self.did(r)if vis else None
    restr=r.u();assert restr==0,(restr,r.p,d,fid);safe=r.u();assert safe in(0,1);value=r.u();assert value in(0,1);value=self.did(r)if value else None;fields.append([fid,name,vis,visible,restr,safe,value])
   taint=r.u();assert taint==0;vflag=r.u();vflags.append({'variant':variant,'ctor':ctor,'symbol':symbol,'relative_discriminant':offset,'fields':fields,'taint':None,'flags':vflag})
  flags=int.from_bytes(r.raw(2),'little');fmt=[r.u(),r.u(),r.u()];assert fmt==[0,0,0],(fmt,r.p,d);reprflags=r.byte();scalable=r.u();assert scalable==0,(r.p,scalable,d);shuffle=r.raw(8).hex()
  if printlog:print(self.ph,hex(start),'ADT',d[:3],d[3][-2:],'generic args start',r.p,self.data[r.p:r.p+18].hex(' '),flush=True)
  args=self.args(r);self.tyrefs.append([start,r.p]);return ['adt',d,{'variants':vflags,'flags':flags,'repr':[fmt,reprflags,scalable,shuffle]},args]
 def coordinates(self,span):
  kind,ct,lo,n,fi,foreign=span;assert kind==0 and foreign is None and n==13;files=S.di.rows(self.data,self.h['tables']['source_map']);p=int.from_bytes(files[fi],'little');r=S.Reader(self.data,p);assert (r.u(),r.u())==(0,0);rel,root,full=(r.string()for _ in range(3));assert rel=='crates/uv-pypi-types/src/simple_json.rs'and root=='/ohm-workspace/v7'and full==root+'/'+rel
  git=lab['plan']['uv'];rev=git['A'if self.ph=='A'else'B'];text=subprocess.check_output(['git','-C',lab['alg']['SRC'],'show',rev+':'+rel]);assert r.byte()==59 and (r.u(),r.u())==(0,32)and r.raw(32)==hashlib.md5(text).digest()+bytes(16)
  return {'path':rel,'source':rev,'source_sha256':sha(text),'lo':lo,'length':n,'line':1+text[:lo].count(b'\n'),'column_1_based':lo-text.rfind(b'\n',0,lo),'text':text[lo:lo+n].decode(),'local_ctxt_index':ct}
def run():
 result={};proof={}
 for ph in ('A','B','cold'):
  oldph='A'if ph=='A'else'B';source=Path(q['inputs'][oldph][0][1]);root=group/('A'if ph=='A'else'B');p=source if ph!='cold'else group/'cold-guard-B'/source.relative_to(root)
  if ph=='cold':
   meta=read(group/'qa/cold-b-samepath.products.json')['metadata'][source.relative_to(root).as_posix()];p=group/'cold-guard-B/independent-native-b/products'/meta['sha256'];assert p.stat().st_size==meta['bytes'] and sh(p)==meta['sha256']==sh(source)
  s=Term(ph,p);a,b=s.body();proof[ph]=b;result[ph]=a
 assert result['A']==result['B']==result['cold'];assert len({x['record']['text']for x in proof.values()})==1 and proof['A']['record']['lo']!=proof['B']['record']['lo']==proof['cold']['record']['lo'];z={'query':'clauses_of(<uv_pypi_types::HashDigests as rkyv::Archive>)','stable_DefPathHash':node['key'],'complete_compared_clause_with_reachable_nominal_adt_definitions':result['A'],'physical_reads':proof,'checked':{'identical_all_terms':True,'reachable_full_hash_stable_AdtDefData_compared':True,'independent_cold':True},'decoder':sh(F/'clauses.py'),'limitation':'The raw syntax-context and source position are reported; stable hygienic identity is verified separately.'};(F/'clauses.json').write_text(json.dumps(z,indent=1,sort_keys=True)+'\n');print('equal',sha((F/'clauses.json').read_bytes()),[(k,v['record'])for k,v in proof.items()])
if __name__=='__main__':run()
