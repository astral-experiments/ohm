"""Classify only real observed native failing branches and safely replay the previously measured disjoint owner costs."""
from collections import Counter,defaultdict
from functools import lru_cache
from pathlib import Path
import bisect,gzip,hashlib,json,runpy
F=Path(__file__).resolve().parent;m=runpy.run_path(str(F/'first.py'));j,sh,write,T,H=(m[k]for k in ('j','sha','write','T','H'));ALL=0xffffffff;RED=0xfffffffe
def run():
 ag,names,members,score,ctx,group,sdk,rev=m['load']();a,b=ag['A'],ag['B'];receipt=j(F/'accepted.json');raw=Path(receipt['raw']);assert sh(raw)==receipt['raw_sha256'];rr=j(raw);reg=j(F/'registration.json');assert receipt['registration']==sh(F/'registration.json')and rr['driver_sha256']==j(F/'elf.json')['roles']['candidate']['driver_sha256'] and rr['compiler_exit']==0 and rr['argv_sha256']==hashlib.sha256(json.dumps(j(raw.parent/'request.json')['argv'],separators=(',',':')).encode()).hexdigest();assert receipt['B_graph']==score['B_graph']and receipt['all_37_A_and_B']and receipt['same_seed_outputs']==ctx['expected_outputs']
 @lru_cache(None)
 def old(i):
  assert i!=ALL and a.offset(i);key,fp,*_=a.get(i);return key,fp,m['deps'](a,i)
 watched=set(reg['watch']);seq=rr['rows'];by_branch=defaultdict(list);by_child=defaultdict(list);by_root=defaultdict(list);wanted=set(members);positive=defaultdict(list)
 for ix,row in enumerate(seq):
  assert ix==row['sequence'];cs=row['chain'];kid=row['child'];assert len(cs)==len(set(cs))and all(v in old(p)[2] for p,v in zip(cs[::-1],cs[::-1][1:]));assert kid in old(cs[0])[2] if kid!=ALL else row['reason']=='promotion-refused'
  by_branch[tuple(row['thread']),tuple(cs)].append(ix);by_child[kid].append(ix);by_root[cs[0]].append(ix)
  if row['force_key'] is not None:
   kind,hexkey=row['force_key'];wire=bytes.fromhex(hexkey)+kind.to_bytes(2,'little');assert old(kid)[0]==(int.from_bytes(wire[:2],'little'),wire[2:])and row['reason']=='force-declined'
 for row in rr['positive_force_colors']:
  ci=row['child'];col=row['color'];assert ci in watched and ci in old(row['chain'][0])[2] and 0<=row['failures_before']<=len(seq);assert col>=RED or b.get(col)[0]==old(ci)[0];positive[ci].append(row)
 def chain(ix):
  path=[]
  while ix is not None:
   q=seq[ix];k=q['child'];cs=tuple(q['chain']);tid=tuple(q['thread']);path.append({'row':ix,'root':cs[0],'child':k,'reason':q['reason'],'thread':list(tid)})
   if k==ALL or q['reason']=='previously-red':break
   ff=by_branch.get((tid,(k,)+cs),[]);prev=bisect.bisect_left(ff,ix)-1
   if prev<0:break
   sub=ff[prev];sib=[v for v in by_branch[tid,cs] if seq[v]['child']==k];q0=bisect.bisect_left(sib,ix)-1
   if q0>=0 and sib[q0]>=sub:break
   assert sub<ix;ix=sub
  return path
 cases={}
 for root,registration in members.items():
  assert registration['native_A_node']==root;expected=registration['native_B_node'];assert old(root)[:2]==b.get(expected)[:2]and any(old(root)[1])
  ids=by_root[root];paths=[chain(ix)for ix in ids];assert ids==sorted(set(ids))
  for ps in paths:
   for hop in ps:
    wanted.add(hop['root'])
    if hop['child']!=ALL:wanted.add(hop['child'])
  direct=old(root)[2];wanted.update(direct);cases[root]={'registration':registration,'first':paths[0]if paths else None,'other_observed_root_failures':len(paths)-1 if paths else 0,'other_distinct_terminal_inputs':sorted(set(p[-1]['child']for p in paths[1:])),'direct':direct}
 wanted_keys={old(i)[0]for i in wanted};btab=defaultdict(list)
 for i in range(b.maximum):
  if b.offset(i):
   key,fp,*_=b.get(i)
   if key in wanted_keys:btab[key].append([i,fp.hex()])
 def describe(i):
  key,af,edges=old(i);rows=btab.get(key,[]);bf=rows[0][1]if len(rows)==1 else None;af=af.hex()
  if not rows:status='missing in ordinary B'
  elif len(rows)>1:status='ambiguous ordinary B'
  elif af=='0'*32 or bf=='0'*32:status='zero result fingerprint'
  elif af==bf:status='same positive result'
  else:status='changed positive result'
  return {'kind':names[key[0]],'key':key[1].hex(),'A':af,'B':bf,'B_nodes':[n for n,f in rows],'status':status,'positive_forces':[{'before':r['failures_before'],'color':r['color']}for r in positive.get(i,[])]}
 classified={i:describe(i)for i in wanted};summary={};exact={};mix=Counter();directmix=Counter();oldbank=j(T.parent/'trait-selection-21041-owner-costs/two-bank.json');assert receipt['registration']==sh(F/'registration.json')and sh(T.parent/'trait-selection-21041-owner-costs/two-bank.json')==reg['separate_original_costs']
 prices={}
 for bnk in oldbank['banks']:
  rr0=[q for q in bnk['by_owner']if q['first_roster']=='Archive<HashDigests>'];assert len(rr0)==49;prices[bnk['bank']]={(q['role'],q['index']):q for q in rr0}
 prior_sums=[0,0];total=Counter();detailed=[];direct_overlaps=defaultdict(set);leaf_overlaps=defaultdict(set)
 for i,case in sorted(cases.items()):
  q=case['registration'];p=case['first'];d0=case.pop('direct');tag=('no observed failure','unresolved','unavailable');leaf=None;first=None;reason=None
  if p:
   first=p[0]['child'];leaf=p[-1]['child'];reason=p[-1]['reason']
   for hop in p:
    hop['parent_kind']=classified[hop['root']]['kind'];hop['child_kind']=('no previous child'if hop['child']==ALL else classified[hop['child']]['kind'])
   if leaf!=ALL:
    row=classified[leaf];tag=(row['kind'],row['status'],reason);leaf_overlaps[leaf].add(i);prior=[u for u in by_child[leaf]if u<p[-1]['row']and seq[u]['reason']=='forced-red'];case['earlier_positive_force_observed_red']=prior[-1]if prior else None;case['leaf']=dict(row,A_node=leaf)
   else:tag=('no previous child','missing promoted key',reason)
  pos={'changed positive result':[],'missing in ordinary B':[],'zero result fingerprint':[],'ambiguous ordinary B':[]};cc=Counter()
  for node in d0:
   src=classified[node];cc[src['status']]+=1
   if src['status']in pos:
    pos[src['status']].append(node)
    if src['status']=='changed positive result':direct_overlaps[node].add(i)
  case['all_previous_direct_status_counts']=dict(cc);case['direct_unstable_nodes']=pos;more=sorted(set(pos['changed positive result'])-{first});case['additional_positive_changed_direct']=more
  ck=q['kind'],q['parent_local_index'];cs=[]
  for bank,pri in prices.items():
   oldrow=pri[ck];assert oldrow['owner']==q['owner'];cs.append(oldrow['Ir']);prior_sums[bank-1]+=oldrow['Ir']
  case['original_parent_nonoverlap_Ir_by_history']=cs;detailed.append(case);state=summary.setdefault(tag,{'owners':Counter(),'old_Ir':[0,0],'with_additional_changed_direct':0,'first_terminal_nodes':set()})
  state['owners'][q['kind']]+=1;state['old_Ir']=[x+y for x,y in zip(state['old_Ir'],cs)];state['with_additional_changed_direct']+=bool(more);state['first_terminal_nodes'].add(leaf);mix[(tag,q['kind'])]+=1
  directmix[(len(pos['changed positive result']),len(pos['missing in ordinary B']),len(pos['zero result fingerprint']))]+=1
 assert prior_sums==[594096860,593652530]and sum(sum(s['owners'].values())for s in summary.values())==49
 def groups(z):
  out=[]
  for node,owners in sorted(z.items(),key=lambda q:(-len(q[1]),q[0])):
   costs=[sum(pr[(members[i]['kind'],members[i]['parent_local_index'])]['Ir']for i in owners)for pr in prices.values()];out.append({'id':node,'query':classified[node],'owners':dict(Counter(members[i]['kind']for i in owners)),'distinct_provider_roles':len(owners),'other_changed_direct':sum(bool(set(cases[i]['direct_unstable_nodes']['changed positive result'])-{node})for i in owners),'old_Ir':costs})
  return out
 summaryrows=[dict(kind=k[0],result=k[1],observed_failure=k[2],owners=dict(s['owners']),old_Ir=s['old_Ir'],with_additional_changed_direct=s['with_additional_changed_direct'],first_terminal_A_indices=sorted(s['first_terminal_nodes'],key=lambda v:-1 if v is None else v)) for k,s in sorted(summary.items())]
 payload={'cohort':detailed,'native_keys_and_results':classified,'exact_groups_first':groups(leaf_overlaps),'all_previous_direct_positive_changes_overlapping':groups(direct_overlaps)};out=F/'cases.json.gz';out.write_bytes(gzip.compress(json.dumps(payload,sort_keys=True,separators=(',',':')).encode(),mtime=0))
 result={'accepted_raw':sh(F/'accepted.json'),'reader':sh(F/'reduce.py'),'payload':sh(out),'candidate_native_rows':len(seq),'genuine_previous_graph_walks':len([i for i in members if by_root[i]]),'enrolled':49,'sum_of_parent_costs_by_history':prior_sums,'distinct_first_terminal':len(leaf_overlaps),'disjoint_first_outcomes':summaryrows,'most_common_physical_first_inputs':groups(leaf_overlaps)[:12],'most_common_independently_changed_directs':groups(direct_overlaps)[:12],'all_previous_direct_changed_missing_zero_histogram':[(list(k),n)for k,n in directmix.most_common()],'counts_by_native_reason':dict(Counter(q['reason']for q in seq)),'positive_forces_crosschecked':len(rr['positive_force_colors']),'prior_cost_scope':'Nonoverlapping old b9 A→B provider intervals, priced once per original provider per history in exclusive first categories. Separate direct-dependency groups overlap. These prices neither measure candidate costs nor forecast that all work can be removed.'};write(F/'findings.json',result);print('49 owner histories',result['genuine_previous_graph_walks'],'distinct terminals',len(leaf_overlaps));print('rows',summaryrows)
if __name__=='__main__':run()
