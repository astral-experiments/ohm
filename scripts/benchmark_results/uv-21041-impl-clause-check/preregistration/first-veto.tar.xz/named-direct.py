"""Resolve the exact, positively changed direct DefId reads on both sides using actual source metadata."""
from collections import defaultdict
from pathlib import Path
import hashlib,json,runpy
F=Path(__file__).resolve().parent;J=F.parent;H=J/'provider-mechanism';m=runpy.run_path(str(H/'owners.py'));lab=m['lab'];sh=m['sh'];j=lab['j'];p=F/'all-direct.json';v=j(p);assert v['distinct_positive_changed_inputs']==len(v['most_shared_changed']);allkeys=[k for _,_,_,k in v['most_shared_changed']];salts={bytes.fromhex(k[:16])[::-1].hex()for k in allkeys};assert len(salts)==1
z={};group=lab['work']/'candidate-1';sem=[];raw={}
for state,step in [('A','cold-a'),('B','first-b')]:
 meta=j(group/'qa'/(step+'.products.json'))['metadata'];assert len(meta)==37;found={};entries=[]
 for path,prod in meta.items():
  q=group/state/path;data=q.read_bytes();assert m['sha'](data)==prod['sha256'];hd=m['lib_tables'](data);salt=hd['stable_crate_id']
  if salt not in salts:continue
  ids,rev,tab,full=m['mapped'](data,hd);entries.append([prod['name'],str(q),prod['sha256'],salt,len(ids)])
  for key in set(allkeys):
   suffix=key[16:]
   if suffix not in rev:continue
   i=rev[suffix];assert key not in found and ids[i].hex()==suffix and bytes.fromhex(salt)[::-1].hex()==key[:16];found[key]={'crate':prod['name'],'local_index':i,'path':full(i),'rmeta':prod['sha256']}
 assert len(entries)==1 and len(found)==len(set(allkeys));z[state]=found;raw[state]=entries
for i,n,kind,k in v['most_shared_changed']:
 a,b=(z[s][k]for s in ('A','B'));assert a['crate']==b['crate']and a['path']==b['path'];sem.append({'A_node':i,'n':n,'query':kind,'key':k,'crate':a['crate'],'unmoved_DefKey_path':a['path'],'A_index':a['local_index'],'B_index':b['local_index']})
out={'graph_classification':sh(p),'inputs':raw,'exact_named_changed':sem};(F/'named-direct.json').write_text(json.dumps(out,sort_keys=True,indent=1)+'\n');print('rows',len(sem),[(r['n'],r['query'],r['crate'],r['unmoved_DefKey_path'][-3:])for r in sem[:4]])
