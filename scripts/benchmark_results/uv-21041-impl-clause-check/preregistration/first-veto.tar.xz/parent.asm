
/mnt/devbox-scratch/dev-user/ohm-21041-incoherent-domain-3aa96764/run-41407590585/child/sdk/lib/librustc_driver-fa217dfcec654979.so:     file format elf64-x86-64


Disassembly of section .text:

0000000004c27d40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green>:
 4c27d40:	55                   	push   %rbp
 4c27d41:	41 57                	push   %r15
 4c27d43:	41 56                	push   %r14
 4c27d45:	41 55                	push   %r13
 4c27d47:	41 54                	push   %r12
 4c27d49:	53                   	push   %rbx
 4c27d4a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
 4c27d51:	49 89 f1             	mov    %rsi,%r9
 4c27d54:	49 89 fc             	mov    %rdi,%r12
 4c27d57:	49 8b 40 10          	mov    0x10(%r8),%rax
 4c27d5b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 4c27d60:	89 94 24 98 00 00 00 	mov    %edx,0x98(%rsp)
 4c27d67:	48 89 8c 24 90 00 00 00 	mov    %rcx,0x90(%rsp)
 4c27d6f:	48 8b 87 10 04 00 00 	mov    0x410(%rdi),%rax
 4c27d76:	48 8b 70 50          	mov    0x50(%rax),%rsi
 4c27d7a:	89 d7                	mov    %edx,%edi
 4c27d7c:	48 39 fe             	cmp    %rdi,%rsi
 4c27d7f:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
 4c27d84:	0f 86 3d 06 00 00    	jbe    4c283c7 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x687>
 4c27d8a:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
 4c27d8f:	48 c1 e7 04          	shl    $0x4,%rdi
 4c27d93:	48 8b 48 48          	mov    0x48(%rax),%rcx
 4c27d97:	4c 8b 70 68          	mov    0x68(%rax),%r14
 4c27d9b:	4c 8b 14 39          	mov    (%rcx,%rdi,1),%r10
 4c27d9f:	4c 89 d5             	mov    %r10,%rbp
 4c27da2:	48 c1 ed 02          	shr    $0x2,%rbp
 4c27da6:	4c 89 f2             	mov    %r14,%rdx
 4c27da9:	48 29 ea             	sub    %rbp,%rdx
 4c27dac:	0f 82 13 05 00 00    	jb     4c282c5 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x585>
 4c27db2:	48 01 f9             	add    %rdi,%rcx
 4c27db5:	41 83 e2 03          	and    $0x3,%r10d
 4c27db9:	49 ff c2             	inc    %r10
 4c27dbc:	8b 71 08             	mov    0x8(%rcx),%esi
 4c27dbf:	4d 89 d6             	mov    %r10,%r14
 4c27dc2:	4c 0f af f6          	imul   %rsi,%r14
 4c27dc6:	49 83 c6 03          	add    $0x3,%r14
 4c27dca:	49 39 d6             	cmp    %rdx,%r14
 4c27dcd:	0f 87 e7 04 00 00    	ja     4c282ba <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x57a>
 4c27dd3:	48 89 7c 24 78       	mov    %rdi,0x78(%rsp)
 4c27dd8:	42 8d 0c d5 00 00 00 00 	lea    0x0(,%r10,8),%ecx
 4c27de0:	f6 d9                	neg    %cl
 4c27de2:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
 4c27de9:	48 d3 ea             	shr    %cl,%rdx
 4c27dec:	48 89 94 24 88 00 00 00 	mov    %rdx,0x88(%rsp)
 4c27df4:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
 4c27df9:	85 f6                	test   %esi,%esi
 4c27dfb:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
 4c27e00:	0f 84 fd 01 00 00    	je     4c28003 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x2c3>
 4c27e06:	4c 89 94 24 80 00 00 00 	mov    %r10,0x80(%rsp)
 4c27e0e:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
 4c27e13:	48 03 68 60          	add    0x60(%rax),%rbp
 4c27e17:	48 8d 05 1a 3f a3 00 	lea    0xa33f1a(%rip),%rax        # 565bd38 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x71f8>
 4c27e1e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 4c27e23:	48 8d 05 16 3d a3 00 	lea    0xa33d16(%rip),%rax        # 565bb40 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x7000>
 4c27e2a:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 4c27e2f:	eb 40                	jmp    4c27e71 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x131>
 4c27e31:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 4c27e40:	48 8b 84 24 80 00 00 00 	mov    0x80(%rsp),%rax
 4c27e48:	49 29 c6             	sub    %rax,%r14
 4c27e4b:	48 01 c5             	add    %rax,%rbp
 4c27e4e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
 4c27e53:	49 8b 40 08          	mov    0x8(%r8),%rax
 4c27e57:	46 89 2c b8          	mov    %r13d,(%rax,%r15,4)
 4c27e5b:	49 ff c7             	inc    %r15
 4c27e5e:	4d 89 78 10          	mov    %r15,0x10(%r8)
 4c27e62:	49 83 fe 04          	cmp    $0x4,%r14
 4c27e66:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
 4c27e6b:	0f 82 87 01 00 00    	jb     4c27ff8 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x2b8>
 4c27e71:	8b 5d 00             	mov    0x0(%rbp),%ebx
 4c27e74:	23 9c 24 88 00 00 00 	and    0x88(%rsp),%ebx
 4c27e7b:	0f 88 0b 04 00 00    	js     4c2828c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x54c>
 4c27e81:	49 8b 74 24 10       	mov    0x10(%r12),%rsi
 4c27e86:	41 89 df             	mov    %ebx,%r15d
 4c27e89:	4c 39 fe             	cmp    %r15,%rsi
 4c27e8c:	0f 86 06 05 00 00    	jbe    4c28398 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x658>
 4c27e92:	49 8b 44 24 08       	mov    0x8(%r12),%rax
 4c27e97:	46 8b 2c b8          	mov    (%rax,%r15,4),%r13d
 4c27e9b:	41 83 fd fd          	cmp    $0xfffffffd,%r13d
 4c27e9f:	77 2f                	ja     4c27ed0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x190>
 4c27ea1:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c27ea8:	0f 83 ee 03 00 00    	jae    4c2829c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x55c>
 4c27eae:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c27eb3:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
 4c27eb7:	4c 3b 3f             	cmp    (%rdi),%r15
 4c27eba:	75 84                	jne    4c27e40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c27ebc:	ff 15 06 54 af 00    	call   *0xaf5406(%rip)        # 571d2c8 <_RNvMs4_NtCscHgRw1M2fX5_5alloc7raw_vecINtB5_6RawVecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8grow_oneBS_@@Base+0xa3fdd8>
 4c27ec2:	e9 79 ff ff ff       	jmp    4c27e40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c27ec7:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
 4c27ed0:	41 83 fd fe          	cmp    $0xfffffffe,%r13d
 4c27ed4:	0f 84 38 03 00 00    	je     4c28212 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c27eda:	49 8b 84 24 10 04 00 00 	mov    0x410(%r12),%rax
 4c27ee2:	48 8b 70 20          	mov    0x20(%rax),%rsi
 4c27ee6:	4c 39 fe             	cmp    %r15,%rsi
 4c27ee9:	0f 86 c8 04 00 00    	jbe    4c283b7 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x677>
 4c27eef:	4c 8b 60 18          	mov    0x18(%rax),%r12
 4c27ef3:	4b 8d 04 ff          	lea    (%r15,%r15,8),%rax
 4c27ef7:	41 0f b7 04 44       	movzwl (%r12,%rax,2),%eax
 4c27efc:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 4c27f01:	48 8b b2 a8 05 02 00 	mov    0x205a8(%rdx),%rsi
 4c27f08:	48 39 c6             	cmp    %rax,%rsi
 4c27f0b:	0f 86 97 04 00 00    	jbe    4c283a8 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x668>
 4c27f11:	48 8b 8a a0 05 02 00 	mov    0x205a0(%rdx),%rcx
 4c27f18:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
 4c27f1c:	80 7c c1 11 00       	cmpb   $0x0,0x11(%rcx,%rax,8)
 4c27f21:	75 4d                	jne    4c27f70 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x230>
 4c27f23:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 4c27f28:	48 89 d6             	mov    %rdx,%rsi
 4c27f2b:	89 da                	mov    %ebx,%edx
 4c27f2d:	48 8d 8c 24 90 00 00 00 	lea    0x90(%rsp),%rcx
 4c27f35:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
 4c27f3a:	e8 01 fe ff ff       	call   4c27d40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green>
 4c27f3f:	41 89 c5             	mov    %eax,%r13d
 4c27f42:	83 f8 ff             	cmp    $0xffffffff,%eax
 4c27f45:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 4c27f4a:	74 24                	je     4c27f70 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x230>
 4c27f4c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c27f51:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
 4c27f55:	4c 3b 3f             	cmp    (%rdi),%r15
 4c27f58:	0f 85 e2 fe ff ff    	jne    4c27e40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c27f5e:	ff 15 64 53 af 00    	call   *0xaf5364(%rip)        # 571d2c8 <_RNvMs4_NtCscHgRw1M2fX5_5alloc7raw_vecINtB5_6RawVecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8grow_oneBS_@@Base+0xa3fdd8>
 4c27f64:	e9 d7 fe ff ff       	jmp    4c27e40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c27f69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 4c27f70:	4b 8d 04 ff          	lea    (%r15,%r15,8),%rax
 4c27f74:	49 8d 04 44          	lea    (%r12,%rax,2),%rax
 4c27f78:	0f b7 48 10          	movzwl 0x10(%rax),%ecx
 4c27f7c:	66 89 4c 24 50       	mov    %cx,0x50(%rsp)
 4c27f81:	f3 0f 6f 00          	movdqu (%rax),%xmm0
 4c27f85:	66 0f 7f 44 24 40    	movdqa %xmm0,0x40(%rsp)
 4c27f8b:	48 89 d7             	mov    %rdx,%rdi
 4c27f8e:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
 4c27f93:	89 da                	mov    %ebx,%edx
 4c27f95:	48 8d 8c 24 90 00 00 00 	lea    0x90(%rsp),%rcx
 4c27f9d:	e8 ce 0b 00 00       	call   4c28b70 <_RNvMs_NtCs1phqxivSrqn_12rustc_middle9dep_graphNtNtNtB6_2ty7context6TyCtxt23try_force_from_dep_node>
 4c27fa2:	84 c0                	test   %al,%al
 4c27fa4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 4c27fa9:	0f 84 63 02 00 00    	je     4c28212 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c27faf:	48 8b 70 10          	mov    0x10(%rax),%rsi
 4c27fb3:	4c 39 fe             	cmp    %r15,%rsi
 4c27fb6:	0f 86 dc 03 00 00    	jbe    4c28398 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x658>
 4c27fbc:	48 8b 40 08          	mov    0x8(%rax),%rax
 4c27fc0:	46 8b 2c b8          	mov    (%rax,%r15,4),%r13d
 4c27fc4:	41 83 fd fd          	cmp    $0xfffffffd,%r13d
 4c27fc8:	0f 87 6c 02 00 00    	ja     4c2823a <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4fa>
 4c27fce:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c27fd5:	0f 83 c1 02 00 00    	jae    4c2829c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x55c>
 4c27fdb:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c27fe0:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
 4c27fe4:	4c 3b 3f             	cmp    (%rdi),%r15
 4c27fe7:	0f 85 53 fe ff ff    	jne    4c27e40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c27fed:	ff 15 d5 52 af 00    	call   *0xaf52d5(%rip)        # 571d2c8 <_RNvMs4_NtCscHgRw1M2fX5_5alloc7raw_vecINtB5_6RawVecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8grow_oneBS_@@Base+0xa3fdd8>
 4c27ff3:	e9 48 fe ff ff       	jmp    4c27e40 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c27ff8:	4c 39 7c 24 10       	cmp    %r15,0x10(%rsp)
 4c27ffd:	0f 87 fb 02 00 00    	ja     4c282fe <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5be>
 4c28003:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 4c28008:	48 8d 2c 85 00 00 00 00 	lea    0x0(,%rax,4),%rbp
 4c28010:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
 4c28015:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
 4c2801a:	49 03 68 08          	add    0x8(%r8),%rbp
 4c2801e:	48 8d 05 31 7a 1b fc 	lea    -0x3e485cf(%rip),%rax        # ddfa56 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x647a6>
 4c28025:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 4c2802a:	48 c7 44 24 48 1a 00 00 00 	movq   $0x1a,0x48(%rsp)
 4c28033:	41 f6 84 24 b0 00 00 00 01 	testb  $0x1,0xb0(%r12)
 4c2803c:	0f 85 d9 02 00 00    	jne    4c2831b <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5db>
 4c28042:	48 c7 84 24 a0 00 00 00 00 00 00 00 	movq   $0x0,0xa0(%rsp)
 4c2804e:	4c 89 e0             	mov    %r12,%rax
 4c28051:	4d 8b a4 24 18 01 00 00 	mov    0x118(%r12),%r12
 4c28059:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
 4c28060:	48 83 c1 10          	add    $0x10,%rcx
 4c28064:	48 8b 05 25 d2 ae 00 	mov    0xaed225(%rip),%rax        # 5715290 <_RNvNCNKNvNtNtCsaeE03MKAZ19_21rustc_data_structures4sync12worker_local11THREAD_DATA0s_023___RUST_STD_INTERNAL_VAL@@Base+0x5711ea8>
 4c2806b:	64 48 39 08          	cmp    %rcx,%fs:(%rax)
 4c2806f:	0f 85 c6 02 00 00    	jne    4c2833b <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5fb>
 4c28075:	64 48 8b 40 08       	mov    %fs:0x8(%rax),%rax
 4c2807a:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c2807f:	48 c1 e0 07          	shl    $0x7,%rax
 4c28083:	49 83 3c 04 00       	cmpq   $0x0,(%r12,%rax,1)
 4c28088:	0f 85 bd 02 00 00    	jne    4c2834b <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x60b>
 4c2808e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 4c28093:	48 8d b9 10 01 00 00 	lea    0x110(%rcx),%rdi
 4c2809a:	49 01 c4             	add    %rax,%r12
 4c2809d:	49 c7 04 24 ff ff ff ff 	movq   $0xffffffffffffffff,(%r12)
 4c280a5:	41 83 7c 24 7c 00    	cmpl   $0x0,0x7c(%r12)
 4c280ab:	74 13                	je     4c280c0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x380>
 4c280ad:	45 8b 6c 24 78       	mov    0x78(%r12),%r13d
 4c280b2:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c280b9:	72 66                	jb     4c28121 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x3e1>
 4c280bb:	e9 20 02 00 00       	jmp    4c282e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5a0>
 4c280c0:	b9 00 01 00 00       	mov    $0x100,%ecx
 4c280c5:	f0 48 0f c1 0f       	lock xadd %rcx,(%rdi)
 4c280ca:	48 89 c8             	mov    %rcx,%rax
 4c280cd:	48 c1 e8 20          	shr    $0x20,%rax
 4c280d1:	48 c1 e1 20          	shl    $0x20,%rcx
 4c280d5:	48 81 c9 00 02 00 00 	or     $0x200,%rcx
 4c280dc:	48 85 c0             	test   %rax,%rax
 4c280df:	b8 01 02 00 00       	mov    $0x201,%eax
 4c280e4:	48 0f 44 c1          	cmove  %rcx,%rax
 4c280e8:	3c 01                	cmp    $0x1,%al
 4c280ea:	0f 84 6d 02 00 00    	je     4c2835d <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x61d>
 4c280f0:	49 89 c5             	mov    %rax,%r13
 4c280f3:	49 c1 ed 20          	shr    $0x20,%r13
 4c280f7:	45 89 6c 24 78       	mov    %r13d,0x78(%r12)
 4c280fc:	48 c1 e8 28          	shr    $0x28,%rax
 4c28100:	3d fe ff ff 00       	cmp    $0xfffffe,%eax
 4c28105:	0f 87 7e 02 00 00    	ja     4c28389 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x649>
 4c2810b:	41 c7 44 24 7c 00 01 00 00 	movl   $0x100,0x7c(%r12)
 4c28114:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c2811b:	0f 83 bf 01 00 00    	jae    4c282e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5a0>
 4c28121:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
 4c28126:	49 39 ce             	cmp    %rcx,%r14
 4c28129:	0f 86 a6 02 00 00    	jbe    4c283d5 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x695>
 4c2812f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 4c28134:	f0 44 0f b1 2c 8b    	lock cmpxchg %r13d,(%rbx,%rcx,4)
 4c2813a:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
 4c2813f:	0f 85 a5 00 00 00    	jne    4c281ea <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4aa>
 4c28145:	f3 41 0f 7e 44 24 78 	movq   0x78(%r12),%xmm0
 4c2814c:	66 0f fe 05 cc 05 e8 fb 	paddd  -0x417fa34(%rip),%xmm0        # aa8720 <anon.829ff91bdf125c2598215c11ab6a766c.0.llvm.11915286338818084809+0x1afee>
 4c28154:	66 41 0f d6 44 24 78 	movq   %xmm0,0x78(%r12)
 4c2815b:	49 ff 44 24 68       	incq   0x68(%r12)
 4c28160:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 4c28165:	48 8b 80 30 01 00 00 	mov    0x130(%rax),%rax
 4c2816c:	4c 8b 70 20          	mov    0x20(%rax),%r14
 4c28170:	49 39 ce             	cmp    %rcx,%r14
 4c28173:	0f 86 65 02 00 00    	jbe    4c283de <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x69e>
 4c28179:	4c 8b 70 38          	mov    0x38(%rax),%r14
 4c2817d:	49 39 ce             	cmp    %rcx,%r14
 4c28180:	0f 86 61 02 00 00    	jbe    4c283e7 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6a7>
 4c28186:	4c 2b 7c 24 10       	sub    0x10(%rsp),%r15
 4c2818b:	4d 8d 44 24 08       	lea    0x8(%r12),%r8
 4c28190:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
 4c28195:	49 81 c1 b8 00 00 00 	add    $0xb8,%r9
 4c2819c:	48 8d 0c c9          	lea    (%rcx,%rcx,8),%rcx
 4c281a0:	48 8b 50 18          	mov    0x18(%rax),%rdx
 4c281a4:	48 8b 40 30          	mov    0x30(%rax),%rax
 4c281a8:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
 4c281ad:	f3 0f 6f 04 30       	movdqu (%rax,%rsi,1),%xmm0
 4c281b2:	0f b7 44 4a 10       	movzwl 0x10(%rdx,%rcx,2),%eax
 4c281b7:	66 89 44 24 70       	mov    %ax,0x70(%rsp)
 4c281bc:	0f 10 0c 4a          	movups (%rdx,%rcx,2),%xmm1
 4c281c0:	0f 11 4c 24 60       	movups %xmm1,0x60(%rsp)
 4c281c5:	f3 0f 7f 44 24 50    	movdqu %xmm0,0x50(%rsp)
 4c281cb:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
 4c281d0:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
 4c281d5:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
 4c281da:	44 89 ee             	mov    %r13d,%esi
 4c281dd:	4c 89 c9             	mov    %r9,%rcx
 4c281e0:	e8 3b f3 f3 ff       	call   4b67520 <_RNvMs6_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph10serializedNtB5_12EncoderState11encode_node>
 4c281e5:	44 89 eb             	mov    %r13d,%ebx
 4c281e8:	eb 12                	jmp    4c281fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4bc>
 4c281ea:	83 f8 fe             	cmp    $0xfffffffe,%eax
 4c281ed:	74 0d                	je     4c281fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4bc>
 4c281ef:	89 c3                	mov    %eax,%ebx
 4c281f1:	3d 01 ff ff ff       	cmp    $0xffffff01,%eax
 4c281f6:	0f 83 e4 00 00 00    	jae    4c282e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5a0>
 4c281fc:	49 ff 04 24          	incq   (%r12)
 4c28200:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
 4c28208:	e8 43 2c ff ff       	call   4c1ae50 <_RINvNtCsc36rpYXAlPq_4core3ptr9drop_glueNtNtCsaeE03MKAZ19_21rustc_data_structures9profiling11TimingGuardECs1phqxivSrqn_12rustc_middle>
 4c2820d:	83 fb ff             	cmp    $0xffffffff,%ebx
 4c28210:	75 05                	jne    4c28217 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d7>
 4c28212:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
 4c28217:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c2821c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 4c28221:	e8 ea 51 0e 00       	call   4d0d410 <_RNvMs_NtCscHgRw1M2fX5_5alloc3vecINtB4_3VecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8truncateBK_>
 4c28226:	89 d8                	mov    %ebx,%eax
 4c28228:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
 4c2822f:	5b                   	pop    %rbx
 4c28230:	41 5c                	pop    %r12
 4c28232:	41 5d                	pop    %r13
 4c28234:	41 5e                	pop    %r14
 4c28236:	41 5f                	pop    %r15
 4c28238:	5d                   	pop    %rbp
 4c28239:	c3                   	ret
 4c2823a:	41 83 fd fe          	cmp    $0xfffffffe,%r13d
 4c2823e:	74 d2                	je     4c28212 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c28240:	b8 90 17 00 00       	mov    $0x1790,%eax
 4c28245:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 4c2824a:	48 03 81 f0 04 02 00 	add    0x204f0(%rcx),%rax
 4c28251:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 4c28256:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
 4c2825f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
 4c28264:	ff 15 f6 f6 ae 00    	call   *0xaef6f6(%rip)        # 5717960 <_RNvMs5_CsdDeWnbHHqre_12rustc_errorsNtB5_14DiagCtxtHandle26has_errors_or_delayed_bugs@@Base+0x68ad20>
 4c2826a:	84 c0                	test   %al,%al
 4c2826c:	75 a4                	jne    4c28212 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c2826e:	48 8d 3d fb 77 1b fc 	lea    -0x3e48805(%rip),%rdi        # ddfa70 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x647c0>
 4c28275:	48 8d 15 9c 39 a3 00 	lea    0xa3399c(%rip),%rdx        # 565bc18 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x70d8>
 4c2827c:	be 73 00 00 00       	mov    $0x73,%esi
 4c28281:	ff 15 31 b6 ae 00    	call   *0xaeb631(%rip)        # 57138b8 <_RNvNtCsc36rpYXAlPq_4core9panicking9panic_fmt@@Base+0x30d508>
 4c28287:	e9 70 01 00 00       	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c2828c:	48 8d 3d 06 73 1b fc 	lea    -0x3e48cfa(%rip),%rdi        # ddf599 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x642e9>
 4c28293:	48 8d 15 86 2e a3 00 	lea    0xa32e86(%rip),%rdx        # 565b120 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x65e0>
 4c2829a:	eb 0e                	jmp    4c282aa <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x56a>
 4c2829c:	48 8d 3d 73 77 1b fc 	lea    -0x3e4888d(%rip),%rdi        # ddfa16 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x64766>
 4c282a3:	48 8d 15 7e 38 a3 00 	lea    0xa3387e(%rip),%rdx        # 565bb28 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fe8>
 4c282aa:	be 26 00 00 00       	mov    $0x26,%esi
 4c282af:	ff 15 fb b5 ae 00    	call   *0xaeb5fb(%rip)        # 57138b0 <_RNvNtCsc36rpYXAlPq_4core9panicking5panic@@Base+0x30d520>
 4c282b5:	e9 42 01 00 00       	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c282ba:	48 8d 0d b7 36 a3 00 	lea    0xa336b7(%rip),%rcx        # 565b978 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6e38>
 4c282c1:	31 ed                	xor    %ebp,%ebp
 4c282c3:	eb 0a                	jmp    4c282cf <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x58f>
 4c282c5:	48 8d 0d c4 36 a3 00 	lea    0xa336c4(%rip),%rcx        # 565b990 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6e50>
 4c282cc:	4c 89 f2             	mov    %r14,%rdx
 4c282cf:	48 89 ef             	mov    %rbp,%rdi
 4c282d2:	4c 89 f6             	mov    %r14,%rsi
 4c282d5:	ff 15 0d b6 ae 00    	call   *0xaeb60d(%rip)        # 57138e8 <_RNvNtNtCsc36rpYXAlPq_4core5slice5index16slice_index_fail@@Base+0x30c118>
 4c282db:	e9 1c 01 00 00       	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c282e0:	48 8d 3d 2f 77 1b fc 	lea    -0x3e488d1(%rip),%rdi        # ddfa16 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x64766>
 4c282e7:	48 8d 15 3a 38 a3 00 	lea    0xa3383a(%rip),%rdx        # 565bb28 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fe8>
 4c282ee:	be 26 00 00 00       	mov    $0x26,%esi
 4c282f3:	ff 15 b7 b5 ae 00    	call   *0xaeb5b7(%rip)        # 57138b0 <_RNvNtCsc36rpYXAlPq_4core9panicking5panic@@Base+0x30d520>
 4c282f9:	e9 fe 00 00 00       	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c282fe:	48 8d 0d fb 38 a3 00 	lea    0xa338fb(%rip),%rcx        # 565bc00 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x70c0>
 4c28305:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
 4c2830a:	4c 89 fe             	mov    %r15,%rsi
 4c2830d:	4c 89 fa             	mov    %r15,%rdx
 4c28310:	ff 15 d2 b5 ae 00    	call   *0xaeb5d2(%rip)        # 57138e8 <_RNvNtNtCsc36rpYXAlPq_4core5slice5index16slice_index_fail@@Base+0x30c118>
 4c28316:	e9 e1 00 00 00       	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c2831b:	49 8d b4 24 a8 00 00 00 	lea    0xa8(%r12),%rsi
 4c28323:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
 4c2832b:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
 4c28330:	ff 15 42 d0 ae 00    	call   *0xaed042(%rip)        # 5715378 <_RINvNvMNtCsaeE03MKAZ19_21rustc_data_structures9profilingNtB5_15SelfProfilerRef4exec9cold_callNCNvB4_16generic_activity0EB7_@@Base+0x3ef4e8>
 4c28336:	e9 13 fd ff ff       	jmp    4c2804e <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x30e>
 4c2833b:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c28340:	ff 15 7a 4a af 00    	call   *0xaf4a7a(%rip)        # 571cdc0 <_RINvCsaeE03MKAZ19_21rustc_data_structures7outlineNCNCNvMNtNtB2_4sync12worker_localNtBS_10RegistryId6verify00jECs1phqxivSrqn_12rustc_middle@@Base+0xbd9bb0>
 4c28346:	e9 34 fd ff ff       	jmp    4c2807f <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x33f>
 4c2834b:	48 8d 3d 96 38 a3 00 	lea    0xa33896(%rip),%rdi        # 565bbe8 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x70a8>
 4c28352:	ff 15 f0 b4 ae 00    	call   *0xaeb4f0(%rip)        # 5713848 <_RNvNtCsc36rpYXAlPq_4core4cell22panic_already_borrowed@@Base+0x30da38>
 4c28358:	e9 9f 00 00 00       	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c2835d:	c6 44 24 40 02       	movb   $0x2,0x40(%rsp)
 4c28362:	48 8d 3d 0b 73 1b fc 	lea    -0x3e48cf5(%rip),%rdi        # ddf674 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x643c4>
 4c28369:	48 8d 0d 00 2f a3 00 	lea    0xa32f00(%rip),%rcx        # 565b270 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6730>
 4c28370:	4c 8d 05 81 37 a3 00 	lea    0xa33781(%rip),%r8        # 565baf8 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fb8>
 4c28377:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
 4c2837c:	be 2b 00 00 00       	mov    $0x2b,%esi
 4c28381:	ff 15 e9 b4 ae 00    	call   *0xaeb4e9(%rip)        # 5713870 <_RNvNtCsc36rpYXAlPq_4core6result13unwrap_failed@@Base+0x30d7e0>
 4c28387:	eb 73                	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c28389:	48 8d 3d 80 37 a3 00 	lea    0xa33780(%rip),%rdi        # 565bb10 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fd0>
 4c28390:	ff 15 d2 b4 ae 00    	call   *0xaeb4d2(%rip)        # 5713868 <_RNvNtCsc36rpYXAlPq_4core6option13unwrap_failed@@Base+0x30d7f8>
 4c28396:	eb 64                	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c28398:	4c 89 ff             	mov    %r15,%rdi
 4c2839b:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 4c283a0:	ff 15 e2 b4 ae 00    	call   *0xaeb4e2(%rip)        # 5713888 <_RNvNtCsc36rpYXAlPq_4core9panicking18panic_bounds_check@@Base+0x30d726>
 4c283a6:	eb 54                	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c283a8:	49 89 c7             	mov    %rax,%r15
 4c283ab:	48 8d 05 5e 36 a3 00 	lea    0xa3365e(%rip),%rax        # 565ba10 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6ed0>
 4c283b2:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 4c283b7:	4c 89 ff             	mov    %r15,%rdi
 4c283ba:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 4c283bf:	ff 15 c3 b4 ae 00    	call   *0xaeb4c3(%rip)        # 5713888 <_RNvNtCsc36rpYXAlPq_4core9panicking18panic_bounds_check@@Base+0x30d726>
 4c283c5:	eb 35                	jmp    4c283fc <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c283c7:	48 8d 05 92 35 a3 00 	lea    0xa33592(%rip),%rax        # 565b960 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6e20>
 4c283ce:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 4c283d3:	eb c6                	jmp    4c2839b <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x65b>
 4c283d5:	48 8d 15 44 39 a3 00 	lea    0xa33944(%rip),%rdx        # 565bd20 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x71e0>
 4c283dc:	eb 10                	jmp    4c283ee <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6ae>
 4c283de:	48 8d 15 5b 37 a3 00 	lea    0xa3375b(%rip),%rdx        # 565bb40 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x7000>
 4c283e5:	eb 07                	jmp    4c283ee <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6ae>
 4c283e7:	48 8d 15 f2 27 a3 00 	lea    0xa327f2(%rip),%rdx        # 565abe0 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x60a0>
 4c283ee:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 4c283f3:	4c 89 f6             	mov    %r14,%rsi
 4c283f6:	ff 15 8c b4 ae 00    	call   *0xaeb48c(%rip)        # 5713888 <_RNvNtCsc36rpYXAlPq_4core9panicking18panic_bounds_check@@Base+0x30d726>
 4c283fc:	0f 0b                	ud2
 4c283fe:	eb 26                	jmp    4c28426 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6e6>
 4c28400:	48 89 c3             	mov    %rax,%rbx
 4c28403:	eb 0c                	jmp    4c28411 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6d1>
 4c28405:	48 89 c3             	mov    %rax,%rbx
 4c28408:	49 ff 04 24          	incq   (%r12)
 4c2840c:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c28411:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
 4c28419:	e8 32 2a ff ff       	call   4c1ae50 <_RINvNtCsc36rpYXAlPq_4core3ptr9drop_glueNtNtCsaeE03MKAZ19_21rustc_data_structures9profiling11TimingGuardECs1phqxivSrqn_12rustc_middle>
 4c2841e:	eb 0e                	jmp    4c2842e <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6ee>
 4c28420:	ff 15 5a b4 ae 00    	call   *0xaeb45a(%rip)        # 5713880 <_RNvNtCsc36rpYXAlPq_4core9panicking16panic_in_cleanup@@Base+0x30d732>
 4c28426:	48 89 c3             	mov    %rax,%rbx
 4c28429:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c2842e:	4c 89 ef             	mov    %r13,%rdi
 4c28431:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 4c28436:	e8 d5 4f 0e 00       	call   4d0d410 <_RNvMs_NtCscHgRw1M2fX5_5alloc3vecINtB4_3VecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8truncateBK_>
 4c2843b:	48 89 df             	mov    %rbx,%rdi
 4c2843e:	e8 2d 3c 7f 00       	call   541c070 <_Unwind_Resume@plt>
 4c28443:	ff 15 37 b4 ae 00    	call   *0xaeb437(%rip)        # 5713880 <_RNvNtCsc36rpYXAlPq_4core9panicking16panic_in_cleanup@@Base+0x30d732>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
