"""One off-clock candidate A→B terminal rustc green-veto observer, bound to exactly 49 earlier Archive survivors."""
from pathlib import Path
from collections import Counter
import fcntl,gzip,hashlib,json,os,runpy,shlex,subprocess,sys
F=Path(__file__).resolve().parent;J=F.parent;H=J/'provider-mechanism';T=J.parent/'trait-selection-21041';D=J.parents[1];lab=runpy.run_path(str(J/'lab.py'));j=lab['j'];sha=lab['sha'];alg=lab['alg'];grmod=runpy.run_path(str(H/'graph.py'));gm=grmod['g'];ad=runpy.run_path(str(J/'sdk-admission/intake.py'))
def write(p,v):
 with p.open('x')as f:json.dump(v,f,indent=1,sort_keys=True);f.write('\n')
def load():
 old=j(H/'candidate-1-01.json');proof=j(H/'join-01/native-graph-summary.json');assert sha(H/'SHA256SUMS')=='51e12d5cf745d5436f1a70f8b7f765bf9e40500b7245bff47f37787fafd01d6b' and sha(F/'elf.json')=='6ee52455c480bb57e969fb0228462d379004674690433725f32f0f5b941c5381'
 subprocess.run(['sha256sum','--strict','--check','--status','SHA256SUMS'],cwd=H,check=True)
 pri=Path(old['raw_receipt']);native=j(pri);ctx=j(pri.parent/'setup.json');assert native['source']==old['source']and native['all_outputs_and_diagnostics_match']and native['never_added_rustc_flags']and sha(pri)==old['raw_receipt_sha']and sha(pri.parent/'setup.json')==old['original_37_A_B']
 group=lab['work']/'candidate-1';sdk,rev,sdkrec=lab['sdk_for']('candidate');assert sdkrec==ctx['sdk_receipt']and rev==old['source'];rows=json.loads(gzip.decompress((H/'join-01/owners.json.gz').read_bytes()))['rows'];keys=json.loads(gzip.decompress((H/'join-01/native-graph-keys.json.gz').read_bytes()))
 spec={};pro=proof['inputs']['candidate'];assert pro['sdk']==rev and old['B_graph']==pro['actual_graphs']['B'];bdata=bytes.fromhex(pro['header']);src=subprocess.check_output(['git','-C',T/'source01/checkout','show',rev+':compiler/rustc_middle/src/queries.rs']);names=runpy.run_path(str(D/'released-source/schema.py'))['roster'](src.decode());assert hashlib.sha256(src).hexdigest()==pro['same_query_roster_and_wire_sources']['compiler/rustc_middle/src/queries.rs']
 gm.edge.KINDS=names;gm.edge.NUMBER={v:i for i,v in enumerate(names)};gm.Graph.__init__.__globals__.update(KINDS=names,HEADER=bdata);graphs={}
 for state in ('A','B'):
  p,=(group/state/'debug/incremental').glob('uv_client-*/s-*/dep-graph.bin');assert sha(p)==pro['actual_graphs'][state]and ctx[state.lower()+'_history']==str(group/state);graphs[state]=gm.Graph(p.read_bytes())
 for row in rows:
  if row['observed_first_roster']!='Archive<HashDigests>':continue
  assert row['candidate_paid']and row['status']=='joined';g,=[x for x in keys if x['arm']=='candidate'and x['kind']==row['kind']and x['native_local_index']==row['candidate_index']and x['absolute_native_key']==row['candidate_stable_key']];assert g['actual_provider_call']and g['owner']==row['owner']
  for state in ('A','B'):
   ix,fp=g[state+'_node_and_fingerprint'];(ki,val),f,*_=graphs[state].get(ix);assert names[ki]==row['kind']and val.hex()==g['absolute_native_key']and f.hex()==fp and any(f)
  n=g['A_node_and_fingerprint'][0];assert n not in spec;spec[n]={'owner':g['owner'],'kind':g['kind'],'native_A_node':n,'native_B_node':g['B_node_and_fingerprint'][0],'previous_positive_value':g['A_node_and_fingerprint'][1],'candidate_local_index':row['candidate_index'],'parent_local_index':row['local_index'],'physical_key':g['absolute_native_key'],'unique_source_identity':row['descriptor_sha256']}
 assert Counter(x['kind']for x in spec.values())=={'typeck_root':28,'mir_borrowck':21}
 return graphs,names,spec,old,ctx,group,sdk,rev
def deps(graph,i):
 _,_,start,end,w=graph.get(i);return tuple(int.from_bytes(graph.data[k:k+w],'little')for k in range(start,end,w))
def prepare():
 graphs,names,spec,old,ctx,group,sdk,rev=load();elf=j(F/'elf.json');og=j(T/'candidate-mark-01/accepted.json');stop=(T/'candidate-stop.py').read_text();assert sha(T/'candidate-stop.py')==og['gdb'];d=elf['roles']['candidate'];assert 'gdb.execute(\'catch load librustc_driver-fa217dfcec654979.so\')'in stop and Path(d['driver']).name=='librustc_driver-fa217dfcec654979.so'
 for k,before in elf['roles']['parent']['sites'].items():assert stop.count(hex(before))==1;stop=stop.replace(hex(before),hex(d['sites'][k]))
 at="base=zero[0];assert hashlib.sha256(driver.read_bytes()).hexdigest()==spec['driver_sha256']"
 assert stop.count(at)==1;stop=stop.replace(at,at+"\nst=driver.stat();assert maps and all(int(r[4])==st.st_ino and int(r[3].split(':')[0],16)==os.major(st.st_dev) and int(r[3].split(':')[1],16)==os.minor(st.st_dev) for r in maps)");(F/'stop.py').write_text(stop)
 a=graphs['A'];watch=set(spec);watch.update(x for i in spec for x in deps(a,i));codes={i for i,k in enumerate(names)if k in ('blanket_trait_impls','non_blanket_trait_impls','trait_impls_of','implementations_of_trait','external_metadata_input_hash')}
 for i in range(a.maximum):
  if a.offset(i)and a.get(i)[0][0]in codes:watch.add(i)
 assert len(watch)>10000
 plan={'method':'Single native diagnostic, no timing. Observe all failed green checks; register these precise 49 native A keys before launch. First failure is chronological per previous root. Missing, changed-positive, returned-equal and unavailable are reported separately. Price each of the 49 old entries at most once per mutually exclusive first cause.','role':rev,'hold':1,'mechanism_seal':sha(H/'SHA256SUMS'),'graph_seal':sha(H/'join-01/native-graph-summary.json'),'physical_provider_receipt':old['raw_receipt_sha'],'group_QA':ctx['qualification'],'group_8_original_commands':ctx['original_ordinary_cargo_argv'],'members':spec,'watch':sorted(watch),'source':sha(Path(__file__)),'stop':sha(F/'stop.py'),'previous_stop':og['gdb'],'elf':sha(F/'elf.json'),'maximum':a.maximum,'separate_original_costs':sha(T.parent/'trait-selection-21041-owner-costs/two-bank.json')};write(F/'registration.json',plan);print('plan',sha(F/'registration.json'),len(watch),len(spec))
def capture():
 assert os.sched_getaffinity(0)<={12,13};graphs,names,spec,old,ctx,group,sdk,rev=load();plan=j(F/'registration.json');assert sha(F/'first.py')==plan['source']and sha(F/'stop.py')==plan['stop']and sha(F/'elf.json')==plan['elf']and {int(k):v for k,v in plan['members'].items()}==spec
 s,t,cargo,slot=(alg[n]for n in ('SRC','T','HOME','SLOT'));a,b=group/'A',group/'B';sv=group/'visits/native';seq=sv/'argv.json';assert sha(seq)==plan['group_8_original_commands'];args=j(seq);ar,=[x for x in args if x[x.index('--crate-name')+1]=='uv_client'and x[x.index('--crate-type')+1]=='lib'];assert len(args)==8 and len(ar)==983 and ar[0]==str(slot/'bin/rustc')
 orig_arg,=[shlex.split(line.strip().removeprefix('Running `').removesuffix('`'))for line in(sv/'first-b.stderr').read_text().splitlines()if line.lstrip().startswith('Running `')and' --crate-name uv_client 'in line];cut=orig_arg.index(ar[0]);assert orig_arg[cut:]==ar;env=dict(z.split('=',1)for z in orig_arg[:cut]);assert all(k.startswith('CARGO')for k in env)
 for st,prod,ref in ((a,'cold-a','all_37_cold_a_metadata'),(b,'first-b','all_37_cold_and_warm_b_metadata')):
  p=group/'qa'/(prod+'.products.json');md=j(p)['metadata'];assert len(md)==37 and sha(p)==ctx[ref]and all((st/k).stat().st_size==v['bytes']and sha(st/k)==v['sha256']for k,v in md.items())
 qual=group/'qa/qualification.json';assert sha(qual)==plan['group_QA']and j(qual)['admitted']and not j(qual)['problems']
 nowext={x.partition('=')[0]:sha(b/Path(x.partition('=')[2]).relative_to(t))for i,item in enumerate(ar)if item=='--extern'and '='in(x:=ar[i+1])};assert len(nowext)==58 and nowext==ctx['term_externs']
 dest=Path(ar[ar.index('--out-dir')+1]);inc=Path(next(x.partition('=')[2]for x in ar if x.startswith('incremental=')));unit,=(a/inc.relative_to(t)).glob('uv_client-*');assert {p.relative_to(unit).as_posix():sha(p)for p in unit.rglob('*')if p.is_file()}==ctx['prior_seed'];assert {p.name:sha(p)for p in (b/dest.relative_to(t)).iterdir()if p.is_file()}==ctx['expected_outputs']
 Dbg=J.parent/'post-callable-21041-costs/metadata-diagnostic/debugger/root';ie=j(F/'elf.json')['roles']['candidate'];driver=Path(ie['driver']);assert sha(driver)==ie['driver_sha256']and driver.parent==sdk/'lib'
 env.update(PATH=str(slot/'bin')+':/usr/bin:/bin',HOME='/tmp',CARGO_HOME=str(cargo),CARGO_TARGET_DIR=str(t),RUSTC=str(slot/'bin/rustc'),RUSTDOC=str(slot/'bin/rustdoc'),LC_ALL='C.UTF-8',SSL_CERT_FILE='/usr/lib/ssl/cert.pem',SSL_CERT_DIR='/usr/lib/ssl/certs',LD_LIBRARY_PATH=str(Dbg/'usr/lib/x86_64-linux-gnu'),DEBUGINFOD_URLS='')
 raw=Path(old['raw_receipt']).parent.parent/'archive-veto-candidate-01';ad['guard'](150<<20);raw.mkdir();out=raw/'out';incdir=raw/'inc';ev=raw/'evidence'
 for p in (out,incdir,ev):p.mkdir()
 spec0={'driver':str(slot/'lib'/driver.name),'driver_sha256':ie['driver_sha256'],'target_indices':sorted(spec),'watch_for_green':plan['watch'],'maximum':plan['maximum'],'argv':ar,'registration':sha(F/'registration.json'),'source':rev};write(ev/'request.json',spec0)
 subprocess.run(['cp','-a','--reflink=auto','--',unit,incdir/unit.name],check=True);assert all(sha(incdir/unit.name/f)==v and not (incdir/unit.name/f).samefile(unit/f)for f,v in ctx['prior_seed'].items())
 print('waiting for canonical source lease',flush=True)
 with (D/'ohm-session-parser/source-lease.lock').open()as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);assert subprocess.check_output(['git','-C',s,'hash-object',lab['plan']['uv']['file']],text=True).strip()==ctx['source_blob'];ex=t.exists()
  if not ex:t.mkdir()
  try:
   cmd=['/usr/bin/bwrap','--die-with-parent','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--ro-bind',b,t,'--ro-bind',sdk,slot,'--bind',incdir,inc,'--bind',out,dest,'--bind',ev,'/tmp/evidence','--chdir',s,'--',Dbg/'usr/bin/gdb','--nx','--nh','-batch','-q','-iex','set auto-load off','-ex','source '+str(F/'stop.py'),'--args',*ar]
   with (raw/'gdb.stdout').open('xb')as so,(raw/'gdb.stderr').open('xb')as se:ret=subprocess.run([str(q)for q in cmd],env=env,stdout=so,stderr=se,timeout=360);assert ret.returncode==0 and (ev/'native-marks.json').is_file(),(ret.returncode,(raw/'gdb.stderr').read_text()[-950:])
  finally:
   if not ex:t.rmdir()
 dep,=incdir.glob('uv_client-*/s-*/dep-graph.bin');marks=j(ev/'native-marks.json');assert marks['compiler_exit']==0 and marks['driver_sha256']==ie['driver_sha256']and marks['argv_sha256']==hashlib.sha256(json.dumps(ar,separators=(',',':')).encode()).hexdigest();assert sha(dep)==old['B_graph'];assert {x.name:sha(x)for x in out.iterdir()if x.is_file()}==ctx['expected_outputs'];assert all(sha(unit/f)==ds for f,ds in ctx['prior_seed'].items())
 # Identical actual compiler diagnostics with the prior independent ordinary B replay.
 plain=Path(old['raw_receipt']).parent/'plain/evidence/stderr';assert plain.exists();lines=[v for v in (raw/'gdb.stderr').read_text().splitlines()if v.startswith('{')];want=[v for v in plain.read_text().splitlines()if v.startswith('{')];assert lines==want
 receipt={'registration':sha(F/'registration.json'),'raw':str(ev/'native-marks.json'),'raw_sha256':sha(ev/'native-marks.json'),'request_sha256':sha(ev/'request.json'),'ordinary_native_comparison':old['raw_receipt_sha'],'B_graph':sha(dep),'same_seed_outputs':ctx['expected_outputs'],'diagnostic_json_lines':len(want),'all_37_A_and_B':True,'externs':len(nowext),'argc':len(ar),'source_compiler':rev,'raw_counts':marks['counts'],'observed_indices':marks['observed_root_indices'],'positive':len(marks['positive_force_colors']),'all_49_registered':len(spec),'node_count':graphs['A'].maximum};write(raw/'accepted.json',receipt);write(F/'accepted.json',receipt);print('accepted',sha(F/'accepted.json'),receipt['raw_counts'],len(receipt['observed_indices']))
if __name__=='__main__':{'prepare':prepare,'capture':capture}[sys.argv[1]]()
