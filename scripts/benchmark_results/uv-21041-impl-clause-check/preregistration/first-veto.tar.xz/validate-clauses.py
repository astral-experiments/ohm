"""Independent guarding of nominal IDs, deep ADT bodies, native span/hygiene, and real positive/negative cases."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,runpy,subprocess
F=Path(__file__).resolve().parent;m=runpy.run_path(str(F/'clauses.py'));sci=runpy.run_path(str(F/'first.py'));T=m['T'];S=m['S'];Term=m['Term'];j=m['read'];sha=m['sh'];native=j(F/'accepted.json');data=j(F/'clauses.json');ordered=j(T/'physical-six/candidate-1-physical-rows.json');ro=j(T/'physical-six/candidate-1-query-outcomes.json');rows=json.loads(gzip.decompress((F/'cases.json.gz').read_bytes()))['cohort']
assert sha(F/'clauses.py')==data['decoder']and ro['native_receipt']==sha(T/'physical-six/candidate-1-physical-rows.json')and ordered['source_commit']==m['commit']==native['source_compiler'];allgraph={}
def file_in(t,name,idx):
 row=S.di.rows(t.data,t.h['tables'][name]);assert idx<len(row);p=int.from_bytes(row[idx],'little');assert p>0;return p
def hyg(t,desc):
 rec=desc['record'];z=j(T/'physical-six/candidate-1-physical-rows.json')['physical_evidence'][t.ph];true=z['rows']['Archive/HashDigests'];src=true['derive'];assert desc['metadata_sha256']==z['rmeta_sha256']and desc['defined_by']['stable']+':'+desc['defined_by']['local']==true['full_impl_identity'];p=file_in(t,'expn_that_defined',desc['defined_by']['index']);r=S.Reader(t.data,p);ct,ex=r.u(),r.u();assert ct==0 and ex
 p=file_in(t,'syntax_contexts',rec['local_ctxt_index']);r=S.Reader(t.data,p);parent,cnum,index,trans=r.u(),r.u(),r.u(),r.u();assert parent==0 and cnum==0 and ex==index
 p=file_in(t,'expn_hashes',index);eh=t.data[p:p+16];assert len(eh)==16 and eh[:8]==bytes.fromhex(desc['defined_by']['stable'])[::-1] and any(eh[8:])
 assert src['callsite_byte_range']==[rec['lo'],rec['lo']+rec['length']]and src['macro_token']==rec['text']=='rkyv::Archive'and src['macro']=='Archive'and src['source_subject']=='HashDigests'
 return {'context_entire_chain':[{'outer_expn_hash_wire':eh.hex(),'transparency':trans},'root'],'source_declaration_parent_proof':{'macro':src['macro'],'token':src['macro_token'],'subject':src['source_subject'],'package':src['resolved_defining_crate'],'declaration':[src['resolved_stable_crate_id'],src['resolved_local_hash']],'export_index':src['authenticated_exported_defindex']},'encoded_implementation_and_syntax_context_both_own_this_expansion':True,'syntax_context_index':rec['local_ctxt_index'],'local_expansion_index':index}
class Extents(Term):
 def ty(self,r):
  p=r.p;a=super().ty(r)
  if self.data[p]==5 and a[0]=='adt'and a[1][0]=='uv_pypi_types'and a[1][3][-1][1]=='HashDigest':
   assert a[3]==[] and self.data[r.p-1]==0 and self.data[r.p-9:r.p-1].hex()==a[2]['repr'][-1];self.hashdigest_deep_shuffle=r.p-9
  return a
def run():
 for ph,y in data['physical_reads'].items():
  obj=Term(ph,Path(y['source_metadata']));actual,extra=obj.body()
  assert json.loads(json.dumps(actual))==data['complete_compared_clause_with_reachable_nominal_adt_definitions']and extra['record']==y['record'];allgraph[ph]=hyg(obj,y)
 assert allgraph['A']==allgraph['B']==allgraph['cold'];s=Extents('A',Path(data['physical_reads']['A']['source_metadata']));good,desc=s.body();k=desc['native_predicate_position'];bad=[]
 for label,ptr,difference in [('nonempty binder',desc['position']+2,1),('absent bound',desc['position']+1,1),('foreign trait DPH corruption',k+3,1),('changed real polarity',desc['native_predicate_end']-1,1)]:
  v=Term('A',s.absolute);b=bytearray(v.data);b[ptr]^=difference;v.data=bytes(b)
  try:v.body()
  except (AssertionError,KeyError,ValueError):bad.append(label);continue
  raise AssertionError(label)
 v=Term('A',s.absolute);b=bytearray(v.data);pos=s.hashdigest_deep_shuffle;b[pos]^=1;v.data=bytes(b);changed,ed=v.body();assert good!=changed and good['trait']==changed['trait']and ed['raw_span']==desc['raw_span'];bad.append('changed deep local HashDigest ADT seed with all nominal IDs and span preserved alters the normalized term')
 v=Term('A',s.absolute);b=bytearray(v.data);start,end=desc['span_chasing'][-1];bb=data['physical_reads']['B'];a1,b1=bb['span_chasing'][-1];assert end-start==b1-a1 and start==file_in(v,'def_span',desc['defined_by']['index']);src=Path(bb['source_metadata']).read_bytes();b[start:end]=src[a1:b1];v.data=bytes(b);same,ev=v.body();assert same==good and ev['raw_span']!=desc['raw_span']and ev['record']['text']!=desc['record']['text'];bad.append('moving only the real compact diagnostic position preserves term but rejects spelling and range at old source')
 v=Term('A',s.absolute);b=bytearray(v.data);ep=file_in(v,'expn_hashes',allgraph['A']['local_expansion_index']);b[ep+8]^=1;v.data=bytes(b);assert hyg(v,desc)!=allgraph['A'];bad.append('altered native expansion hash with same raw context index and text rejected')
 # A prior red assignment to the same physical key, and the official previously enrolled bucket rows.
 G,N,mem,*_=sci['load']();trace=j(Path(native['raw']));req=j(Path(native['raw']).parent/'request.json');assert len(trace['rows'])==sum(native['raw_counts'].values()) and all(r['registration']['kind']in('typeck_root','mir_borrowck')and r['leaf']['kind']=='clauses_of'and r['leaf']['A_node']==41525 and r['leaf']['key']==data['stable_DefPathHash']and r['first'][-1]['reason']=='previously-red'for r in rows)
 prior={r['earlier_positive_force_observed_red']for r in rows};assert len(prior)==1;ix=prior.pop();force=trace['rows'][ix];assert force['child']==41525 and force['reason']=='forced-red' and any(p['child']==41525 and p['color']==0xfffffffe and p['failures_before']<=ix for p in trace['positive_force_colors'])
 nr={}
 for kind,t in ro['results']['A']['rows'].items():
  oa=t['index'];tb=ro['results']['B']['rows'][kind];ob=tb['index'];assert oa in req['watch_for_green'];assert G['A'].get(oa)[:2]==G['B'].get(ob)[:2]and t['key_kind']==N[G['A'].get(oa)[0][0]]and t['key_fp']==G['A'].get(oa)[0][1].hex() and tb['result_fp']==t['result_fp']==G['A'].get(oa)[1].hex();nr[kind]={'A':oa,'B':ob,'positive_equal_result':t['result_fp'],'actual_failed_edges':sum(e['child']==oa for e in trace['rows'])}
 tr=data['complete_compared_clause_with_reachable_nominal_adt_definitions'];adt=tr['args'][0][1];slice_=adt[3][0][1];alloc=adt[3][1][1];assert tr['trait'][0]=='rkyv'and tr['trait'][3][-1][1]=='Archive'and adt[:1]==['adt']and adt[1][3][-1][1]=='Box' and slice_[0]=='slice' and slice_[1][1][3][-1][1]=='HashDigest'and alloc[1][3][-1][1]=='Global'and tr['polarity']=='positive'
 receipt={'source':m['commit'],'native_first_veto':sha(F/'accepted.json'),'original_49_paths':sha(F/'cases.json.gz'),'true_source_comparison':sha(F/'clauses.json'),'actual_49_first_leaves_and_one_prior_force':{'index':41525,'code':'forced-red','genuine_force_event':ix,'observed_first_leaf_count':49},'positively_reopened_native_rosters':nr,'A_B_independent_cold_hygiene':allgraph,'hostile_checks':bad,'owner_source_hashes':{},'native_A_B_observables':{k:v['record']for k,v in data['physical_reads'].items()},'meaning':'Stable projection of the exact one native trait clause agrees including every embedded nominal ADT field. The generic-clause diagnostic Span changes by 677 bytes; the stable hygiene chain, its macro declaration, text, and length agree. The rest of the 49 roots is not assumed green.'}
 for f in ('compiler/rustc_middle/src/ty/generics.rs','compiler/rustc_hir_analysis/src/collect/clauses_of.rs','compiler/rustc_middle/src/ty/codec.rs','compiler/rustc_middle/src/ty/adt.rs','compiler/rustc_middle/src/ty/mod.rs','compiler/rustc_type_ir/src/ty_kind.rs','compiler/rustc_type_ir/src/predicate_kind.rs','compiler/rustc_type_ir/src/predicate.rs','compiler/rustc_type_ir/src/generic_arg.rs','compiler/rustc_abi/src/lib.rs','compiler/rustc_serialize/src/opaque.rs','compiler/rustc_serialize/src/serialize.rs','compiler/rustc_metadata/src/rmeta/encoder.rs','compiler/rustc_metadata/src/rmeta/decoder.rs','compiler/rustc_span/src/hygiene.rs','compiler/rustc_middle/src/dep_graph/graph.rs'):
  b=subprocess.check_output(['git','-C',T/'source01/checkout','show',m['commit']+':'+f]);receipt['owner_source_hashes'][f]={'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes_sha256':hashlib.sha256(b).hexdigest()}
 (F/'clause-validation.json').write_text(json.dumps(receipt,indent=1,sort_keys=True)+'\n');print('validated',sha(F/'clause-validation.json'),'negative_controls',len(bad),'will fail uniformly on real term mutations; earlier forced red',ix)
if __name__=='__main__':run()
