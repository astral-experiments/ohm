"""Independent check of prior positive direct A→B fingerprint changes on all 49 actual paying owners."""
from collections import Counter,defaultdict
from pathlib import Path
import json,runpy
F=Path(__file__).resolve().parent;m=runpy.run_path(str(F/'first.py'));graphs,names,mem,orig,ctx,group,sdk,rev=m['load']();a,b=graphs['A'],graphs['B'];nodes={i:set(m['deps'](a,i))for i in mem};prior={node:a.get(node)[:2]for member in nodes.values()for node in member};needed={key for key,_ in prior.values()};new=defaultdict(list)
for i in range(b.maximum):
 if b.offset(i):
  key,fp,*_=b.get(i)
  if key in needed:new[key].append(fp)
how=Counter();den=Counter();kind=Counter();nkeys=defaultdict(set);ids=defaultdict(set);histo=Counter()
for i,children in nodes.items():
 c=Counter()
 for e in children:
  key,f=prior[e];obs=new.get(key,[]);t='missing'if not obs else'ambiguous'if len(obs)!=1 else'zero'if not any(f)or not any(obs[0])else'changed'if f!=obs[0]else'equal';c[t]+=1
  if t=='changed':kind[names[key[0]]]+=1;nkeys[names[key[0]]].add(i);ids[e].add(i)
 how.update(c);den.update((t for t in c));histo[tuple(sorted((t,x)for t,x in c.items()if t!='equal'))]+=1
r={'role':rev,'ordinary_A_B_digests':m['j'](F.parent/'provider-mechanism/join-01/native-graph-summary.json')['inputs']['candidate']['actual_graphs'],'registered_owner_count':len(mem),'distinct_prior_direct_inputs':len(prior),'all_direct_observations':dict(how),'affected_owners_by_status':dict(den),'distinct_positive_changed_inputs':len(ids),'known_changed_directed_reads_by_kind':dict(kind),'affected_unique_owners_per_positive_changed_kind':{k:len(v)for k,v in nkeys.items()},'modes':[[list(z),n]for z,n in histo.most_common()],'most_shared_changed':[[k,len(v),names[prior[k][0][0]], prior[k][0][1].hex()]for k,v in sorted(ids.items(),key=lambda kv:-len(kv[1]))[:20]],'scope':'All direct native previous reads only. No evidence of first green failure or unavoidable transitive work from this diagnostic alone.'};m['write'](F/'all-direct.json',r);print({k:v for k,v in r.items()if k in ('affected_owners_by_status','affected_unique_owners_per_positive_changed_kind','distinct_prior_direct_inputs','all_direct_observations','most_shared_changed')})
