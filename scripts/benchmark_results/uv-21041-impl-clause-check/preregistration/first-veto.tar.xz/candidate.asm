
/mnt/devbox-scratch/dev-user/ohm-21041-incoherent-domain-3aa96764/derive-stage1-bd03d5709719-41425151965/child/sdk/lib/librustc_driver-fa217dfcec654979.so:     file format elf64-x86-64


Disassembly of section .text:

0000000004c283e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green>:
 4c283e0:	55                   	push   %rbp
 4c283e1:	41 57                	push   %r15
 4c283e3:	41 56                	push   %r14
 4c283e5:	41 55                	push   %r13
 4c283e7:	41 54                	push   %r12
 4c283e9:	53                   	push   %rbx
 4c283ea:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
 4c283f1:	49 89 f1             	mov    %rsi,%r9
 4c283f4:	49 89 fc             	mov    %rdi,%r12
 4c283f7:	49 8b 40 10          	mov    0x10(%r8),%rax
 4c283fb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 4c28400:	89 94 24 98 00 00 00 	mov    %edx,0x98(%rsp)
 4c28407:	48 89 8c 24 90 00 00 00 	mov    %rcx,0x90(%rsp)
 4c2840f:	48 8b 87 10 04 00 00 	mov    0x410(%rdi),%rax
 4c28416:	48 8b 70 50          	mov    0x50(%rax),%rsi
 4c2841a:	89 d7                	mov    %edx,%edi
 4c2841c:	48 39 fe             	cmp    %rdi,%rsi
 4c2841f:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
 4c28424:	0f 86 3d 06 00 00    	jbe    4c28a67 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x687>
 4c2842a:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
 4c2842f:	48 c1 e7 04          	shl    $0x4,%rdi
 4c28433:	48 8b 48 48          	mov    0x48(%rax),%rcx
 4c28437:	4c 8b 70 68          	mov    0x68(%rax),%r14
 4c2843b:	4c 8b 14 39          	mov    (%rcx,%rdi,1),%r10
 4c2843f:	4c 89 d5             	mov    %r10,%rbp
 4c28442:	48 c1 ed 02          	shr    $0x2,%rbp
 4c28446:	4c 89 f2             	mov    %r14,%rdx
 4c28449:	48 29 ea             	sub    %rbp,%rdx
 4c2844c:	0f 82 13 05 00 00    	jb     4c28965 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x585>
 4c28452:	48 01 f9             	add    %rdi,%rcx
 4c28455:	41 83 e2 03          	and    $0x3,%r10d
 4c28459:	49 ff c2             	inc    %r10
 4c2845c:	8b 71 08             	mov    0x8(%rcx),%esi
 4c2845f:	4d 89 d6             	mov    %r10,%r14
 4c28462:	4c 0f af f6          	imul   %rsi,%r14
 4c28466:	49 83 c6 03          	add    $0x3,%r14
 4c2846a:	49 39 d6             	cmp    %rdx,%r14
 4c2846d:	0f 87 e7 04 00 00    	ja     4c2895a <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x57a>
 4c28473:	48 89 7c 24 78       	mov    %rdi,0x78(%rsp)
 4c28478:	42 8d 0c d5 00 00 00 00 	lea    0x0(,%r10,8),%ecx
 4c28480:	f6 d9                	neg    %cl
 4c28482:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
 4c28489:	48 d3 ea             	shr    %cl,%rdx
 4c2848c:	48 89 94 24 88 00 00 00 	mov    %rdx,0x88(%rsp)
 4c28494:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
 4c28499:	85 f6                	test   %esi,%esi
 4c2849b:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
 4c284a0:	0f 84 fd 01 00 00    	je     4c286a3 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x2c3>
 4c284a6:	4c 89 94 24 80 00 00 00 	mov    %r10,0x80(%rsp)
 4c284ae:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
 4c284b3:	48 03 68 60          	add    0x60(%rax),%rbp
 4c284b7:	48 8d 05 72 46 a3 00 	lea    0xa34672(%rip),%rax        # 565cb30 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x71f8>
 4c284be:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 4c284c3:	48 8d 05 6e 44 a3 00 	lea    0xa3446e(%rip),%rax        # 565c938 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x7000>
 4c284ca:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 4c284cf:	eb 40                	jmp    4c28511 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x131>
 4c284d1:	66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 4c284e0:	48 8b 84 24 80 00 00 00 	mov    0x80(%rsp),%rax
 4c284e8:	49 29 c6             	sub    %rax,%r14
 4c284eb:	48 01 c5             	add    %rax,%rbp
 4c284ee:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
 4c284f3:	49 8b 40 08          	mov    0x8(%r8),%rax
 4c284f7:	46 89 2c b8          	mov    %r13d,(%rax,%r15,4)
 4c284fb:	49 ff c7             	inc    %r15
 4c284fe:	4d 89 78 10          	mov    %r15,0x10(%r8)
 4c28502:	49 83 fe 04          	cmp    $0x4,%r14
 4c28506:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
 4c2850b:	0f 82 87 01 00 00    	jb     4c28698 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x2b8>
 4c28511:	8b 5d 00             	mov    0x0(%rbp),%ebx
 4c28514:	23 9c 24 88 00 00 00 	and    0x88(%rsp),%ebx
 4c2851b:	0f 88 0b 04 00 00    	js     4c2892c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x54c>
 4c28521:	49 8b 74 24 10       	mov    0x10(%r12),%rsi
 4c28526:	41 89 df             	mov    %ebx,%r15d
 4c28529:	4c 39 fe             	cmp    %r15,%rsi
 4c2852c:	0f 86 06 05 00 00    	jbe    4c28a38 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x658>
 4c28532:	49 8b 44 24 08       	mov    0x8(%r12),%rax
 4c28537:	46 8b 2c b8          	mov    (%rax,%r15,4),%r13d
 4c2853b:	41 83 fd fd          	cmp    $0xfffffffd,%r13d
 4c2853f:	77 2f                	ja     4c28570 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x190>
 4c28541:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c28548:	0f 83 ee 03 00 00    	jae    4c2893c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x55c>
 4c2854e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c28553:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
 4c28557:	4c 3b 3f             	cmp    (%rdi),%r15
 4c2855a:	75 84                	jne    4c284e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c2855c:	ff 15 ae 5b af 00    	call   *0xaf5bae(%rip)        # 571e110 <_RNvMs4_NtCscHgRw1M2fX5_5alloc7raw_vecINtB5_6RawVecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8grow_oneBS_@@Base+0xa40580>
 4c28562:	e9 79 ff ff ff       	jmp    4c284e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c28567:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
 4c28570:	41 83 fd fe          	cmp    $0xfffffffe,%r13d
 4c28574:	0f 84 38 03 00 00    	je     4c288b2 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c2857a:	49 8b 84 24 10 04 00 00 	mov    0x410(%r12),%rax
 4c28582:	48 8b 70 20          	mov    0x20(%rax),%rsi
 4c28586:	4c 39 fe             	cmp    %r15,%rsi
 4c28589:	0f 86 c8 04 00 00    	jbe    4c28a57 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x677>
 4c2858f:	4c 8b 60 18          	mov    0x18(%rax),%r12
 4c28593:	4b 8d 04 ff          	lea    (%r15,%r15,8),%rax
 4c28597:	41 0f b7 04 44       	movzwl (%r12,%rax,2),%eax
 4c2859c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 4c285a1:	48 8b b2 a8 05 02 00 	mov    0x205a8(%rdx),%rsi
 4c285a8:	48 39 c6             	cmp    %rax,%rsi
 4c285ab:	0f 86 97 04 00 00    	jbe    4c28a48 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x668>
 4c285b1:	48 8b 8a a0 05 02 00 	mov    0x205a0(%rdx),%rcx
 4c285b8:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
 4c285bc:	80 7c c1 11 00       	cmpb   $0x0,0x11(%rcx,%rax,8)
 4c285c1:	75 4d                	jne    4c28610 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x230>
 4c285c3:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 4c285c8:	48 89 d6             	mov    %rdx,%rsi
 4c285cb:	89 da                	mov    %ebx,%edx
 4c285cd:	48 8d 8c 24 90 00 00 00 	lea    0x90(%rsp),%rcx
 4c285d5:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
 4c285da:	e8 01 fe ff ff       	call   4c283e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green>
 4c285df:	41 89 c5             	mov    %eax,%r13d
 4c285e2:	83 f8 ff             	cmp    $0xffffffff,%eax
 4c285e5:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 4c285ea:	74 24                	je     4c28610 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x230>
 4c285ec:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c285f1:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
 4c285f5:	4c 3b 3f             	cmp    (%rdi),%r15
 4c285f8:	0f 85 e2 fe ff ff    	jne    4c284e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c285fe:	ff 15 0c 5b af 00    	call   *0xaf5b0c(%rip)        # 571e110 <_RNvMs4_NtCscHgRw1M2fX5_5alloc7raw_vecINtB5_6RawVecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8grow_oneBS_@@Base+0xa40580>
 4c28604:	e9 d7 fe ff ff       	jmp    4c284e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c28609:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 4c28610:	4b 8d 04 ff          	lea    (%r15,%r15,8),%rax
 4c28614:	49 8d 04 44          	lea    (%r12,%rax,2),%rax
 4c28618:	0f b7 48 10          	movzwl 0x10(%rax),%ecx
 4c2861c:	66 89 4c 24 50       	mov    %cx,0x50(%rsp)
 4c28621:	f3 0f 6f 00          	movdqu (%rax),%xmm0
 4c28625:	66 0f 7f 44 24 40    	movdqa %xmm0,0x40(%rsp)
 4c2862b:	48 89 d7             	mov    %rdx,%rdi
 4c2862e:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
 4c28633:	89 da                	mov    %ebx,%edx
 4c28635:	48 8d 8c 24 90 00 00 00 	lea    0x90(%rsp),%rcx
 4c2863d:	e8 ce 0b 00 00       	call   4c29210 <_RNvMs_NtCs1phqxivSrqn_12rustc_middle9dep_graphNtNtNtB6_2ty7context6TyCtxt23try_force_from_dep_node>
 4c28642:	84 c0                	test   %al,%al
 4c28644:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 4c28649:	0f 84 63 02 00 00    	je     4c288b2 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c2864f:	48 8b 70 10          	mov    0x10(%rax),%rsi
 4c28653:	4c 39 fe             	cmp    %r15,%rsi
 4c28656:	0f 86 dc 03 00 00    	jbe    4c28a38 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x658>
 4c2865c:	48 8b 40 08          	mov    0x8(%rax),%rax
 4c28660:	46 8b 2c b8          	mov    (%rax,%r15,4),%r13d
 4c28664:	41 83 fd fd          	cmp    $0xfffffffd,%r13d
 4c28668:	0f 87 6c 02 00 00    	ja     4c288da <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4fa>
 4c2866e:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c28675:	0f 83 c1 02 00 00    	jae    4c2893c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x55c>
 4c2867b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c28680:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
 4c28684:	4c 3b 3f             	cmp    (%rdi),%r15
 4c28687:	0f 85 53 fe ff ff    	jne    4c284e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c2868d:	ff 15 7d 5a af 00    	call   *0xaf5a7d(%rip)        # 571e110 <_RNvMs4_NtCscHgRw1M2fX5_5alloc7raw_vecINtB5_6RawVecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8grow_oneBS_@@Base+0xa40580>
 4c28693:	e9 48 fe ff ff       	jmp    4c284e0 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x100>
 4c28698:	4c 39 7c 24 10       	cmp    %r15,0x10(%rsp)
 4c2869d:	0f 87 fb 02 00 00    	ja     4c2899e <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5be>
 4c286a3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 4c286a8:	48 8d 2c 85 00 00 00 00 	lea    0x0(,%rax,4),%rbp
 4c286b0:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
 4c286b5:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
 4c286ba:	49 03 68 08          	add    0x8(%r8),%rbp
 4c286be:	48 8d 05 01 75 1b fc 	lea    -0x3e48aff(%rip),%rax        # ddfbc6 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x647a6>
 4c286c5:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 4c286ca:	48 c7 44 24 48 1a 00 00 00 	movq   $0x1a,0x48(%rsp)
 4c286d3:	41 f6 84 24 b0 00 00 00 01 	testb  $0x1,0xb0(%r12)
 4c286dc:	0f 85 d9 02 00 00    	jne    4c289bb <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5db>
 4c286e2:	48 c7 84 24 a0 00 00 00 00 00 00 00 	movq   $0x0,0xa0(%rsp)
 4c286ee:	4c 89 e0             	mov    %r12,%rax
 4c286f1:	4d 8b a4 24 18 01 00 00 	mov    0x118(%r12),%r12
 4c286f9:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
 4c28700:	48 83 c1 10          	add    $0x10,%rcx
 4c28704:	48 8b 05 c5 d9 ae 00 	mov    0xaed9c5(%rip),%rax        # 57160d0 <_RNvNCNKNvNtNtCsaeE03MKAZ19_21rustc_data_structures4sync12worker_local11THREAD_DATA0s_023___RUST_STD_INTERNAL_VAL@@Base+0x5712ce8>
 4c2870b:	64 48 39 08          	cmp    %rcx,%fs:(%rax)
 4c2870f:	0f 85 c6 02 00 00    	jne    4c289db <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5fb>
 4c28715:	64 48 8b 40 08       	mov    %fs:0x8(%rax),%rax
 4c2871a:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c2871f:	48 c1 e0 07          	shl    $0x7,%rax
 4c28723:	49 83 3c 04 00       	cmpq   $0x0,(%r12,%rax,1)
 4c28728:	0f 85 bd 02 00 00    	jne    4c289eb <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x60b>
 4c2872e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 4c28733:	48 8d b9 10 01 00 00 	lea    0x110(%rcx),%rdi
 4c2873a:	49 01 c4             	add    %rax,%r12
 4c2873d:	49 c7 04 24 ff ff ff ff 	movq   $0xffffffffffffffff,(%r12)
 4c28745:	41 83 7c 24 7c 00    	cmpl   $0x0,0x7c(%r12)
 4c2874b:	74 13                	je     4c28760 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x380>
 4c2874d:	45 8b 6c 24 78       	mov    0x78(%r12),%r13d
 4c28752:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c28759:	72 66                	jb     4c287c1 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x3e1>
 4c2875b:	e9 20 02 00 00       	jmp    4c28980 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5a0>
 4c28760:	b9 00 01 00 00       	mov    $0x100,%ecx
 4c28765:	f0 48 0f c1 0f       	lock xadd %rcx,(%rdi)
 4c2876a:	48 89 c8             	mov    %rcx,%rax
 4c2876d:	48 c1 e8 20          	shr    $0x20,%rax
 4c28771:	48 c1 e1 20          	shl    $0x20,%rcx
 4c28775:	48 81 c9 00 02 00 00 	or     $0x200,%rcx
 4c2877c:	48 85 c0             	test   %rax,%rax
 4c2877f:	b8 01 02 00 00       	mov    $0x201,%eax
 4c28784:	48 0f 44 c1          	cmove  %rcx,%rax
 4c28788:	3c 01                	cmp    $0x1,%al
 4c2878a:	0f 84 6d 02 00 00    	je     4c289fd <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x61d>
 4c28790:	49 89 c5             	mov    %rax,%r13
 4c28793:	49 c1 ed 20          	shr    $0x20,%r13
 4c28797:	45 89 6c 24 78       	mov    %r13d,0x78(%r12)
 4c2879c:	48 c1 e8 28          	shr    $0x28,%rax
 4c287a0:	3d fe ff ff 00       	cmp    $0xfffffe,%eax
 4c287a5:	0f 87 7e 02 00 00    	ja     4c28a29 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x649>
 4c287ab:	41 c7 44 24 7c 00 01 00 00 	movl   $0x100,0x7c(%r12)
 4c287b4:	41 81 fd 01 ff ff ff 	cmp    $0xffffff01,%r13d
 4c287bb:	0f 83 bf 01 00 00    	jae    4c28980 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5a0>
 4c287c1:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
 4c287c6:	49 39 ce             	cmp    %rcx,%r14
 4c287c9:	0f 86 a6 02 00 00    	jbe    4c28a75 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x695>
 4c287cf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 4c287d4:	f0 44 0f b1 2c 8b    	lock cmpxchg %r13d,(%rbx,%rcx,4)
 4c287da:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
 4c287df:	0f 85 a5 00 00 00    	jne    4c2888a <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4aa>
 4c287e5:	f3 41 0f 7e 44 24 78 	movq   0x78(%r12),%xmm0
 4c287ec:	66 0f fe 05 ac 00 e8 fb 	paddd  -0x417ff54(%rip),%xmm0        # aa88a0 <anon.829ff91bdf125c2598215c11ab6a766c.0.llvm.11915286338818084809+0x1afee>
 4c287f4:	66 41 0f d6 44 24 78 	movq   %xmm0,0x78(%r12)
 4c287fb:	49 ff 44 24 68       	incq   0x68(%r12)
 4c28800:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 4c28805:	48 8b 80 30 01 00 00 	mov    0x130(%rax),%rax
 4c2880c:	4c 8b 70 20          	mov    0x20(%rax),%r14
 4c28810:	49 39 ce             	cmp    %rcx,%r14
 4c28813:	0f 86 65 02 00 00    	jbe    4c28a7e <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x69e>
 4c28819:	4c 8b 70 38          	mov    0x38(%rax),%r14
 4c2881d:	49 39 ce             	cmp    %rcx,%r14
 4c28820:	0f 86 61 02 00 00    	jbe    4c28a87 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6a7>
 4c28826:	4c 2b 7c 24 10       	sub    0x10(%rsp),%r15
 4c2882b:	4d 8d 44 24 08       	lea    0x8(%r12),%r8
 4c28830:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
 4c28835:	49 81 c1 b8 00 00 00 	add    $0xb8,%r9
 4c2883c:	48 8d 0c c9          	lea    (%rcx,%rcx,8),%rcx
 4c28840:	48 8b 50 18          	mov    0x18(%rax),%rdx
 4c28844:	48 8b 40 30          	mov    0x30(%rax),%rax
 4c28848:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
 4c2884d:	f3 0f 6f 04 30       	movdqu (%rax,%rsi,1),%xmm0
 4c28852:	0f b7 44 4a 10       	movzwl 0x10(%rdx,%rcx,2),%eax
 4c28857:	66 89 44 24 70       	mov    %ax,0x70(%rsp)
 4c2885c:	0f 10 0c 4a          	movups (%rdx,%rcx,2),%xmm1
 4c28860:	0f 11 4c 24 60       	movups %xmm1,0x60(%rsp)
 4c28865:	f3 0f 7f 44 24 50    	movdqu %xmm0,0x50(%rsp)
 4c2886b:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
 4c28870:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
 4c28875:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
 4c2887a:	44 89 ee             	mov    %r13d,%esi
 4c2887d:	4c 89 c9             	mov    %r9,%rcx
 4c28880:	e8 3b f3 f3 ff       	call   4b67bc0 <_RNvMs6_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph10serializedNtB5_12EncoderState11encode_node>
 4c28885:	44 89 eb             	mov    %r13d,%ebx
 4c28888:	eb 12                	jmp    4c2889c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4bc>
 4c2888a:	83 f8 fe             	cmp    $0xfffffffe,%eax
 4c2888d:	74 0d                	je     4c2889c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4bc>
 4c2888f:	89 c3                	mov    %eax,%ebx
 4c28891:	3d 01 ff ff ff       	cmp    $0xffffff01,%eax
 4c28896:	0f 83 e4 00 00 00    	jae    4c28980 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x5a0>
 4c2889c:	49 ff 04 24          	incq   (%r12)
 4c288a0:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
 4c288a8:	e8 43 2c ff ff       	call   4c1b4f0 <_RINvNtCsc36rpYXAlPq_4core3ptr9drop_glueNtNtCsaeE03MKAZ19_21rustc_data_structures9profiling11TimingGuardECs1phqxivSrqn_12rustc_middle>
 4c288ad:	83 fb ff             	cmp    $0xffffffff,%ebx
 4c288b0:	75 05                	jne    4c288b7 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d7>
 4c288b2:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
 4c288b7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 4c288bc:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 4c288c1:	e8 ea 51 0e 00       	call   4d0dab0 <_RNvMs_NtCscHgRw1M2fX5_5alloc3vecINtB4_3VecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8truncateBK_>
 4c288c6:	89 d8                	mov    %ebx,%eax
 4c288c8:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
 4c288cf:	5b                   	pop    %rbx
 4c288d0:	41 5c                	pop    %r12
 4c288d2:	41 5d                	pop    %r13
 4c288d4:	41 5e                	pop    %r14
 4c288d6:	41 5f                	pop    %r15
 4c288d8:	5d                   	pop    %rbp
 4c288d9:	c3                   	ret
 4c288da:	41 83 fd fe          	cmp    $0xfffffffe,%r13d
 4c288de:	74 d2                	je     4c288b2 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c288e0:	b8 90 17 00 00       	mov    $0x1790,%eax
 4c288e5:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 4c288ea:	48 03 81 f0 04 02 00 	add    0x204f0(%rcx),%rax
 4c288f1:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 4c288f6:	48 c7 44 24 48 00 00 00 00 	movq   $0x0,0x48(%rsp)
 4c288ff:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
 4c28904:	ff 15 96 fe ae 00    	call   *0xaefe96(%rip)        # 57187a0 <_RNvMs5_CsdDeWnbHHqre_12rustc_errorsNtB5_14DiagCtxtHandle26has_errors_or_delayed_bugs@@Base+0x68b4c0>
 4c2890a:	84 c0                	test   %al,%al
 4c2890c:	75 a4                	jne    4c288b2 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x4d2>
 4c2890e:	48 8d 3d cb 72 1b fc 	lea    -0x3e48d35(%rip),%rdi        # ddfbe0 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x647c0>
 4c28915:	48 8d 15 f4 40 a3 00 	lea    0xa340f4(%rip),%rdx        # 565ca10 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x70d8>
 4c2891c:	be 73 00 00 00       	mov    $0x73,%esi
 4c28921:	ff 15 d1 bd ae 00    	call   *0xaebdd1(%rip)        # 57146f8 <_RNvNtCsc36rpYXAlPq_4core9panicking9panic_fmt@@Base+0x30d588>
 4c28927:	e9 70 01 00 00       	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c2892c:	48 8d 3d d6 6d 1b fc 	lea    -0x3e4922a(%rip),%rdi        # ddf709 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x642e9>
 4c28933:	48 8d 15 de 35 a3 00 	lea    0xa335de(%rip),%rdx        # 565bf18 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x65e0>
 4c2893a:	eb 0e                	jmp    4c2894a <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x56a>
 4c2893c:	48 8d 3d 43 72 1b fc 	lea    -0x3e48dbd(%rip),%rdi        # ddfb86 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x64766>
 4c28943:	48 8d 15 d6 3f a3 00 	lea    0xa33fd6(%rip),%rdx        # 565c920 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fe8>
 4c2894a:	be 26 00 00 00       	mov    $0x26,%esi
 4c2894f:	ff 15 9b bd ae 00    	call   *0xaebd9b(%rip)        # 57146f0 <_RNvNtCsc36rpYXAlPq_4core9panicking5panic@@Base+0x30d5a0>
 4c28955:	e9 42 01 00 00       	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c2895a:	48 8d 0d 0f 3e a3 00 	lea    0xa33e0f(%rip),%rcx        # 565c770 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6e38>
 4c28961:	31 ed                	xor    %ebp,%ebp
 4c28963:	eb 0a                	jmp    4c2896f <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x58f>
 4c28965:	48 8d 0d 1c 3e a3 00 	lea    0xa33e1c(%rip),%rcx        # 565c788 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6e50>
 4c2896c:	4c 89 f2             	mov    %r14,%rdx
 4c2896f:	48 89 ef             	mov    %rbp,%rdi
 4c28972:	4c 89 f6             	mov    %r14,%rsi
 4c28975:	ff 15 ad bd ae 00    	call   *0xaebdad(%rip)        # 5714728 <_RNvNtNtCsc36rpYXAlPq_4core5slice5index16slice_index_fail@@Base+0x30c198>
 4c2897b:	e9 1c 01 00 00       	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c28980:	48 8d 3d ff 71 1b fc 	lea    -0x3e48e01(%rip),%rdi        # ddfb86 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x64766>
 4c28987:	48 8d 15 92 3f a3 00 	lea    0xa33f92(%rip),%rdx        # 565c920 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fe8>
 4c2898e:	be 26 00 00 00       	mov    $0x26,%esi
 4c28993:	ff 15 57 bd ae 00    	call   *0xaebd57(%rip)        # 57146f0 <_RNvNtCsc36rpYXAlPq_4core9panicking5panic@@Base+0x30d5a0>
 4c28999:	e9 fe 00 00 00       	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c2899e:	48 8d 0d 53 40 a3 00 	lea    0xa34053(%rip),%rcx        # 565c9f8 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x70c0>
 4c289a5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
 4c289aa:	4c 89 fe             	mov    %r15,%rsi
 4c289ad:	4c 89 fa             	mov    %r15,%rdx
 4c289b0:	ff 15 72 bd ae 00    	call   *0xaebd72(%rip)        # 5714728 <_RNvNtNtCsc36rpYXAlPq_4core5slice5index16slice_index_fail@@Base+0x30c198>
 4c289b6:	e9 e1 00 00 00       	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c289bb:	49 8d b4 24 a8 00 00 00 	lea    0xa8(%r12),%rsi
 4c289c3:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
 4c289cb:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
 4c289d0:	ff 15 e2 d7 ae 00    	call   *0xaed7e2(%rip)        # 57161b8 <_RINvNvMNtCsaeE03MKAZ19_21rustc_data_structures9profilingNtB5_15SelfProfilerRef4exec9cold_callNCNvB4_16generic_activity0EB7_@@Base+0x3ef568>
 4c289d6:	e9 13 fd ff ff       	jmp    4c286ee <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x30e>
 4c289db:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c289e0:	ff 15 22 52 af 00    	call   *0xaf5222(%rip)        # 571dc08 <_RINvCsaeE03MKAZ19_21rustc_data_structures7outlineNCNCNvMNtNtB2_4sync12worker_localNtBS_10RegistryId6verify00jECs1phqxivSrqn_12rustc_middle@@Base+0xbda358>
 4c289e6:	e9 34 fd ff ff       	jmp    4c2871f <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x33f>
 4c289eb:	48 8d 3d ee 3f a3 00 	lea    0xa33fee(%rip),%rdi        # 565c9e0 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x70a8>
 4c289f2:	ff 15 90 bc ae 00    	call   *0xaebc90(%rip)        # 5714688 <_RNvNtCsc36rpYXAlPq_4core4cell22panic_already_borrowed@@Base+0x30dab8>
 4c289f8:	e9 9f 00 00 00       	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c289fd:	c6 44 24 40 02       	movb   $0x2,0x40(%rsp)
 4c28a02:	48 8d 3d db 6d 1b fc 	lea    -0x3e49225(%rip),%rdi        # ddf7e4 <_RNvNvNtCs740YcEqacM5_10libloading4util19cstr_cow_from_bytes4ZERO+0x643c4>
 4c28a09:	48 8d 0d 58 36 a3 00 	lea    0xa33658(%rip),%rcx        # 565c068 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6730>
 4c28a10:	4c 8d 05 d9 3e a3 00 	lea    0xa33ed9(%rip),%r8        # 565c8f0 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fb8>
 4c28a17:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
 4c28a1c:	be 2b 00 00 00       	mov    $0x2b,%esi
 4c28a21:	ff 15 89 bc ae 00    	call   *0xaebc89(%rip)        # 57146b0 <_RNvNtCsc36rpYXAlPq_4core6result13unwrap_failed@@Base+0x30d860>
 4c28a27:	eb 73                	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c28a29:	48 8d 3d d8 3e a3 00 	lea    0xa33ed8(%rip),%rdi        # 565c908 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6fd0>
 4c28a30:	ff 15 72 bc ae 00    	call   *0xaebc72(%rip)        # 57146a8 <_RNvNtCsc36rpYXAlPq_4core6option13unwrap_failed@@Base+0x30d878>
 4c28a36:	eb 64                	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c28a38:	4c 89 ff             	mov    %r15,%rdi
 4c28a3b:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 4c28a40:	ff 15 82 bc ae 00    	call   *0xaebc82(%rip)        # 57146c8 <_RNvNtCsc36rpYXAlPq_4core9panicking18panic_bounds_check@@Base+0x30d7a6>
 4c28a46:	eb 54                	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c28a48:	49 89 c7             	mov    %rax,%r15
 4c28a4b:	48 8d 05 b6 3d a3 00 	lea    0xa33db6(%rip),%rax        # 565c808 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6ed0>
 4c28a52:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 4c28a57:	4c 89 ff             	mov    %r15,%rdi
 4c28a5a:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 4c28a5f:	ff 15 63 bc ae 00    	call   *0xaebc63(%rip)        # 57146c8 <_RNvNtCsc36rpYXAlPq_4core9panicking18panic_bounds_check@@Base+0x30d7a6>
 4c28a65:	eb 35                	jmp    4c28a9c <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6bc>
 4c28a67:	48 8d 05 ea 3c a3 00 	lea    0xa33cea(%rip),%rax        # 565c758 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x6e20>
 4c28a6e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 4c28a73:	eb c6                	jmp    4c28a3b <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x65b>
 4c28a75:	48 8d 15 9c 40 a3 00 	lea    0xa3409c(%rip),%rdx        # 565cb18 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x71e0>
 4c28a7c:	eb 10                	jmp    4c28a8e <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6ae>
 4c28a7e:	48 8d 15 b3 3e a3 00 	lea    0xa33eb3(%rip),%rdx        # 565c938 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x7000>
 4c28a85:	eb 07                	jmp    4c28a8e <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6ae>
 4c28a87:	48 8d 15 4a 2f a3 00 	lea    0xa32f4a(%rip),%rdx        # 565b9d8 <_RNvNvNvMs7_NtNtCs1phqxivSrqn_12rustc_middle2ty3styNtBb_2Ty6fn_sig10___CALLSITE4META+0x60a0>
 4c28a8e:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
 4c28a93:	4c 89 f6             	mov    %r14,%rsi
 4c28a96:	ff 15 2c bc ae 00    	call   *0xaebc2c(%rip)        # 57146c8 <_RNvNtCsc36rpYXAlPq_4core9panicking18panic_bounds_check@@Base+0x30d7a6>
 4c28a9c:	0f 0b                	ud2
 4c28a9e:	eb 26                	jmp    4c28ac6 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6e6>
 4c28aa0:	48 89 c3             	mov    %rax,%rbx
 4c28aa3:	eb 0c                	jmp    4c28ab1 <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6d1>
 4c28aa5:	48 89 c3             	mov    %rax,%rbx
 4c28aa8:	49 ff 04 24          	incq   (%r12)
 4c28aac:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c28ab1:	48 8d bc 24 a0 00 00 00 	lea    0xa0(%rsp),%rdi
 4c28ab9:	e8 32 2a ff ff       	call   4c1b4f0 <_RINvNtCsc36rpYXAlPq_4core3ptr9drop_glueNtNtCsaeE03MKAZ19_21rustc_data_structures9profiling11TimingGuardECs1phqxivSrqn_12rustc_middle>
 4c28abe:	eb 0e                	jmp    4c28ace <_RNvMs7_NtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graphNtB5_12DepGraphData23try_mark_previous_green+0x6ee>
 4c28ac0:	ff 15 fa bb ae 00    	call   *0xaebbfa(%rip)        # 57146c0 <_RNvNtCsc36rpYXAlPq_4core9panicking16panic_in_cleanup@@Base+0x30d7b2>
 4c28ac6:	48 89 c3             	mov    %rax,%rbx
 4c28ac9:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 4c28ace:	4c 89 ef             	mov    %r13,%rdi
 4c28ad1:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 4c28ad6:	e8 d5 4f 0e 00       	call   4d0dab0 <_RNvMs_NtCscHgRw1M2fX5_5alloc3vecINtB4_3VecNtNtNtCs1phqxivSrqn_12rustc_middle9dep_graph5graph12DepNodeIndexE8truncateBK_>
 4c28adb:	48 89 df             	mov    %rbx,%rdi
 4c28ade:	e8 4d 43 7f 00       	call   541ce30 <_Unwind_Resume@plt>
 4c28ae3:	ff 15 d7 bb ae 00    	call   *0xaebbd7(%rip)        # 57146c0 <_RNvNtCsc36rpYXAlPq_4core9panicking16panic_in_cleanup@@Base+0x30d7b2>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
