"""Use each original upstream binary to lock a locally editable workspace, offline."""
from pathlib import Path
from hashlib import sha256
import json,runpy,subprocess,shutil,tomllib
root_project='''[project]
name = "uv-g-lock-root"
version = "1.0.0"
requires-python = ">=3.11"
dependencies = ["uv-g-lock-child"]

[project.optional-dependencies]
feature = ["uv-g-lock-child"]

[dependency-groups]
dev = ["uv-g-lock-child"]

[tool.uv.workspace]
members = ["child"]

[tool.uv.sources]
uv-g-lock-child = { workspace = true }
'''
child_project='''[project]
name = "uv-g-lock-child"
version = "0.2.0"
requires-python = ">=3.11"
'''
def test(base,check,env):
    qa=base.ROOT/'linked';qa.mkdir();src=qa/'uv';project=qa/'project';project.mkdir();(project/'child').mkdir();(project/'pyproject.toml').write_text(root_project);(project/'child/pyproject.toml').write_text(child_project)
    target=qa/'target';e=dict(env,CARGO_TARGET_DIR=str(target),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',UV_PYTHON_DOWNLOADS='never',UV_CACHE_DIR=str(qa/'uv-cache'),UV_NO_PROGRESS='1');proof={}
    for st in 'AB':
        orig=base.source(src,st,e,initialize=st=='A');build=[check[0],'build','-p','uv','--bin','uv','--locked','--offline','-j8'];c=base.direct('native-build-'+st,e,build,src);exe=target/'debug/uv'
        table=subprocess.check_output(['/usr/bin/nm','--defined-only','-C',str(exe)],env=e);hits=[v.partition(' ')[2]for v in table.decode().splitlines()if 'uv_resolver::lock::PackageMetadata::from_distribution'in v]
        lock=project/'uv.lock';assert not lock.exists();cmd=[str(exe),'lock','--offline','--python','/usr/bin/python3'];v=base.direct('lock-'+st,e,cmd,project);raw=lock.read_bytes();(v/'uv.lock').write_bytes(raw);lock.unlink();data=tomllib.loads(raw.decode());packages={v['name']:v for v in data['package']};assert set(packages)=={'uv-g-lock-root','uv-g-lock-child'}and packages['uv-g-lock-root']['source']=={'virtual':'.'}and packages['uv-g-lock-child']['source']=={'editable':'child'}
        pkg=packages['uv-g-lock-root'];meta=pkg['metadata'];assert {r['name']for r in meta['requires-dist']}=={'uv-g-lock-child'}and meta['provides-extras']==['feature']and {q['name']for q in meta['requires-dev']['dev']}=={'uv-g-lock-child'}
        proof[st]={'source':orig,'binary':base.fingerprint(exe),'cargo':build,'cargo_log':base.fingerprint(c/'stderr'),'command':cmd,'native_log':base.fingerprint(v/'stderr'),'TOML':sha256(raw).hexdigest(),'linked_constructor_symbols':hits,'three_live_metadata_collections':meta}
    assert proof['A']['TOML']==proof['B']['TOML']and not proof['A']['linked_constructor_symbols']
    proof['actual_inputs']={p:base.fingerprint(project/p)for p in ['pyproject.toml','child/pyproject.toml']};shutil.rmtree(qa);return proof
