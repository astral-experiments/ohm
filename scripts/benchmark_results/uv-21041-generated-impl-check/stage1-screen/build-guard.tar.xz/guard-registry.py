"""Run the registered four-history ordinary uv #20992 linked build guard on 0-7."""
from pathlib import Path
import os,sys,shutil,runpy,subprocess,time,hashlib,json,re,shlex,signal,types,importlib.util,stat,argparse,tomllib
Q=Path(__file__).resolve().parent; STUDY=Q.parent; W=STUDY.parents[2].parent
OLD=W/'work/round18-rustc/over18-2x/frontend/derive-20992'
V=Path('/tmp/ohm-over18-named-test'); SRC=V/'source'; TARG=V/'target'; SDK=V/'sdk'; OUT=Path('/tmp/measurements')
BANK=OLD/'source-crlf/material-001'; NATIVE=OLD/'native-library'; ARMS=['parent','candidate','candidate','parent']
COMMAND=['build','--locked','--offline','-j8','-p','uv-cli']
CARGO='3ce4e300d4463dfc769b6c18e138d1c951b02dfb15416a39cb5301303d168871'
REG='1b22f1ab7d1493538aef77ef4de1a11db36b14e9c09407f6d560f13dcccc4697'
PLAN='b2801bb8a8f30b4facd5cc4c1a7b0b9142a7841906f17fd241629504a9273ab2'
G=1<<30
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def jsonread(p):return json.loads(p.read_bytes())
def save(p,data):
 with p.open('x')as s:json.dump(data,s,sort_keys=True,indent=2);s.write('\n')
def module(label,path):
 s=importlib.util.spec_from_file_location(label,path);m=importlib.util.module_from_spec(s);sys.modules[label]=m;s.loader.exec_module(m);return m
def need(a,why):
 if not a:raise ValueError(why)
def static():
 assert digest(STUDY/'protocol.json')==PLAN and digest(NATIVE/'registration.json')==REG
 reg=jsonread(NATIVE/'registration.json');plan=jsonread(STUDY/'protocol.json');sr=reg['source_receipt']
 assert reg['command']==plan['old_negative_build_guard']['command']==COMMAND and reg['source']==plan['old_negative_build_guard']['uv_commits']
 assert digest(BANK/'receipt.json')==sr['material_receipt_sha256'] and digest(BANK/'verified-source.json')==sr['checkout_proof_sha256'] and digest(OLD/'source-crlf/attributes.json')==sr['attributes_sha256']
 assert jsonread(Q/'original-source-audit.json')==jsonread(BANK/'receipt.json')
 for n,val in reg['files'].items():assert digest(NATIVE/n)==val
 return dict(plan=PLAN,original_library_registration=REG,source_receipt=sr,original_offline_audit=digest(Q/'original-source-audit.json'),source=reg['source'],tool=CARGO)
def environment():
 return dict(PATH=str(SDK/'bin')+':/usr/bin:/bin',HOME=str(V/'home'),TMPDIR=str(V/'tmp'),CARGO_HOME=str(V/'cargo-home'),CARGO_TARGET_DIR=str(TARG),CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never',RUSTC=str(SDK/'bin/rustc'),GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file',TZ='UTC',LC_ALL='C.UTF-8')
def execute(label,argv,cwd=SRC):
 log=OUT/(label+'.log')
 with log.open('xb')as w:
  begin=time.monotonic_ns()
  p=subprocess.Popen(list(map(str,argv)),cwd=cwd,env=environment(),stdin=subprocess.DEVNULL,stdout=w,stderr=subprocess.STDOUT);rc=p.wait()
  end=time.monotonic_ns()
 out=dict(argv=list(map(str,argv)),cwd=str(cwd),start_monotonic_ns=begin,end_monotonic_ns=end,elapsed_ns=end-begin,exit=rc,log_sha256=digest(log),log_bytes=log.stat().st_size)
 save(OUT/(label+'.json'),out);assert rc==0,(label,rc,log.read_text(errors='replace')[-2400:]);return out,log.read_text(errors='strict')
def standard(name,compiles):
 rec,log=execute(name,[SDK/'bin/cargo',*COMMAND]);lines=[l.strip()for l in log.splitlines()]
 got=[l.split()[1]for l in lines if l.startswith('Compiling ')]
 assert bool(re.search(r'^Finished .+ target\(s\) in ',lines[-1])) and not any(l.startswith('error:')for l in lines),(name,lines[-4:])
 if compiles is not None:need(got==compiles,(name,got))
 return rec
def target_proof(root):
 h=hashlib.sha256();n=0;total=0
 for p in sorted(root.rglob('*')):
  if not p.is_file() and not p.is_symlink():continue
  st=p.lstat();rel=p.relative_to(root).as_posix();v=os.readlink(p)if p.is_symlink()else digest(p)
  h.update(json.dumps([rel,st.st_mode,st.st_size,st.st_mtime_ns,v],separators=(',',':')).encode()+b'\n');n+=1;total+=st.st_size
 assert n>400 and total>100<<20
 return dict(files=n,logical_bytes=total,content_mode_mtime_manifest=h.hexdigest())
def clone(a,b):assert not b.exists();subprocess.run(['/bin/cp','-a','--reflink=auto',str(a),str(b)],check=True,env=environment())
def reset_target(ss):
 assert TARG.is_dir() and TARG.parent==V and ss==V/'seed'
 shutil.rmtree(TARG);clone(ss,TARG)
def probe(phase,unit,arm,qa,sub):
 obj,q,m=qa
 obs=obj.probe(types.SimpleNamespace(TARGET=TARG,SDK=SDK,SRC=SRC,environment=environment,ID={arm:{'driver_sha256':sub}}),q,unit,unit,arm,phase,V/('consumer-'+phase))
 save(OUT/('probe-'+phase+'.json'),obs);obj.check_probe(obs);return obs
def retain(name,unit):
 r=OUT/'archives'/name;r.mkdir(parents=True);rows={}
 for f in (unit,unit.with_suffix('.rmeta')):
  assert f.is_file()and not f.is_symlink();p=r/f.name;shutil.copyfile(f,p);x=digest(f);assert x==digest(p);rows[p.name]=dict(bytes=p.stat().st_size,sha256=x)
 return rows
def worker(arm,num):
 assert os.sched_getaffinity(0)==set(range(8));assert os.statvfs('/tmp').f_blocks*os.statvfs('/tmp').f_frsize<=13*G
 st=static();registr=jsonread(Q/'registration-registry.json');assert digest(Path(__file__))==registr['runner'] and registr['source']==st
 native=module('native_20992_artifacts_existing',NATIVE/'artifacts.py');material=module('native_20992_material_existing',OLD/'source-crlf/material.py')
 for p in ('tmp','home','source','cargo-home'):(V/p).mkdir()
 home=V/'cargo-home';(home/'registry').symlink_to(BANK/'registry')
 config=tomllib.loads(Path('/.cargo/config.toml').read_text())['source'];name=config['crates-io']['replace-with'];assert name=='socket-firewall-see-go-blocked-3p-dep' and config[name]['registry']=='sparse+https://socket-firewall-registry.gateway.admin-0.internal.api.openai.org/cargo/'
 save(OUT/'actual-offline-routing.json',dict(config=digest(Path('/.cargo/config.toml')),registry_name=name,registry=config[name]['registry']))
 assert digest(SDK/'bin/cargo')==CARGO;ins=jsonread(OUT/'sdk.json');driver=ins['driver'];assert driver==digest(next((SDK/'lib').glob('librustc_driver*.so')))
 assert arm==ARMS[num-1] and ins['role']==arm and ins['sdk']['source']['commit']==registr['roles'][arm]['commit']
 if arm=='candidate':
  assert digest(STUDY/'candidate-qualified.json')==ins['qualification'] and jsonread(STUDY/'candidate-qualified.json')['record']==digest(STUDY/'candidate-sdk.json')
 a=material.install(SRC);save(OUT/'source-A.json',a)
 assert a['git_head']==st['source'][0] and digest(SRC/'Cargo.lock')=='2ab7a7e2d64ab31200b78f1729ca83f15b247f65fcdc63fa5550d41b9f1b2164'
 save(OUT/'environment.json',environment());_,meta=execute('roster-A',[SDK/'bin/cargo','build','--unit-graph','-Zunstable-options','--locked','--offline','-j8','-p','uv-cli'])
 rosterA=json.loads(meta);assert len(rosterA['units'])>200
 standard('cold-A',None);standard('untouched-A',[]);q=types.SimpleNamespace(read=jsonread,sha=digest);adapter=(native,q,material)
 ua=native.lib(TARG);archives={'A':retain('A',ua)};A=probe('A',ua,arm,adapter,driver)
 seed=V/'seed';p=target_proof(TARG);clone(TARG,seed);assert target_proof(seed)==p;save(OUT/'seed-A.json',p)
 reset_target(seed);assert target_proof(TARG)==p;standard('restored-A-sham',[])
 reset_target(seed);assert target_proof(TARG)==p
 b=material.apply_b(SRC);save(OUT/'source-edited-B.json',b);assert set(b['changed_files'])==set(jsonread(OLD/'source/identity.json')['changed'])
 wall=standard('ordinary-first-B',['uv-cli']);ub=native.lib(TARG);archives['ordinary-B']=retain('ordinary-B',ub);B=probe('B',ub,arm,adapter,driver);comparison=native.compare(A,B)
 standard('untouched-B',[])
 _,meta=execute('roster-B',[SDK/'bin/cargo','build','--unit-graph','-Zunstable-options','--locked','--offline','-j8','-p','uv-cli']);assert json.loads(meta)==rosterA
 # Restore the exact A artifact tree again, leaving all four already applied working-copy edits intact at their B content/mtimes.
 reset_target(seed);assert target_proof(TARG)==p
 _,raw=execute('verbose-first-B',[SDK/'bin/cargo',*COMMAND,'-vv'])
 rows=[]
 for line in raw.splitlines():
  marker='Running '+chr(96)
  if marker in line and '--crate-name' in line:
   cmd=line.split(marker,1)[1];assert cmd.endswith(chr(96));words=shlex.split(cmd[:-1]);i=words.index(str(SDK/'bin/rustc'));rows.append(words[i:])
 argv,=rows;assert argv[argv.index('--crate-name')+1]=='uv_cli' and argv[argv.index('--crate-type')+1] in ('lib','rlib')
 emit=next((x.partition('=')[2]for x in argv if x.startswith('--emit=')),None)or argv[argv.index('--emit')+1]
 assert {'link','metadata','dep-info'}<=set(emit.split(',')) and any(x.endswith('crates/uv-cli/src/lib.rs')for x in argv) and any('incremental='in x for x in argv) and '--test'not in argv
 save(OUT/'actual-uv-cli-argv.json',argv);re=native.lib(TARG);replay={'archive':digest(re),'metadata':digest(re.with_suffix('.rmeta')),'objects':native.members(re)}
 save(OUT/'replayed-edited-archive.json',replay);save(OUT/'archives.json',archives)
 disk=shutil.disk_usage('/tmp');assert disk.used<=12*G
 save(OUT/'passed.json',dict(role=arm,ordinal=num,seed=p,ordinary_wall_ns=wall['elapsed_ns'],ordinary_log=wall['log_sha256'],roster_units=len(rosterA['units']),roster=digest(OUT/'roster-A.log'),A=digest(OUT/'probe-A.json'),B=digest(OUT/'probe-B.json'),argc=len(argv),argv=digest(OUT/'actual-uv-cli-argv.json'),objects=comparison,replay_matches_ordinary_bytes=replay['archive']==archives['ordinary-B'][re.name]['sha256'],tmp_bytes_used=disk.used,physical_archives=digest(OUT/'archives.json'),source=st))
def host(num,out):
 lab=runpy.run_path(str(STUDY/'lab.py'));guard=lab['guard'];guard();role=ARMS[num-1];rs=static();sour,commit,rec=lab['sdk_for'](role)
 sdkrec=jsonread(STUDY/'candidate-sdk.json' if role=='candidate'else STUDY.parent/'incoherent-crate-domain-21041/retry01/run-41407590585/artifact-receipt.json')
 assert sour.resolve()==Path(sdkrec['physical_sdk']).resolve() and commit==sdkrec['source']['commit'];physical=Path(jsonread(STUDY.parent/'incoherent-crate-domain-21041/storage.json')['path'])
 assert out.parent.parent==physical/'build-guard-20992-proc-derive' and out.parent.name.startswith('run-') and out.name==f'{num:02}-{role}'
 assert shutil.disk_usage(physical).free>40*G and int(Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0])>24*1024**2
 out.mkdir(parents=True);driver=digest(next((sour/'lib').glob('librustc_driver*.so')))
 save(out/'sdk.json',dict(role=role,sdk=sdkrec,receipt_sha256=rec,driver=driver,qualification=digest(STUDY/'candidate-qualified.json')if role=='candidate'else None))
 shell=['/usr/bin/bwrap','--die-with-parent','--new-session','--unshare-user','--unshare-pid','--unshare-net','--ro-bind','/','/','--dev','/dev','--proc','/proc','--size',str(12*G),'--tmpfs','/tmp','--dir',str(V),'--ro-bind',str(sour),str(SDK),'--bind',str(out),str(OUT),'--chdir',str(V),'/usr/bin/python3','-ISB',str(Path(__file__).resolve()),'worker',role,str(num)]
 with (out/'worker.stdout').open('xb')as so,(out/'worker.stderr').open('xb')as se:r=subprocess.run(['/usr/bin/taskset','-c','0-7',*shell],stdout=so,stderr=se,timeout=1200,env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8'})
 save(out/'physical.json',dict(argv=shell,exit=r.returncode,stdout_sha256=digest(out/'worker.stdout'),stderr_sha256=digest(out/'worker.stderr')))
 assert r.returncode==0,(out,(out/'worker.stderr').read_text()[-1200:]);guard();passed=jsonread(out/'passed.json');print(role,passed['ordinal'],passed['ordinary_wall_ns'],flush=True)
if __name__=='__main__':
 if sys.argv[1]=='worker':worker(sys.argv[2],int(sys.argv[3]))
 elif sys.argv[1]=='host':host(int(sys.argv[2]),Path(sys.argv[3]).resolve())
 elif sys.argv[1]=='register':
  ex=static();r={'source':ex,'runner':digest(Path(__file__)),'roles':{'parent':{'commit':'b9b3f6bba90145e25eb3b76864cfd0b5f4cbdc1f'},'candidate':{'commit':'bd03d5709719c5f0712f84573faa01b943f68cb8'}},'orders':[['parent','candidate'],['candidate','parent']],'endpoint':COMMAND,'clock':'one immediate blocking Popen.wait, each separately cold seeded','local_guard':'each ratio candidate/parent >= 1.10 vetoes if repeated in both holds; smaller or opposing results are descriptive','alloc':'12 GiB newly isolated tmpfs, dedicated output only in existing task scratch; >40 GiB physical free and total task allocation max 32 GiB before each role','qualification':'candidate sdk_for plus actual candidate-qualified record before scoring','gates':'original corrected audit, 4 real source edits, signed Cargo; fresh A plus A noop and byte/mtime-checked restored A sham; ordinary firstB singleton, B noop and independent restored-A verbose actual kernel argument display; 2 original linked archives with all 7 CLI cases; same A/B full unit graph; retained actual native bytes and ELF members. No formal hardware claim.'}
  save(Q/'registration-registry.json',r);print(digest(Q/'registration-registry.json'))
 else:raise SystemExit('modes: register, host, worker')

