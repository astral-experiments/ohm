"""Reprice every retained ordinary first edit after re-reading the four A admissions, all original clocks and B archive products."""
from pathlib import Path
import json,sys,runpy,re,statistics
p=Path(__file__).resolve().parent;s=runpy.run_path(str(p/'shipped-metadata-held.py'));old=s['old'];j=s['j'];sha=s['sha'];reg=s['reg']();root=s['root'];nativeg=s['g'];closure=s['common'](4,True);rows=[]
def archive_view(out,tag):
 return j(s['view'](out,tag)/'members.json')
for i,role in enumerate(s['roles'],1):
 out=root('clock',i);A=root('prep',i);ref=j(out/'passed-clock.json');assert ref['role']==role and ref['ordinal']==i and ref['original_registration']==sha(s['freeze']) and ref['all_four_A']==closure and sha(out/'sdk.json') and j(out/'physical.json')['exit']==0
 w=j(out/'ordinary-first-B.json');log=out/'ordinary-first-B.log';assert w['exit']==0 and w['argv']==[str(s['SDK']/'bin/cargo'),*old['CMD']] and w['cwd']==str(s['S']) and w['end_monotonic_ns']-w['start_monotonic_ns']==w['elapsed_ns']==ref['first_B_ns'] and sha(log)==ref['original_stderr']==w['log_sha256']
 finished=log.read_text().strip().splitlines()[-1];match=re.fullmatch(r'\s*Finished .+ target\(s\) in ([0-9.]+)s',finished);assert match
 bg=j(A/'restored-verbose-A/enrolled.json');kernel=j(out/'first-B-verbose/enrolled.json');v=kernel['argv'];assert sorted(v)==['build_script_build','uv_cli','uv_python']and all(bg['argv'][k]==v[k]for k in bg['argv'])
 phase1=j(out/'bare-B-products.json');phase2=j(out/'verbose-B-products.json');report=s['equivalent'](out,'bare-to-verbose-B',s['view'](out,'bare-B'),s['view'](out,'verbose-B'),phase1,phase2,'B',v,save=False);assert report==j(out/'bare-to-verbose-B-structural-replay.json')
 src=j(out/'bare-source-edited-B.json');src2=j(out/'verbose-source-edited-B.json');assert src['actual_files_verified']==src2['actual_files_verified']==1608 and src['changed_files']==src2['changed_files']and len(src['changed_files'])==4
 assert s['roster'](j(A/'roster-A.log'),j(out/'roster-B.log'))==j(out/'roster-identity.json')and len(j(A/'roster-A.log')['units'])==575
 controls=[]
 for side in ['bare','verbose']:
  probe=j(out/(side+'-B-probe.json'));old['obj'].check_probe(probe);ch=archive_view(out,side+'-B')['uv_cli'];xp=s['view'](out,side+'-B')/ch['raw']
  assert sha(xp)==ch['sha256']==probe['archive_sha256'] and old['obj'].members(xp)==probe['objects'];controls.append(probe['execute']['stdout'])
 assert controls[0]==controls[1];pre=j(A/'cold-A-probe.json');old['obj'].check_probe(pre);assert pre['execute']['stdout']!=controls[0]
 rows.append(dict(ordinal=i,role=role,hold=1 if i<=2 else 2,wall_ns=w['elapsed_ns'],cargo_reported_seconds=match[1],start_ns=w['start_monotonic_ns'],end_ns=w['end_monotonic_ns'],A_seed=closure[i-1]['full_native_seed'],compiler=j(out/'sdk.json')['commit'],sdk=sha(out/'sdk.json'),original=sha(out/'passed-clock.json'),archive=archive_view(out,'bare-B')['uv_cli']['sha256'],object_count=report['certificates']['uv_cli']['object_files'],raw_paths=report['all_raw_changes'],full_replay=sha(out/'bare-to-verbose-B-structural-replay.json'),native_products=len(phase1),kernel=sha(out/'first-B-verbose/kernel-events.json'),directory=str(out)))
assert all(b['start_ns']>a['end_ns']for a,b in zip(rows,rows[1:]));ratios=[]
for h in [1,2]:
 m={r['role']:r['wall_ns']for r in rows if r['hold']==h};ratios.append(m['candidate']/m['parent'])
result=dict(bench='real uv #20992 first linked uv-cli library build',fixed_Cargo=old['g']['CARGO']if 'g'in old else nativeg['CARGO'],admission=sha(s['freeze']),source_commits=reg['source']['source'],order=s['roles'],two_pairs=rows,ratios_candidate_over_parent=ratios,repeat_10pct_regression_veto=all(x>=1.10 for x in ratios),formal_eight_pair_governance='Unmeasured; two pairs only. Both local ratios >=1.10 veto progression regardless of #21041 check.',prior_strict_raw_refusal=sha(p/'zero-sham-refusal.json'),prior_unchanged_archive_refusal=sha(p/'parent-cold-unchanged-archive.json'),wire_validation=sha(p/'wire-verified.json'))
output=p/'metadata-held-results.json';content=json.dumps(result,sort_keys=True,indent=2)+'\n'
if output.exists():assert output.read_text()==content
else:output.write_text(content)
print(sha(output),[(r['role'],r['wall_ns'])for r in rows],ratios,result['repeat_10pct_regression_veto'])
