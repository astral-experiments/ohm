"""Run exactly the existing #20992 shipped-Cargo guard with two structurally verified archive wires."""
from pathlib import Path
import runpy,sys,json,os,re,shutil,subprocess,types,hashlib
q=Path(__file__).resolve().parent;old=runpy.run_path(str(q/'shipped.py'));m=old['host'].__globals__;oldbase=old['BASE'];w=runpy.run_path(str(q/'rlib_wire.py'));g=old['g'];j=old['j'];sha=old['sha'];put=old['put'];O=old['O'];V=old['V'];S=old['S'];T=old['T'];SDK=old['SDK'];roles=old['roles'];freeze=q/'metadata-held-registration.json';sourcebank=oldbase/'prep/01-parent';base=old['store']/'build-guard-20992-proc-derive/shipped-metadata-held-05';logic={'uv_python':177,'uv_cli':209}
roster=runpy.run_path(str(q/'roster-bijection.py'))['prove']
role_refs=j(q/'role-inventories.json');assert sha(q/'role-inventories.json')=='6a67cb7b8829ce8053fe75c07c8463025233aa111f32cc6b96902a75b2dad4e5'
rt=old['store']/'build-guard-20992-proc-derive'
previous=rt/'shipped-own-inventory-04'
cross=j(q/'crossseed-semantics.json')
assert sha(q/'crossseed-semantics.json')=='60cce2848bb9d625d78a8b78c14bfe88980f6fd7edc71fe7796e6821dee0664b'
meta=runpy.run_path(str(q/'crossseed_metadata.py'))
fixed={1:sourcebank,2:rt/'shipped-wire-roster-03/prep/02-candidate',3:previous/'prep/03-candidate',4:rt/'unscored-fourth-seed/prep/04-parent'}
def anchor(i):return fixed[i]
def crossref(before,after,crate,count,role,phase,name):
 try:return w['compare'](before,after,crate,count)
 except ValueError:pass
 row=cross['rows'][role]['stages'][phase][name];record=row['result']
 assert record['metadata_mode']=='full typed cross-seed OpaqueLifetime projection'
 proof=record['qualified'];oldpos,one,_=meta['metadata_member'](before);newpos,two,_=meta['metadata_member'](after)
 assert before==Path(row['reference']).read_bytes() and oldpos==newpos and len(one)==len(two)
 assert proof['native_complete_projection']['check_sha256']==w['ident'](two) and proof['qualified_reader']['warm']==[len(one),w['ident'](one)] and proof['qualified_reader']['cold']==[len(two),w['ident'](two)]
 assert two==meta['metadata_member'](Path(row['target']).read_bytes())[1] and all(proof['qualified_reader']['checks'].values()) and len(proof['damaged'])==3
 adjusted=bytearray(before);adjusted[oldpos:oldpos+len(one)]=two
 out=w['compare'](bytes(adjusted),after,crate,count);out.update(typed_metadata_reference=sha(q/'crossseed-semantics.json'),actual_previous_full_archive=w['ident'](before),actual_old_metadata=w['ident'](one),exact_projected_metadata=w['ident'](two),native_Zls_root=proof['native_Zls_root'])
 return out
def spec():
 a=old['inputlock']().copy();r=j(q/'wire-verified.json');assert r['oracle']==sha(q/'rlib_wire.py')and sha(q/'wire-verified.json')=='39eb878be5a45313accf68bfd4b0e0d92679b92d2408911e7eb8189d3e91c8c2'
 a.update(fixed_role_and_state_native=sha(q/'role-inventories.json'),inventory_replay_source=sha(q/'role-inventories.py'),independent_reference_rule='For every independently seeded A and B, prove both actual uv_python and uv_cli ar archives against that exact SDK/state previously linked physical enrollment, apart from rustc per-invocation name fields. No cross-compiler native content assumption. Parent A/B 177 and 209 objects; candidate A/B 183 and 209. Preserve all native bytes and programmed refusals.',refused_cross_sdk_count=sha(q/'wire-roster-registration.json'),prior_wire=sha(q/'wire-registration.json'),full_unit_bijection=sha(q/'roster-bijection.py'),roster_hostile_controls=sha(q/'roster-qualified.json'),adapter_old=sha(q/'shipped.py'),old_protocol=sha(q/'shipped-registration.json'),scope_before_candidate='Cold-to-first-unchanged raw veto retained; exact two compiler paths and identical CLI alias are the sole prospective structural classes. The raw original in every role stays preserved; within role all other final products remain byte-identical. Count and compare each of the 177/209 complete ELF objects and every parsed GNU and Rust late metadata reference, member ordering, compiled Rust metadata and symbol table. Refuse every unsupported form and changed payload.',wire_oracle=sha(q/'rlib_wire.py'),wire_controls=sha(q/'wire-controls.py'),native_source_proof=sha(q/'wire-verified.json'),parent_A_reuse=dict(path=str(sourcebank),seed=sha(sourcebank/'seed-identity.json'),cold_outputs=sha(sourcebank/'cold-A-products.json'),cold_probe=sha(sourcebank/'cold-A-probe.json'),refusal=sha(sourcebank/'cold-to-verbose-A-raw-differences.json')),roles_and_argv='P,C|C,P. Require byte-exact full unmodified rustc argv and actual six Cargo reasons across all four independent A histories before opening B. Zero cross-role native-ABI byte-equality assertion. No runtime flag, mtime, identity or uv source adjustment.',candidate_qualifier=sha(old['study']/'candidate-qualified.json'),source_exact=sha(Path(__file__)))
 a.update(fully_verified_typed_cross_seed=sha(q/'crossseed-semantics.json'),previous_no_clocks=sha(q/'own-inventory-registration.json'),four_fixed_source_histories={str(i):{'physical':sha(path/'physical.json'),'seed':j(path/'seed-identity.json')['sha256'],'linked':sha(path/'cold-A-probe.json')}for i,path in fixed.items()},typed_replay=sha(q/'crossseed-qualify.py'),sparse_native=sha(q/'sparse-lifetime.py'),typed_header=sha(q/'crossseed_metadata.py'),accepted_scope='Complete per-role cross-seed uv_python archive, including the exact preregistered A/B byte strings individually reproduced by the native sparse-DefPath metadata encoder and by rustc -Zls. All same-seed replayed cold/edited native products remain under the previous strict full rlib/filename-only oracle. All independent uv_cli remain under that same original strict cross-seed native archive oracle. Two already complete ordinary A admissions retain their previous physical and registration records.')
 return a
def reg():v=spec();assert j(freeze)==v;return v
def root(mode,i):return (previous if mode=='prep' and i in (1,2) else base)/mode/f'{i:02}-{roles[i-1]}'
def seed_file(i):return anchor(i)/'seed-A.tar.zst'
def select(inv):
 paths={}
 for name,hyphen in [('uv_python','uv-python'),('uv_cli','uv-cli')]:
  pattern=re.compile('^debug/build/'+hyphen+r'/([0-9a-f]{16})/out/lib'+name+r'-\1\.rlib$');key,=[k for k in inv if pattern.fullmatch(k)];paths[name]=key
 paths['uv_cli_alias']='debug/libuv_cli.rlib';assert inv[paths['uv_cli_alias']]==inv[paths['uv_cli']];return paths
def argv_path(name,argv):
 assert argv[argv.index('--crate-name')+1]==name;d=Path(argv[argv.index('--out-dir')+1])
 x=[v.removeprefix('extra-filename=')for i,v in enumerate(argv)if i and argv[i-1]=='-C'and v.startswith('extra-filename=')]+[v.removeprefix('-Cextra-filename=')for v in argv if v.startswith('-Cextra-filename=')];suffix,=x;return str((d/('lib'+name+suffix+'.rlib')).relative_to(T))
def retained_to(out,label,prods):
 keys=select(prods);dest=out/'raw-archive-views'/label;dest.mkdir(parents=True);roster={}
 for n,rel in keys.items():
  real=T/rel;item=prods[rel];raw=real.read_bytes();assert len(raw)==item['bytes'] and w['ident'](raw)==item['sha256']
  if n!='uv_cli_alias':
   fn=dest/(n+'.rlib');fn.write_bytes(raw)
  else:
   fn=dest/'uv_cli.rlib';assert raw==fn.read_bytes()
  roster[n]=dict(rel=rel,sha256=item['sha256'],bytes=item['bytes'],raw=fn.name,real_alias_same_inode=(real.samefile(T/keys['uv_cli'])if n=='uv_cli_alias'else None))
 put(dest/'members.json',roster);return roster
def view(out,tag):return out/'raw-archive-views'/tag
def equivalent(out,label,left,right,y,z,phase,kernel=None,save=True):
 keys=select(y);assert keys==select(z);allowed=['uv_python']if phase=='A'else['uv_python','uv_cli'];oldr=j(left/'members.json');newr=j(right/'members.json')
 if kernel is not None:
  for k in allowed:assert argv_path(k,kernel[k])==keys[k]
 for n in keys:
  for where,rr,iv in [(left,oldr,y),(right,newr,z)]:
   x=rr[n];assert x['rel']==keys[n] and sha(where/x['raw'])==iv[x['rel']]['sha256']==x['sha256']
  if n=='uv_cli_alias':
   for rr in [oldr,newr]:assert rr['uv_cli']['raw']==rr[n]['raw']and rr['uv_cli']['sha256']==rr[n]['sha256']
 diffs=sorted(k for k in y.keys()|z.keys()if y.get(k)!=z.get(k));allow={keys[k]for k in allowed}
 if phase=='B':allow.add(keys['uv_cli_alias'])
 if save:put(out/(label+'-all-raw-differences.json'),{k:[y.get(k),z.get(k)]for k in diffs})
 if not set(diffs)<=allow:
  if save:
   dest=out/(label+'-unexpected-raw');dest.mkdir();sz=0
   for k in set(diffs)-allow:
    if k in z:
     p=T/k;sz+=p.stat().st_size;assert sz<2<<30;d=dest/z[k]['sha256']
     if not d.exists():shutil.copyfile(p,d);assert sha(d)==z[k]['sha256']
  raise ValueError(('unexpected other raw product(s)',diffs))
 sdk_role=j(out/'sdk.json')['role'];fixed=role_refs['stages'][sdk_role]['states'][phase];certificates={};reference={}
 for k in allowed:
  cut=lambda d,r:(d/r[k]['raw']).read_bytes()
  st=Path(keys[k]).name[3:-5];certificates[k]=w['compare'](cut(left,oldr),cut(right,newr),st,fixed[k]['native_objects'])
 for k in ['uv_python','uv_cli']:
  ff=fixed[k];rr=Path(ff['reference']).read_bytes();assert w['ident'](rr)==ff['reference_proof']['before']and ff['crate']==Path(keys[k]).name[3:-5];ct=ff['native_objects'];reference[k]={tag:crossref(rr,(cur/ro[k]['raw']).read_bytes(),ff['crate'],ct,sdk_role,phase,k)for tag,cur,ro in [('left',left,oldr),('right',right,newr)]}
 ret=dict(phase=phase,all_raw_changes=diffs,total_products=len(y),certificates=certificates,own_independently_linked_native_references=reference,other_raw_identical=len(y)-len(diffs))
 if save:put(out/(label+'-structural-replay.json'),ret)
 return ret
def prepare(i,role,r,driver):
 old['source_env']()
 if i in fixed:
  f=seed_file(i);rec=j(anchor(i)/'seed-identity.json');assert sha(f)==rec['sha256'] and (j(anchor(i)/'physical.json')['exit']==0)==(i==4) and j(anchor(i)/'sdk.json')['role']==role
  a=old['restore'](f,rec)
 else:a=old['mat'].install(S)
 put(O/'source-A.json',a);graph=j(sourcebank/'roster-A.log')
 _,raw=g['execute']('roster-A',[SDK/'bin/cargo','build','--unit-graph','-Zunstable-options','--locked','--offline','-j8','-p','uv-cli'])
 put(O/'roster-identity.json',roster(graph,json.loads(raw)));assert len(graph['units'])==575
 if i not in fixed:g['execute']('cold-A',[SDK/'bin/cargo',*old['CMD'],'-vv'])
 pre=old['native_proof'](T);put(O/'cold-A-products.json',pre);retained_to(O,'cold-A',pre);nativeA=old['parser']('cold-A','A',role,driver)
 if i in fixed:assert pre==j(anchor(i)/'cold-A-products.json')and nativeA['archive_sha256']==j(anchor(i)/'cold-A-probe.json')['archive_sha256']
 else:rec=old['pack'](O/'seed-A.tar.zst')
 put(O/'seed-identity.json',rec);f=seed_file(i);captures={}
 for name,verbose in [('verbose',True),('plain',False),('bare',None)]:
  old['restore'](f,rec)
  if verbose is not None:
   cr=old['kernel']('restored-'+name+'-A',verbose);captures[name]=cr
   if name=='verbose':old['checkbg'](cr,r)
   else:assert cr['argv']==captures['verbose']['argv']
  else:
   g['standard']('restored-bare-A',None);flags=re.findall(r'^\s*Compiling (\S+)',(O/'restored-bare-A.log').read_text(),re.M);assert sorted(flags)==sorted(r['expected_dirty_reasons'])
  current=old['native_proof'](T);put(O/(name+'-A-products.json'),current);retained_to(O,name+'-A',current)
  equivalent(O,'cold-to-'+name+'-A',view(O,'cold-A'),view(O,name+'-A'),pre,current,'A',captures['verbose']['argv'])
  witness=old['parser'](name+'-A','A',role,driver);assert witness['archive_sha256']==nativeA['archive_sha256'] and witness['objects']==nativeA['objects'] and witness['execute']['stdout']==nativeA['execute']['stdout']
  if name=='verbose':old['collect_depinfo']('verbose-A')
 put(O/'passed-prep.json',dict(role=role,num=i,reg=sha(freeze),seed=rec,roster=sha(O/'roster-A.log'),native_products=len(pre),orig=sha(O/'cold-A-products.json'),archive=sha(O/'cold-A-probe.json'),bg=sha(O/'restored-verbose-A/enrolled.json'),sdk=sha(O/'sdk.json'),source=sha(O/'source-A.json'),physical_before_B=True))
def common(count,require_all):
 ref=None;rows=[]
 for i in range(1,count+1):
  p=root('prep',i);v=j(p/'passed-prep.json');assert v['role']==roles[i-1] and v['num']==i and v['reg']==(sha(q/'own-inventory-registration.json') if i in (1,2) else sha(freeze))and v['bg']==sha(p/'restored-verbose-A/enrolled.json')and j(p/'physical.json')['exit']==0
  a=j(p/'restored-verbose-A/enrolled.json');b=j(p/'restored-plain-A/enrolled.json');assert a['argv']==b['argv'];old['checkbg'](a,reg())
  if ref is None:ref=a
  if ref['argv']!=a['argv'] or ref['dirty']!=a['dirty']:
   keyed={k:[(n,x,y)for n,(x,y) in enumerate(zip(ref['argv'][k],a['argv'].get(k,[])))if x!=y]for k in ref['argv']};raise ValueError(('cross-role background differs; no B',[(k,len(v),v[:2])for k,v in keyed.items()]))
  cold=j(p/'cold-A-products.json')
  for state in ['verbose','plain','bare']:
   loc='cold-to-'+state+'-A';rr=equivalent(p,loc,view(p,'cold-A'),view(p,state+'-A'),cold,j(p/(state+'-A-products.json')),'A',a['argv'],save=False);assert rr==j(p/(loc+'-structural-replay.json'))
  rows.append(dict(i=i,role=v['role'],sdk=v['sdk'],A_prep=sha(p/'passed-prep.json'),full_native_seed=v['seed']['sha256']))
 if require_all:assert count==4 and [x['role']for x in rows]==roles
 return rows
def clock(i,role,r,driver):
 allpre=common(4,True);p=root('prep',i);seed=seed_file(i);rec=j(p/'seed-identity.json');A=j(p/'cold-A-probe.json');background=j(p/'restored-verbose-A/enrolled.json')
 results={};probes={};vectors=None
 for mode in ['bare','verbose']:
  old['restore'](seed,rec);actual=old['mat'].apply_b(S);assert len(actual['changed_files'])==4;put(O/(mode+'-source-edited-B.json'),actual)
  if mode=='bare':clockrec=g['standard']('ordinary-first-B',None)
  else:
   kernel=old['kernel']('first-B-verbose',True);vectors=kernel['argv'];assert sorted(vectors)==['build_script_build','uv_cli','uv_python'];assert all(vectors[k]==v for k,v in background['argv'].items())and kernel['dirty']['uv-python']==r['expected_dirty_reasons']['uv-python']
   av=vectors['uv_cli'];assert any(x.endswith('crates/uv-cli/src/lib.rs')for x in av)and any('incremental='in x for x in av);em=next((x.partition('=')[2]for x in av if x.startswith('--emit=')),None)or av[av.index('--emit')+1];assert {'dep-info','metadata','link'}<=set(em.split(','))
  data=old['native_proof'](T);put(O/(mode+'-B-products.json'),data);retained_to(O,mode+'-B',data);results[mode]=data
  probes[mode]=old['parser'](mode+'-B','B',role,driver);old['obj'].check_probe(probes[mode])
 assert probes['bare']['execute']['stdout']==probes['verbose']['execute']['stdout'];pairproof=equivalent(O,'bare-to-verbose-B',view(O,'bare-B'),view(O,'verbose-B'),results['bare'],results['verbose'],'B',vectors)
 for v in ['bare','verbose']:assert probes[v]['archive_sha256']==j(view(O,v+'-B')/'members.json')['uv_cli']['sha256']
 _,raw=g['execute']('roster-B',[SDK/'bin/cargo','build','--unit-graph','-Zunstable-options','--locked','--offline','-j8','-p','uv-cli']);put(O/'roster-identity.json',roster(j(p/'roster-A.log'),json.loads(raw)))
 put(O/'passed-clock.json',dict(ordinal=i,role=role,original_registration=sha(freeze),all_four_A=allpre,first_B_ns=clockrec['elapsed_ns'],source=sha(O/'bare-source-edited-B.json'),clock=sha(O/'ordinary-first-B.json'),original_stderr=sha(O/'ordinary-first-B.log'),kernel=sha(O/'first-B-verbose/enrolled.json'),raw_diff=pairproof['all_raw_changes'],complete_wire=sha(O/'bare-to-verbose-B-structural-replay.json'),A_to_B_archive=old['obj'].compare(A,probes['bare']),all_native_products=len(results['bare']),behavior=sha(O/'bare-B-probe.json')))
# Use the original source, SDK, namespace, capacity and acquisition code; only bind this immutable successor and the narrower representation proof.
m.update(BASE=base,common=common,prep=prepare,clock=clock,reg=reg,__file__=str(Path(__file__).resolve()))
if __name__=='__main__':
 if sys.argv[1]=='register':put(freeze,spec());print(sha(freeze))
 elif sys.argv[1]=='precursors':print(common(int(sys.argv[2]),False))
 else:old['main']()

