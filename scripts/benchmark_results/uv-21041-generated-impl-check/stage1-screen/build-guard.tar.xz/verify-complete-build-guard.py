"""Reopen all native metadata and object gates and then reprice the original ordinary build visits."""
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
for component in (
    "role-inventories.py",
    "own-hostile-controls.py",
    "crossseed-qualify.py",
    "verify-metadata-held-panel.py",
):
    runpy.run_path(str(HERE / component), run_name="__main__")

