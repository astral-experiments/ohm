"""Recompute both independent real signed-Rust hash failures from the supplied original metadata."""
from collections import Counter
from pathlib import Path
import gzip,hashlib,json,re,runpy,tarfile,tempfile

ROOT=Path(__file__).resolve().parent
def sha(x):return hashlib.sha256(x).hexdigest()
def read(path):return json.loads(path.read_bytes())
def verify():
    sums=read(ROOT/"files.json")
    assert {str(f.relative_to(ROOT))for f in ROOT.rglob("*")if f.is_file()and f.name!="files.json"}==sums.keys()
    assert all(sha((ROOT/name).read_bytes())==digest for name,digest in sums.items())
    case=read(ROOT/"case.json");reg=read(ROOT/"registration.json")
    assert reg["roles"]["R_release"]["rustc"]=="008a21ac0d750dc9a1c18b7959d7e7984c03d887" and reg["cargo_command"]==["cargo","check","-p","uv-client","--locked","--offline","-j8"]
    assert (case["A"],case["B"])==("8ca75796365f348e25d3f7bea9daa1440218d40b","362613dbf38f60fe285cdd6bca53641149a23c04")
    kit=ROOT/"metadata-kit.tar.xz";assert sha(kit.read_bytes())==case["kit_sha"]
    with tempfile.TemporaryDirectory()as tmp:
        work=Path(tmp)
        with tarfile.open(kit)as t:
            assert set(t.getnames())==set(case["toolkit"])
            for item in t:
                assert item.isfile()and not Path(item.name).is_absolute()and ".."not in Path(item.name).parts
                data=t.extractfile(item).read();assert sha(data)==case["toolkit"][item.name]
                dest=work/item.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        dec=runpy.run_path(str(work/case["kit_module"]))["Z"]
        histories=[]
        for tag in ("01","02"):
            d=ROOT/("history-"+tag);warm=read(d/"warm-inventory.json");cold=read(d/"cold-inventory.json");assert read(d/"bare-inventory.json")==warm
            assert len(warm["workspace"])==len(cold["workspace"])==39 and len(warm["all_public_sidecars"])==len(cold["all_public_sidecars"])==423
            dirty=read(d/"warm-forms.json");assert set(dirty)=={"uv_configuration","uv_client"}and all(len(v)==1 for v in dirty.values())
            differing=[n for n,v in warm["all_public_sidecars"].items()if cold["all_public_sidecars"][n]!=v]
            assert len(differing)==1 and Path(differing[0]).name=="lib-uv_client.public-api-hash"
            records={}
            for name in ("uv_client","uv_configuration"):
                path,=[n for n in warm["workspace"]if Path(n).name.startswith("lib"+name+"-")]
                bytes_=[]
                for kind,inv in (("warm",warm),("cold",cold)):
                    raw=(d/(kind+"."+name+".rmeta")).read_bytes();assert [len(raw),sha(raw)]==inv["workspace"][path]
                    bytes_.append(raw)
                result=dec["delta"](*bytes_,name);sem=result["semantic"];xs=sem["allocations"];h=sem["header"]
                assert result["identical_stable_def_set"] and not any(sem["missing_keys"]) and not sem["def_key_descriptor_differences"]
                assert sem["exact_all_dependencies"] and sem["exact_keyed_reachable_expansions"]
                assert all(a==b for k,(a,b)in h.items()if k!="public_svh") and not xs["multisets_identical"]
                if name=="uv_client":
                    assert h["public_svh"]==["86b91d18cf9d9766036dbeab56d30586","6073d32f197ad3f221c0f2bb85b31698"]
                    assert sem["defs"]==[6292,6292]and sem["changed_RDR_key_count"]==2564 and xs["total"]==[548,547]and xs["distinct"]==[430,430]
                    for i,(kind,inv)in enumerate((("warm",warm),("cold",cold))):
                        original=(d/(kind+".sidecar.json")).read_bytes()
                        assert [len(original),sha(original)]==inv["all_public_sidecars"][differing[0]]
                        assert json.loads(original)=={"version":1,"value":h["public_svh"][i]}
                        assert re.search(r"(?m)^public_hash ([0-9a-f]{32})$",(d/(kind+".uv_client-ls.txt")).read_text())[1]==h["public_svh"][i]
                else:
                    assert h["public_svh"][0]==h["public_svh"][1]and sem["changed_RDR_key_count"]==0 and xs["total"]==[303,301]
                records[name]={"bytes":[len(v)for v in bytes_],"sha256":[sha(v)for v in bytes_],"rdr_changes":sem["changed_RDR_key_count"],"definitions":sem["defs"],"public":h["public_svh"],"ctfe_allocation_totals":xs["total"],"shared_literal_patterns_with_different_multiplicities":xs["shared_immutable_pointer_free_text_with_different_multiplicities"]}
            for name in ("A","warm","cold"):
                obs=read(d/(name+"-witness.json"))
                assert obs["codes"]["schema"]==([1,["E0432"]]if name=="A"else[0,[]]) and obs["codes"]["client-negative"]==[1,["E0308"]]
                assert obs["linked"]["existing"]["actual"]==[[None,"columns, text\n"]]
                if name!="A":assert obs["linked"]["schema"]["actual"]==[[v,'"preview"\n']for v in (None,"preview","future-version","")]
            histories.append(records)
    assert len({data["uv_client"]["sha256"][i] for i in (0,1)for data in histories})==4
    return {"independent_native_histories":2,"actual_dirty_rustc":["uv_configuration","uv_client"],"other_matching_public_sidecars":422,
            "signed_release_clock_observations":0,"histories":histories}
if __name__=="__main__":print(json.dumps(verify(),indent=2,sort_keys=True))
