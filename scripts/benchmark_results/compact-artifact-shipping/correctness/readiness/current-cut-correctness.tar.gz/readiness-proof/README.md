This bundle records the narrowed compact-artifact candidate before the new performance matrix completes. Independent review found **no remaining correctness/safety blocker within the reviewed source and native test scope**. This is not an adoption recommendation: performance evidence remains pending, and compiler CI remains blocked by missing private-source credentials.

The reviewed Rust patch is `8c24f6cf911c0829de90e5ec49b0ae04598f00d983168c9e1d126bef1d555275`, applied to `9546795cae23d424bec08487b4f3cace591efb5a` and published unchanged as `3b84b46e3fb38f80246f744275c69fe608dfb2f3`. The subsequent `54f8b75ac31207d47af50fc8c5bc9dc90f2457de` changes only the Cargo gitlink. [Publication equality](storeless-cut/source-publication.json) and the [33-path manifest](storeless-cut/candidate-manifest.json) preserve that boundary.

The cut removes the experimental Rust wrapper/indexed-metadata/external-store interfaces and restores 13 decoder, mapping, and metadata paths to the original baseline. It retains self-contained ar archives with compact objects and raw metadata, codec tuning, and the complete archive/member scan. No metadata-schema shortcut, filename assumption, or sidecar dependency was introduced. Ordinary-linker/staticlib/doctest/replay conversion, metadata-prefix invalidation and corruption fallback, atomic object publication, and hardlink safety remain covered. The unrelated external-DWO workaround was removed to restore baseline behavior; compact packing does not alter those external files. See the [independent source review](storeless-cut/independent-review.json) and [current correctness review](readiness/correctness-review.json).

Native Linux proofs and the frozen performance matrix use Cargo `4a2813050da607ca5cfe7b5cf3a17ba7c9676be1` and Wild `9179eb988df2676342192a24dc337cf9823e9d56`. The candidate Linux driver SHA-256 is `a254b72ecfd128572bc1c09e2579de84f7d88006129588b9bc8f1c8e8929ed01`; its macOS counterpart is `47c9235e742c82e66d6cd6334087edce5b1e9198d757d3643bf03900923caf1f`. Identity comes from recorded byte hashes, not version strings. The published Cargo cleanup `0d39870c83ccf09a250e55d9dd13a83d606b72be` only removes obsolete flag validation; its eight enabled CI jobs passed, but that later Cargo binary is not substituted into this matrix.

Verified coverage:

- Linux: two forced compiler run-make suites; actual rustc-component tar generation/install with bundled Wild, capability marker, and license checks; default and opt-in installed smoke tests. This uses separately supplied std and Cargo, not a full production distribution or PGO/BOLT build.
- Fresh native controls: Cargo private replay/public invalidation, ordinary/compact toggles, errors, doctests, registry sharing and cleanup; 64/4,096/16,777,216-byte alignment through BFD/LLD and fresh/green staticlibs; a real Btrfs worktree with 45 seeded files, 19 independent compact child objects, seven donor paths hidden, standalone archive linking, runtime changes 42→43→44, and second-edit replay. The new owned image was detached and retained. Preservation of the older image is based on stat/inode/size/mtime and reviewed no-write paths, not a full image hash.
- macOS: optimized non-PGO stage1 compiler/rustdoc/std build, ordinary link/runtime, clean rejection of unsupported compact output, 12 metadata UI cases and nine focused run-makes (21 passed, none failed or ignored). A full optimized distribution remains unbuilt.
- Fixture admission: all 26 v2 source/runtime states passed, including each edited uv diagnostic. Zero preflight rows are accepted performance timings. The v1 rejection is retained: requirements-file parsing intercepted the intended diagnostic, so v2 invokes `uv pip install '=foo' --no-index --offline` directly. The failed 14th row and partial oracle are not pooled into timing data.

Raw initial LLVM assembly/cache errors, the missing linker-directory setup, the macOS rustdoc bookkeeping interruption, and the successful repairs remain in the bundle. Rust `54f8` CI stopped in all three jobs while creating the dedicated read-only source token because its client ID was missing; downstream compiler CI was not executed. No credentials were configured and no release was performed. The [local 200-check audit](readiness/current-cut-correctness-audit.json) and portable receipt audit distinguish observed host execution from review of archived proof.

The scanner profile is an instrumented current-954 diagnostic, not an accepted timing result or the original measured compiler. The new matrix holds Cargo/Wild fixed and compares baseline, current ordinary, narrowed ordinary, and narrowed compact across four balanced fresh rounds. Each edit class has three sequential edits per round; these are four independent rounds, not twelve. Numerical continuity with the older e55 study and causal attribution of its slowdown are not presumed.

To verify this archive after extraction, use Python 3.11 or newer from the `readiness-proof` directory. These commands need no compiler, network, credentials, or original absolute paths; they write their new results beside the extracted directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 verify_inventory.py .
PYTHONDONTWRITEBYTECODE=1 python3 readiness/harness/audit_preflight.py readiness/evidence --original-build provenance/original-compiler-build.json --output ../preflight-audit.json
PYTHONDONTWRITEBYTECODE=1 python3 readiness/harness/audit_correctness.py . --output ../correctness-audit.json
```

The inventory covers every regular payload file except itself; the external seal covers the inventory and compressed archive. Raw evidence bytes are unchanged. Compiler binaries, filesystem images, distribution archives, build caches, live partial timing status, and the unexecuted final-Cargo proof are excluded. Historical path strings in receipts are provenance, not local dependencies. `readiness/control/` contains host-specific execution controls for inspection; do not run them as portable audits.

A later matrix supplement may add `readiness/evidence/real-edit-matrix/` and its collection records without replacing sealed files. Verify the original inventory with `--allow-additions`, verify the supplement's own inventory, then run:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 readiness/harness/audit_readiness.py readiness/evidence --original-build provenance/original-compiler-build.json --harness readiness/harness/benchmark_readiness_v2.py --source-snapshots readiness/evidence/fixture-originals --output ../matrix-audit.json
```

The independent matrix auditor also accepts `--summary PATH` to compare the separately calculated summary and `--transfer-manifest PATH --transfer-root .` to verify its collection. No matrix result is included or claimed by this pre-performance seal.
