from pathlib import Path
import hashlib,json,subprocess
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness');dest=work/'evidence/fixture-originals';assert not dest.exists();dest.mkdir()
paths={'ruff':['crates/ruff/src/main.rs','crates/ruff/src/lib.rs','crates/ruff_linter/src/rules/pyflakes/rules/unused_variable.rs'], 'uv':['crates/uv/src/bin/uv.rs','crates/uv/src/lib.rs','crates/uv/src/commands/cache_dir.rs','crates/uv-pep508/src/lib.rs']}
manifest={}
for project,names in paths.items():
 source=work/'sources'/project;original=(work/'evidence'/f'{project}-compatibility.patch').read_bytes()
 assert subprocess.check_output(['git','diff','--binary'],cwd=source)==original
 manifest[project]={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'files':{}}
 for name in names:
  data=(source/name).read_bytes();target=dest/project/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  manifest[project]['files'][name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
