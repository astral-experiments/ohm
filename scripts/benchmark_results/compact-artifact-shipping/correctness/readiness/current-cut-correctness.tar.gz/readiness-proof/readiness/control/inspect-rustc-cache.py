from pathlib import Path
import json
root=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/bootstrap')
for p in root.rglob('.rustc_info.json'):
 try:
  data=p.read_text()
  if 'libLLVM' in data or 'exit_status' in data:print(str(p),data[:4000])
 except OSError:pass
