from pathlib import Path
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/evidence/candidate-build')
print((root/'compiler-build-resume.log').read_text()[-10000:])
