from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/home/dev-user/code/oss/ohm-compact-study');work=root/'shipping/readiness';evidence=work/'evidence'
name='preservation-after' if (evidence/'real-edit-matrix/status.json').exists() else 'preservation-before'
destination=evidence/(name+'.json');assert not destination.exists()
def digest(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
reference=root/'shipping/final-review/bounds-fix/evidence/measured-artifacts-after.json';expected=json.loads(reference.read_text())
errors=[]
for path,row in expected.items():
 p=Path(path)
 if not p.is_file() or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256'] or ('symlink' in row and (not p.is_symlink() or os.readlink(p)!=row['symlink'])):errors.append(path)
assert not errors,errors[:20]
current=json.loads((root/'shipping/final-review/bounds-fix/evidence/compiler-build.json').read_text())
for name,sha in current['drivers'].items():assert digest(root/'toolchains/compact-final-review-bounds/lib'/name)==sha
assert digest(root/'shipping/final-review/bin/cargo')==current['cargo']['sha256']
preparation=json.loads((evidence/'preparation.json').read_text())
for project in ('ruff','uv'):
 for path in (root/'sources'/project,work/'sources'/project):
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()==preparation['sources'][project]['head']
  assert hashlib.sha256(subprocess.check_output(['git','diff','--binary'],cwd=path)).hexdigest()==preparation['sources'][project]['patch_sha256']
for project,path in [('rust',root/'rust'),('wild',root/'wild'),('cargo',root/'shipping/cargo')]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()==current['sources'][project]
 assert not subprocess.check_output(['git','status','--porcelain','--ignore-submodules=all'],cwd=path,text=True).strip()
image=root/'cow-fixture.img';assert image.is_file()
loops=subprocess.check_output(['losetup','-j',str(image)],text=True).strip();assert not loops
stat=image.stat()
receipt={'passed':True,'checked_at':time.time(),'reference':str(reference),'reference_sha256':digest(reference),'retained_measured_files_verified':len(expected),'prior_current_driver_and_cargo_verified':True,'original_sources_unchanged':True,'fixture_sources_restored':True,'image':{'path':str(image),'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns,'inode':stat.st_ino,'detached':True}}
destination.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
