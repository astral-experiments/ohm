from pathlib import Path
import subprocess,json
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/sources')
print(json.dumps({str(p):p.read_text() for project in ('ruff','uv') for p in (root/project).rglob('AGENTS.md')},indent=2))
print(subprocess.check_output(['ps','-eo','pid,etime,pcpu,rss,comm,args'],text=True)[-6000:])
