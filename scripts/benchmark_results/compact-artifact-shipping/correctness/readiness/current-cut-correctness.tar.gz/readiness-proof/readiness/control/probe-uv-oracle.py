from pathlib import Path
import subprocess,json,os
binary=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/fixture-preflight/uv/round-0/storeless/target/debug/uv')
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/evidence/fixture-preflight/uv-storeless-0/oracle-work')
env={k:v for k,v in os.environ.items() if not k.startswith(('UV_','OHM_'))};env.update(NO_COLOR='1',TERM='dumb',UV_NO_PROGRESS='1')
args=[str(binary),'--no-config','--offline','--color','never','--cache-dir',str(root/'cache'),'pip','install','--no-index','=foo']
p=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True,timeout=30)
r={'args':args,'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};(root.parent/'oracle-adjustment-probe.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
