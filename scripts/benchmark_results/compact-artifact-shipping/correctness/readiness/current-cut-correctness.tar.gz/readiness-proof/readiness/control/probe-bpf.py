from pathlib import Path
import json,subprocess
p=subprocess.run(['sudo','-n','bpftrace','-e','BEGIN { printf("probe ready\\n"); exit(); }'],capture_output=True,text=True)
print(json.dumps({'bpf':{'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}}))
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness')
print((root/'evidence/preparation.json').read_text() if (root/'evidence/preparation.json').is_file() else 'preparation pending')
