"""Run candidate-specific functional tests serially before the readiness timing matrix."""
from pathlib import Path
import hashlib,json,os,platform,shutil,subprocess,time
STUDY=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=STUDY/'shipping/readiness'
SCRIPTS=Path(__file__).resolve().parent;TARGET=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/correctness')
EVIDENCE=WORK/'evidence/correctness';SYSROOT=WORK/'toolchains/storeless';CARGO=STUDY/'shipping/final-review/bin/cargo'
PATCH='8c24f6cf911c0829de90e5ec49b0ae04598f00d983168c9e1d126bef1d555275'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
assert platform.system()=='Linux' and platform.machine()=='x86_64'
assert not EVIDENCE.exists() and not TARGET.exists()
assert shutil.disk_usage(WORK).free>10*1024**3
preflight=load(WORK/'evidence/fixture-preflight-v2/status.json');assert preflight['passed'] and preflight['samples']==26 and preflight['accepted']==0
assert not (WORK/'evidence/real-edit-matrix/samples.jsonl').exists(), 'functional tests must precede measured matrix'
build_path=WORK/'evidence/candidate-build/result.json';package_path=WORK/'evidence/candidate-package/result.json'
build=load(build_path);package=load(package_path);assert build['passed'] and package['passed']
assert build['patch_sha256']==package['patch_sha256']==PATCH and build['wild']=='9179eb988df2676342192a24dc337cf9823e9d56'
assert Path(build['toolchain']['path'])==SYSROOT
assert package['driver_hashes']==build['toolchain']['drivers']
preflight_provenance=load(WORK/'evidence/fixture-preflight-v2/provenance.json')
assert preflight_provenance['script_sha256']=='4ddd91a0cc2003347f789fce4722da9bb4b27e264abff1266d6e9c0ca0732588'
assert preflight_provenance['toolchains']['storeless']['drivers']==build['toolchain']['drivers']
assert preflight_provenance['cargo']['sha256']==build['toolchain']['cargo_sha256']
expected={SYSROOT/'lib'/name:sha for name,sha in build['toolchain']['drivers'].items()}
expected[CARGO]=build['toolchain']['cargo_sha256'];expected[SYSROOT/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd']=build['toolchain']['wild_sha256']
assert expected and all(digest(p)==sha for p,sha in expected.items())
assert (SYSROOT/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/compact-artifacts-v1').read_bytes()==b'RCOBJ001\n'
manifest=load(SCRIPTS/'derivation.json')
for name,row in manifest.items():assert digest(SCRIPTS/name)==row['derived_sha256']
old_image=STUDY/'cow-fixture.img';old_stat=old_image.stat();old_identity=(old_stat.st_dev,old_stat.st_ino,old_stat.st_size,old_stat.st_mtime_ns)
assert old_image.is_file() and not old_image.is_symlink()
EVIDENCE.mkdir();TARGET.mkdir()
receipt={'passed':False,'started':time.time(),'rust_source_commit':'3b84b46e3fb38f80246f744275c69fe608dfb2f3','rust_base':build['base'],'patch_sha256':PATCH,'wild':build['wild'],'cargo_source':'4a2813050da607ca5cfe7b5cf3a17ba7c9676be1','candidate_build_sha256':digest(build_path),'candidate_package_sha256':digest(package_path),'preflight_sha256':digest(WORK/'evidence/fixture-preflight-v2/status.json'),'preflight_provenance_sha256':digest(WORK/'evidence/fixture-preflight-v2/provenance.json'),'script_sha256':digest(Path(__file__)),'derivation':manifest,'expected_binaries':{str(p):s for p,s in expected.items()},'old_image_identity':old_identity,'commands':[]}
def save():(EVIDENCE/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST'))};env['PYTHONDONTWRITEBYTECODE']='1'
def run(label,args):
 log=EVIDENCE/(label+'.log');start=time.monotonic();row={'label':label,'argv':list(map(str,args))};receipt['commands'].append(row);save()
 with log.open('w') as f:result=subprocess.run(row['argv'],cwd=WORK,env=env,stdout=f,stderr=subprocess.STDOUT)
 row.update(exit_code=result.returncode,seconds=time.monotonic()-start,log_sha256=digest(log));save();print(json.dumps(row),flush=True);assert result.returncode==0,label
try:
 bridge={'sysroot':str(SYSROOT),'version':build['toolchain']['version'],'drivers':build['toolchain']['drivers'],'source_build_receipt_sha256':digest(build_path),'patch_sha256':PATCH}
 (EVIDENCE/'alignment-build.json').write_text(json.dumps(bridge,indent=2)+'\n')
 run('lifecycle',['python3',SCRIPTS/'cargo_lifecycle.py','--cargo',CARGO,'--rustc',SYSROOT/'bin/rustc','--rustdoc',SYSROOT/'bin/rustdoc','--source-root',WORK/'fixtures/lifecycle','--target-root',TARGET/'lifecycle','--output',EVIDENCE/'lifecycle.json'])
 lld=STUDY/'toolchains/compact-final-review/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld'
 assert digest(lld)=='9f47056ea756a869ce9d130f4633894c0c0a17ef8575d32a16f6f43397c5228c'
 run('alignment',['python3',SCRIPTS/'alignment_correctness.py','--study',STUDY,'--rustc',SYSROOT/'bin/rustc','--target',TARGET/'alignment','--receipt',EVIDENCE/'alignment.json','--lld',lld,'--build-receipt',EVIDENCE/'alignment-build.json'])
 run('worktree',['python3',SCRIPTS/'worktree_correctness.py','--cargo',CARGO,'--rustc',SYSROOT/'bin/rustc','--rustdoc',SYSROOT/'bin/rustdoc','--case','storeless-candidate','--output',EVIDENCE/'worktree.json'])
 for name in ('lifecycle','alignment','worktree'):assert load(EVIDENCE/(name+'.json'))['passed']
 alignment=load(EVIDENCE/'alignment.json');assert [c['alignment'] for c in alignment['cases']]==[64,4096,1<<24]
 assert all(c['ordinary_lld_runtime'].get('value')==90 and c['ordinary_bfd_runtime'].get('value')==90 for c in alignment['cases'])
 assert all(digest(p)==sha for p,sha in expected.items());receipt['binaries_unchanged']=True
 info=old_image.stat();assert (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns)==old_identity
 receipt.update(old_image_unchanged=True,passed=True)
except BaseException as error:receipt['error']=f'{type(error).__name__}: {error}';raise
finally:receipt['finished']=time.time();save()
