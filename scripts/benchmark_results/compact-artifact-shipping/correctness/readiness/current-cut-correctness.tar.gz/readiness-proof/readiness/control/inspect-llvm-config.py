from pathlib import Path
import subprocess,json
base=Path('/tmp/codex-cargo-targets/ohm/isolated')
for name in ('compact-objects','compact-readiness'):
 root=base/name/'bootstrap/x86_64-unknown-linux-gnu'
 p=root/'ci-llvm/bin/llvm-config'
 print(name,subprocess.run([str(p),'--libfiles'],capture_output=True,text=True).__dict__)
 for folder in (root/'ci-llvm/lib',root/'stage1/lib'):
  print([(str(p),p.is_symlink(),str(p.readlink()) if p.is_symlink() else '') for p in folder.glob('libLLVM*')])
 print('cfg', (root/'ci-llvm/bin/llvm-config').read_bytes()[:100])
