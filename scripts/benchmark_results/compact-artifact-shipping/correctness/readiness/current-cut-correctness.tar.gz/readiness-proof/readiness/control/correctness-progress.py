from pathlib import Path
import json,shutil
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness')
p=work/'evidence/correctness/result.json'
result={'freeGiB':shutil.disk_usage(work).free/1024**3,'started':p.exists()}
if p.exists():
 r=json.loads(p.read_text());result['correctness']={k:r.get(k) for k in ('passed','error','binaries_unchanged','old_image_unchanged','commands','finished')}
print(json.dumps(result,indent=2))
