from pathlib import Path
import hashlib,json
out=Path(__file__).parent;old=Path('/private/tmp/ohm-compact-shipping/control')
sources={'cargo_lifecycle.py':old/'final-review-inputs/cargo_lifecycle.py','alignment_correctness.py':old/'alignment_correctness.py','worktree_correctness.py':old/'worktree_correctness.py'}
records={}
for name,path in sources.items():
 text=path.read_text();records[name]={'source':str(path),'original_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 if name=='alignment_correctness.py':
  assert text.count("['-Zcompact-artifacts=yes', '-Zcompress-incremental=no']")==1
  text=text.replace("['-Zcompact-artifacts=yes', '-Zcompress-incremental=no']","['-Zcompact-artifacts=yes']")
 if name=='worktree_correctness.py':
  text=text.replace('Validate compact archive worktree seeds on the retained, owned Btrfs fixture.','Validate compact archive worktree seeds on a fresh, owned Btrfs fixture.')
  text=text.replace('No compiler build. No formatting or deletion of the retained image. Only the','No compiler build. Format only a new exclusively-created image. Only the')
  text=text.replace("IMAGE = STUDY / 'cow-fixture.img'\nUUID = 'bd56beef-edf3-4499-bd76-cb58c9b34088'", "WORK = STUDY / 'shipping/readiness'\nIMAGE = WORK / 'fixtures/worktree-cow.img'\nUUID = 'c936d1ac-5608-4c57-9cb7-511bb41f8e19'")
  text=text.replace("STUDY / 'shipping/worktree-cow'", "WORK / 'fixtures/worktree-mount'")
  text=text.replace("    def mount_fixture(self):\n        info = IMAGE.lstat()", '''    def mount_fixture(self):
        # Never reuse or format the historical study image. Exclusive creation owns only this
        # fresh 4-GiB regular file; retain it on both success and failure for inspection.
        assert not IMAGE.exists() and not IMAGE.is_symlink(), IMAGE
        IMAGE.parent.mkdir(parents=True, exist_ok=True)
        assert IMAGE.parent.resolve() == WORK.resolve() / 'fixtures'
        assert shutil.disk_usage(IMAGE.parent).free > 10 * 1024**3
        with IMAGE.open('xb') as image:
            image.truncate(4 * 1024**3)
        created = IMAGE.stat()
        self.receipt['created_image'] = {'inode': created.st_ino, 'device': created.st_dev,
                                         'size': created.st_size, 'owner_uid': created.st_uid}
        self.save()
        assert stat.S_ISREG(created.st_mode) and created.st_uid == os.getuid()
        self.run('format-new-owned-image', ['mkfs.btrfs', '--nodiscard', '--uuid', UUID, IMAGE])
        info = IMAGE.lstat()
        assert (info.st_dev, info.st_ino) == (created.st_dev, created.st_ino)''')
  text=text.replace("'retained image size changed'", "'owned image size changed'").replace("'verify-retained-image'", "'verify-new-image'")
  text=text.replace("        self.receipt['mount_record'] = self.mount_record\n", "        self.receipt['mount_record'] = self.mount_record\n        self.run('own-new-filesystem-root', ['sudo', '-n', 'chown',\n                 f'{os.getuid()}:{os.getgid()}', self.mount])\n")
  text=text.replace("assert actual == self.donor and actual.is_relative_to(STUDY)","assert actual == self.donor and actual.is_relative_to(WORK)")
  text=text.replace("        self.run('git-local-identity'", "        self.run('git-local-name', ['git', 'config', '--local', 'user.name', 'Charlie Marsh'], self.donor)\n        self.run('git-local-identity'")
 (out/name).write_text(text);records[name]['derived_sha256']=hashlib.sha256(text.encode()).hexdigest()
(out/'derivation.json').write_text(json.dumps(records,indent=2)+'\n')
