#!/usr/bin/env python3
"""Independently audit the downloaded, unmeasured 26-state fixture preflight."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import re

import audit_readiness as common


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--original-build', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    a = common.Audit(); check = a.check; load = common.load; digest = common.digest
    root = args.evidence; matrix = root / 'fixture-preflight-v2'
    result = {'passed': False, 'auditor_sha256': digest(Path(__file__)),
              'shared_auditor_sha256': digest(Path(common.__file__))}
    try:
        transfer = load(root / 'preflight-v2-transfer.json')
        files = transfer['files']; check(len(files) == transfer['file_count'] == 140, 'full transfer inventory')
        recorded = set()
        for record in files:
            relative = Path(record['path'])
            check(not relative.is_absolute() and '..' not in relative.parts, 'bounded evidence path')
            path = root.parent.parent / relative
            check(path.is_file() and not path.is_symlink(), ('regular evidence file', relative))
            check(path.stat().st_size == record['bytes'] and digest(path) == record['sha256'], ('transferred bytes', relative))
            recorded.add(relative.as_posix())
        actual = {str(p.relative_to(root.parent.parent)) for folder in transfer['paths']
                  for p in ([root.parent.parent / folder] if (root.parent.parent / folder).is_file()
                            else (root.parent.parent / folder).rglob('*')) if p.is_file()}
        check(actual == recorded and sum(r['bytes'] for r in files) == transfer['total_bytes'], 'transfer coverage and byte total')
        p = load(matrix / 'provenance.json'); build = load(root / 'candidate-build/result.json')
        package = load(root / 'candidate-package/result.json'); old = load(args.original_build)
        check(p['script_sha256'] == common.HARNESS and p['core_sha256'] == common.CORE and p['format_wrapper_sha256'] == common.WRAPPER, 'frozen v2 harness/core/wrapper')
        check(p['candidate_build_receipt_sha256'] == digest(root / 'candidate-build/result.json') and p['candidate_package_receipt_sha256'] == digest(root / 'candidate-package/result.json'), 'build/package receipt hashes')
        check(p['final_review_build_receipt_sha256'] == digest(args.original_build), 'original compiler receipt binding')
        check(build['passed'] and package['passed'] and old['passed'], 'build/package passed')
        check(p['candidate_manifest']['base'] == build['base'] == common.CURRENT and p['candidate_manifest']['patch_sha256'] == build['patch_sha256'] == package['patch_sha256'] == common.PATCH, 'reviewed source patch')
        check(p['toolchains']['storeless']['drivers'] == p['toolchains']['compact']['drivers'] == build['toolchain']['drivers'] == package['driver_hashes'], 'candidate driver bytes')
        check(p['toolchains']['current']['drivers'] == old['drivers'] and p['baseline_original_build']['source_base'] == common.BASE and p['toolchains']['baseline']['drivers'] == p['baseline_original_build']['drivers'], 'other compiler identities')
        check(p['cargo']['sha256'] == old['cargo']['sha256'] == package['cargo_sha256'] == build['toolchain']['cargo_sha256'], 'same Cargo bytes')
        check(p['cargo']['version']['stdout'].strip() == old['cargo']['version'].strip() and old['sources']['cargo'] == common.CARGO, 'Cargo4a source identity')
        check(p['wild_sha256'] == build['toolchain']['wild_sha256'] == package['wild_sha256'] == old['wild_sha256'] and build['wild'] == common.WILD, 'same Wild9179 bytes')
        status = load(matrix / 'status.json')
        check(status['passed'] and status['samples'] == 26 and status['accepted'] == 0 and not (matrix / 'failure.json').exists(), '26 complete unaccepted preflight commands')
        rows = [json.loads(line) for line in (matrix / 'samples.jsonl').read_text().splitlines()]
        check([(r['project'], r['mode'], r['round'], r['phase'], r['state']) for r in rows] == [(project, 'storeless', 0, phase, list(state)) for project in common.PROJECTS for phase, state in common.SEQUENCE], 'every ordered fixture state')
        plans = {cell['project']: cell for cell in p['plan']}; check(len(plans) == len(p['plan']) == 2, 'one fresh cell per project')
        snapshots = root / 'fixture-originals'; manifest = load(snapshots / 'manifest.json'); prep = load(root / 'preparation.json')
        grouped = defaultdict(list); observations = []; sources = {}; patches = {}
        for project, cell in plans.items():
            env = cell['environment']
            check(not env['CARGO_ENCODED_RUSTFLAGS'] and not cell['logger_environment'], 'no manual flags/logger')
            check(env['RUSTC'] == p['toolchains']['storeless']['path'] + '/bin/rustc', 'candidate compiler path')
            check(cell['argv'] == [p['cargo']['path'], '-Zohm-defaults=yes', 'build', '--offline', '--locked', '-vv', '-p', project, '--bin', project, '-j', '8'], 'preflight actual Cargo argv')
            check(p['sources'][project]['head']['stdout'].strip() == manifest[project]['head'] == prep['sources'][project]['head'], 'fixture source head')
            for name, record in manifest[project]['files'].items():
                file = snapshots / project / name
                check(digest(file) == record['sha256'] and file.stat().st_size == record['bytes'], 'fixture original bytes')
        for row in rows:
            project = row['project']; cell = plans[project]; grouped[project].append(row)
            check(row['preflight'] and not row['accepted'] and row['returncode'] == 0 and 'error' not in row, 'preflight success without timing admission')
            check(row['argv'] == cell['argv'], 'executed Cargo argv')
            check(not row['unrelated_compilers'] and len(row['outside_cpu_intervals']) < 3 and not row['disk_reserve_failed'], 'resource/interference gates')
            check(not row['instrumented_disk'] and row['sampled_peak_allocated_bytes'] is None, 'uninstrumented timing path')
            remote = Path(row['log']); local = matrix / remote.parent.name / remote.name
            text = local.read_text(); commands = [line for line in text.splitlines() if 'Running `' in line and '/bin/rustc ' in line]
            check(row['compiler_crates'] == re.findall(r'Running [^\n]*\brustc\b[^\n]*--crate-name ([^\s]+)', text), 'raw compiler list')
            check(not any('-Z' + flag in text for flag in common.REMOVED), 'removed options absent')
            check(all(cell['environment']['RUSTC'] in line and '-Zcompact-artifacts' not in line for line in commands), 'ordinary candidate preflight compiler invocations')
            if row['phase'].startswith('noop'):
                check(not commands, 'no compiler or replay during noop')
            check(load(local.with_suffix('.oracle.json')) == row['oracle'], 'raw oracle receipt')
            common.oracle(a, row)
            state = (project, tuple(row['state']))
            wanted = {name: common.hashlib.sha256(data).hexdigest() for name, data in common.fixture_bytes(snapshots, *state).items()}
            check(row['source_sha256'] == wanted, 'independently reconstructed source bytes')
            check(digest(local.with_suffix('.patch')) == row['patch_sha256'], 'complete saved source patch')
            check(state not in patches or patches[state] == row['patch_sha256'], 'same repeated source state')
            patches[state] = row['patch_sha256']; sources[state] = wanted
            monitor = load(local.with_suffix('.monitor.json'))
            check(monitor and max(s['rss'] for s in monitor) == row['sampled_process_tree_peak_rss_bytes'], 'tree RSS receipt')
            spikes = [s for s in monitor if s['outside_user_cpu_cores'] > 0.5]
            check(len(spikes) == len(row['outside_cpu_intervals']), 'outside CPU spike count')
            for sample, recorded in zip(spikes, row['outside_cpu_intervals']):
                a.close(sample['outside_user_cpu_cores'], recorded['cores'], 'outside CPU value')
            resources = local.with_suffix('.time').read_text()
            for label, field, scale in (('User time (seconds)', 'user_seconds', 1), ('System time (seconds)', 'system_seconds', 1), ('Maximum resident set size (kbytes)', 'max_child_rss_bytes', 1024)):
                match = re.search(r'^\s*' + re.escape(label) + r':\s*(\S+)', resources, re.M)
                check(match and float(match[1]) * scale == row[field], ('GNU time metric', field))
            check(re.search(r'^\s*Exit status:\s*0\s*$', resources, re.M), 'GNU time success')
            census = row['census']
            for field in ('allocated', 'logical'):
                check(census[field] == sum(c[field] for c in census['categories'].values()), 'full census sum')
            check(not census['categories'].get('compact-store', {}).get('allocated', 0), 'no external store')
            if 'formats' in row:
                f = row['formats']; check(f['passed'] and not f['archive_member_formats']['compact'] and f['metadata_formats']['raw'] and not f['metadata_formats']['packed'], 'ordinary preflight artifacts')
            if row['phase'] == 'real-library':
                observations.append({'project': project, 'state': row['state'], 'source_sha256': row['source_sha256'], 'binary_sha256': row['oracle']['binary_sha256'], 'case': row['oracle']['cases']['library']})
        for project, cell in grouped.items():
            for index in (1, 12):
                check(cell[index]['oracle']['binary_sha256'] == cell[index - 1]['oracle']['binary_sha256'], 'no-op binary identity')
        v1 = root / 'fixture-preflight'; old_rows = [json.loads(line) for line in (v1 / 'samples.jsonl').read_text().splitlines()]
        check(len(old_rows) == 14 and not any(r['accepted'] for r in old_rows), 'failed v1 retained without admitted timings')
        check(old_rows[-1] == load(v1 / 'failure.json') and not old_rows[-1]['oracle']['passed'], 'failed v1 row and partial oracle retained')
        check(load(v1 / 'provenance.json')['script_sha256'] == '5d9e4dc225be302ca13b3f88bf857604aac4e9984887cad5f133aa139691b0d4', 'old frozen harness retained')
        result.update(passed=True, checks=a.checks, states=26, accepted_timings=0, transferred_files=140,
                      transferred_bytes=transfer['total_bytes'], source_states=len(sources),
                      matrix_sha256=digest(matrix / 'samples.jsonl'), provenance_sha256=digest(matrix / 'provenance.json'),
                      observed_real_library_cases=observations, scope='All26v2source/runtime states pass independently, including everyedited UV message. This admits fixtures and functional gates, not performance results. Failed14-rowv1 remains historical, never pooled.')
    except BaseException as error:
        result.update(error=f'{type(error).__name__}: {error}', checks=a.checks)
        raise
    finally:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'observed_real_library_cases'}, indent=2))


if __name__ == '__main__':
    main()
