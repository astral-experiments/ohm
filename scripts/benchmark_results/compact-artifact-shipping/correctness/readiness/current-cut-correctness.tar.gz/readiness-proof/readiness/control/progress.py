from pathlib import Path
import json,shutil,subprocess,time
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness');p=root/'evidence/candidate-build/result.json'
r=json.loads(p.read_text());print(json.dumps({'passed':r['passed'],'elapsed':time.time()-r['started'],'commands':r['commands'][-3:],'freeGiB':shutil.disk_usage(root).free/1024**3},indent=2))
log=root/'evidence/candidate-build/compiler-build.log'
if log.exists():
 with log.open('rb') as f:
  f.seek(max(0,log.stat().st_size-3000));print(f.read().decode(errors='replace'))
