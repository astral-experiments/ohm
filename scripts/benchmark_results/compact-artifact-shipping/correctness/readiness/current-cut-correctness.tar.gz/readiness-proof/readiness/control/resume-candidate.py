import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/home/dev-user/code/oss/ohm-compact-study');work=root/'shipping/readiness';inputs=root/'shipping/control/readiness-inputs'
evidence=work/'evidence/candidate-build';assert evidence.is_dir()
manifest=json.loads((inputs/'candidate-manifest.json').read_text())
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def output(cmd,cwd=None):return subprocess.check_output(list(map(str,cmd)),cwd=cwd,text=True).strip()
assert digest(inputs/'candidate.patch')==manifest['patch_sha256']
assert json.loads((work/'evidence/scanner-profile/result.json').read_text())['passed']
source=work/'compiler/rust';original=root/'rust';target=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/bootstrap')
receipt=json.loads((evidence/'result.json').read_text())
assert not receipt['passed'] and receipt['commands'][-1]['label']=='compiler-build' and receipt['commands'][-1]['code']==1
assert not (evidence/'initial-result.json').exists()
shutil.copy2(evidence/'result.json',evidence/'initial-result.json')
(evidence/'compiler-build.log').rename(evidence/'compiler-build-initial.log')
old=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-objects/bootstrap')
triple='x86_64-unknown-linux-gnu'
alias='libLLVM-23-rust-1.99.0-beta.so';soname='libLLVM.so.23.1-rust-1.99.0-beta'
original_alias=old/triple/'ci-llvm/lib'/alias
assert original_alias.is_symlink() and original_alias.readlink()==Path(soname)
new_alias=target/triple/'ci-llvm/lib'/alias;new_real=target/triple/'ci-llvm/lib'/soname
assert not new_alias.is_symlink()
sha=digest(old/triple/'ci-llvm/lib'/soname)
assert digest(new_alias)==digest(new_real)==sha
new_alias.unlink();new_alias.symlink_to(soname)
repairs=[]
for rel in ['stage1/lib','stage1/lib/rustlib/'+triple+'/lib','stage0-sysroot/lib/rustlib/'+triple+'/lib']:
 destination=target/triple/rel/soname
 assert not destination.exists()
 shutil.copy2(new_real,destination)
 repairs.append({'path':str(destination),'sha256':digest(destination)})
receipt['assembly_repair']={'cause':'Dereferenced CI LLVM symlink during isolated bootstrap copy; bootstrap copied only alias filename, losing runtime SONAME filename.', 'source':str(old/triple/'ci-llvm/lib'/soname),'sha256':sha,'restored_alias':str(new_alias),'copied_libraries':repairs,'source_patch_changed':False,'original_target_changed':False}
def save(): (evidence/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(label,cmd,cwd=None,env=None):
 row={'label':label,'argv':list(map(str,cmd)),'cwd':str(cwd) if cwd else None,'started':time.time()};receipt['commands'].append(row);save()
 with (evidence/f'{label}.log').open('w') as log:p=subprocess.run(row['argv'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(code=p.returncode,seconds=time.time()-row['started']);save();print(json.dumps({'step':label,'code':p.returncode,'seconds':row['seconds']}),flush=True)
 assert p.returncode==0,label
try:
 env={k:v for k,v in os.environ.items() if not k.startswith(('RUSTFLAGS','RUSTC','RUSTDOC','CARGO_PROFILE_','CARGO_TARGET_','CARGO_UNSTABLE_','CARGO_ENCODED_','CARGO_BUILD_','RUSTUP_TOOLCHAIN'))}
 env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='12')
 common=['--stage','1','--set','build.submodules=false','--set',f'target.x86_64-unknown-linux-gnu.ohm-wild-linker={root}/shipping/final-review/bounds-fix/wild-release']
 run('compiler-build-resume',['python3','x.py','build',*common,'compiler/rustc','src/tools/rustdoc','library'],source,env)
 run('compiler-tests',['python3','x.py','test',*common,'--force-rerun','tests/run-make/compact-artifact-exports','tests/run-make/public-api-hash-artifact'],source,env)
 sysroot=work/'toolchains/storeless';assert not sysroot.exists()
 run('install',['cp','-aL','--reflink=auto',target/'x86_64-unknown-linux-gnu/stage1',sysroot])
 linker=Path('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld')
 for name in ('ld.bfd','compact-artifacts-v1'):
  shutil.copy2(root/'toolchains/compact-final-review-bounds'/linker/name,sysroot/linker/name)
 receipt['toolchain']={'path':str(sysroot),'version':output([sysroot/'bin/rustc','-vV']),'rustc_sha256':digest(sysroot/'bin/rustc'),'drivers':{p.name:digest(p) for p in (sysroot/'lib').glob('librustc_driver*.so')},'wild_sha256':digest(sysroot/linker/'ld.bfd'),'cargo_sha256':digest(root/'shipping/final-review/bin/cargo')}
 assert not output(['git','status','--porcelain','--ignore-submodules=all'],original)
 for path,sha in manifest['files'].items():assert (digest(source/path) if (source/path).is_file() else None)==sha,path
 receipt['linked_libraries']={str(p.relative_to(sysroot)):digest(p) for p in (sysroot/'lib').glob('libLLVM*') if p.is_file()}
 receipt['dynamic_dependencies']=output(['ldd',sysroot/'bin/rustc'])
 assert 'not found' not in receipt['dynamic_dependencies']
 receipt['passed']=True
finally:
 receipt['finished']=time.time();save()
print(json.dumps({'passed':receipt['passed'],'evidence':str(evidence)}),flush=True)
