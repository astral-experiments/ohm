#!/usr/bin/env python3
"""Matched storeless compiler comparison with observable real and synthetic edits."""
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from types import SimpleNamespace

ROOT = Path('/home/dev-user/code/oss/ohm-compact-study')
WORK = ROOT / 'shipping/readiness'
TARGET = Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness')
# Exact frozen core remains the resource/timing and synthetic-fixture implementation.
CORE_SHA = 'ea7867f9f9a0f19ceb7d9c558aa7aa6758ae3e254878685fbc58768c65713cef'
spec = importlib.util.spec_from_file_location('shipping', ROOT / 'shipping/harness/benchmark_shipping.py')
shipping = importlib.util.module_from_spec(spec)
spec.loader.exec_module(shipping)
core = shipping.core
WRAPPER_SHA = 'cb972b8f75c9e89a98e76e7e244a39fb616a6c341129650e3745e73df56faad2'
assert core.digest(ROOT / 'shipping/harness/benchmark_shipping.py') == WRAPPER_SHA
assert core.digest(ROOT / 'harness/benchmark.py') == CORE_SHA
ORDERS = (('baseline', 'current', 'storeless', 'compact'),
          ('compact', 'storeless', 'current', 'baseline'),
          ('storeless', 'compact', 'baseline', 'current'),
          ('current', 'baseline', 'compact', 'storeless'))
RESERVE = 60 * 1024**3
RUFF_DIRECT = ('ruff failed', 'ruff operation failed', 'Ruff command failed', 'Ruff operation failed')
RUFF_LIBRARY = (
    'Local variable `{name}` is assigned to but never used',
    'Local variable `{name}` is assigned a value but never used',
    'Local variable `{name}` is unused after assignment',
    'Local variable `{name}` has an assigned value that is never used',
)
UV_DIRECT = ('', 'Cache directory: ', 'Cache path: ', 'Cache location: ')
UV_LIBRARY = (
    'Expected package name starting with an alphanumeric character, found `{char}`',
    'Package name must start with an alphanumeric character, found `{char}`',
    'Expected an alphanumeric first character in package name, found `{char}`',
    'Invalid package name starting character; expected alphanumeric, found `{char}`',
)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


class Fixture:
    def __init__(self, root, project):
        self.root, self.project = root, project
        self.synthetic = core.Fixture(root, project)
        self.direct = (self.synthetic.main if project == 'ruff' else root / 'crates/uv/src/commands/cache_dir.rs')
        self.library = root / ('crates/ruff_linter/src/rules/pyflakes/rules/unused_variable.rs' if project == 'ruff'
                               else 'crates/uv-pep508/src/lib.rs')
        self.original = {p: p.read_bytes() for p in {self.direct, self.library, self.synthetic.main, self.synthetic.lib}}
        self.initial_diff = subprocess.check_output(['git', 'diff', '--binary'], cwd=root)

    def write(self, synthetic=0, direct=0, library=0):
        contents = dict(self.original)
        probe = ("fn main() -> ExitCode {\n"
                 '    if std::env::var_os("OHM_COMPACT_BENCH_ORACLE").is_some() {\n'
                 f'        println!("{{}}", {self.project}::__ohm_compact_bench_value() + {self.project}::__ohm_compact_bench_inline_value() + std::hint::black_box(0u32));\n'
                 '        return ExitCode::SUCCESS;\n    }')
        contents[self.synthetic.main] = self.synthetic.main_text.replace("fn main() -> ExitCode {", probe).encode()
        contents[self.synthetic.lib] = self.synthetic.original_lib + (
            '\n#[inline(never)]\npub fn __ohm_compact_bench_value() -> u32 { std::hint::black_box(0u32) }\n'
            f'#[inline]\npub fn __ohm_compact_bench_inline_value() -> u32 {{ std::hint::black_box({synthetic}u32) }}\n').encode()
        text = contents[self.direct].decode()
        if self.project == 'ruff':
            old, new = f'"{RUFF_DIRECT[0]}"', f'"{RUFF_DIRECT[direct]}"'
        else:
            old, new = 'printer.stdout(),\n        "{}",', f'printer.stdout(),\n        "{UV_DIRECT[direct]}{{}}",'
        assert text.count(old) == 1
        contents[self.direct] = text.replace(old, new).encode()
        messages = RUFF_LIBRARY if self.project == 'ruff' else UV_LIBRARY
        text = contents[self.library].decode()
        old, new = f'"{messages[0]}"', f'"{messages[library]}"'
        assert text.count(old) == 1
        contents[self.library] = text.replace(old, new).encode()
        for path, data in contents.items():
            if path.read_bytes() != data:
                path.write_bytes(data)
        return {str(p.relative_to(self.root)): core.digest(p) for p in self.original}

    def restore(self):
        for path, contents in self.original.items():
            path.write_bytes(contents)
        assert subprocess.check_output(['git', 'diff', '--binary'], cwd=self.root) == self.initial_diff


def oracle(binary, project, state, destination):
    synthetic, direct, library = state
    probe = destination.parent / 'oracle-work'
    probe.mkdir(exist_ok=True)
    (probe / 'invalid.toml').write_text('[\n')
    (probe / 'empty.py').write_text('')
    (probe / 'requirements.in').write_text('=foo\n')
    cache = probe / 'cache'
    env = {k: v for k, v in os.environ.items() if not k.startswith(('UV_', 'RUFF_', 'OHM_'))}
    env.update(NO_COLOR='1', TERM='dumb', UV_NO_PROGRESS='1')
    rows = {}
    def run(label, args, input=None, extra=None):
        result = subprocess.run([str(binary), *args], input=input, cwd=probe, env={**env, **(extra or {})},
                                capture_output=True, text=True, timeout=30)
        rows[label] = {'argv': [str(binary), *args], 'input': input, 'code': result.returncode,
                       'stdout': result.stdout, 'stderr': result.stderr}
        return result
    receipt = {'passed': False, 'state': list(state), 'binary_sha256': core.digest(binary), 'cases': rows}
    try:
        value = run('synthetic', [], extra={'OHM_COMPACT_BENCH_ORACLE': '1'})
        assert value.returncode == 0 and value.stdout.strip() == str(synthetic), rows
        assert run('version', ['--version']).returncode == 0
        if project == 'ruff':
            result = run('direct', ['check', '--config', str(probe / 'invalid.toml'), '--no-cache', str(probe / 'empty.py')])
            assert result.returncode == 2 and RUFF_DIRECT[direct] in result.stderr, rows
            result = run('library', ['check', '--isolated', '--no-cache', '--select', 'F841', '--output-format', 'json', '-'],
                         'def f():\n    x = 1\n')
            diagnostics = json.loads(result.stdout)
            assert result.returncode == 1 and len(diagnostics) == 1, rows
            diagnostic = diagnostics[0]
            assert diagnostic['code'] == 'F841' and diagnostic['message'] == RUFF_LIBRARY[library].replace('{name}', 'x'), rows
            assert diagnostic['location'] == {'row': 2, 'column': 5}, rows
        else:
            result = run('direct', ['--no-config', '--color', 'never', '--cache-dir', str(cache), 'cache', 'dir'])
            assert result.returncode == 0 and result.stdout == UV_DIRECT[direct] + str(cache) + '\n', rows
            result = run('library', ['--no-config', '--offline', '--color', 'never', '--cache-dir', str(cache),
                                    'pip', 'install', '--no-index', '=foo'])
            assert result.returncode == 2 and UV_LIBRARY[library].replace('{char}', '=') in result.stderr, rows
        linked = subprocess.run(['readelf', '--string-dump=.comment', str(binary)], capture_output=True, text=True, check=True)
        rows['linker'] = {'stdout': linked.stdout, 'code': linked.returncode}
        assert 'Wild' in linked.stdout
        receipt['passed'] = True
    finally:
        save(destination, receipt)

    return receipt


def environment(sysroot, lane, project):
    # Baseline mode supplies identical empty user flags for every arm; the compact
    # arm uses the real Cargo opt-in in argv, which supplies compact+fast itself.
    args = SimpleNamespace(baseline=sysroot, candidate=sysroot, cargo_home=Path('/tmp/codex-cargo-home'),
                           jobs=8, profile='line', compression_profile='fast')
    env, flags = core.environment(args, 'baseline', lane, project)
    assert not flags
    for key in list(env):
        if key.startswith(('RUSTC_LOG', 'CARGO_UNSTABLE_')):
            env.pop(key)
    env.update(CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST='all', CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST='all')
    assert env['CARGO_ENCODED_RUSTFLAGS'] == ''
    return env


def sequence():
    return [('clean', (0, 0, 0)), ('noop', (0, 0, 0)),
            *[('synthetic-inline', (i, 0, 0)) for i in range(1, 4)], ('restore', (0, 0, 0)),
            *[('real-direct', (0, i, 0)) for i in range(1, 4)],
            *[('real-library', (0, 3, i)) for i in range(1, 4)], ('noop-final', (0, 3, 3))]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight', action='store_true')
    args = parser.parse_args()
    output = WORK / 'evidence' / ('fixture-preflight-v2' if args.preflight else 'real-edit-matrix')
    assert not output.exists()
    output.mkdir()
    cargo = ROOT / 'shipping/final-review/bin/cargo'
    current = ROOT / 'toolchains/compact-final-review-bounds'
    cut = json.loads((WORK / 'evidence/candidate-build/result.json').read_text())
    assert cut['passed']
    paths = {'baseline': WORK / 'toolchains/baseline-same-wild', 'current': current,
             'storeless': WORK / 'toolchains/storeless', 'compact': WORK / 'toolchains/storeless'}
    wild = current / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd'
    provenance = {'script_sha256': core.digest(__file__), 'core_sha256': CORE_SHA, 'format_wrapper_sha256': WRAPPER_SHA,
                  'cargo': {'path': str(cargo), 'sha256': core.digest(cargo), 'version': core.command_output([str(cargo), '-vV'])},
                  'wild_sha256': core.digest(wild), 'toolchains': {}, 'sources': {}, 'plan': [],
                  'admission': {'outside_user_cores_threshold': 0.5, 'reject_at_intervals': 3,
                                'unrelated_compilers_allowed': False, 'free_reserve_bytes': RESERVE,
                                'instrumented_runs_accepted': False, 'runtime_oracles_required': True},
                  'scope': 'Same Cargo4a/Wild9179; baseline348, current954, stripped candidate, actual Cargo compact opt-in. Four fresh rounds with balanced arm positions and reversed pair order; three sequential edits per edit class, not twelve independent rounds.',
                  'candidate_manifest': json.loads((ROOT / 'shipping/control/readiness-inputs/candidate-manifest.json').read_text())}
    candidate_manifest = provenance['candidate_manifest']
    assert cut['base'] == candidate_manifest['base'] == '9546795cae23d424bec08487b4f3cace591efb5a'
    assert cut['patch_sha256'] == candidate_manifest['patch_sha256'] == '8c24f6cf911c0829de90e5ec49b0ae04598f00d983168c9e1d126bef1d555275'
    provenance['candidate_build_receipt_sha256'] = core.digest(WORK / 'evidence/candidate-build/result.json')
    package = json.loads((WORK / 'evidence/candidate-package/result.json').read_text())
    assert package['passed'] and package['patch_sha256'] == cut['patch_sha256']
    assert package['driver_hashes'] == cut['toolchain']['drivers']
    provenance['candidate_package_receipt_sha256'] = core.digest(WORK / 'evidence/candidate-package/result.json')
    assert provenance['cargo']['sha256'] == cut['toolchain']['cargo_sha256']
    for mode, path in paths.items():
        provenance['toolchains'][mode] = {'path': str(path), 'version': core.command_output([str(path / 'bin/rustc'), '-vV']),
                                         'rustc_sha256': core.digest(path / 'bin/rustc'),
                                         'drivers': {p.name: core.digest(p) for p in (path / 'lib').glob('librustc_driver*.so')}}
        assert core.digest(path / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd') == provenance['wild_sha256']
    original_build = json.loads((ROOT / 'shipping/final-review/bounds-fix/evidence/compiler-build.json').read_text())
    assert provenance['toolchains']['current']['drivers'] == original_build['drivers']
    assert original_build['sources']['cargo'] == '4a2813050da607ca5cfe7b5cf3a17ba7c9676be1'
    assert provenance['cargo']['sha256'] == original_build['cargo']['sha256']
    assert provenance['cargo']['version']['stdout'].strip() == original_build['cargo']['version'].strip()
    assert original_build['sources']['wild'] == '9179eb988df2676342192a24dc337cf9823e9d56'
    assert provenance['wild_sha256'] == original_build['wild_sha256'] == cut['toolchain']['wild_sha256']
    assert provenance['toolchains']['storeless']['drivers'] == cut['toolchain']['drivers']
    preparation = json.loads((WORK / 'evidence/preparation.json').read_text())
    assert provenance['toolchains']['baseline']['drivers'] == preparation['baseline_clone']['driver']
    baseline_match = json.loads((ROOT / 'shipping/evidence/shipping-build-provenance/baseline-driver-match.json').read_text())
    assert baseline_match['source_base'] == '348339ddae4288ebb3af97d204b19479fef8f5f2'
    assert provenance['toolchains']['baseline']['drivers'] == baseline_match['drivers']
    provenance['baseline_original_build'] = baseline_match
    provenance['final_review_build_receipt_sha256'] = core.digest(ROOT / 'shipping/final-review/bounds-fix/evidence/compiler-build.json')
    assert original_build['sources']['rust'] == '9546795cae23d424bec08487b4f3cace591efb5a'
    for project in ('ruff', 'uv'):
        source = WORK / 'sources' / project
        provenance['sources'][project] = {'head': core.command_output(['git', 'rev-parse', 'HEAD'], source),
                                          'diff': core.command_output(['git', 'diff', '--binary'], source)}
        assert provenance['sources'][project]['head']['stdout'].strip() == preparation['sources'][project]['head']
        assert __import__('hashlib').sha256(provenance['sources'][project]['diff']['stdout'].encode()).hexdigest() == preparation['sources'][project]['patch_sha256']
        for round_index in range(1 if args.preflight else 4):
            # Every arm occupies every position once, with reversed ordering in paired rounds.
            modes = ('storeless',) if args.preflight else ORDERS[round_index]
            for mode in modes:
                lane = TARGET / ('fixture-preflight-v2' if args.preflight else 'real-edit-matrix') / project / f'round-{round_index}' / mode
                env = environment(paths[mode], lane, project)
                argv = [str(cargo), '-Zohm-defaults=yes']
                if mode == 'compact':
                    argv += ['-Zohm-compact-artifacts=yes']
                argv += ['build', '--offline', '--locked', '-vv', '-p', project, '--bin', project, '-j', '8']
                provenance['plan'].append({'project': project, 'round': round_index, 'mode': mode, 'lane': str(lane), 'argv': argv,
                                           'environment': {k: env[k] for k in core.RECORDED_ENV if k in env},
                                           'logger_environment': {k: v for k, v in env.items() if k.startswith('RUSTC_LOG')}})
    if not args.preflight:
        preflight = WORK / 'evidence/fixture-preflight-v2'
        status = json.loads((preflight / 'status.json').read_text())
        assert status['passed'] and status['samples'] == 26 and status['accepted'] == 0
        checked = json.loads((preflight / 'provenance.json').read_text())
        assert checked['script_sha256'] == provenance['script_sha256']
        assert checked['toolchains'] == provenance['toolchains'] and checked['cargo'] == provenance['cargo']
        provenance['fixture_preflight_receipt_sha256'] = core.digest(preflight / 'status.json')
    save(output / 'provenance.json', provenance)
    lock = (TARGET / 'readiness.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    rows = []
    for cell in provenance['plan']:
        project, mode = cell['project'], cell['mode']
        source, lane = WORK / 'sources' / project, Path(cell['lane'])
        assert not lane.exists() and shutil.disk_usage(TARGET).free >= RESERVE
        lane.mkdir(parents=True); (lane / 'scratch').mkdir()
        (lane / '.ohm-compact-benchmark').write_text('owned by benchmark.py\n')
        directory = output / f'{project}-{mode}-{cell["round"]}'
        directory.mkdir()
        fixture = Fixture(source, project)
        env = environment(paths[mode], lane, project)
        try:
            for index, (phase, state) in enumerate(sequence()):
                hashes = fixture.write(*state)
                stem = directory / f'{index:02}-{phase}'
                patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=source)
                stem.with_suffix('.patch').write_bytes(patch)
                row = {'project': project, 'mode': mode, 'round': cell['round'], 'phase': phase,
                       'state': list(state), 'accepted': False, 'preflight': args.preflight,
                       'source_sha256': hashes, 'patch_sha256': core.digest(stem.with_suffix('.patch'))}
                try:
                    row.update(core.timed(cell['argv'], source, env, stem, [lane], False, RESERVE))
                    row.update(project=project, mode=mode, round=cell['round'], phase=phase, state=list(state),
                               source_sha256=hashes, patch_sha256=core.digest(stem.with_suffix('.patch')),
                               accepted=False, preflight=args.preflight)
                    assert row['returncode'] == 0, row['log']
                    row['oracle'] = oracle(lane / 'target/debug' / project, project, state, stem.with_suffix('.oracle.json'))
                    row['census'] = core.census([lane])
                    if phase in ('clean', 'noop-final'):
                        row['formats'] = shipping.formats([lane], 'compact-archive' if mode == 'compact' else 'standard')
                        assert row['formats']['passed'], row['formats']
                    text = stem.with_suffix('.log').read_text()
                    assert not any(flag in text for flag in ('-Zcompress-incremental', '-Zcompress-artifacts', '-Zcompact-artifact-store', '-Zcompact-artifact-raw-metadata'))
                    if phase.startswith('noop'):
                        assert not row['compiler_crates'], row['compiler_crates']
                    row['accepted'] = (not args.preflight and not row['unrelated_compilers'] and len(row['outside_cpu_intervals']) < 3
                                       and not row['disk_reserve_failed'])
                    assert not row['unrelated_compilers'] and len(row['outside_cpu_intervals']) < 3 and not row['disk_reserve_failed'], row
                except BaseException as error:
                    row['accepted'] = False
                    row['error'] = f'{type(error).__name__}: {error}'
                    if stem.with_suffix('.oracle.json').is_file():
                        row['oracle'] = json.loads(stem.with_suffix('.oracle.json').read_text())
                    save(output / 'failure.json', row)
                    raise
                finally:
                    rows.append(row)
                    with (output / 'samples.jsonl').open('a') as stream:
                        stream.write(json.dumps(row) + '\n')
                    print(json.dumps({key: row[key] for key in ('project', 'mode', 'round', 'phase', 'accepted')}), flush=True)
        finally:
            fixture.restore()
        # Only this run's freshly created lane is eligible for cleanup. Retained study targets are outside TARGET.
        core.owned_cleanup(lane)
    save(output / 'status.json', {'passed': True, 'samples': len(rows), 'accepted': sum(row['accepted'] for row in rows), 'finished': time.time()})


if __name__ == '__main__':
    main()
