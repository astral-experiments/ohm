#!/usr/bin/env python3
"""Audit downloaded readiness receipts without running builds or mutating evidence.

The measurements are four fresh rounds, with three sequential edits per class.
The current954-to-cut comparison isolates the removal within this matrix. It
does not by itself explain the older e55/old-Cargo study's slowdown.
"""
import argparse
from collections import defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import statistics

HARNESS = '5d9e4dc225be302ca13b3f88bf857604aac4e9984887cad5f133aa139691b0d4'
CORE = 'ea7867f9f9a0f19ceb7d9c558aa7aa6758ae3e254878685fbc58768c65713cef'
WRAPPER = 'cb972b8f75c9e89a98e76e7e244a39fb616a6c341129650e3745e73df56faad2'
BASE = '348339ddae4288ebb3af97d204b19479fef8f5f2'
CURRENT = '9546795cae23d424bec08487b4f3cace591efb5a'
PATCH = '8c24f6cf911c0829de90e5ec49b0ae04598f00d983168c9e1d126bef1d555275'
CARGO = '4a2813050da607ca5cfe7b5cf3a17ba7c9676be1'
WILD = '9179eb988df2676342192a24dc337cf9823e9d56'
PROJECTS = ('ruff', 'uv')
ARMS = ('baseline', 'current', 'storeless', 'compact')
ORDERS = (ARMS, tuple(reversed(ARMS)),
          ('storeless', 'compact', 'baseline', 'current'),
          ('current', 'baseline', 'compact', 'storeless'))
SEQUENCE = [('clean', (0, 0, 0)), ('noop', (0, 0, 0))]
SEQUENCE += [('synthetic-inline', (i, 0, 0)) for i in (1, 2, 3)]
SEQUENCE += [('restore', (0, 0, 0))]
SEQUENCE += [('real-direct', (0, i, 0)) for i in (1, 2, 3)]
SEQUENCE += [('real-library', (0, 3, i)) for i in (1, 2, 3)]
SEQUENCE += [('noop-final', (0, 3, 3))]
PAIRINGS = (('baseline', 'current'), ('current', 'storeless'),
            ('baseline', 'storeless'), ('storeless', 'compact'), ('baseline', 'compact'))
RUFF_DIRECT = ('ruff failed', 'ruff operation failed', 'Ruff command failed', 'Ruff operation failed')
RUFF_LIBRARY = ('Local variable `{name}` is assigned to but never used',
                'Local variable `{name}` is assigned a value but never used',
                'Local variable `{name}` is unused after assignment',
                'Local variable `{name}` has an assigned value that is never used')
UV_DIRECT = ('', 'Cache directory: ', 'Cache path: ', 'Cache location: ')
UV_LIBRARY = ('Expected package name starting with an alphanumeric character, found `{char}`',
              'Package name must start with an alphanumeric character, found `{char}`',
              'Expected an alphanumeric first character in package name, found `{char}`',
              'Invalid package name starting character; expected alphanumeric, found `{char}`')
REMOVED = ('compress-incremental', 'compress-artifacts', 'compact-artifact-store', 'compact-artifact-raw-metadata')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


class Audit:
    def __init__(self):
        self.checks = 0

    def check(self, condition, context):
        self.checks += 1
        if not condition:
            raise AssertionError(context)

    def close(self, actual, expected, context):
        self.check(actual is expected if actual is None or expected is None else
                   math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-9), (context, actual, expected))


def oracle(audit, row):
    value = row['oracle']; cases = value['cases']
    s, d, l = row['state']; project = row['project']
    audit.check(value['passed'] and value['state'] == row['state'], 'oracle state')
    audit.check(re.fullmatch('[0-9a-f]{64}', value['binary_sha256']), 'binary hash')
    audit.check(set(cases) == {'synthetic', 'version', 'direct', 'library', 'linker'}, 'all runtime cases')
    audit.check(cases['synthetic']['code'] == 0 and cases['synthetic']['stdout'].strip() == str(s), 'synthetic value')
    audit.check(cases['version']['code'] == 0 and cases['version']['stdout'].startswith(project + ' '), 'version')
    audit.check(cases['linker']['code'] == 0 and 'Wild' in cases['linker']['stdout'], 'Wild-linked executable')
    paths = [cases[n]['argv'][0] for n in ('synthetic', 'version', 'direct', 'library')]
    audit.check(len(set(paths)) == 1 and paths[0].endswith('/target/debug/' + project), 'one observed binary')
    direct, library = cases['direct'], cases['library']
    if project == 'ruff':
        audit.check(direct['code'] == 2 and RUFF_DIRECT[d] in direct['stderr'], 'Ruff real direct output')
        diagnostics = json.loads(library['stdout'])
        audit.check(library['code'] == 1 and len(diagnostics) == 1, 'Ruff diagnostic count')
        diagnostic = diagnostics[0]
        audit.check(diagnostic['code'] == 'F841' and diagnostic['message'] == RUFF_LIBRARY[l].replace('{name}', 'x'), 'Ruff real library output')
        audit.check(diagnostic['location'] == {'row': 2, 'column': 5}, 'Ruff diagnostic location')
        audit.check(library['input'] == 'def f():\n    x = 1\n', 'Ruff library input')
    else:
        args = direct['argv']; cache = args[args.index('--cache-dir') + 1]
        audit.check(direct['code'] == 0 and direct['stdout'] == UV_DIRECT[d] + cache + '\n', 'uv real direct output')
        audit.check(library['code'] == 2 and UV_LIBRARY[l].replace('{char}', '=') in library['stderr'], 'uv real library output')
        audit.check('--offline' in library['argv'] and '--no-index' in library['argv'], 'offline uv oracle')


def fixture_bytes(snapshots, project, state):
    """Reconstruct expected touched files from retained pre-fixture file bytes."""
    main = f'crates/{project}/src/' + ('main.rs' if project == 'ruff' else 'bin/uv.rs')
    lib = f'crates/{project}/src/lib.rs'
    direct = main if project == 'ruff' else 'crates/uv/src/commands/cache_dir.rs'
    library = ('crates/ruff_linter/src/rules/pyflakes/rules/unused_variable.rs' if project == 'ruff'
               else 'crates/uv-pep508/src/lib.rs')
    files = {p: (snapshots / project / p).read_bytes() for p in {main, lib, direct, library}}
    s, d, l = state
    original = files[main].decode()
    assert original.count('fn main() -> ExitCode {') == 1
    hook = ('fn main() -> ExitCode {\n'
            '    if std::env::var_os("OHM_COMPACT_BENCH_ORACLE").is_some() {\n'
            f'        println!("{{}}", {project}::__ohm_compact_bench_value() + {project}::__ohm_compact_bench_inline_value() + std::hint::black_box(0u32));\n'
            '        return ExitCode::SUCCESS;\n    }')
    files[main] = original.replace('fn main() -> ExitCode {', hook).encode()
    files[lib] += ('\n#[inline(never)]\npub fn __ohm_compact_bench_value() -> u32 { std::hint::black_box(0u32) }\n'
                   f'#[inline]\npub fn __ohm_compact_bench_inline_value() -> u32 {{ std::hint::black_box({s}u32) }}\n').encode()
    old, new = (('"ruff failed"', '"' + RUFF_DIRECT[d] + '"') if project == 'ruff' else
                ('printer.stdout(),\n        "{}",', 'printer.stdout(),\n        "' + UV_DIRECT[d] + '{}",'))
    assert files[direct].count(old.encode()) == 1
    files[direct] = files[direct].replace(old.encode(), new.encode())
    messages = RUFF_LIBRARY if project == 'ruff' else UV_LIBRARY
    old, new = ('"' + messages[0] + '"').encode(), ('"' + messages[l] + '"').encode()
    assert files[library].count(old) == 1
    files[library] = files[library].replace(old, new)
    return files


def pair_metrics(pairs, getter):
    left, right = [getter(a) for a, _ in pairs], [getter(b) for _, b in pairs]
    deltas = [b - a for a, b in zip(left, right)]
    changes = [100 * (b / a - 1) for a, b in zip(left, right) if a > 0]
    return {'reference_mean': statistics.mean(left), 'candidate_mean': statistics.mean(right),
            'reference_median': statistics.median(left), 'candidate_median': statistics.median(right),
            'delta_mean': statistics.mean(deltas),
            'paired_delta_median': statistics.median(deltas),
            'paired_delta_range': [min(deltas), max(deltas)],
            'ratio_of_means_percent': 100 * (sum(right) / sum(left) - 1) if sum(left) else None,
            'n_percent_pairs': len(changes),
            'paired_percent_median': statistics.median(changes) if changes else None,
            'paired_percent_range': [min(changes), max(changes)] if changes else [None, None],
            'increased_pairs': sum(b > a for a, b in zip(left, right))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--original-build', type=Path, required=True)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--source-snapshots', type=Path, required=True)
    parser.add_argument('--summary', type=Path)
    parser.add_argument('--transfer-manifest', type=Path)
    parser.add_argument('--transfer-root', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    audit = Audit(); check = audit.check
    root = args.evidence; matrix = root / 'real-edit-matrix'
    result = {'passed': False, 'auditor_sha256': digest(Path(__file__))}
    try:
        if args.transfer_manifest:
            check(args.transfer_root is not None, 'transfer root required with manifest')
            transfer = load(args.transfer_manifest)
            for relative, record in transfer['files'].items():
                file = args.transfer_root / relative
                check(not Path(relative).is_absolute() and '..' not in Path(relative).parts, 'bounded transfer entry')
                check(file.is_file() and not file.is_symlink(), ('transferred regular file', relative))
                check(file.stat().st_size == record['bytes'] and digest(file) == record['sha256'], ('transferred bytes', relative))
            result['transferred_files_verified'] = len(transfer['files'])
        check(digest(args.harness) == HARNESS, 'frozen derived harness')
        p = load(matrix / 'provenance.json'); built = load(root / 'candidate-build/result.json')
        package = load(root / 'candidate-package/result.json'); original = load(args.original_build)
        check(p['script_sha256'] == HARNESS and p['core_sha256'] == CORE and p['format_wrapper_sha256'] == WRAPPER, 'frozen timing/format implementations')
        check(p['candidate_build_receipt_sha256'] == digest(root / 'candidate-build/result.json'), 'candidate receipt binding')
        check(p['candidate_package_receipt_sha256'] == digest(root / 'candidate-package/result.json'), 'package receipt binding')
        check(p['final_review_build_receipt_sha256'] == digest(args.original_build), 'prior compiler receipt binding')
        check(built['passed'] and package['passed'] and original['passed'], 'build/package proof passed')
        check(built['base'] == p['candidate_manifest']['base'] == CURRENT, 'candidate base')
        check(built['patch_sha256'] == package['patch_sha256'] == p['candidate_manifest']['patch_sha256'] == PATCH, 'candidate source patch')
        check(original['sources'] == {'rust': CURRENT, 'wild': WILD, 'cargo': CARGO}, 'current source pins')
        check(p['cargo']['sha256'] == original['cargo']['sha256'] == built['toolchain']['cargo_sha256'], 'same Cargo bytes')
        check(p['cargo']['version']['stdout'].strip() == original['cargo']['version'].strip(), 'Cargo source version')
        check(p['wild_sha256'] == original['wild_sha256'] == built['toolchain']['wild_sha256'], 'same Wild bytes')
        check(p['toolchains']['current']['drivers'] == original['drivers'], 'current compiler bytes')
        check(p['toolchains']['storeless']['drivers'] == p['toolchains']['compact']['drivers'] == built['toolchain']['drivers'] == package['driver_hashes'], 'same cut/compact compiler bytes')
        driver_sets = [set(p['toolchains'][arm]['drivers'].values()) for arm in ('baseline', 'current', 'storeless')]
        check(all(a.isdisjoint(b) for a, b in itertools.combinations(driver_sets, 2)), 'three distinct compiled implementations, not inferred from version strings')
        check(p['baseline_original_build']['source_base'] == BASE and p['toolchains']['baseline']['drivers'] == p['baseline_original_build']['drivers'], 'baseline compiler bytes')
        check(all(t['drivers'] and t['version']['returncode'] == 0 for t in p['toolchains'].values()), 'compiler identities complete')
        check(not original['production_pgo_bolt'] and not built['production_pgo_bolt'], 'non-PGO/BOLT scope')
        preparation = load(root / 'preparation.json')
        snapshots = load(args.source_snapshots / 'manifest.json')
        for project in PROJECTS:
            source = p['sources'][project]
            check(source['head']['stdout'].strip() == preparation['sources'][project]['head'], 'project source head')
            check(hashlib.sha256(source['diff']['stdout'].encode()).hexdigest() == preparation['sources'][project]['patch_sha256'], 'compatibility patch')
            check(snapshots[project]['head'] == preparation['sources'][project]['head'], 'snapshot source head')
            for name, record in snapshots[project]['files'].items():
                file = args.source_snapshots / project / name
                check(digest(file) == record['sha256'] and file.stat().st_size == record['bytes'], ('original fixture bytes', project, name))
        preflight = load(root / 'fixture-preflight/provenance.json')
        status = load(root / 'fixture-preflight/status.json')
        check(p['fixture_preflight_receipt_sha256'] == digest(root / 'fixture-preflight/status.json'), 'preflight receipt binding')
        check(status['passed'] and status['samples'] == 26 and status['accepted'] == 0, '26 unaccepted fixture preflight commands')
        check(preflight['script_sha256'] == HARNESS and preflight['cargo'] == p['cargo'] and preflight['toolchains'] == p['toolchains'], 'preflight exact identities')
        preflight_rows = [json.loads(line) for line in (root / 'fixture-preflight/samples.jsonl').read_text().splitlines()]
        check([(r['project'], r['mode'], r['round'], r['phase'], r['state']) for r in preflight_rows] == [(project, 'storeless', 0, phase, list(state)) for project in PROJECTS for phase, state in SEQUENCE], '26 unique preflight states')
        for row in preflight_rows:
            check(row['preflight'] and not row['accepted'] and row['returncode'] == 0 and 'error' not in row, 'preflight succeeded without admission')
            oracle(audit, row)
            wanted = {name: hashlib.sha256(contents).hexdigest() for name, contents in fixture_bytes(args.source_snapshots, row['project'], row['state']).items()}
            check(row['source_sha256'] == wanted, 'preflight source bytes')
        expected_order = [(project, mode, r) for project in PROJECTS for r, order in enumerate(ORDERS) for mode in order]
        check([(c['project'], c['mode'], c['round']) for c in p['plan']] == expected_order, '32 fresh balanced cells')
        plans = {(c['project'], c['mode'], c['round']): c for c in p['plan']}
        for key, c in plans.items():
            env = c['environment']; project, mode, _ = key
            argv = [p['cargo']['path'], '-Zohm-defaults=yes'] + (['-Zohm-compact-artifacts=yes'] if mode == 'compact' else [])
            argv += ['build', '--offline', '--locked', '-vv', '-p', project, '--bin', project, '-j', '8']
            check(c['argv'] == argv, ('exact real Cargo argv', key))
            check(not env['CARGO_ENCODED_RUSTFLAGS'] and not c['logger_environment'], ('no manual flags/logger', key))
            check(env['RUSTC'] == p['toolchains'][mode]['path'] + '/bin/rustc', ('compiler selection', key))
            check(env['RUSTDOC'] == p['toolchains'][mode]['path'] + '/bin/rustdoc', ('rustdoc selection', key))
            for name, child in (('CARGO_TARGET_DIR', 'target'), ('CARGO_BUILD_BUILD_DIR', 'build'), ('TMPDIR', 'scratch')):
                check(env[name] == c['lane'] + '/' + child, ('whole-lane paths', key, name))
            check(env['CARGO_INCREMENTAL'] == '1' and env['CARGO_BUILD_JOBS'] == '8', ('incremental/jobs', key))
            check(env['CARGO_PROFILE_DEV_DEBUG'] == 'line-tables-only' and env['CARGO_PROFILE_DEV_BUILD_OVERRIDE_DEBUG'] == '0', ('debug profile', key))
            check(env.get('CARGO_PROFILE_DEV_OPT_LEVEL') == ('1' if project == 'ruff' else None), ('optimization profile', key))
            check(env.get('CARGO_UNSTABLE_EMBED_METADATA') is None, ('embedding only actual Cargo option', key))
            check(env['CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST'] == env['CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'] == 'all', ('development trust scope', key))
        rows = [json.loads(line) for line in (matrix / 'samples.jsonl').read_text().splitlines()]
        expected = [(project, mode, r, phase, list(state)) for project, mode, r in expected_order for phase, state in SEQUENCE]
        check([(r['project'], r['mode'], r['round'], r['phase'], r['state']) for r in rows] == expected, 'all 416 ordered unique samples')
        status = load(matrix / 'status.json')
        check(status['passed'] and status['samples'] == status['accepted'] == 416 and not (matrix / 'failure.json').exists(), 'complete matrix, no discarded failure')
        state_sources = {}; state_patches = {}; grouped = defaultdict(list); anomalies = []; log_scope = []
        for row in rows:
            key = (row['project'], row['mode'], row['round']); cell = plans[key]; grouped[key].append(row)
            context = (*key, row['phase'], row['state'])
            check(row['accepted'] and not row['preflight'] and row['returncode'] == 0 and 'error' not in row, ('accepted', context))
            check(row['argv'] == cell['argv'], ('command matches plan', context))
            check(not row['unrelated_compilers'] and not row['disk_reserve_failed'], ('compiler/disk gates', context))
            check(len(row['outside_cpu_intervals']) < 3 and not row['instrumented_disk'] and row['sampled_peak_allocated_bytes'] is None, ('resource admission', context))
            check(row['wall_seconds'] > 0 and row['user_seconds'] >= 0 and row['system_seconds'] >= 0, ('times', context))
            remote = Path(row['log']); local = matrix / remote.parent.name / remote.name
            check(local.parent.name == f'{key[0]}-{key[1]}-{key[2]}', ('per-cell receipt path', context))
            text = local.read_text(errors='replace'); check(not any('-Z' + f in text for f in REMOVED), ('no research flags', context))
            crates = re.findall(r'Running [^\n]*\brustc\b[^\n]*--crate-name ([^\s]+)', text)
            check(crates == row['compiler_crates'], ('compiler log receipt', context))
            commands = [line for line in text.splitlines() if 'Running `' in line and '/bin/rustc ' in line]
            if row['phase'].startswith('noop'):
                check(not commands, ('no compiler or link-only invocation during noop', context))
            for command in commands:
                check(cell['environment']['RUSTC'] in command, ('right compiler invoked', context))
                if row['mode'] == 'compact':
                    check('-Zcompact-artifacts=yes' in command and '-Zartifact-compression-profile=fast' in command, ('generated compact/fast flags', context))
                    check('-Zembed-metadata=no' not in command, ('self-contained metadata', context))
                else:
                    check('-Zcompact-artifacts' not in command and '-Zartifact-compression-profile' not in command, ('ordinary generated flags', context))
            monitor = load(local.with_suffix('.monitor.json'))
            check(monitor and row['sampled_process_tree_peak_rss_bytes'] == max(x['rss'] for x in monitor), ('summed RSS receipt', context))
            spikes = [x for x in monitor if x['outside_user_cpu_cores'] > 0.5]
            check(len(spikes) == len(row['outside_cpu_intervals']), ('interference sample count', context))
            for sample, recorded in zip(spikes, row['outside_cpu_intervals']):
                audit.close(sample['outside_user_cpu_cores'], recorded['cores'], ('outside CPU value', context))
                check(abs(sample['time'] - recorded['time']) < 0.1, ('outside CPU time', context))
            if spikes:
                anomalies.append({'cell': key, 'phase': row['phase'], 'state': row['state'], 'spikes': spikes})
            resources = local.with_suffix('.time').read_text()
            for label, field, multiplier in (('User time (seconds)', 'user_seconds', 1), ('System time (seconds)', 'system_seconds', 1), ('Maximum resident set size (kbytes)', 'max_child_rss_bytes', 1024)):
                match = re.search(r'^\s*' + re.escape(label) + r':\s*(\S+)', resources, re.M)
                check(match and float(match[1]) * multiplier == row[field], ('GNU time metric', context, field))
            check(re.search(r'^\s*Exit status:\s*0\s*$', resources, re.M), ('GNU time exit', context))
            check(load(local.with_suffix('.oracle.json')) == row['oracle'], ('raw oracle receipt', context)); oracle(audit, row)
            check(digest(local.with_suffix('.patch')) == row['patch_sha256'], ('saved source patch', context))
            skey = (row['project'], tuple(row['state']))
            if skey not in state_sources:
                state_sources[skey] = {name: hashlib.sha256(contents).hexdigest() for name, contents in fixture_bytes(args.source_snapshots, *skey).items()}
                state_patches[skey] = row['patch_sha256']
            check(row['source_sha256'] == state_sources[skey], ('reconstructed source bytes', context))
            check(row['patch_sha256'] == state_patches[skey], ('same full source diff for matched state', context))
            census = row['census']
            for field in ('allocated', 'logical'):
                check(census[field] == sum(c[field] for c in census['categories'].values()), ('storage category sums', context, field))
            check(census['files'] + census['directories'] == sum(c['entries'] for c in census['categories'].values()), ('census entries', context))
            check(not census['categories'].get('compact-store', {}).get('allocated', 0), ('no external object store', context))
            if row['phase'] in ('clean', 'noop-final'):
                f = row['formats']; counts = f['counts']; metadata = f['metadata_formats']
                check(f['passed'] and metadata['raw'] > 0 and metadata['packed'] == metadata['other'] == 0, ('raw metadata', context))
                check(counts.get('archive', 0) > 0 and not counts.get('manifest', 0) and not counts.get('wrapper', 0), ('ordinary self-contained ar', context))
                check((f['archive_member_formats']['compact'] > 0) == (row['mode'] == 'compact'), ('compact members', context))
                check((counts.get('object', 0) > 0) == (row['mode'] == 'compact'), ('incremental object format', context))
            if row['phase'] in ('synthetic-inline', 'real-direct', 'real-library'):
                check(commands, ('real rebuild occurred', context))
                log_scope.append({'cell': key, 'phase': row['phase'], 'state': row['state'], 'compiler_crates': crates, 'link_only_commands': sum('-Zlink-only' in c or '-Z link-only' in c for c in commands), 'log_sha256': digest(local)})
        for key, cell in grouped.items():
            for i in (1, 12):
                check(not cell[i]['compiler_crates'] and cell[i]['oracle']['binary_sha256'] == cell[i - 1]['oracle']['binary_sha256'], ('no-op binary identity', key, i))
        metrics = {'wall_seconds': lambda r: r['wall_seconds'], 'user_seconds': lambda r: r['user_seconds'], 'system_seconds': lambda r: r['system_seconds'], 'cpu_seconds': lambda r: r['user_seconds'] + r['system_seconds'], 'max_child_rss_bytes': lambda r: r['max_child_rss_bytes'], 'sampled_process_tree_peak_rss_bytes': lambda r: r['sampled_process_tree_peak_rss_bytes'], 'allocated_bytes': lambda r: r['census']['allocated'], 'logical_bytes': lambda r: r['census']['logical']}
        index = {(r['project'], r['mode'], r['round'], r['phase'], tuple(r['state'])): r for r in rows}
        comparisons = []
        for (left, right), project, phase in itertools.product(PAIRINGS, PROJECTS, dict(SEQUENCE)):
            pairs = [(r, index[(project, right, r['round'], phase, tuple(r['state']))]) for r in rows if (r['project'], r['mode'], r['phase']) == (project, left, phase)]
            group = {'reference': left, 'candidate': right, 'project': project, 'phase': phase, 'n': len(pairs)}
            check(len(pairs) == (12 if phase in ('synthetic-inline', 'real-direct', 'real-library') else 4), 'paired sample count')
            group.update({name: pair_metrics(pairs, getter) for name, getter in metrics.items()})
            group['rounds'] = [{'round': i, 'n': len(part), **{name: pair_metrics(part, getter) for name, getter in metrics.items()}} for i in range(4) if (part := [(a, b) for a, b in pairs if a['round'] == i])]
            comparisons.append(group)
        if args.summary:
            summary = load(args.summary)
            ours = {(g['reference'], g['candidate'], g['project'], g['phase']): g for g in comparisons}
            theirs = {(g['reference'], g['candidate'], g['project'], g['phase']): g for g in summary['comparisons']}
            check(len(summary['comparisons']) == len(theirs) and set(ours) == set(theirs), 'all independent summary comparisons')
            names = {'reference_mean': 'reference_mean', 'candidate_mean': 'candidate_mean', 'delta_mean': 'delta_mean', 'percent': 'ratio_of_means_percent', 'paired_percent_median': 'paired_percent_median'}
            for key, expected in ours.items():
                actual = theirs[key]; check(actual['n_pairs'] == expected['n'], ('summary count', key))
                check(set(actual['metrics']) == set(metrics) - {'logical_bytes'}, ('complete summary metrics', key))
                for metric, values in actual['metrics'].items():
                    check(metric in metrics, ('known summary metric', metric))
                    for theirs_name, our_name in names.items():
                        audit.close(values[theirs_name], expected[metric][our_name], ('summary metric', key, metric, theirs_name))
                    audit.close(values['paired_percent_min'], expected[metric]['paired_percent_range'][0], ('summary minimum', key, metric))
                    audit.close(values['paired_percent_max'], expected[metric]['paired_percent_range'][1], ('summary maximum', key, metric))
                    check(values['n_percent_pairs'] == expected[metric]['n_percent_pairs'], ('defined percentage pairs', key, metric))
                    check([r['round'] for r in values['rounds']] == list(range(4)), ('summary all rounds', key, metric))
                    for r, e in zip(values['rounds'], expected['rounds']):
                        check(r['n_pairs'] == e['n'], ('round pair count', key, metric))
                        for theirs_name, our_name in list(names.items())[:4]:
                            audit.close(r[theirs_name], e[metric][our_name], ('independent round metric', key, metric, r['round'], theirs_name))
            result['summary_sha256'] = digest(args.summary)
        result.update(passed=True, commands=len(rows), preflight_commands=len(preflight_rows), checks=audit.checks, matrix_sha256=digest(matrix / 'samples.jsonl'), comparisons=comparisons, interference=anomalies, edit_log_scope=log_scope,
                      scope='Four fresh rounds per project/arm; three sequential edits per class, not twelve independent rounds. All arms use Cargo4a and Wild9179. Full-lane allocated bytes include target/build/scratch and deduplicate hardlinks; they exclude source/download caches and are not peak disk or unique CoW extents. Summed sampled RSS is not PSS. The new current954-to-cut comparison does not establish numerical continuity or causation for the older e55 study.')
    except BaseException as error:
        result.update(error=f'{type(error).__name__}: {error}', checks=audit.checks)
        raise
    finally:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('comparisons', 'interference', 'edit_log_scope')}, indent=2))


if __name__ == '__main__':
    main()
