import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path('/home/dev-user/code/oss/ohm-compact-study')
def command(argv, cwd=None):
    value = subprocess.run(argv, cwd=cwd, text=True, capture_output=True)
    return {'argv': argv, 'code': value.returncode, 'stdout': value.stdout, 'stderr': value.stderr}

data = {'disk': dict(zip(('total', 'used', 'free'), shutil.disk_usage(root))),
        'affinity': sorted(os.sched_getaffinity(0)),
        'loadavg': Path('/proc/loadavg').read_text(),
        'meminfo': '\n'.join(Path('/proc/meminfo').read_text().splitlines()[:5]),
        'instructions': {}, 'sources': {}, 'tools': {}}
for path in (Path.home()/'.codex/AGENTS.md', root/'AGENTS.md', root/'rust/AGENTS.md', root/'wild/AGENTS.md'):
    if path.is_file(): data['instructions'][str(path)] = path.read_text()
for name, path in [('rust', root/'rust'), ('wild', root/'wild'), ('cargo', root/'shipping/cargo'),
                   ('ruff', root/'sources/ruff'), ('uv', root/'sources/uv')]:
    data['sources'][name] = {k: command(['git', *args], path) for k,args in {
        'root':['rev-parse','--show-toplevel'], 'common':['rev-parse','--git-common-dir'],
        'head':['rev-parse','HEAD'], 'status':['status','--short','--ignore-submodules=all'],
        'identity':['config','user.email']}.items()}
for tool in ('perf','strace','bpftrace','rsync'):
    data['tools'][tool] = shutil.which(tool)
data['perf_paranoid'] = Path('/proc/sys/kernel/perf_event_paranoid').read_text()
ps = command(['ps','-eo','pid,etimes,pcpu,rss,comm,args'])['stdout']
data['active_compilers'] = [line for line in ps.splitlines() if len(line.split()) > 4 and line.split()[4] in {
    'rustc','cargo','rustdoc','wild','ld.bfd','ld.lld','cc1','cc1plus','clang','clang++','gcc','g++','make','ninja'}]
data['toolchains'] = sorted(p.name for p in (root/'toolchains').iterdir())
data['validation'] = json.loads((root/'shipping/final-review/bounds-fix/evidence/validation.json').read_text())
data['validation'].pop('commands', None)
data['btrfs_loop'] = command(['losetup','--list','--output','NAME,BACK-FILE'])
data['mounts'] = command(['findmnt','-rn','-t','btrfs','-o','SOURCE,TARGET'])
print(json.dumps(data, indent=2))
