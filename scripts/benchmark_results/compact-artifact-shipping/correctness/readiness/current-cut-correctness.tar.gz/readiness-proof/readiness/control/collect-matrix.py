from pathlib import Path
import hashlib,json,shutil,time
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping');work=root/'readiness';study=root.parent
matrix=work/'evidence/real-edit-matrix';status_path=matrix/'status.json';samples=matrix/'samples.jsonl'
def digest(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
status=json.loads(status_path.read_text());assert status['passed'] and status['samples']==status['accepted']==416
rows=[json.loads(line) for line in samples.read_text().splitlines()]
assert len(rows)==416 and all(row['accepted'] for row in rows)
assert not (matrix/'failure.json').exists()
assert json.loads((work/'evidence/preservation-after.json').read_text())['passed']
anchors=work/'anchors';assert not anchors.exists();anchors.mkdir()
for src,name in [(root/'final-review/bounds-fix/evidence/compiler-build.json','original-current-compiler-build.json'),(root/'evidence/shipping-build-provenance/baseline-driver-match.json','original-baseline-driver-match.json'),(study/'harness/benchmark.py','benchmark-core.py'),(root/'harness/benchmark_shipping.py','benchmark-shipping.py')]:
 shutil.copy2(src,anchors/name)
paths=['readiness/evidence','readiness/harness','readiness/correctness','readiness/anchors','control/readiness-inputs']
manifest=work/'evidence/collection.json';assert not manifest.exists()
files=[]
for name in paths:
 path=root/name
 for p in sorted(path.rglob('*')) if path.is_dir() else [path]:
  assert not p.is_symlink(),str(p)
  if p.is_file():files.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest(p)})
receipt={'passed':True,'matrix_status_sha256':digest(status_path),'matrix_samples_sha256':digest(samples),'files':files,'file_count':len(files),'total_bytes':sum(f['bytes'] for f in files),'paths':paths,'created':time.time()}
manifest.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
