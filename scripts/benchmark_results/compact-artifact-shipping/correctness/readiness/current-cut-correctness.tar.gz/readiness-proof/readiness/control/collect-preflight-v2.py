from pathlib import Path
import hashlib,json,time
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping');work=root/'readiness'
status=json.loads((work/'evidence/fixture-preflight-v2/status.json').read_text());assert status['passed'] and status['samples']==26 and status['accepted']==0
paths=['readiness/evidence/fixture-preflight-v2','readiness/evidence/fixture-preflight-v2.log']
files=[]
for name in paths:
 path=root/name
 for p in sorted(path.rglob('*')) if path.is_dir() else [path]:
  if p.is_file():
   assert not p.is_symlink()
   with p.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
   files.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha})
receipt={'files':files,'file_count':len(files),'total_bytes':sum(f['bytes'] for f in files),'paths':paths,'created':time.time()}
(work/'evidence/preflight-v2-transfer.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
