from pathlib import Path
import subprocess,json,shutil
root=Path('/home/dev-user/code/oss/ohm-compact-study');target=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-objects/bootstrap')
print(json.dumps({'disk':shutil.disk_usage(root)._asdict(),'sizes':subprocess.check_output(['du','-s','-B1',str(target),str(root/'rust'),str(root/'shipping/readiness/toolchains/baseline-same-wild')],text=True),'submodules':subprocess.check_output(['git','submodule','status'],cwd=root/'rust',text=True),'bootstrap_dirs':[p.name for p in target.iterdir()]},indent=2))
p=root/'shipping/readiness/evidence/scanner-profile/result.json'
if p.exists():print(p.read_text())
p=root/'shipping/readiness/evidence/scanner-profile/00-prepare.log'
if p.exists():print('\n'.join(p.read_text().splitlines()[-5:]))
