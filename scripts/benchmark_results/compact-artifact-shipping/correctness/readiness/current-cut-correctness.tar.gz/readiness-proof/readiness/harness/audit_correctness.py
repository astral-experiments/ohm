#!/usr/bin/env python3
"""Audit archived source/build/package/native/macOS correctness receipts, without executing binaries."""
import argparse
import json
from pathlib import Path
import re

import audit_readiness as common

SOURCE = '3b84b46e3fb38f80246f744275c69fe608dfb2f3'
INTEGRATION = '54f8b75ac31207d47af50fc8c5bc9dc90f2457de'
CARGO_FINAL = '0d39870c83ccf09a250e55d9dd13a83d606b72be'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('bundle', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    root = args.bundle
    ev = root / 'readiness/evidence'
    cut = root / 'storeless-cut'
    a = common.Audit(); check = a.check; load = common.load; digest = common.digest
    result = {'passed': False, 'auditor_sha256': digest(Path(__file__))}
    try:
        transfer = load(ev / 'correctness-transfer.json')
        check(len(transfer['files']) == transfer['file_count'] == 14, 'native transfer count')
        for f in transfer['files']:
            relative = Path(f['path'])
            check(not relative.is_absolute() and '..' not in relative.parts, 'bounded transfer path')
            file = root / relative
            check(file.is_file() and not file.is_symlink(), 'regular transfer file')
            check(file.stat().st_size == f['bytes'] and digest(file) == f['sha256'], ('transferred native bytes', relative))
        check(sum(f['bytes'] for f in transfer['files']) == transfer['total_bytes'], 'native byte total')
        manifest = load(cut / 'candidate-manifest.json'); pub = load(cut / 'source-publication.json')
        review = load(root / 'readiness/correctness-review.json')
        check(digest(cut / 'candidate.patch') == manifest['patch_sha256'] == common.PATCH, 'frozen source patch bytes')
        check(manifest['base'] == pub['base'] == common.CURRENT and len(manifest['files']) == 33, '33-path source boundary')
        check(pub['frozen_patch_sha256'] == common.PATCH and pub['source_commit'] == SOURCE and pub['final_commit'] == INTEGRATION, 'published cut identities')
        check(pub['no_other_source_changes'] and pub['manifest_paths_verified'] == 33 and pub['source_equal_excluding_gitlink'], 'publication equality receipt')
        check(pub['pin_only_delta'] == ['src/tools/cargo'] and pub['cargo_before'] == common.CARGO and pub['cargo_after'] == CARGO_FINAL, 'integration gitlink-only delta')
        check(digest(cut / 'source-publication.json') == review['source_publication_sha256'], 'independent publication binding')
        check(digest(cut / 'independent-review.json') == review['source_review_sha256'], 'source review binding')
        source_review = load(cut / 'independent-review.json')
        check(all(f['base_identical'] for f in source_review['restored_files'].values()) and len(source_review['restored_files']) == 13, '13 baseline reader paths restored')
        for rel, sha in review['sealed_local_evidence'].items():
            check(digest(ev / rel) == sha, ('reviewed build/package raw bytes', rel))
        build = load(ev / 'candidate-build/result.json'); package = load(ev / 'candidate-package/result.json')
        prior = load(root / 'provenance/original-compiler-build.json')
        check(build['passed'] and package['passed'] and prior['passed'], 'build/package passed')
        check(build['base'] == package['base'] == common.CURRENT and build['patch_sha256'] == package['patch_sha256'] == common.PATCH, 'native build source')
        check(build['wild'] == common.WILD and build['toolchain']['drivers'] == package['driver_hashes'] == review['linux']['drivers'], 'native compiler byte identity')
        check(build['toolchain']['cargo_sha256'] == package['cargo_sha256'] == prior['cargo']['sha256'], 'Cargo4a byte identity')
        check(build['toolchain']['wild_sha256'] == package['wild_sha256'] == prior['wild_sha256'], 'Wild9179 byte identity')
        check(package['forced_run_make'] == {'passed': 2, 'failed': 0, 'ignored': 0}, 'forced suites receipt')
        tests = (ev / 'candidate-build/compiler-tests.log').read_text()
        check(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', tests) == [('2', '0', '0')], 'actual forced run-make output')
        check(package['default_compact_members'] == 0 and package['optin_compact_members'] > 0 and package['marker'] == 'RCOBJ001', 'installed opt-in/default formats and capability')
        check(package['shared_crate_copyright_notices_verified'] and set(package['licenses']) == {'LICENSE-APACHE', 'LICENSE-MIT'}, 'packaged license checks')
        check(not build['production_pgo_bolt'] and not package['production_pgo_bolt'], 'non-PGO scope')
        for command in package['commands']:
            check(command['exit_code'] == 0 and digest(ev / 'candidate-package' / (command['name'] + '.log')) == command['log_sha256'], 'actual package command log')
        check(digest(root / 'provenance/release-helpers/smoke_test_compact.py') == package['helper_sha256'], 'installed smoke helper bytes')
        check(digest(root / 'provenance/release-helpers/smoke-test-release.sh') == package['release_script_sha256'], 'release fixture bytes')
        native = load(ev / 'correctness/result.json')
        check(native['passed'] and native['binaries_unchanged'] and native['old_image_unchanged'], 'native completion and preservation')
        check(native['rust_source_commit'] == SOURCE and native['rust_base'] == common.CURRENT and native['patch_sha256'] == common.PATCH and native['wild'] == common.WILD and native['cargo_source'] == common.CARGO, 'native source boundary')
        for field, rel in [('candidate_build_sha256', 'candidate-build/result.json'), ('candidate_package_sha256', 'candidate-package/result.json'), ('preflight_sha256', 'fixture-preflight-v2/status.json'), ('preflight_provenance_sha256', 'fixture-preflight-v2/provenance.json')]:
            check(native[field] == digest(ev / rel), ('native receipt binding', field))
        check(native['script_sha256'] == digest(root / 'readiness/correctness/run_correctness.py'), 'actual orchestrator')
        for rel, info in native['derivation'].items():
            check(digest(root / 'readiness/correctness' / rel) == info['derived_sha256'], 'actual native control')
        for command in native['commands']:
            check(command['exit_code'] == 0 and digest(ev / 'correctness' / (command['label'] + '.log')) == command['log_sha256'], 'native control command log')
        expected = set(build['toolchain']['drivers'].values()) | {package['cargo_sha256'], package['wild_sha256']}
        check(set(native['expected_binaries'].values()) == expected, 'native actual inputs')
        lifecycle = load(ev / 'correctness/lifecycle.json')
        worktree = load(ev / 'correctness/worktree.json')
        alignment = load(ev / 'correctness/alignment.json')
        for receipt in (lifecycle, worktree):
            check(receipt['passed'] and receipt['provenance']['cargo_sha256'] == package['cargo_sha256'] and receipt['provenance']['wild_sha256'] == package['wild_sha256'], 'native fixture provenance')
        records = {r['label']: r for r in lifecycle['records']}
        check(len(records) == len(lifecycle['records']), 'unique lifecycle steps')
        for label, r in records.items():
            check(r['returncode'] == (101 if label.startswith('type-error-') else 0), ('lifecycle exit', label))
            check('internal compiler error' not in r['stderr'], 'no lifecycle ICE')
        for label, value in {'compact-first-output': 42, 'second-fixture-output': 42, 'second-after-clean-output': 42, 'private-edit-output': 43, 'public-api-edit-output': 44, 'ordinary-output': 44, 'toggle-back-output': 44, 'first-rebuilt-output': 44}.items():
            check(records[label]['stdout'].strip() == str(value), ('lifecycle runtime', label))
        for label in ('compact-noop', 'ordinary-noop', 'compact-again-noop', 'second-after-first-clean'):
            check(records[label]['all_fresh'], ('lifecycle freshness', label))
        check('-Zlink-only' in records['private-edit']['stderr'] or '-Z link-only' in records['private-edit']['stderr'], 'private edit replay')
        check('test result: ok. 1 passed; 0 failed; 0 ignored;' in records['compact-doctest']['stdout'], 'actual doctest executes')
        shared = records['compact-first']['selected_libraries']['itoa']
        for label in ('second-fixture-shared-cache', 'first-after-clean'):
            check(records[label]['selected_libraries']['itoa'] == shared, 'immutable registry reuse across fixtures and cleanup')
        check(records['toggle-ordinary']['selected_libraries']['itoa'] != shared, 'format toggle invalidation')
        storage = [lifecycle[k]['allocated_bytes'] for k in ('storage_before_clean', 'storage_after_first_clean', 'storage_after_both_clean')]
        check(storage[0] > storage[1] > storage[2] > 0, 'owned Cargo cleanup shrinks artifacts')
        bridge = load(ev / 'correctness/alignment-build.json')
        check(bridge['drivers'] == build['toolchain']['drivers'] and bridge['patch_sha256'] == common.PATCH and bridge['source_build_receipt_sha256'] == digest(ev / 'candidate-build/result.json'), 'alignment driver binding')
        check(alignment['passed'] and alignment['candidate_build_validated'] and alignment['candidate_build_sha256'] == digest(ev / 'correctness/alignment-build.json'), 'validated alignment build')
        check(all(c['returncode'] == 0 for c in alignment['commands']), 'alignment command success')
        check([c['alignment'] for c in alignment['cases']] == [64, 4096, 16777216], 'alignment coverage')
        for case in alignment['cases']:
            check(case['passed'] and case['compact_incremental_objects'] > 0, 'actual compact alignment case')
            check([s['phase'] for s in case['staticlib']] == ['fresh', 'green'], 'fresh and green staticlibs')
            runtime = [case[k] for k in ('baseline_runtime', 'ordinary_bfd_runtime', 'ordinary_lld_runtime')]
            for s in case['staticlib']:
                check(s['restored_native_section']['alignment'] == case['alignment'] and s['restored_native_section']['size'] == 1, 'restored section layout')
                runtime.append(s['runtime'])
            for output in runtime:
                check(output['value'] == 90 and output['alignment'] == case['alignment'] and output['address'] > 0 and output['address'] % case['alignment'] == 0, 'actual runtime alignment/value')
        seed = worktree['seed']
        check(worktree['correctness_passed'] and seed['files'] == 45 and seed['reflinked_files'] == 43 and seed['bytes'] == 793108, 'actual seeded worktree')
        check(len(seed['child_objects_before_build']) == 19 and len(worktree['hidden_donor_paths']) == 7, 'compact objects and hidden donor coverage')
        for obj in seed['child_objects_before_build'].values():
            matches = [d for d in seed['donor_objects'].values() if d['sha256'] == obj['sha256'] and d['size'] == obj['size']]
            check(matches and all((d['device'], d['inode']) != (obj['device'], obj['inode']) for d in matches), 'independent child inode with exact compact bytes')
        records = {r['label']: r for r in worktree['commands']}
        for r in worktree['commands']:
            check(r['returncode'] == 0 or (r['label'] == 'unmount-owned-fixture' and r['returncode'] == 32 and 'target is busy' in r['stderr']), 'worktree command or preserved retry')
        for label, value in {'donor-build': 42, 'donor-noop': 42, 'seeded-archive-alone': 42, 'child-with-donor-hidden': 42, 'first-private-child-edit': 43, 'second-private-child-edit': 44, 'child-final-noop': 44}.items():
            check(records[label + '-runtime']['stdout'].strip() == str(value), ('seed runtime', label))
        for label in ('donor-noop', 'child-final-noop'):
            check(records[label]['all_fresh'] and 'Compiling ' not in records[label]['stderr'], 'seed no-op freshness')
        check(re.search(r'-Z\s*link-only', records['second-private-child-edit']['stderr']), 'second private child edit replay')
        check(worktree['image_identity']['uuid'] == 'c936d1ac-5608-4c57-9cb7-511bb41f8e19' and worktree['image_identity']['size'] == 4 * 1024**3, 'bounded owned image identity')
        check(worktree['teardown']['unmounted'] and worktree['teardown']['image_preserved'] and records['unmount-owned-fixture']['returncode'] == 0 and not records['verify-loop-autoclear']['stdout'].strip(), 'owned image detached and retained')
        mac = load(cut / 'macos-stage1-build.json'); suites = load(cut / 'macos-metadata-summary.json')
        check(mac['passed'] and mac['build_exit_code'] == 0 and mac['source_unchanged'], 'macOS build proof')
        check(mac['rust_patch_sha256'] == suites['patch_sha256'] == common.PATCH and mac['wild_source'] == suites['wild_head'] == common.WILD, 'macOS source binding')
        check(suites['source_head'] == INTEGRATION and suites['runtime_source_commit'] == SOURCE and suites['source_equal_excluding_cargo_gitlink'], 'macOS suite source boundary')
        check(digest(cut / 'macos-stage1-build.log') == mac['build_log_sha256'] and digest(cut / 'macos-stage1-build.json') == suites['original_build_receipt_sha256'], 'macOS build bytes')
        for r in mac['commands']:
            check(r['exit_code'] == (1 if r['label'] == 'compact-rejected-on-macos' else 0), 'macOS build/smoke status')
        commands = {r['label']: r for r in mac['commands']}
        check(commands['ordinary-macos-runtime']['stdout'].strip() == 'macOS storeless: 42', 'macOS codegen/link/runtime')
        check('compact artifacts require 64-bit little-endian Linux ELF' in commands['compact-rejected-on-macos']['stderr'], 'clean unsupported target rejection')
        check(suites['passed'] and suites['forced_rerun'] and suites['counts']['total'] == {'passed': 21, 'failed': 0, 'ignored': 0}, 'forced macOS21 suite results')
        check(suites['all_binary_hashes_unchanged'] and suites['expected_binaries'] == suites['actual_binaries_after'], 'macOS recorded driver/std/rustdoc preservation')
        for name, sha in suites['evidence'].items():
            check(digest(cut / name) == sha, ('macOS suite evidence', name))
        for name, counts in [('macos-metadata-rmeta.log', ('12', '0', '0')), ('macos-metadata-runmake.log', ('9', '0', '0'))]:
            check(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (cut / name).read_text()) == [counts], 'actual macOS suite output')
        result.update(passed=True, checks=a.checks, source=SOURCE, integration=INTEGRATION,
                      patch_sha256=common.PATCH, cargo_runtime=common.CARGO, wild=common.WILD,
                      native_driver=build['toolchain']['drivers'], macos_driver=mac['drivers'],
                      scope='Portable receipt/source/log verification. No compiler, binary, image or network access; raw test execution and binary hash observations remain bound to recorded host receipts. No performance/adoption conclusion.')
    except BaseException as error:
        result.update(error=f'{type(error).__name__}: {error}', checks=a.checks)
        raise
    finally:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
