from pathlib import Path
import json
p=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/evidence/scanner-profile')
r=json.loads((p/'result.json').read_text())
print(json.dumps({'passed':r.get('passed'),'rows':[{'name':x['name'],'wall':x['wall_seconds'],'cpu':x['user_seconds']+x['system_seconds']} for x in r['rows']],'traces':{f.name:f.read_text() for f in sorted(p.glob('*.bpf.jsonl'))}},indent=2))
