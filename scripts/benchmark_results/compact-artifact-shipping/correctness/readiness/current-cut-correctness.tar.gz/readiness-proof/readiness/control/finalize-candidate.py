from pathlib import Path
import hashlib,json,shutil,subprocess,time
root=Path('/home/dev-user/code/oss/ohm-compact-study');work=root/'shipping/readiness';ev=work/'evidence/candidate-build'
r=json.loads((ev/'result.json').read_text());assert not r['passed'] and r['commands'][-1]['label']=='install' and r['commands'][-1]['code']==0
assert not (ev/'pre-linker-install-result.json').exists();shutil.copy2(ev/'result.json',ev/'pre-linker-install-result.json')
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def output(args,cwd=None):return subprocess.check_output(list(map(str,args)),cwd=cwd,text=True).strip()
sysroot=work/'toolchains/storeless';linker=Path('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld')
assert not (sysroot/linker).exists();(sysroot/linker).mkdir(parents=True)
for name in ('ld.bfd','compact-artifacts-v1'):shutil.copy2(root/'toolchains/compact-final-review-bounds'/linker/name,sysroot/linker/name)
r['linker_install']={'repair':'Create standalone bundled linker directory; stage1 build did not create the distribution-only payload directory.','source':str(root/'toolchains/compact-final-review-bounds'/linker),'sha256':digest(sysroot/linker/'ld.bfd'),'marker':'RCOBJ001'}
r['toolchain']={'path':str(sysroot),'version':output([sysroot/'bin/rustc','-vV']),'rustc_sha256':digest(sysroot/'bin/rustc'),'drivers':{p.name:digest(p) for p in (sysroot/'lib').glob('librustc_driver*.so')},'wild_sha256':digest(sysroot/linker/'ld.bfd'),'cargo_sha256':digest(root/'shipping/final-review/bin/cargo')}
assert list((sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/lib').glob('libstd-*.rlib'))
assert not output(['git','status','--porcelain','--ignore-submodules=all'],root/'rust')
manifest=json.loads((root/'shipping/control/readiness-inputs/candidate-manifest.json').read_text())
for name,sha in manifest['files'].items():
 p=work/'compiler/rust'/name;assert (digest(p) if p.is_file() else None)==sha,name
r['linked_libraries']={str(p.relative_to(sysroot)):digest(p) for p in (sysroot/'lib').glob('libLLVM*') if p.is_file()}
r['dynamic_dependencies']=output(['ldd',sysroot/'bin/rustc']);assert 'not found' not in r['dynamic_dependencies']
r['passed']=True;r['finished']=time.time();(ev/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'passed':True,'toolchain':r['toolchain']}),flush=True)
