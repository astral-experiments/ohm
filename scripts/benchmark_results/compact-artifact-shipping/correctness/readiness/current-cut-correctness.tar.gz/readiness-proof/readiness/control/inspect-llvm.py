from pathlib import Path
import subprocess,json
base=Path('/tmp/codex-cargo-targets/ohm/isolated');old=base/'compact-objects/bootstrap';new=base/'compact-readiness/bootstrap'
for path in (old,new):
 print('ROOT',path)
 print('\n'.join(str(p)+(' -> '+str(p.resolve()) if p.is_symlink() else '') for p in path.rglob('libLLVM*') if p.is_file()))
 stage=path/'x86_64-unknown-linux-gnu/stage1'
 for p in list((stage/'lib').glob('librustc_driver*.so'))+[stage/'bin/rustc']:
  r=subprocess.run(['readelf','-d',str(p)],capture_output=True,text=True)
  print(p);print('\n'.join(line for line in r.stdout.splitlines() if 'NEEDED' in line or 'RPATH' in line or 'RUNPATH' in line))
 print('llvmstamp',[(str(p),p.read_text()[:200]) for p in path.rglob('*llvm*.stamp')])
