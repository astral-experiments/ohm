import hashlib,json,os,subprocess,time
from pathlib import Path
repo=Path('/private/tmp/ohm-compact-shipping/rust'); ev=Path('/private/tmp/ohm-compact-shipping-evidence/storeless-cut');ev.mkdir(exist_ok=True)
formatter='/Users/charliemarsh/.rustup/toolchains/nightly-2026-07-19-aarch64-apple-darwin/bin/rustfmt'
env={**os.environ,'CARGO_HOME':'/private/tmp/codex-cargo-home','CARGO_TARGET_DIR':'/private/tmp/codex-cargo-targets/ohm-rust/ohm-compact-incremental-rust/ohm','RUSTUP_TOOLCHAIN':'ohm','CARGO_BUILD_JOBS':'8'}
for key in ['GITHUB_ACTIONS','CARGO_BUILD_BUILD_DIR','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTDOC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:
 env.pop(key,None)
base=['python3','x.py','--config','/private/tmp/ohm-compact-incremental-rust/bootstrap.toml','--ci','false','--set','build.submodules=false','--set',f'build.rustfmt={formatter}']
checks=[('fmt',base+['fmt','--check']),('tidy',base+['test','tidy']),('compiler-check',base+['--set','rust.debug-assertions=true','--set','rust.lto=off','--warnings','deny','check','compiler'])]
receipt={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'scope':'Local macOS compiler check of uncommitted storeless-only candidate; Linux correctness/performance pending','started':time.time(),'steps':[]}
for label,argv in checks:
 log=ev/f'{label}.log'; start=time.monotonic();print(f'Starting {label}',flush=True)
 with log.open('w') as out: result=subprocess.run(argv,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 item={'label':label,'argv':argv,'exit_code':result.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};receipt['steps'].append(item);receipt['passed']=all(s['exit_code']==0 for s in receipt['steps']) and len(receipt['steps'])==len(checks)
 (ev/'local-validation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(f'Finished {label}: exit {result.returncode} in {item["seconds"]:.1f}s',flush=True)
 if result.returncode: print(log.read_text()[-6000:],flush=True);break
