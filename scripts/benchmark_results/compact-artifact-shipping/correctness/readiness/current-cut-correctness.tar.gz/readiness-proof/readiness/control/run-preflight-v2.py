from pathlib import Path
import hashlib,json,os,subprocess,time
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness')
script=work/'harness/benchmark_readiness_v2.py';review=json.loads((work/'harness/harness-review-v2.json').read_text())
assert review['passed'] and hashlib.sha256(script.read_bytes()).hexdigest()==review['script_sha256']=='4ddd91a0cc2003347f789fce4722da9bb4b27e264abff1266d6e9c0ca0732588'
assert json.loads((work/'evidence/candidate-package/result.json').read_text())['passed']
log=work/'evidence/fixture-preflight-v2.log';assert not log.exists()
with log.open('w') as output:
 result=subprocess.run(['python3',str(script),'--preflight'],env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=output,stderr=subprocess.STDOUT)
print(json.dumps({'exit_code':result.returncode,'log':str(log)}),flush=True)
raise SystemExit(result.returncode)
