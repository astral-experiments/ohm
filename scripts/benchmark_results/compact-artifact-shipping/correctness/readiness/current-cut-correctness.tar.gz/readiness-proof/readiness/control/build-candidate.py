import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/home/dev-user/code/oss/ohm-compact-study');work=root/'shipping/readiness';inputs=root/'shipping/control/readiness-inputs'
evidence=work/'evidence/candidate-build';assert not evidence.exists();evidence.mkdir()
manifest=json.loads((inputs/'candidate-manifest.json').read_text())
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def output(cmd,cwd=None):return subprocess.check_output(list(map(str,cmd)),cwd=cwd,text=True).strip()
assert digest(inputs/'candidate.patch')==manifest['patch_sha256']
assert json.loads((work/'evidence/scanner-profile/result.json').read_text())['passed']
source=work/'compiler/rust';original=root/'rust';target=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/bootstrap')
assert not source.exists() and not target.exists()
assert output(['git','rev-parse','--show-toplevel'],original)==str(original)
assert output(['git','config','user.email'],original)=='charlie.r.marsh@gmail.com'
assert output(['git','rev-parse','HEAD'],original)==manifest['base']
assert not output(['git','status','--porcelain','--ignore-submodules=all'],original)
assert shutil.disk_usage(work).free>110*1024**3
(source.parent).mkdir();(source.parent/'wild').symlink_to(root/'wild',target_is_directory=True)
receipt={'passed':False,'base':manifest['base'],'patch_sha256':manifest['patch_sha256'],'started':time.time(),'commands':[],'source':str(source),'target':str(target),'wild':output(['git','rev-parse','HEAD'],root/'wild'),'production_pgo_bolt':False}
assert receipt['wild']=='9179eb988df2676342192a24dc337cf9823e9d56'
def save(): (evidence/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(label,cmd,cwd=None,env=None):
 row={'label':label,'argv':list(map(str,cmd)),'cwd':str(cwd) if cwd else None,'started':time.time()};receipt['commands'].append(row);save()
 with (evidence/f'{label}.log').open('w') as log:p=subprocess.run(row['argv'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(code=p.returncode,seconds=time.time()-row['started']);save();print(json.dumps({'step':label,'code':p.returncode,'seconds':row['seconds']}),flush=True)
 assert p.returncode==0,label
try:
 run('worktree',['git','worktree','add','-b','charlie/compact-readiness-storeless',source,manifest['base']],original)
 run('base-branch',['git','branch','charlie/compact-readiness-954',manifest['base']],original)
 run('upstream',['git','branch','--set-upstream-to=charlie/compact-readiness-954','charlie/compact-readiness-storeless'],source)
 for line in output(['git','submodule','status'],original).splitlines():
  if line[0]=='-':continue
  rel=line.split()[1];a=original/rel;b=source/rel
  if a.is_dir():run('copy-submodule-'+rel.replace('/','-'),['rsync','-a','--exclude=.git',str(a)+'/',str(b)+'/'])
 run('apply',['git','apply','--binary',inputs/'candidate.patch'],source)
 for path,sha in manifest['files'].items():assert (digest(source/path) if (source/path).is_file() else None)==sha,path
 # Copy reusable bootstrap inputs and outputs; dereference links so this build cannot write through into the retained target.
 old=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-objects/bootstrap')
 run('copy-bootstrap',['cp','-aL','--reflink=auto',old,target])
 config=(original/'bootstrap.toml').read_text().replace(str(old),str(target))
 (source/'bootstrap.toml').write_text(config)
 env={k:v for k,v in os.environ.items() if not k.startswith(('RUSTFLAGS','RUSTC','RUSTDOC','CARGO_PROFILE_','CARGO_TARGET_','CARGO_UNSTABLE_','CARGO_ENCODED_','CARGO_BUILD_','RUSTUP_TOOLCHAIN'))}
 env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='12')
 common=['--stage','1','--set','build.submodules=false','--set',f'target.x86_64-unknown-linux-gnu.ohm-wild-linker={root}/shipping/final-review/bounds-fix/wild-release']
 run('compiler-build',['python3','x.py','build',*common,'compiler/rustc','src/tools/rustdoc','library'],source,env)
 run('compiler-tests',['python3','x.py','test',*common,'--force-rerun','tests/run-make/compact-artifact-exports','tests/run-make/public-api-hash-artifact'],source,env)
 sysroot=work/'toolchains/storeless';assert not sysroot.exists()
 run('install',['cp','-aL','--reflink=auto',target/'x86_64-unknown-linux-gnu/stage1',sysroot])
 linker=Path('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld')
 for name in ('ld.bfd','compact-artifacts-v1'):
  shutil.copy2(root/'toolchains/compact-final-review-bounds'/linker/name,sysroot/linker/name)
 receipt['toolchain']={'path':str(sysroot),'version':output([sysroot/'bin/rustc','-vV']),'rustc_sha256':digest(sysroot/'bin/rustc'),'drivers':{p.name:digest(p) for p in (sysroot/'lib').glob('librustc_driver*.so')},'wild_sha256':digest(sysroot/linker/'ld.bfd'),'cargo_sha256':digest(root/'shipping/final-review/bin/cargo')}
 assert not output(['git','status','--porcelain','--ignore-submodules=all'],original)
 for path,sha in manifest['files'].items():assert (digest(source/path) if (source/path).is_file() else None)==sha,path
 receipt['passed']=True
finally:
 receipt['finished']=time.time();save()
print(json.dumps({'passed':receipt['passed'],'evidence':str(evidence)}),flush=True)
