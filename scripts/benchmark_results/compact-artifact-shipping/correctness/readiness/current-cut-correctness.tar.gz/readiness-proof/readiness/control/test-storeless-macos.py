from pathlib import Path
import hashlib,json,os,platform,re,shutil,subprocess,time
RUST=Path('/private/tmp/ohm-compact-shipping/rust');WILD=RUST.parent/'wild'
EVIDENCE=Path('/private/tmp/ohm-compact-shipping-evidence/storeless-cut')
BUILD=Path('/private/tmp/codex-cargo-targets/ohm-rust/ohm-compact-incremental-rust/ohm/bootstrap')
CONFIG=Path('/private/tmp/ohm-compact-incremental-rust/bootstrap.toml')
SOURCE='54f8b75ac31207d47af50fc8c5bc9dc90f2457de';CUT='3b84b46e3fb38f80246f744275c69fe608dfb2f3';WILD_HEAD='9179eb988df2676342192a24dc337cf9823e9d56'
def out(args,cwd=RUST):return subprocess.check_output(args,cwd=cwd,text=True).strip()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
build_receipt=json.loads((EVIDENCE/'macos-stage1-build.json').read_text());manifest=json.loads((EVIDENCE/'candidate-manifest.json').read_text())
stage=Path(build_receipt['compiler']).parent.parent
expected={stage/'bin/rustc':build_receipt['compiler_sha256'],stage/'bin/rustdoc':build_receipt['rustdoc_sha256']}
expected.update({stage/'lib'/p:h for p,h in build_receipt['drivers'].items()})
expected.update({stage/'lib/rustlib/aarch64-apple-darwin/lib'/p:h for p,h in build_receipt['standard_library'].items()})
def verify():
 assert out(['git','rev-parse','HEAD'])==SOURCE
 assert out(['git','diff','--name-only',CUT,SOURCE])=='src/tools/cargo'
 assert not out(['git','status','--porcelain'])
 assert out(['git','rev-parse','HEAD'],WILD)==WILD_HEAD
 for name,h in manifest['files'].items():
  p=RUST/name;assert (sha(p) if p.exists() else None)==h,name
 assert all(sha(p)==h for p,h in expected.items()),'compiler/rustdoc/std bytes changed'
verify();assert platform.machine()=='arm64' and shutil.disk_usage(BUILD).free>10*1024**3
runmake=[]
for pattern in ('public-api-hash*','rdr-public-hash*','incremental-directory-copy','incremental-session-fail'):
 runmake.extend(str(p.relative_to(RUST)) for p in sorted((RUST/'tests/run-make').glob(pattern)))
assert len(runmake)==9,runmake
common=['python3','x.py','--config',str(CONFIG),'--ci','false','--set','build.submodules=false','--set','build.jobs=8','--set','rust.lto=off','test','--stage','1','--force-rerun']
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST'))};env.update(build_receipt['environment'])
receipt={'passed':False,'started':time.time(),'source_head':SOURCE,'runtime_source_commit':CUT,'wild_head':WILD_HEAD,'patch_sha256':manifest['patch_sha256'],'source_delta':['src/tools/cargo'],'source_equal_excluding_cargo_gitlink':True,'build_receipt_sha256':sha(EVIDENCE/'macos-stage1-build.json'),'configuration_text':CONFIG.read_text(),'configuration_sha256':sha(CONFIG),'expected_binaries':{str(p):h for p,h in expected.items()},'environment':build_receipt['environment'],'commands':[],'scope':'Forced focused rmeta and public-hash/incremental run-make tests using the existing optimized macOS stage1 compiler with debug assertions disabled, unchanged LTO-off build configuration. No compact Linux export suite or full CI.'}
result_path=EVIDENCE/'macos-metadata-suites.json';assert not result_path.exists()
def save():result_path.write_text(json.dumps(receipt,indent=2)+'\n')
save()
try:
 for label,paths,expected_count in [('rmeta',['tests/ui/rmeta'],12),('runmake',runmake,9)]:
  verify();log=EVIDENCE/('macos-metadata-'+label+'.log');assert not log.exists()
  row={'label':label,'argv':common+paths,'cwd':str(RUST),'expected_minimum_passed':expected_count};receipt['commands'].append(row);save();start=time.monotonic();print('Starting '+label,flush=True)
  with log.open('w') as stream:result=subprocess.run(row['argv'],cwd=RUST,env=env,stdout=stream,stderr=subprocess.STDOUT)
  text=log.read_text();counts=[{'passed':int(p),'failed':int(f),'ignored':int(i)} for p,f,i in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored',text)]
  row.update(exit_code=result.returncode,seconds=time.monotonic()-start,counts=counts,log_sha256=sha(log));save();print(json.dumps(row),flush=True)
  verify();assert result.returncode==0,label+' suite failed; see log'
  assert counts and counts[-1]['passed']>=expected_count and counts[-1]['failed']==0 and counts[-1]['ignored']==0,(label,counts)
 verify();receipt.update(passed=True,source_unchanged=True,binaries_unchanged=True)
except BaseException as error:receipt['error']=repr(error);raise
finally:receipt['finished']=time.time();save()
