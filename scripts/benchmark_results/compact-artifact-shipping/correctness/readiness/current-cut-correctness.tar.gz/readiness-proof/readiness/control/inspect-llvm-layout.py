from pathlib import Path
import subprocess,os
base=Path('/tmp/codex-cargo-targets/ohm/isolated')
for task in ('compact-objects','compact-readiness'):
 root=base/task/'bootstrap';print(task)
 for d in ('host','x86_64-unknown-linux-gnu'):
  p=root/d;print(d,'symlink',p.is_symlink(),'realpath',p.resolve())
  for name in ('ci-llvm/lib/libLLVM-23-rust-1.99.0-beta.so','ci-llvm/lib/libLLVM.so.23.1-rust-1.99.0-beta','stage1/lib/libLLVM.so.23.1-rust-1.99.0-beta'):
   f=p/name;print(str(f),'link',f.is_symlink(),'bytes',f.stat().st_size if f.exists() else None,'prefix',f.open('rb').read(8) if f.exists() else None)
 p=root/'x86_64-unknown-linux-gnu/stage1/bin/rustc';r=subprocess.run([str(p),'-vV'],capture_output=True,text=True);print(r.returncode,r.stdout,r.stderr)
