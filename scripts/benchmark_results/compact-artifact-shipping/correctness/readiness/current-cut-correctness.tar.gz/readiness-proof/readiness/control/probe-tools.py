import json
from pathlib import Path
import subprocess

root=Path('/home/dev-user/code/oss/ohm-compact-study')
sysroot=root/'toolchains/compact-final-review-bounds'
driver=next((sysroot/'lib').glob('librustc_driver-*.so'))
def run(argv):
    p=subprocess.run(list(map(str,argv)),capture_output=True,text=True)
    return {'argv':list(map(str,argv)), 'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
data={}
for dynamic in (False,True):
    argv=['nm', '-C', *(['-D'] if dynamic else []), driver]
    r=run(argv)
    r['stdout']='\n'.join(line for line in r['stdout'].splitlines() if any(name in line for name in ('materialize_compressed_rlibs','rlib_contains_compact_objects','compressed_artifacts')))
    data['symbols_dynamic' if dynamic else 'symbols']=r
data['perf_user']=run(['perf','stat','-e','task-clock','true'])
data['perf_sudo']=run(['sudo','-n','perf','stat','-e','task-clock','true'])
data['worktree_help']=run(['/home/dev-user/.cargo/bin/cargo','+ohm','worktree','add','--help'])
data['cpu']=run(['lscpu'])
data['bootstrap_config']=(root/'rust/bootstrap.toml').read_text()
print(json.dumps(data,indent=2))
