from pathlib import Path
import hashlib,json,os,subprocess,time
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness')
script=work/'harness/benchmark_readiness.py';review=json.loads((work/'harness/harness-review.json').read_text())
assert review['passed'] and hashlib.sha256(script.read_bytes()).hexdigest()==review['script_sha256']=='5d9e4dc225be302ca13b3f88bf857604aac4e9984887cad5f133aa139691b0d4'
status=json.loads((work/'evidence/fixture-preflight/status.json').read_text());assert status['passed'] and status['samples']==26
assert not any(name.startswith('RUSTC_LOG') for name in os.environ)
log=work/'evidence/real-edit-matrix.log';assert not log.exists()
with log.open('w') as output:
 result=subprocess.run(['python3',str(script)],env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=output,stderr=subprocess.STDOUT)
print(json.dumps({'exit_code':result.returncode,'log':str(log)}),flush=True)
raise SystemExit(result.returncode)
