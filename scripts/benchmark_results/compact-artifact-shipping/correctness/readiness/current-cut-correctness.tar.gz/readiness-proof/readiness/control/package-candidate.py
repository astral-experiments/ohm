from pathlib import Path
import hashlib,html,importlib.util,json,os,re,shutil,subprocess,tarfile,time
root=Path('/home/dev-user/code/oss/ohm-compact-study');work=root/'shipping/readiness';source=work/'compiler/rust';target=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/bootstrap')
inputs=root/'shipping/control/readiness-inputs';ev=work/'evidence/candidate-package';assert not ev.exists();ev.mkdir()
assembly=json.loads((work/'evidence/candidate-build/result.json').read_text());assert assembly['passed']
sysroot=work/'toolchains/storeless';wild=root/'shipping/final-review/bounds-fix/wild-release';cargo=root/'shipping/final-review/bin/cargo'
receipt={'passed':False,'base':assembly['base'],'patch_sha256':assembly['patch_sha256'],'scope':'Actual rustc component tar generation and installer into private prefix, completed with this candidate standard library and Cargo4a; exact compact release smoke. Non-PGO; not complete multi-component release installer or production CI.','started':time.time(),'commands':[]}
def digest(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
def save(): (ev/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith(('RUSTFLAGS','RUSTC','RUSTDOC','CARGO_PROFILE_','CARGO_TARGET_','CARGO_UNSTABLE_','CARGO_ENCODED_','CARGO_BUILD_','RUSTUP_TOOLCHAIN'))}
env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='8')
def run(name,cmd,cwd=None,extra=None):
 log=ev/f'{name}.log';row={'name':name,'argv':list(map(str,cmd)),'cwd':str(cwd) if cwd else None,'started':time.time()};receipt['commands'].append(row);save()
 with log.open('w') as f:p=subprocess.run(row['argv'],cwd=cwd,env={**env,**(extra or {})},stdout=f,stderr=subprocess.STDOUT)
 row.update(exit_code=p.returncode,seconds=time.time()-row['started'],log_sha256=digest(log));save();assert p.returncode==0,name
 print(json.dumps({'step':name,'seconds':row['seconds']}),flush=True)
try:
 tests=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (work/'evidence/candidate-build/compiler-tests.log').read_text())
 assert tests==[('2','0','0')],tests
 receipt['forced_run_make']={'passed':2,'failed':0,'ignored':0}
 run('distribution',['python3','x.py','dist','--stage','1','--set','build.submodules=false','--set',f'target.x86_64-unknown-linux-gnu.ohm-wild-linker={wild}','--set','dist.compression-formats=["gz"]','rustc'],source)
 archives=list((target/'dist').glob('rustc-*-x86_64-unknown-linux-gnu.tar.gz'));assert len(archives)==1;archive=archives[0]
 receipt['archive']={'path':str(archive),'sha256':digest(archive),'bytes':archive.stat().st_size}
 case=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/installed-smoke');assert not case.exists();case.mkdir()
 extracted=case/'component';extracted.mkdir()
 with tarfile.open(archive,'r:gz') as tar:
  members=tar.getmembers()
  def payload(suffix):
   found=[m for m in members if m.name.endswith(suffix)];assert len(found)==1 and found[0].isfile(),suffix
   return tar.extractfile(found[0]).read()
  assert hashlib.sha256(payload('/bin/wild-ld/ld.bfd')).hexdigest()==assembly['toolchain']['wild_sha256']==digest(wild/'wild')
  assert payload('/bin/wild-ld/compact-artifacts-v1')==b'RCOBJ001\n'
  receipt['licenses']={}
  for name in ('LICENSE-APACHE','LICENSE-MIT'):
   text=(root/'wild'/name).read_bytes();assert payload('/licenses/wild-'+name)==text
   receipt['licenses'][name]=hashlib.sha256(text).hexdigest()
  copyright=html.unescape(payload('/share/doc/rust/COPYRIGHT.html').decode())
  section=copyright.split('<h3>📦 compact-artifact-0.1.0</h3>',1)[1].split('<h3>',1)[0]
  for name in ('LICENSE-APACHE','LICENSE-MIT'):assert (root/'wild/compact-artifact'/name).read_text() in section
  for name,sha in assembly['toolchain']['drivers'].items():assert hashlib.sha256(payload('/lib/'+name)).hexdigest()==sha
  tar.extractall(extracted,filter='data')
 prefix=case/'toolchain';component=next(extracted.iterdir())
 run('install-component',['sh',component/'install.sh',f'--prefix={prefix}','--disable-ldconfig'])
 librel=Path('lib/rustlib/x86_64-unknown-linux-gnu/lib')
 for existing in (prefix/librel).rglob('*') if (prefix/librel).exists() else []:
  if existing.is_file():assert digest(existing)==digest(sysroot/librel/existing.relative_to(prefix/librel))
 shutil.copytree(sysroot/librel,prefix/librel,symlinks=False,dirs_exist_ok=True)
 shutil.copy2(cargo,prefix/'bin/cargo')
 for name in ('rustc','rustdoc'):
  assert digest(prefix/'bin'/name)==digest(sysroot/'bin'/name)
 for name,sha in assembly['toolchain']['drivers'].items():assert digest(prefix/'lib'/name)==sha
 assert digest(prefix/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')==assembly['toolchain']['wild_sha256']
 assert (prefix/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/compact-artifacts-v1').read_bytes()==b'RCOBJ001\n'
 assert digest(prefix/'bin/cargo')==assembly['toolchain']['cargo_sha256']
 release=inputs/'smoke-test-release.sh';helper=inputs/'smoke_test_compact.py';crate=case/'crate';fixture={}
 for relative in ['Cargo.toml','macros/Cargo.toml','macros/src/lib.rs','src/main.rs','src/lib.rs']:
  expr=r'cat > "\$smoke_crate/'+re.escape(relative)+r'" <<\x27EOF\x27\n(.*?)\nEOF\n'
  matches=re.findall(expr,release.read_text(),re.DOTALL);assert len(matches)==1,relative
  path=crate/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(matches[0]+'\n');fixture[relative]=digest(path)
 manifest=work/'evidence/candidate-package/source-manifest.json';manifest.write_text(json.dumps({'bundled_tools':{'wild':{'source':{'revision':'9179eb988df2676342192a24dc337cf9823e9d56'}}}})+'\n')
 extra={'RUSTC':str(prefix/'bin/rustc'),'RUSTDOC':str(prefix/'bin/rustdoc'),'CARGO_TARGET_DIR':str(case/'defaults-target'),'CARGO_BUILD_BUILD_DIR':str(case/'defaults-build')}
 run('defaults-build',[prefix/'bin/cargo','build','--offline','--manifest-path',crate/'Cargo.toml'],crate,extra)
 run('compact-smoke',['python3',helper,manifest,'x86_64-unknown-linux-gnu',prefix,crate,case],crate,extra)
 spec=importlib.util.spec_from_file_location('smoke',helper);smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
 receipt['default_compact_members']=smoke.compact_members(case/'defaults-target/debug/libohm_smoke.rlib')
 receipt['optin_compact_members']=smoke.compact_members(case/'compact-target/debug/libohm_smoke.rlib')
 assert receipt['default_compact_members']==0 and receipt['optin_compact_members']>0
 receipt.update(passed=True,driver_hashes=assembly['toolchain']['drivers'],cargo_sha256=digest(cargo),wild_sha256=digest(wild/'wild'),marker='RCOBJ001',shared_crate_copyright_notices_verified=True,fixture=fixture,helper_sha256=digest(helper),release_script_sha256=digest(release),prefix=str(prefix),production_pgo_bolt=False)
except BaseException as error:
 receipt['error']=f'{type(error).__name__}: {error}';raise
finally:
 receipt['finished']=time.time();save()
print(json.dumps({'passed':receipt['passed'],'evidence':str(ev)}),flush=True)
