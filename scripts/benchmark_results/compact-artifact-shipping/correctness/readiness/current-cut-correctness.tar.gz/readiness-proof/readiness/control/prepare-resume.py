import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/home/dev-user/code/oss/ohm-compact-study')
work=root/'shipping/readiness'
target=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness')
assert work.is_dir() and target.is_dir()
assert shutil.disk_usage(root).free > 100*1024**3
assert (work/'.owned').read_text() == 'compact readiness investigation\n'
(work/'.owned').write_text('compact readiness investigation\n'); (target/'.owned').write_text('compact readiness investigation\n')
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def run(cmd,cwd=None,env=None):
 p=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env,capture_output=True,text=True)
 r={'argv':list(map(str,cmd)),'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 print(json.dumps(r),flush=True)
 assert p.returncode==0
 return p.stdout.strip()
receipt={'started':time.time(),'sources':{},'instructions':{}}
for project in ('ruff','uv'):
 old=root/'sources'/project; new=work/'sources'/project
 assert run(['git','config','user.email'],old)=='charlie.r.marsh@gmail.com'
 head=run(['git','rev-parse','HEAD'],old)
 patch=subprocess.check_output(['git','diff','--binary'],cwd=old)
 (work/'evidence'/f'{project}-compatibility.patch').write_bytes(patch)
 env={**os.environ,'CARGO_HOME':'/tmp/codex-cargo-home','CARGO_TARGET_DIR':str(target/'source-seeding'/project),'CARGO_BUILD_BUILD_DIR':str(target/'shared-source-seeding')}
 branch=f'charlie/compact-readiness-{project}'
 if not new.exists(): run(['/home/dev-user/.cargo/bin/cargo','+ohm','worktree','add','-b',branch,new,'--target-dir',target/'prepared'/project,head],old,env)
 assert run(['git','rev-parse','HEAD'],new)==head
 base_branch=f'charlie/compact-readiness-base-{project}'
 run(['git','branch',base_branch,head],old)
 run(['git','branch',f'--set-upstream-to={base_branch}',branch],new)
 if patch: subprocess.run(['git','apply','--binary','-'],cwd=new,input=patch,check=True)
 assert subprocess.check_output(['git','diff','--binary'],cwd=new)==patch
 instructions={str(p.relative_to(new)):p.read_text() for p in new.rglob('AGENTS.md') if '.git' not in p.parts}
 receipt['instructions'][project]=instructions
 receipt['sources'][project]={'original':str(old),'path':str(new),'head':head,'patch_sha256':hashlib.sha256(patch).hexdigest(),'branch':branch,'status':run(['git','status','--short'],new)}
base=root/'toolchains/baseline-shipping'; new=work/'toolchains/baseline-same-wild'
new.parent.mkdir()
run(['cp','-aL','--reflink=auto',base,new])
current=root/'toolchains/compact-final-review-bounds'
for name in ('ld.bfd','compact-artifacts-v1'):
 path=Path('lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld')/name
 shutil.copy2(current/path,new/path)
receipt['baseline_clone']={'source':str(base),'path':str(new),'driver':{p.name:digest(p) for p in (new/'lib').glob('librustc_driver*.so')},'wild':digest(new/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')}
receipt['finished']=time.time()
(work/'evidence/preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
