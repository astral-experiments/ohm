import importlib.util,json,os,shutil,signal,subprocess,time
from pathlib import Path
from types import SimpleNamespace
root=Path('/home/dev-user/code/oss/ohm-compact-study');work=root/'shipping/readiness'
assert (work/'evidence/preparation.json').is_file()
out=work/'evidence/scanner-profile';assert not out.exists();out.mkdir()
lane=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/scanner-profile');assert not lane.exists();lane.mkdir();(lane/'scratch').mkdir()
spec=importlib.util.spec_from_file_location('core',root/'harness/benchmark.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
sysroot=root/'toolchains/compact-final-review-bounds';cargo=root/'shipping/final-review/bin/cargo';source=work/'sources/ruff'
args=SimpleNamespace(baseline=sysroot,candidate=sysroot,compression_profile='fast',cargo_home=Path('/tmp/codex-cargo-home'),jobs=8,profile='line')
env,flags=core.environment(args,'standard',lane,'ruff')
for key in list(env):
 if key.startswith('RUSTC_LOG'):del env[key]
argv=[str(cargo),'-Zohm-defaults=yes','build','--offline','--locked','-vv','-p','ruff','--bin','ruff','-j','8']
driver=next((sysroot/'lib').glob('librustc_driver-*.so'))
symbols=subprocess.check_output(['nm',str(driver)],text=True)
syms={name:next(line.split()[-1] for line in symbols.splitlines() if name in line) for name in ('materialize_compressed_rlibs','rlib_contains_compact_objects')}
program='BEGIN { printf("READY\\n"); }\n'
for label,name in [('materialize','materialize_compressed_rlibs'),('scan','rlib_contains_compact_objects')]:
 probe=f'{driver}:{syms[name]}'
 program+=f'uprobe:{probe} {{ @{label}_start[tid] = nsecs; }}\n'
 program+=f'uretprobe:{probe} /@{label}_start[tid]/ {{ @{label}_count[pid] = count(); @{label}_ns[pid] = sum(nsecs - @{label}_start[tid]); delete(@{label}_start[tid]); }}\n'
program+='END { clear(@materialize_start); clear(@scan_start); }\n'
(out/'scanner.bt').write_text(program)
receipt={'scope':'External uprobes on current954 compiler; instrumented causal diagnostics only, not accepted timing samples','driver':str(driver),'driver_sha256':core.digest(driver),'cargo_sha256':core.digest(cargo),'flags':flags,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'rows':[]}
fixture=core.Fixture(source,'ruff');original=subprocess.check_output(['git','diff','--binary'],cwd=source)
def build(name,expected,instrument=False):
 bpf=None; streams=[]
 try:
  if instrument:
   output=out/f'{name}.bpf.jsonl';errors=out/f'{name}.bpf.stderr'
   streams=[output.open('w'),errors.open('w')]
   bpf=subprocess.Popen(['sudo','-n','bpftrace','-B','none','-f','json',str(out/'scanner.bt')],stdout=streams[0],stderr=streams[1],start_new_session=True)
   for _ in range(200):
    if 'READY' in output.read_text():break
    assert bpf.poll() is None, errors.read_text()
    time.sleep(.1)
   else:raise RuntimeError('uprobes readiness timed out')
  row=core.timed(argv,source,env,out/name,[lane],False,60*1024**3)
  row.update(name=name,instrumented=instrument,accepted=False)
  assert row['returncode']==0,row
  row['oracle']=core.runtime(lane/'target/debug/ruff',expected,(out/name).with_suffix('.oracle.json'))
  assert row['oracle']['passed']
  if not instrument:
   row['formats']=core.formats([lane],'standard');assert row['formats']['passed']
  receipt['rows'].append(row)
 finally:
  if bpf:
   subprocess.run(['sudo','-n','kill','-INT','--',f'-{bpf.pid}'],check=True)
   bpf.wait(timeout=15)
  for stream in streams:stream.close()
  (out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'name':name,'done':True}),flush=True)
try:
 fixture.write(library=3);build('00-prepare',3)
 for index in range(1,4):
  fixture.write(library=3,inline=index);build(f'{index:02}-inline',3+index,True)
 receipt['passed']=True
finally:
 fixture.restore()
 receipt['source_restored']=subprocess.check_output(['git','diff','--binary'],cwd=source)==original
 receipt['finished']=time.time()
 (out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':receipt.get('passed',False),'out':str(out)}),flush=True)
