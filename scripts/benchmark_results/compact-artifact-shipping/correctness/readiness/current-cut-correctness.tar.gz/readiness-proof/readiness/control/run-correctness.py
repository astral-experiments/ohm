from pathlib import Path
import hashlib,json,subprocess
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness')
script=work/'correctness/run_correctness.py'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='3a86821e3aa91c019bc78aff137c41d4ffd679fb05ab0d2022d67bf3a30a586d'
review=json.loads((work/'correctness/independent-review.json').read_text());assert review['passed']
result=subprocess.run(['python3',str(script)])
raise SystemExit(result.returncode)
