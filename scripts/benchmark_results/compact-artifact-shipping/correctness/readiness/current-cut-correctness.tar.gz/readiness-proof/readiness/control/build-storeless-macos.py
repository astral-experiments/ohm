from pathlib import Path
import hashlib,json,os,platform,shutil,subprocess,time
root=Path('/private/tmp/ohm-compact-shipping');rust=root/'rust';wild=root/'wild';evidence=Path('/private/tmp/ohm-compact-shipping-evidence/storeless-cut')
build=Path('/private/tmp/codex-cargo-targets/ohm-rust/ohm-compact-incremental-rust/ohm/bootstrap');config=Path('/private/tmp/ohm-compact-incremental-rust/bootstrap.toml')
manifest=json.loads((evidence/'candidate-manifest.json').read_text());expectedwild='9179eb988df2676342192a24dc337cf9823e9d56'
def out(argv,cwd=None):return subprocess.check_output(argv,cwd=cwd,text=True).strip()
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verify_source():
 assert out(['git','rev-parse','HEAD'],rust)==manifest['base']
 assert out(['git','rev-parse','HEAD'],wild)==expectedwild
 assert not out(['git','status','--porcelain'],wild)
 for p,h in manifest['files'].items():
  p=rust/p;assert (digest(p) if p.exists() else None)==h,str(p)
 assert out(['git','diff','HEAD','--','Cargo.lock'],rust)==''
verify_source();assert shutil.disk_usage(root).free>20*1024**3
stage=build/'aarch64-apple-darwin/stage1'
env={key:value for key,value in os.environ.items() if not key.startswith(('CARGO_','RUST'))}
env.update(CARGO_HOME='/private/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(build.parent),RUSTUP_TOOLCHAIN='ohm')
command=['python3','x.py','--config',str(config),'--ci','false','--set','build.submodules=false','--set','build.jobs=8','--set','rust.lto=off','build','--stage','1','compiler/rustc','src/tools/rustdoc','library']
receipt={'passed':False,'started':time.time(),'rust_base':manifest['base'],'rust_patch_sha256':manifest['patch_sha256'],'wild_source':expectedwild,'wild_compact_tree':out(['git','rev-parse','HEAD:compact-artifact'],wild),'platform':platform.platform(),'argv':command,'cwd':str(rust),'environment':{key:env[key] for key in ('CARGO_HOME','CARGO_TARGET_DIR','RUSTUP_TOOLCHAIN')},'build_dir':str(build),'config':str(config),'config_text':config.read_text(),'free_bytes_before':shutil.disk_usage(root).free,'previous_cache_drivers':{p.name:digest(p) for p in (stage/'lib').glob('librustc_driver*.dylib')},'scope':'Current uncommitted storeless Rust candidate on macOS: non-PGO stage1 compiler/rustdoc/std build, ordinary link/runtime, compact-target rejection. Not optimized distribution or Linux compact validation.','commands':[]}
path=evidence/'macos-stage1-build.json';log=evidence/'macos-stage1-build.log';assert not path.exists() and not log.exists()
def save():path.write_text(json.dumps(receipt,indent=2)+'\n')
save();start=time.monotonic();print('Starting cached macOS compiler/rustdoc/std build',flush=True)
try:
 with log.open('w') as stream:result=subprocess.run(command,cwd=rust,env=env,stdout=stream,stderr=subprocess.STDOUT)
 receipt.update(build_exit_code=result.returncode,build_seconds=time.monotonic()-start,build_log_sha256=digest(log));save();assert result.returncode==0,'stage1 build failed; see log'
 compiler=stage/'bin/rustc';rustdoc=stage/'bin/rustdoc';assert compiler.is_file() and rustdoc.is_file()
 receipt['compiler']=str(compiler);receipt['compiler_sha256']=digest(compiler);receipt['rustdoc_sha256']=digest(rustdoc)
 receipt['drivers']={p.name:digest(p) for p in (stage/'lib').glob('librustc_driver*.dylib')};assert receipt['drivers']
 std=stage/'lib/rustlib/aarch64-apple-darwin/lib';receipt['standard_library']={p.name:digest(p) for p in std.glob('libstd-*.rlib')};assert receipt['standard_library']
 fixture=build.parent/'storeless-macos-smoke';assert not fixture.exists();fixture.mkdir()
 source=fixture/'main.rs';source.write_text('fn main() { let values: Vec<u64> = (0..=6).collect(); let sum: u64 = values.iter().sum(); assert_eq!(sum, 21); println!("macOS storeless: {}", sum * 2); }\n')
 receipt['fixture_source_sha256']=digest(source)
 def run(label,argv,bootstrap=False):
  environment=dict(env)
  if bootstrap:environment['RUSTC_BOOTSTRAP']='1'
  started=time.monotonic();result=subprocess.run(list(map(str,argv)),cwd=fixture,env=environment,capture_output=True,text=True)
  receipt['commands'].append({'label':label,'argv':list(map(str,argv)),'cwd':str(fixture),'rustc_bootstrap':bootstrap,'seconds':time.monotonic()-started,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr});save();return result
 version=run('version',[compiler,'-vV']);assert version.returncode==0 and 'host: aarch64-apple-darwin' in version.stdout
 doc=run('rustdoc-version',[rustdoc,'-vV']);assert doc.returncode==0
 normal=fixture/'ordinary';compiled=run('ordinary-macos-codegen-link',[compiler,source,'--edition=2024','-Copt-level=1','-o',normal]);assert compiled.returncode==0,compiled.stderr
 executed=run('ordinary-macos-runtime',[normal]);assert executed.returncode==0 and executed.stdout.strip()=='macOS storeless: 42',executed
 rejected=fixture/'unsupported';negative=run('compact-rejected-on-macos',[compiler,source,'--edition=2024','-Zcompact-artifacts=yes','-o',rejected],bootstrap=True)
 assert negative.returncode==1 and 'compact artifacts require 64-bit little-endian Linux ELF' in negative.stderr,negative
 assert not rejected.exists() and 'panicked' not in negative.stderr and 'internal compiler error' not in negative.stderr
 verify_source();receipt['source_unchanged']=True;receipt['passed']=True
except BaseException as error:
 receipt['error']=repr(error);raise
finally:
 receipt.update(finished=time.time(),seconds=time.monotonic()-start,free_bytes_after=shutil.disk_usage(root).free);save()
print(json.dumps({k:receipt[k] for k in ['passed','build_seconds','seconds','drivers','standard_library','free_bytes_after']}),flush=True)
