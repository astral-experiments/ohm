#!/usr/bin/env python3
"""Verify all sealed payload bytes; --allow-additions permits a later matrix supplement."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('root', type=Path, nargs='?', default=Path(__file__).resolve().parent)
p.add_argument('--allow-additions', action='store_true')
a = p.parse_args()
m = json.loads((a.root / 'inventory.json').read_text())
seen = set()
for row in m['files']:
    rel = Path(row['path'])
    assert not rel.is_absolute() and '..' not in rel.parts and row['path'] not in seen, rel
    seen.add(row['path'])
    file = a.root / rel
    assert file.is_file() and not file.is_symlink(), rel
    with file.open('rb') as stream:
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert file.stat().st_size == row['bytes'] and actual == row['sha256'], rel
actual = set()
for file in a.root.rglob('*'):
    assert not file.is_symlink(), file
    if file.is_file():
        actual.add(file.relative_to(a.root).as_posix())
    else:
        assert file.is_dir(), file
extra = actual - seen - {'inventory.json'}
assert a.allow_additions or not extra, sorted(extra)
assert len(seen) == m['file_count'] and sum(r['bytes'] for r in m['files']) == m['total_bytes']
print(json.dumps({'passed': True, 'sealed_files': len(seen), 'sealed_bytes': m['total_bytes'], 'additional_files': len(extra)}))
