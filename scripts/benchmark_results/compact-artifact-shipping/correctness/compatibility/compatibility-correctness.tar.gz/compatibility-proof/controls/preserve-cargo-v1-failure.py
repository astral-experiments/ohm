from pathlib import Path
import hashlib,json,shutil,time
W=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility');E=W/'evidence/cargo-v1'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((E/'result.json').read_text());assert not r['passed'] and r['phase']=='routing-suite' and r['commands'][-1]['code']==101
protected=json.loads((E/'protected-before.json').read_text());changed=[p for p,h in protected.items() if not Path(p).is_file() or sha(Path(p))!=h];assert not changed,changed
cargo=Path(r['cargo']['path']);assert sha(cargo)==r['cargo']['sha256'];retained=W/'retained/cargo-d6';assert not retained.exists();retained.mkdir(parents=True);shutil.copy2(cargo,retained/'cargo');assert sha(retained/'cargo')==sha(cargo)
proof={'passed':True,'scope':'Preserve genuine failed d6 routing test and its built Cargo; no test reclassification.','failed_result_sha256':sha(E/'result.json'),'protected_unchanged':len(protected),'retained_cargo':str(retained/'cargo'),'cargo_sha256':sha(cargo),'finished':time.time()};(E/'failure-custody.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
