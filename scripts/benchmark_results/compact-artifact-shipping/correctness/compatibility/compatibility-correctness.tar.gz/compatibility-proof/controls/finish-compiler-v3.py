from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
ROOT=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=ROOT/'shipping/compatibility';E=WORK/'evidence/compiler-v3';SOURCE=WORK/'compiler/rust';HOST='x86_64-unknown-linux-gnu';SYS=WORK/'toolchains/compiler-v3'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def out(a):return subprocess.check_output(list(map(str,a)),text=True).strip()
r=json.loads((E/'result.json').read_text());assert not r['passed'] and r['commands'][-1]['label']=='install' and r['commands'][-1]['code']==0 and 'IsADirectoryError' in r['error']
assert not (E/'assembly-failure.json').exists();shutil.copy2(E/'result.json',E/'assembly-failure.json')
r['assembly_failure_sha256']=sha(E/'assembly-failure.json');r.pop('error');r['phase']='correcting-payload-assembly';put(E/'result.json',r)
try:
 donor=ROOT/'shipping/readiness/final-cargo-current/toolchain/lib/rustlib'/HOST/'bin/wild-ld/ld.bfd'
 assert sha(donor)=='37303b949ecd2f76831381583c51ec4f551ce2de89154f131832ef6c7bd94372'
 linker=SYS/'lib/rustlib'/HOST/'bin/wild-ld';linker.mkdir(parents=True,exist_ok=True)
 shutil.copy2(donor,linker/'ld.bfd');(linker/'compact-artifacts-v1').unlink(missing_ok=True);(linker/'compact-artifacts-v2').write_bytes(b'RCOBJ001\n')
 r['assembly_correction']={'donor':str(donor),'sha256':sha(donor),'compiler_rebuilt':False}
 r['toolchain']={'path':str(SYS),'version':out([SYS/'bin/rustc','-vV']),'rustc_sha256':sha(SYS/'bin/rustc'),'rustdoc_sha256':sha(SYS/'bin/rustdoc'),'drivers':{p.name:sha(p) for p in (SYS/'lib').glob('librustc_driver*.so')},'wild_sha256':sha(linker/'ld.bfd'),'marker':{'name':'compact-artifacts-v2','sha256':sha(linker/'compact-artifacts-v2')},'linked_libraries':{str(p.relative_to(SYS)):sha(p) for p in (SYS/'lib').glob('libLLVM*') if p.is_file()},'dynamic_dependencies':out(['ldd',SYS/'bin/rustc'])}
 assert 'not found' not in r['toolchain']['dynamic_dependencies'];assert list((SYS/'lib/rustlib'/HOST/'lib').glob('libstd-*.rlib'))
 files=json.loads((E/'source-files.json').read_text())['files']
 for n,h in files.items():assert sha(SOURCE/n)==h,n
 r['phase']='verify-preserved-inputs';put(E/'result.json',r)
 protected=json.loads((WORK/'evidence/compiler-v2/protected-before.json').read_text());changed=[]
 for name,row in protected.items():
  p=Path(name);ok=(p.is_symlink() and os.readlink(p)==row['symlink']) if 'symlink' in row else (p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'])
  if not ok:changed.append(name)
 put(E/'protected-after.json',{'passed':not changed,'files':len(protected),'changed':changed,'finished':time.time()});assert not changed,changed[:10]
 r['passed']=True;r['phase']='built-awaiting-test-payload';r['protected_after_sha256']=sha(E/'protected-after.json')
except BaseException as e:r['error']=repr(e);raise
finally:r['finished']=time.time();put(E/'result.json',r)
print(json.dumps({'passed':r['passed'],'toolchain':r['toolchain']}))
