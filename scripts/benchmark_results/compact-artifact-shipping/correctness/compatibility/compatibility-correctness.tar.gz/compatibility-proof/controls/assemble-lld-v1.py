from pathlib import Path
import hashlib,json,shutil,subprocess,time
WORK=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility');H='x86_64-unknown-linux-gnu';SOURCE=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility/bootstrap')/H/'ci-llvm/bin/lld';SYS=WORK/'toolchains/compiler-v3';DEST=SYS/'lib/rustlib'/H/'bin';E=WORK/'evidence/lld-assembly-v1'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
build_path=WORK/'evidence/compiler-v3/result.json';build=json.loads(build_path.read_text());assert build['passed'] and Path(build['toolchain']['path'])==SYS and SOURCE.is_file() and not SOURCE.is_symlink()
assert not E.exists() and not (DEST/'rust-lld').exists() and not (DEST/'gcc-ld/ld.lld').exists();E.mkdir()
protected={str(p):sha(p) for p in [SYS/'bin/rustc',SYS/'bin/rustdoc',*list((SYS/'lib').glob('librustc_driver*.so')),DEST/'wild-ld/ld.bfd',DEST/'wild-ld/compact-artifacts-v2']}
shutil.copy2(SOURCE,DEST/'rust-lld');(DEST/'gcc-ld').mkdir(exist_ok=True);(DEST/'gcc-ld/ld.lld').symlink_to('../rust-lld')
version=subprocess.check_output([str(DEST/'gcc-ld/ld.lld'),'--version'],text=True).strip();assert '23.1.1' in version,version
assert protected=={p:sha(Path(p)) for p in protected}
r={'passed':True,'scope':'Separate matching LLVM23 LLD assembly for isolated non-PGO native proof; compiler bytes unchanged.','compiler_build_sha256':sha(build_path),'source':str(SOURCE),'source_sha256':sha(SOURCE),'files':{str(DEST/'rust-lld'):{'sha256':sha(DEST/'rust-lld')},str(DEST/'gcc-ld/ld.lld'):{'symlink':'../rust-lld','sha256':sha(DEST/'gcc-ld/ld.lld')}},'version':version,'protected':protected,'finished':time.time()};(E/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
