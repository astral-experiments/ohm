"""Build exact published Cargo after verified90 collection, preserving timed sources/binaries."""
from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time
ROOT=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=ROOT/'shipping/compatibility'
DEST=WORK/'final-cargo';INPUTS=DEST/'inputs';SOURCE=DEST/'source';E=DEST/'evidence'
TARGET_ROOT=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility');TARGET=TARGET_ROOT/'final-cargo';DONOR=WORK/'cargo';CACHE=TARGET_ROOT/'cargo/release'
BASE='6333daf7cf99cf80125234c9419cbd36e9bff81a';HEAD='76793c44b8f426220ce9b86449fe405b8a85a95f';PATCH='cc8871ae6b1572a771c54f8ac84e118be3354986190951b54faed4762c123d5d'
BUNDLE='2b57c45a5a067aa4791ca1eacff140bc44a4cb8ae83d6c8ab683c52e80620acc'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def output(a,cwd=None):return subprocess.check_output(list(map(str,a)),cwd=cwd,text=True).strip()
def budget():
 free=shutil.disk_usage(WORK).free;used=sum(int(output(['du','-s','-B1',p]).split()[0]) for p in (WORK,TARGET_ROOT))
 assert free>=60*1024**3 and used<=40*1024**3,(free,used)
 return {'free':free,'owned_allocated':used}
collection_path=WORK/'collection-v1.json';collection=load(collection_path)
handover_path=DEST/'measurement-handover.json';handover=load(handover_path)
assert collection['passed'] and collection['counts']=={'commands':90,'accepted':90,'excluded':0}
assert handover['passed'] and handover['collection_sha256']==sha(collection_path) and handover['verified_files']==collection['file_count'] and handover['verified_bytes']==collection['total_bytes']
assert handover['samples_sha256']==collection['samples_sha256']==sha(WORK/'evidence/performance-v1/samples.jsonl')
assert handover['status_sha256']==collection['status_sha256']==sha(WORK/'evidence/performance-v1/status.json')
status=load(WORK/'evidence/performance-v1/status.json');assert status['passed'] and status['samples']==status['accepted']==90 and status['source_and_toolchain_unchanged']
assert not (WORK/'evidence/performance-v1/failure.json').exists()
manifest=load(INPUTS/'final-source-manifest.json');assert manifest['base']==BASE and manifest['head']==HEAD and manifest['patch_sha256']==PATCH==sha(INPUTS/'final-source.patch')
assert sha(INPUTS/'cargo-final.bundle')==BUNDLE
compiler_path=WORK/'evidence/compiler-v3/result.json';compiler=load(compiler_path);old=load(WORK/'evidence/cargo-v2/result.json')
assert compiler['passed'] and old['passed'] and old['patch_sha256']=='20b9d1fdf46667b3f65bbcba67bf7358acaeb4653b6df1fd05ed431f46172872'
sysroot=Path(compiler['toolchain']['path']);assert sysroot==WORK/'toolchains/compiler-v3' and old['cargo']['path']==str(sysroot/'bin/cargo')
assert old['cargo']['sha256']=='8451f441757f18aaaeb59a8e0c7daf947da0a26d839fe3c0e7c6ac87f5a55db6'==sha(sysroot/'bin/cargo')
assert not E.exists() and not SOURCE.exists() and not TARGET.exists();E.mkdir()
protected={str(collection_path):sha(collection_path),str(handover_path):sha(handover_path)}
for item in collection['files']:
 p=WORK/item['path'];assert p.resolve()==p and p.is_relative_to(WORK) and not p.is_symlink() and p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];protected[str(p)]=item['sha256']
measured_manifest=load(WORK/'inputs/cargo-v2-manifest.json')
for item in measured_manifest['files']:
 p=DONOR/item['path'];assert sha(p)==item['sha256'];protected[str(p)]=item['sha256']
t=old['toolchain'];assert t['marker']['name']=='compact-artifacts-v2'
for p,h in [(sysroot/'bin/cargo',old['cargo']['sha256']),(sysroot/'bin/rustc',t['rustc_sha256']),(sysroot/'bin/rustdoc',t['rustdoc_sha256']),(sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd',t['wild_sha256']),(sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/compact-artifacts-v2',t['marker']['sha256'])]:assert sha(p)==h;protected[str(p)]=h
for name,h in t['drivers'].items():assert sha(sysroot/'lib'/name)==h;protected[str(sysroot/'lib'/name)]=h
put(E/'protected-before.json',protected)
r={'passed':False,'scope':'Exact published final Cargo build and focused checks after frozen90 collection; measured20b Cargo remains unchanged.','base':BASE,'head':HEAD,'patch_sha256':PATCH,'manifest_sha256':sha(INPUTS/'final-source-manifest.json'),'bundle_sha256':BUNDLE,'compiler_build_sha256':sha(compiler_path),'collection_sha256':sha(collection_path),'handover_sha256':sha(handover_path),'source':str(SOURCE),'target':str(TARGET),'script_sha256':sha(Path(__file__)),'started':time.time(),'commands':[],'protected_files':len(protected),'budget':budget()}
def save():put(E/'build.json',r)
env={k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO_'))};env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='8',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
def run(name,args,cwd=SOURCE):
 row={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'started':time.time()};r['commands'].append(row);r['phase']=name;save()
 with (E/(name+'.log')).open('w') as f:
  p=subprocess.Popen(row['argv'],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   next_budget=time.time()+30
   while p.poll() is None:
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
    assert shutil.disk_usage(WORK).free>=60*1024**3
    if time.time()>=next_budget:budget();next_budget=time.time()+30
  except BaseException:
   if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
   raise
  finally:row.update(code=p.returncode,seconds=time.time()-row['started'],log_sha256=sha(E/(name+'.log')));save()
 assert row['code']==0,(name,row['code']);r['budget']=budget();save();print(json.dumps(row),flush=True)
 return row
try:
 run('clone',['git','clone','--shared','--no-checkout',DONOR,SOURCE],WORK)
 assert SOURCE.resolve()==SOURCE and SOURCE.is_relative_to(WORK) and output(['git','rev-parse','--show-toplevel'],SOURCE)==str(SOURCE)
 for key,value in [('user.name','Charlie Marsh'),('user.email','charlie.r.marsh@gmail.com'),('core.sshCommand','ssh -i /home/dev-user/.ssh/id_ed25519 -o IdentitiesOnly=yes')]:run('identity-'+key.replace('.','-'),['git','config',key,value])
 assert output(['git','config','user.email'],SOURCE)=='charlie.r.marsh@gmail.com'
 run('bundle-verify',['git','bundle','verify',INPUTS/'cargo-final.bundle'])
 run('bundle-import',['git','fetch',INPUTS/'cargo-final.bundle','HEAD'])
 run('checkout',['git','checkout','-b','charlie/compatibility-final-cargo',HEAD])
 run('local-base',['git','branch','compatibility-base',BASE]);run('upstream',['git','branch','--set-upstream-to=compatibility-base'])
 assert output(['git','rev-parse','HEAD'],SOURCE)==HEAD and not output(['git','status','--porcelain'],SOURCE)
 assert set(output(['git','diff','--name-only','--no-renames',BASE,HEAD],SOURCE).splitlines())=={x['path'] for x in manifest['files']}
 for item in manifest['files']:assert (SOURCE/item['path']).stat().st_size==item['bytes'] and sha(SOURCE/item['path'])==item['sha256']
 run('exact-patch-reverse-check',['git','apply','--reverse','--check',INPUTS/'final-source.patch'])
 put(E/'source-files.json',manifest);r['source_manifest_sha256']=sha(E/'source-files.json')
 assert CACHE.is_dir() and not CACHE.is_symlink() and not any(p.is_symlink() for p in CACHE.rglob('*'))
 cache_bytes=int(output(['du','-s','-B1',CACHE]).split()[0]);assert cache_bytes<2*1024**3;TARGET.mkdir()
 cache_sources=[CACHE]+[TARGET_ROOT/'cargo/debug'/name for name in ('deps','.fingerprint','build')]
 cache_entries=[]
 for source_cache in cache_sources:
  assert source_cache.is_dir() and not source_cache.is_symlink() and not any(p.is_symlink() for p in source_cache.rglob('*'))
  size=int(output(['du','-s','-B1',source_cache]).split()[0]);cache_entries.append({'path':str(source_cache),'allocated_bytes':size})
 assert sum(x['allocated_bytes'] for x in cache_entries)<8*1024**3
 (TARGET/'debug').mkdir()
 for entry in cache_entries:
  source_cache=Path(entry['path']);dest_cache=TARGET/('release' if source_cache==CACHE else 'debug/'+source_cache.name)
  run('cache-copy-'+dest_cache.name.replace('.',''),['cp','-a','--reflink=always',source_cache,dest_cache])
 r['cache_copy']={'sources':cache_entries,'scope':'CoW release and debug dependency state only; no old test fixtures/tmp, no hardlinks, donor never built or altered'}
 # Force source-path and Git-version build-script fields to reflect the fresh checkout.
 original_build=sha(SOURCE/'build.rs');os.utime(SOURCE/'build.rs',None);assert sha(SOURCE/'build.rs')==original_build
 common=['cargo','+ohm','-Zohm-defaults=no']
 r['build_compiler']={'version':output(['rustc','+ohm','-vV']),'path':output(['rustup','which','--toolchain','ohm','rustc'])};save()
 run('release-build',[*common,'build','--locked','--offline','--release','--features','ohm-defaults','--bin','cargo'])
 (DEST/'bin').mkdir();cargo=DEST/'bin/cargo';shutil.copy2(TARGET/'release/cargo',cargo)
 r['cargo']={'path':str(cargo),'sha256':sha(cargo),'version':output([cargo,'-vV'])};assert HEAD in r['cargo']['version']
 r['toolchain']={**compiler['toolchain'],'cargo_sha256':sha(cargo)};save()
 for name,args in [('selection-units',['test','--locked','--offline','-p','cargo','--features','ohm-defaults','--lib','ohm_linker','-j8']),('provenance-units',['test','--locked','--offline','-p','cargo','--features','ohm-defaults','--lib','bundled_linker_provenance','-j8']),('wrapper-range',['test','--locked','--offline','-p','cargo-util','--lib','removing_generated_range','-j8']),('routing-suite',['test','--locked','--offline','-p','cargo','--features','ohm-defaults','--test','testsuite','ohm_linker','-j8','--','--include-ignored','--test-threads=1'])]:
  run(name,[*common,*args])
  expected={'selection-units':4,'provenance-units':1,'wrapper-range':1,'routing-suite':6}[name]
  assert f'{expected} passed; 0 failed; 0 ignored' in (E/(name+'.log')).read_text(),name
 for name,test in [('corrected-dylib','build::embed_metadata_no_dylib_dep'),('ordinary-bad-config','bad_config::bad1'),('ordinary-target-env','tool_paths::target_in_environment_contains_lower_case')]:
  feature_args=['--features','ohm-defaults'] if name=='corrected-dylib' else []
  run(name,[*common,'test','--locked','--offline','-p','cargo',*feature_args,'--test','testsuite',test,'-j8','--','--exact','--include-ignored','--test-threads=1','--nocapture'])
  assert '1 passed; 0 failed; 0 ignored' in (E/(name+'.log')).read_text(),name
 for item in manifest['files']:assert sha(SOURCE/item['path'])==item['sha256']
 assert not output(['git','status','--porcelain'],SOURCE)
 r['passed']=True;r['phase']='ready-for-final-native-policy'
except BaseException as exc:r['error']=repr(exc);raise
finally:
 changed=[p for p,h in protected.items() if not Path(p).is_file() or sha(Path(p))!=h];put(E/'protected-after.json',{'passed':not changed,'changed':changed,'files':len(protected)})
 if changed:r['passed']=False;r['preservation_error']=changed[:10]
 r['finished']=time.time();save();assert not changed,changed[:10]
