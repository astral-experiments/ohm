#!/usr/bin/env python3
"""Small actual final-Cargo confirmation after the frozen timing run is collected."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

WORK = Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility')
TARGET = Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility/final-cargo/native')
HEAD = '76793c44b8f426220ce9b86449fe405b8a85a95f'
PATCH = 'cc8871ae6b1572a771c54f8ac84e118be3354986190951b54faed4762c123d5d'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def archive(path):
    data = path.read_bytes()
    assert data.startswith(b'!<arch>\n'), path
    offset = 8
    compact = 0
    while offset < len(data):
        header = data[offset:offset + 60]
        assert len(header) == 60 and header[58:] == b'`\n'
        size = int(header[48:58])
        payload = data[offset + 60:offset + 60 + size]
        assert len(payload) == size
        if header[:3] == b'#1/':
            payload = payload[int(header[3:16]):]
        compact += payload.startswith(b'RCOBJ001')
        offset += 60 + size + (size % 2)
    assert offset == len(data)
    return {'path': str(path), 'sha256': sha(path), 'compact_members': compact}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-receipt', type=Path, required=True)
    args = parser.parse_args()
    build = load(args.build_receipt)
    compiler_path = WORK / 'evidence/compiler-v3/result.json'
    compiler = load(compiler_path)
    lld_path = WORK / 'evidence/lld-assembly-v1/result.json'
    lld = load(lld_path)
    assert build['passed'] and build['head'] == HEAD and build['patch_sha256'] == PATCH
    assert compiler['passed'] and lld['passed']
    assert build['compiler_build_sha256'] == sha(compiler_path)
    assert lld['compiler_build_sha256'] == sha(compiler_path)
    cargo = Path(build['cargo']['path'])
    sysroot = Path(compiler['toolchain']['path'])
    assert cargo == cargo.resolve() == WORK / 'final-cargo/bin/cargo'
    assert sha(cargo) == build['cargo']['sha256']
    assert build['toolchain'] == {**compiler['toolchain'], 'cargo_sha256': sha(cargo)}
    assert sysroot == WORK / 'toolchains/compiler-v3'
    evidence = WORK / 'final-cargo/native-evidence'
    source = WORK / 'final-cargo/native-source'
    assert not evidence.exists() and not source.exists() and not TARGET.exists()
    evidence.mkdir(); source.mkdir(); TARGET.mkdir(parents=True)
    (source / 'src').mkdir(); (source / 'dep/src').mkdir(parents=True)
    (source / 'Cargo.toml').write_text('[package]\nname="final-app"\nversion="0.1.0"\n[dependencies]\nfinal-dep={path="dep"}\n')
    (source / 'src/main.rs').write_text('fn main(){println!("{}", final_dep::value());}\n')
    (source / 'dep/Cargo.toml').write_text('[package]\nname="final-dep"\nversion="0.1.0"\n')
    (source / 'dep/src/lib.rs').write_text('pub fn value()->u32{42}\n')
    (source / 'flags').write_text('-Zcompact-artifacts=no\n')
    wrapper = source / 'record.py'
    wrapper.write_text('#!/usr/bin/python3\nimport os,sys,json\nwith open(os.environ["FINAL_ARGV_LOG"],"a") as f:f.write(json.dumps(sys.argv[1:])+"\\n")\nos.execv(sys.argv[1],sys.argv[1:])\n')
    wrapper.chmod(0o755)
    protected = {str(cargo): sha(cargo), str(sysroot / 'bin/cargo'): sha(sysroot / 'bin/cargo')}
    for relative in ['bin/rustc', 'bin/rustdoc',
                     'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd',
                     'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/compact-artifacts-v2',
                     'lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld']:
        protected[str(sysroot / relative)] = sha(sysroot / relative)
    for name in compiler['toolchain']['drivers']:
        protected[str(sysroot / 'lib' / name)] = sha(sysroot / 'lib' / name)
    prior = load(WORK / 'evidence/cargo-v2/result.json')
    assert protected[str(sysroot / 'bin/cargo')] == prior['cargo']['sha256']
    tc = compiler['toolchain']
    assert protected[str(sysroot / 'bin/rustc')] == tc['rustc_sha256']
    assert protected[str(sysroot / 'bin/rustdoc')] == tc['rustdoc_sha256']
    for name, value in tc['drivers'].items():
        assert protected[str(sysroot / 'lib' / name)] == value
    assert protected[str(sysroot / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')] == tc['wild_sha256']
    marker = sysroot / 'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/compact-artifacts-v2'
    assert tc['marker'] == {'name': marker.name, 'sha256': sha(marker)}
    assert marker.read_bytes() == b'RCOBJ001\n'
    for path, record in lld['files'].items():
        p = Path(path)
        assert p.is_relative_to(sysroot) and sha(p) == record['sha256']
        if 'symlink' in record:
            assert p.is_symlink() and os.readlink(p) == record['symlink']
        protected[path] = record['sha256']
    result = {'passed': False, 'scope': 'Five actual final-Cargo lib/bin cases; no timing or new compiler build.',
              'head': HEAD, 'patch_sha256': PATCH, 'script_sha256': sha(__file__),
              'build_receipt_sha256': sha(args.build_receipt), 'compiler_build_sha256': sha(compiler_path),
              'lld_assembly_sha256': sha(lld_path),
              'cargo': build['cargo'], 'protected': protected, 'records': [], 'started': time.time()}
    def save():
        (evidence / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    save()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('CARGO_', 'RUST', 'OHM_'))}
    env.update(CARGO_HOME='/tmp/codex-cargo-home', CARGO=str(cargo),
               RUSTC=str(sysroot / 'bin/rustc'), RUSTDOC=str(sysroot / 'bin/rustdoc'),
               RUSTC_WRAPPER=str(wrapper), CARGO_BUILD_JOBS='8', CARGO_NET_OFFLINE='true',
               CARGO_TERM_COLOR='never', CARGO_INCREMENTAL='1')
    cases = [('ordinary', ['-Zohm-defaults=no'], '', False, False),
             ('default', ['-Zohm-defaults=yes'], '', True, True),
             ('optout', ['-Zohm-defaults=yes', '-Zohm-compact-artifacts=no'], '', False, False),
             ('response-fallback', ['-Zohm-defaults=yes'], '@' + str(source / 'flags'), False, False),
             ('lld-adapter', ['-Zohm-defaults=yes', '-Zohm-linker=lld'], '', True, False)]
    try:
        for label, options, flags, compact, direct in cases:
            assert shutil.disk_usage(WORK).free >= 60 * 1024**3
            argvlog = evidence / (label + '.argv.jsonl')
            runenv = {**env, 'CARGO_TARGET_DIR': str(TARGET / label / 'target'),
                      'CARGO_BUILD_BUILD_DIR': str(TARGET / label / 'build'),
                      'CARGO_ENCODED_RUSTFLAGS': flags, 'FINAL_ARGV_LOG': str(argvlog)}
            argv = [str(cargo), *options, 'build', '--offline', '-vv', '--message-format=json']
            row = {'label': label, 'argv': argv, 'cwd': str(source), 'expected_compact': compact,
                   'expected_direct_reader': direct, 'started': time.time()}
            result['records'].append(row); save()
            process = subprocess.Popen(argv, cwd=source, env=runenv, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, text=True, start_new_session=True)
            try:
                stdout, stderr = process.communicate(timeout=300)
            except BaseException:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGTERM)
                process.communicate()
                raise
            for ext, data in [('stdout', stdout), ('stderr', stderr)]:
                p = evidence / (label + '.' + ext); p.write_text(data); row[ext + '_sha256'] = sha(p)
            row['returncode'] = process.returncode; save(); assert process.returncode == 0, stderr
            calls = [json.loads(line) for line in argvlog.read_text().splitlines()]
            units = [a for a in calls if '--crate-name' in a and a[a.index('--crate-name') + 1] == 'final_app']
            assert len(units) == 1
            actual = units[0]
            assert ('-Zcompact-artifacts=yes' in actual) == compact
            assert ('-Zcompact-artifacts-linker=yes' in actual) == direct
            if label in ('ordinary', 'response-fallback', 'lld-adapter'):
                assert not any('wild-ld' in arg for arg in actual)
            events = [json.loads(line) for line in stdout.splitlines() if line.startswith('{')]
            artifacts = [x for x in events if x.get('reason') == 'compiler-artifact']
            libs = [Path(p) for x in artifacts if x['target']['name'] == 'final_dep' for p in x['filenames'] if p.endswith('.rlib')]
            assert len(libs) == 1
            row['archive'] = archive(libs[0]); assert (row['archive']['compact_members'] > 0) == compact
            bins = [Path(x['executable']) for x in artifacts if x.get('executable') and x['target']['name'] == 'final-app']
            assert len(bins) == 1
            runtime = subprocess.check_output([bins[0]], text=True, timeout=10)
            assert runtime == '42\n'
            leftovers = [str(p) for p in (TARGET / label).rglob('*') if p.name.startswith('rustc-artifacts') or
                         p.name.startswith('.compact-link.') or (p.name.startswith('.compact.') and p.name.endswith('.tmp'))]
            assert not leftovers
            row.update(passed=True, argv_log_sha256=sha(argvlog), runtime=runtime,
                       executable_sha256=sha(bins[0]), scratch_leftovers=leftovers)
            save()
        assert all(sha(Path(p)) == value for p, value in protected.items())
        result.update(passed=True, protected_unchanged=True)
    finally:
        result['finished'] = time.time(); save()


if __name__ == '__main__':
    main()
