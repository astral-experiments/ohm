"""Build only the frozen compatibility candidate in new owned sources and cache."""
import hashlib,json,os,shutil,signal,subprocess,time
from pathlib import Path
ROOT=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=ROOT/'shipping/compatibility';INPUTS=WORK/'inputs';EVIDENCE=WORK/'evidence/compiler-v2'
TARGET_ROOT=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility');TARGET=TARGET_ROOT/'bootstrap'
SOURCE=WORK/'compiler/rust';DONOR=ROOT/'shipping/readiness/compiler/rust';OLD=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/bootstrap')
PROOF=ROOT/'shipping/readiness/final-cargo-current/rust-proof.git';CARGO_DONOR=ROOT/'shipping/readiness/final-cargo-current/source'
HOST='x86_64-unknown-linux-gnu';BASE='36f01299cd71f6c090150a80fe4a7babb6245a0b';PATCH='cf3bf33fb82efcfb415558f13dd16c21186c138ff1704ab3caf9337860e2f6dc';WILD='9179eb988df2676342192a24dc337cf9823e9d56'
CAP=40*1024**3;RESERVE=60*1024**3

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def output(args,cwd=None):return subprocess.check_output(list(map(str,args)),cwd=cwd,text=True).strip()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def allocated(p):return int(output(['du','-s','-B1',p]).split()[0]) if p.exists() else 0
def budget():
 free=shutil.disk_usage(WORK).free;used=allocated(WORK)+allocated(TARGET_ROOT)
 assert free>=RESERVE,('free-space reserve',free)
 assert used<=CAP,('owned-root cap',used)
 return {'free':free,'owned_allocated':used,'cap':CAP,'reserve':RESERVE}
manifest=json.loads((INPUTS/'compiler-v2-manifest.json').read_text());assert manifest['base']==BASE and manifest['patch_sha256']==PATCH==sha(INPUTS/'compiler-v2.patch')
assert SOURCE.is_dir() and not TARGET.exists()
assert output(['git','config','user.email'],SOURCE)=='charlie.r.marsh@gmail.com'
receipt=json.loads((EVIDENCE/'result.json').read_text())
assert not receipt['passed'] and receipt['phase']=='base-branch' and receipt['commands'][-1]['code']==128
assert not (EVIDENCE/'source-clone-failure.json').exists()
shutil.copy2(EVIDENCE/'result.json',EVIDENCE/'source-clone-failure.json')
protected=json.loads((EVIDENCE/'protected-before.json').read_text())
receipt.pop('error',None)
bundle=ROOT/'shipping/readiness/final-cargo-current/inputs/rust.bundle'
receipt['assembly_recovery']={'reason':'Shared clone did not expose the imported unreferenced36f commit; import existing verified source bundle into the new owned clone','retained_receipt':'source-clone-failure.json','source_bundle_sha256':sha(bundle),'resumed':time.time()}
def save():put(EVIDENCE/'result.json',receipt)
def run(label,args,cwd=None,env=None):
 label='resume-'+label
 row={'label':label,'argv':list(map(str,args)),'cwd':str(cwd) if cwd else None,'started':time.time()};receipt['commands'].append(row);receipt['phase']=label;save();print(json.dumps({'started':label}),flush=True)
 with (EVIDENCE/(label+'.log')).open('w') as log:
  p=subprocess.Popen(row['argv'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   next_budget=time.time()+30
   while p.poll() is None:
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
    assert shutil.disk_usage(WORK).free>=RESERVE,'free-space reserve during '+label
    if time.time()>=next_budget:budget();next_budget=time.time()+30
   row['code']=p.returncode
  except BaseException:
   if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
   row['code']=p.returncode;raise
  finally:row['seconds']=time.time()-row['started'];save()
 row['budget']=budget();save();print(json.dumps({'finished':label,'code':row['code'],'seconds':row['seconds']}),flush=True)
 assert row['code']==0,label

def protected_snapshot():
 refs=[ROOT/'shipping/readiness/evidence/collection.json',ROOT/'shipping/readiness/evidence/current-cargo-collection.json']
 records={}
 historical=ROOT/'shipping/final-review/bounds-fix/evidence/measured-artifacts-after.json'
 records[str(historical)]={'bytes':historical.stat().st_size,'sha256':sha(historical)}
 receipt['preservation_scope']='Published readiness/current evidence files, complete borrowed compiler cache, measured toolchains; historical artifact inventory bytes bound without repeating its full artifact census.'
 for ref in refs:
  data=json.loads(ref.read_text())
  if 'files' in data:
   items=[(ROOT/'shipping'/r['path'],r) for r in data['files']]
  else:items=[(Path(p),r) for p,r in data.items()]
  for p,r in items:
   assert p.is_file() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],str(p)
   if 'symlink' in r:assert p.is_symlink() and os.readlink(p)==r['symlink']
   records[str(p)]={'bytes':p.stat().st_size,'sha256':r['sha256']}
  records[str(ref)]={'bytes':ref.stat().st_size,'sha256':sha(ref)}
 # Preserve every byte of the cache used for the copy, including internal/outward links.
 for p in sorted(OLD.rglob('*')):
  if p.is_symlink():records[str(p)]={'symlink':os.readlink(p)}
  elif p.is_file():records[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
 for sysroot in (ROOT/'shipping/readiness/toolchains/storeless',ROOT/'shipping/readiness/toolchains/baseline-same-wild',ROOT/'shipping/readiness/final-cargo-current/toolchain'):
  for p in sorted(sysroot.rglob('*')):
   if p.is_symlink():records[str(p)]={'symlink':os.readlink(p)}
   elif p.is_file():records[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return records

def verify_protected(expected):
 errors=[]
 for name,row in expected.items():
  p=Path(name)
  ok=(p.is_symlink() and os.readlink(p)==row['symlink']) if 'symlink' in row else (p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'])
  if not ok:errors.append(name)
 return {'passed':not errors,'files':len(expected),'changed':errors,'finished':time.time()}

try:
 run('bundle-verify',['git','bundle','verify',bundle],SOURCE)
 run('bundle-import',['git','fetch','--no-tags','--no-recurse-submodules',bundle,'refs/heads/charlie/current-proof','refs/heads/charlie/prior-proof'],SOURCE)
 assert output(['git','cat-file','-t',BASE],SOURCE)=='commit'
 run('base-branch',['git','branch','charlie/compact-compatibility-base',BASE],SOURCE)
 run('checkout',['git','checkout','-b','charlie/compact-compatibility-compiler','charlie/compact-compatibility-base'],SOURCE)
 run('upstream',['git','branch','--set-upstream-to=charlie/compact-compatibility-base'],SOURCE)
 for line in output(['git','submodule','status'],ROOT/'rust').splitlines():
  if line.startswith('-'):continue
  rel=line.split()[1]
  if rel=='src/tools/cargo':continue
  src=ROOT/'rust'/rel;dst=SOURCE/rel
  if src.is_dir():run('submodule-'+rel.replace('/','-'),['rsync','-a','--exclude=.git',str(src)+'/',str(dst)+'/'])
 run('cargo-source',['git','clone','--shared',CARGO_DONOR,SOURCE/'src/tools/cargo'])
 run('cargo-oss-name',['git','config','--local','user.name','Charlie Marsh'],SOURCE/'src/tools/cargo')
 run('cargo-oss-email',['git','config','--local','user.email','charlie.r.marsh@gmail.com'],SOURCE/'src/tools/cargo')
 assert output(['git','config','user.email'],SOURCE/'src/tools/cargo')=='charlie.r.marsh@gmail.com'
 run('cargo-checkout',['git','checkout','--detach','6333daf7cf99cf80125234c9419cbd36e9bff81a'],SOURCE/'src/tools/cargo')
 run('patch-check',['git','apply','--check',INPUTS/'compiler-v2.patch'],SOURCE)
 run('patch',['git','apply',INPUTS/'compiler-v2.patch'],SOURCE)
 for name,digest in manifest['files'].items():assert (sha(SOURCE/name) if (SOURCE/name).is_file() else None)==digest,name
 changed=output(['git','diff','--name-only'],SOURCE).splitlines()
 assert set(changed)==set(manifest['files'])
 put(EVIDENCE/'source-files.json',{'base':BASE,'patch_sha256':PATCH,'files':manifest['files'],'changed_paths':changed,'git_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--binary'],cwd=SOURCE)).hexdigest()})
 receipt['source_manifest_sha256']=sha(EVIDENCE/'source-files.json');save()
 run('cache-copy',['cp','-a','--reflink=auto',OLD,TARGET])
 fixed=[];internal=[]
 for p in TARGET.rglob('*'):
  if not p.is_symlink():continue
  resolved=p.resolve(strict=True)
  if resolved.is_relative_to(TARGET):continue
  if resolved.is_relative_to(OLD):
   p.unlink();p.symlink_to(TARGET/resolved.relative_to(OLD),target_is_directory=resolved.is_dir());internal.append(str(p.relative_to(TARGET)));continue
  assert resolved==DONOR,(str(p),str(resolved))
  p.unlink();p.symlink_to(SOURCE,target_is_directory=True);fixed.append(str(p.relative_to(TARGET)))
 assert len(fixed)==3,fixed
 config=(DONOR/'bootstrap.toml').read_text().replace(str(OLD),str(TARGET));(SOURCE/'bootstrap.toml').write_text(config)
 receipt['cache_copy']={'from':str(OLD),'source_link_retargets':fixed,'internal_absolute_link_retargets':internal,'bootstrap_config_sha256':sha(SOURCE/'bootstrap.toml'),'llvm_library_sha256':sha(TARGET/HOST/'ci-llvm/lib/libLLVM.so.23.1-rust-1.99.0-beta')};save()
 env={k:v for k,v in os.environ.items() if not k.startswith(('RUSTFLAGS','RUSTC','RUSTDOC','CARGO_PROFILE_','CARGO_TARGET_','CARGO_UNSTABLE_','CARGO_ENCODED_','CARGO_BUILD_','RUSTUP_TOOLCHAIN'))}
 env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='12')
 common=['--stage','1','--set','build.submodules=false','--set',f'target.{HOST}.ohm-wild-linker={ROOT}/shipping/final-review/bounds-fix/wild-release']
 run('compiler-build',['python3','x.py','build',*common,'compiler/rustc','src/tools/rustdoc','library'],SOURCE,env)
 sysroot=WORK/'toolchains/compiler-v2';assert not sysroot.exists();sysroot.parent.mkdir()
 run('install',['cp','-aL','--reflink=auto',TARGET/HOST/'stage1',sysroot])
 linker=sysroot/'lib/rustlib'/HOST/'bin/wild-ld';linker.mkdir(parents=True,exist_ok=True)
 shutil.copy2(ROOT/'shipping/final-review/bounds-fix/wild-release',linker/'ld.bfd')
 (linker/'compact-artifacts-v1').unlink(missing_ok=True);(linker/'compact-artifacts-v2').write_bytes(b'RCOBJ001\n')
 receipt['toolchain']={'path':str(sysroot),'version':output([sysroot/'bin/rustc','-vV']),'rustc_sha256':sha(sysroot/'bin/rustc'),'rustdoc_sha256':sha(sysroot/'bin/rustdoc'),'drivers':{p.name:sha(p) for p in (sysroot/'lib').glob('librustc_driver*.so')},'wild_sha256':sha(linker/'ld.bfd'),'marker':{'name':'compact-artifacts-v2','sha256':sha(linker/'compact-artifacts-v2')},'linked_libraries':{str(p.relative_to(sysroot)):sha(p) for p in (sysroot/'lib').glob('libLLVM*') if p.is_file()},'dynamic_dependencies':output(['ldd',sysroot/'bin/rustc'])}
 assert 'not found' not in receipt['toolchain']['dynamic_dependencies'];assert list((sysroot/'lib/rustlib'/HOST/'lib').glob('libstd-*.rlib'))
 for name,digest in manifest['files'].items():assert (sha(SOURCE/name) if (SOURCE/name).is_file() else None)==digest,name
 after=verify_protected(protected);put(EVIDENCE/'protected-after.json',after);assert after['passed'],after['changed'][:10]
 receipt['budget']=budget();receipt['passed']=True;receipt['phase']='built-awaiting-test-payload'
except BaseException as e:
 receipt['error']=repr(e);raise
finally:
 receipt['finished']=time.time();save()
print(json.dumps({'passed':receipt['passed'],'evidence':str(EVIDENCE),'toolchain':receipt.get('toolchain')}),flush=True)
