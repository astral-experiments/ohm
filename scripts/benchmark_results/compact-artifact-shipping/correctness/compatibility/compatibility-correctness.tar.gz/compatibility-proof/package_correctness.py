#!/usr/bin/env python3
"""Seal only the compatibility layer's source and correctness evidence."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

TASK = Path('/private/tmp/ohm-compact-compatibility')
LOCAL = Path('/private/tmp/ohm-compact-compatibility-evidence')
RAW = Path('/private/tmp/ohm-compact-shipping/receipts/compatibility/evidence')
OUT = TASK / 'portable'
STAGE = OUT / 'stage/compatibility-proof'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    assert json.loads((RAW / 'native-v1/result.json').read_text())['passed']
    final_root = RAW.parent / 'final-cargo'
    assert json.loads((final_root / 'evidence/build.json').read_text())['passed']
    assert json.loads((final_root / 'native-evidence/result.json').read_text())['passed']
    assert not STAGE.exists()
    STAGE.mkdir(parents=True)
    copies = []
    exclusions = []

    def copy(source, relative):
        assert source.is_file() and not source.is_symlink(), source
        if str(relative) == 'evidence/compiler-v2/protected-before.json':
            exclusions.append({'path': str(relative), 'bytes': source.stat().st_size,
                               'sha256': sha(source), 'reason': 'Historical 397,719-file input snapshot; retained locally. Bounded after-comparison receipts remain included.'})
            return
        destination = STAGE / relative
        assert not destination.exists(), destination
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        assert sha(source) == sha(destination)
        copies.append({'source': str(source), 'path': str(relative), 'sha256': sha(source)})

    for name in ('compiler-v1', 'compiler-v2', 'compiler-v3', 'cargo-v1', 'cargo-v2',
                 'rust-suites-v1', 'native-supplement-v1', 'cargo-policy-v1', 'lld-assembly-v1', 'native-v1'):
        for p in sorted((RAW / name).rglob('*')):
            if p.is_file():
                copy(p, Path('evidence') / p.relative_to(RAW))
    for name in ('evidence', 'native-evidence'):
        for p in sorted((final_root / name).rglob('*')):
            if p.is_file():
                copy(p, Path('final-cargo') / p.relative_to(final_root))
    copy(final_root / 'measurement-handover.json', Path('final-cargo/measurement-handover.json'))
    copy(RAW.parent / 'collection-v1.json', Path('anchors/performance-collection.json'))
    copy(final_root / 'transfer-manifest.json', Path('anchors/final-cargo-transfer.json'))
    for p in sorted((TASK / 'inputs').glob('compiler*')):
        if p.is_file():
            copy(p, Path('inputs') / p.name)
    for source, dest in [('candidate.patch', 'cargo-v2.patch'),
                         ('candidate-manifest.json', 'cargo-v2-manifest.json'),
                         ('final-source.patch', 'cargo-final.patch'),
                         ('final-source-manifest.json', 'cargo-final-manifest.json'),
                         ('test-only-supplement.patch', 'cargo-test-only.patch'),
                         ('test-only-supplement.json', 'cargo-test-only.json')]:
        copy(LOCAL / 'cargo' / source, Path('inputs') / dest)
    for p in sorted((LOCAL / 'cargo/history').rglob('*')):
        if p.is_file():
            copy(p, Path('inputs/cargo-history') / p.relative_to(LOCAL / 'cargo/history'))
    for section in ('cargo', 'compiler'):
        for p in sorted((LOCAL / section).rglob('*')):
            relative = p.relative_to(LOCAL / section)
            if relative.parts[0] in ('history', 'legacy-dylib-proof'):
                continue
            if p.is_file() and p.suffix in ('.json', '.log', '.toml', '.patch') and p.name not in ('candidate-manifest.json', 'candidate.patch'):
                copy(p, Path('reviews') / section / relative)
            elif p.is_file() and relative.parts[0] == 'ci-fix' and p.name == 'candidate.patch':
                copy(p, Path('reviews') / section / relative)
    for name in ('portable-verifier-peer-review.json', 'final-cargo-build-control-review.json',
                 'final-cargo-native-control-review.json', 'final-cargo-cache-control-review.json',
                 'portable-final-verifier-peer-review.json', 'portable-final-gate-peer-review.json'):
        copy(LOCAL / name, Path('reviews') / name)
    copy(LOCAL / 'final-cargo-transfer-verification.json', Path('reviews/final-cargo-transfer-verification.json'))
    for p in sorted((LOCAL / 'final-cargo-preparation').rglob('*')):
        if p.is_file():
            copy(p, Path('reviews/final-cargo-preparation') / p.relative_to(LOCAL / 'final-cargo-preparation'))
    for name in ('publication-source-binding.json', 'publication-independent-review.json',
                 'publication-final-source-binding.json', 'publication-final-independent-review.json'):
        copy(LOCAL / name, Path('reviews') / name)
    copy(Path('/private/tmp/ohm-compact-shipping/receipts/readiness/final-cargo-current/evidence/result.json'),
         Path('anchors/base6333-build.json'))
    controls = ['build-compiler-v1', 'supersede-v1-before-build', 'build-compiler-v2',
                'resume-compiler-v2', 'build-compiler-v3', 'finish-compiler-v3',
                'build-cargo-v1', 'preserve-cargo-v1-failure', 'build-cargo-v2',
                'run-rust-suites-v1', 'assemble-lld-v1', 'native_compiler_compatibility',
                'native_cargo_compatibility', 'aggregate-native-v1', 'build-final-cargo',
                'native_final_cargo', 'build-final-cargo-b3a39809']
    for name in controls:
        copy(TASK / 'control' / (name + '.py'), Path('controls') / (name + '.py'))
    for name in ('verify_correctness.py', 'package_correctness.py', 'README.md'):
        copy(OUT / name, Path(name))
    (STAGE / 'copy-provenance.json').write_text(json.dumps(copies, indent=2) + '\n')
    (STAGE / 'excluded-evidence.json').write_text(json.dumps(exclusions, indent=2) + '\n')
    files = {str(p.relative_to(STAGE)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(STAGE.rglob('*')) if p.is_file()}
    inventory = {'scope': 'Additive compatibility correctness proof; excludes binaries, images, caches and earlier archives.',
                 'files': files}
    assert len(files) < 2000 and sum(x['bytes'] for x in files.values()) < 100 * 1024**2
    assert all(x['bytes'] < 20 * 1024**2 for x in files.values())
    (STAGE / 'inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
    archive = OUT / 'compatibility-correctness.tar.gz'
    assert not archive.exists()
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for p in sorted(STAGE.rglob('*')):
                    if not p.is_file():
                        continue
                    data = p.read_bytes()
                    info = tarfile.TarInfo('compatibility-proof/' + str(p.relative_to(STAGE)))
                    info.size = len(data)
                    info.mode = 0o644
                    tar.addfile(info, io.BytesIO(data))
    seal = {'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
            'inventory_sha256': sha(STAGE / 'inventory.json'), 'members': len(files) + 1,
            'payload_bytes': sum(x['bytes'] for x in files.values()),
            'rust_patch': '4790daedc77c40dc4dc3a0f1789a9579d6aee773b88f4ec968e2884ef42fcc49',
            'cargo_patch': '20b9d1fdf46667b3f65bbcba67bf7358acaeb4653b6df1fd05ed431f46172872'}
    (OUT / 'correctness-bundle.json').write_text(json.dumps(seal, indent=2) + '\n')
    shutil.copyfile(STAGE / 'inventory.json', OUT / 'correctness-inventory.json')
    print(json.dumps(seal, indent=2))


if __name__ == '__main__':
    main()
