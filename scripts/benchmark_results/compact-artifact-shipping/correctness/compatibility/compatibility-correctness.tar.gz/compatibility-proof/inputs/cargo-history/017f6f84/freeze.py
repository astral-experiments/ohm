import hashlib,json,subprocess
from pathlib import Path
r=Path('/private/tmp/ohm-compact-compatibility-cargo');o=Path(__file__).parent
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert base=='6333daf7cf99cf80125234c9419cbd36e9bff81a'
subprocess.run(['git','diff','--check'],cwd=r,check=True)
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r)
(o/'candidate.patch').write_bytes(patch)
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[]
for name in subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=r,text=True).splitlines():
 data=(r/name).read_bytes();before=subprocess.check_output(['git','show',f'{base}:{name}'],cwd=r)
 files.append({'path':name,'bytes':len(data),'sha256':sha(data),'base_sha256':sha(before)})
assert len(files)==11
manifest={'base':base,'branch':'charlie/compact-artifact-compatibility','patch_sha256':sha(patch),'patch_bytes':len(patch),'files':files,'committed':False,'marker':{'filename':'compact-artifacts-v2','content':'RCOBJ001\n'},'source_policy':'Automatic compact only for eligible native x86_64 GNU Linux with v2 marker and Ohm defaults; explicit opt-out, custom/late linker selection and ordinary metadata fallback preserved.','local_validation':{'selection_units':4,'wrapper_range':1,'cache_admission':1,'macos_unsupported_host_integration':1,'help_snapshot':1,'format':True,'additional_metadata_tests':{'passed':2,'failed':1,'test':'build::embed_metadata_no_dylib_dep','failure':'Dylib argv expectation fails after successful build: test excludes -Zembed-metadata=no on dylib but receives it. Same explicit flag observed in retained Cargo207 smoke and same policy branch in base6333; no exact base6333 suite execution, so inherited assertion mismatch is source-supported, not a proved base test failure.','native_check_pending':True}},'response_file_policy':'Automatic compact yields to opaque rustc response args in early rustflags and late profile/cargo-rustc flags; explicit compact errors, no file expansion.','linux_validation_pending':True}
(o/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
logs=['unit-final.log','wrappers-final.log','admission-final.log','integration-macos-final.log','help-final.log','format.log','metadata-policy.log','legacy-dylib-proof.log','response-after.log','response-macos-suite.log','response-format.log','history/response-before.log']
proof={'scope':'Local macOS source and focused tests; Linux adapters still require native integration execution','patch_sha256':sha(patch),'manifest_sha256':sha((o/'candidate-manifest.json').read_bytes()),'logs':{name:{'bytes':(o/name).stat().st_size,'sha256':sha((o/name).read_bytes())} for name in logs},'peer_review':'rust_exports independently approved metadata-policy conversion and the corrected unwrapped range interface','range_regression':'Failed before corrected accessor; passed after; rejected initial log retained under history/','response_file_regression':'Root found opaque response-file override; focused unit failed before the precheck and passed after. Linux three-source routing regression remains pending; original fc8 snapshot preserved under history/fc8f20eb.'}
(o/'focused-validation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'patch_sha256':sha(patch),'patch_bytes':len(patch),'manifest_sha256':sha((o/'candidate-manifest.json').read_bytes()),'manifest_bytes':(o/'candidate-manifest.json').stat().st_size,'validation_sha256':sha((o/'focused-validation.json').read_bytes()),'files':len(files)},indent=2))
