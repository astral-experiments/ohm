import hashlib,json,subprocess
from pathlib import Path
r=Path('/private/tmp/ohm-compact-compatibility-cargo');o=Path(__file__).parent
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert base=='6333daf7cf99cf80125234c9419cbd36e9bff81a'
subprocess.run(['git','diff','--check'],cwd=r,check=True)
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r)
(o/'candidate.patch').write_bytes(patch)
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[]
for name in subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=r,text=True).splitlines():
 data=(r/name).read_bytes();before=subprocess.check_output(['git','show',f'{base}:{name}'],cwd=r)
 files.append({'path':name,'bytes':len(data),'sha256':sha(data),'base_sha256':sha(before)})
assert len(files)==11
manifest={'base':base,'branch':'charlie/compact-artifact-compatibility','patch_sha256':sha(patch),'patch_bytes':len(patch),'files':files,'committed':False,'marker':{'filename':'compact-artifacts-v2','content':'RCOBJ001\n'},'source_policy':'Automatic compact only for eligible native x86_64 GNU Linux with v2 marker and Ohm defaults; explicit opt-out, custom/late linker selection and ordinary metadata fallback preserved.','local_validation':{'selection_units':4,'wrapper_range':1,'cache_admission':1,'macos_unsupported_host_integration':1,'help_snapshot':1,'format':True,'additional_metadata_tests':{'passed':2,'failed':1,'failure':'Inherited dylib argv expectation after successful build; no production or test semantics changed for this case. Same explicit -Zembed-metadata=no observed in retained Cargo207 binary and same policy branch in base6333.'}},'linux_validation_pending':True}
(o/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
logs=['unit-final.log','wrappers-final.log','admission-final.log','integration-macos-final.log','help-final.log','format.log','metadata-policy.log','legacy-dylib-proof.log']
proof={'scope':'Local macOS source and focused tests; Linux adapters still require native integration execution','patch_sha256':sha(patch),'manifest_sha256':sha((o/'candidate-manifest.json').read_bytes()),'logs':{name:{'bytes':(o/name).stat().st_size,'sha256':sha((o/name).read_bytes())} for name in logs},'peer_review':'rust_exports independently approved metadata-policy conversion and the corrected unwrapped range interface','range_regression':'Failed before corrected accessor; passed after; rejected initial log retained under history/'}
(o/'focused-validation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'patch_sha256':sha(patch),'patch_bytes':len(patch),'manifest_sha256':sha((o/'candidate-manifest.json').read_bytes()),'manifest_bytes':(o/'candidate-manifest.json').stat().st_size,'validation_sha256':sha((o/'focused-validation.json').read_bytes()),'files':len(files)},indent=2))
