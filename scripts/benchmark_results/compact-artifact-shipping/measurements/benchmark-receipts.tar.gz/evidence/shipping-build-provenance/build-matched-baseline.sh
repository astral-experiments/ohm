#!/bin/bash
set -eu
cd /home/dev-user/code/oss/ohm-compact-study
stage=/tmp/codex-cargo-targets/ohm/isolated/compact-objects/bootstrap/x86_64-unknown-linux-gnu/stage1
wild=/tmp/codex-cargo-targets/ohm/isolated/compact-objects/wild/release/wild
mkdir -p toolchains
# Dereference stage1's symlinks so later bootstrap rebuilds cannot mutate this candidate.
cp -aL --reflink=auto "$stage" toolchains/compact
mkdir -p toolchains/compact/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld
cp "$wild" toolchains/compact/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd
toolchains/compact/bin/rustc -vV > evidence/candidate-rustc-version.txt
export CARGO_HOME=/tmp/codex-cargo-home
export COMPACT_TEST_ROOT=/tmp/codex-cargo-targets/ohm/isolated/compact-objects/correctness
export COMPACT_SOURCE_ROOT=$PWD/fixtures COMPACT_LAB_OUTPUT=$PWD/evidence/metadata-fix COMPACT_REUSE_CASE=ohm-reuse-final
export RUSTC=$PWD/toolchains/compact/bin/rustc WILD=$wild
python3 harness/test_ohm_reuse.py > evidence/metadata-fix/ohm-reuse-final.log 2>&1
unset RUSTC
cd rust
git checkout main
git diff --exit-code
export CARGO_TARGET_DIR=/tmp/codex-cargo-targets/ohm/isolated/compact-objects/bootstrap
export CARGO_BUILD_BUILD_DIR=/tmp/codex-cargo-targets/shared-build/ohm
python3 x.py build --stage 1 compiler/rustc library > ../evidence/compiler-pristine-build.log 2>&1
cd ..
cp -aL --reflink=auto "$stage" toolchains/baseline
mkdir -p toolchains/baseline/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld
cp "$wild" toolchains/baseline/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd
toolchains/baseline/bin/rustc -vV > evidence/baseline-rustc-version.txt
cd rust
git checkout charlie/compact-objects
