from pathlib import Path
import hashlib,json,subprocess,os,time
root=Path('/home/dev-user/code/oss/ohm-compact-study');ship=root/'shipping';ev=ship/'evidence'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((ship/'control/final-source-heads.json').read_text())
logger_names=['RUSTC_LOG','RUSTC_LOG_COLOR','RUSTC_LOG_ENTRY_EXIT','RUSTC_LOG_THREAD_IDS','RUSTC_LOG_BACKTRACE','RUSTC_LOG_WRAPTREE','RUSTC_LOG_LINES','RUSTC_LOG_FORMAT_JSON','RUSTC_LOG_OUTPUT_TARGET']
assert not any(name in os.environ for name in logger_names), 'compiler logging must be absent before timing'
assert not any(name.startswith('RUSTC_LOG') for name in os.environ)
for name,path in [('rust',root/'rust'),('wild',root/'wild'),('cargo',ship/'cargo')]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()==expected[name]
checks={}
for name in ['compiler-shipping-final','final-wild-validation','cargo-lifecycle-final','worktree-correctness-final','alignment-correctness-final','candidate-sysroot-assembly']:
 path=ev/(name+'.json');receipt=json.loads(path.read_text());assert receipt['passed'],name
 checks[name]=digest(path)
compiler=json.loads((ev/'compiler-shipping-final.json').read_text());assert compiler['sources']==expected
installation=json.loads((ev/'licensed-wild-install.json').read_text());assert installation['wild_source']==expected['wild'] and installation['tested_binary_unchanged']
assert installation['candidate_wild_sha256']==compiler['wild_sha256']
for name,sha in compiler['drivers'].items():assert digest(root/'toolchains/compact-shipping/lib'/name)==sha
assert digest(ship/'wild-release/wild')==compiler['wild_sha256']
assert digest(root/'toolchains/compact-shipping/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')==compiler['wild_sha256']
assert digest(root/'toolchains/baseline-shipping/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')==digest(ship/'wild-upstream-release/wild')
assert (root/'toolchains/compact-shipping/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/compact-artifacts-v1').read_bytes()==b'RCOBJ001\n'
hashes=json.loads((ship/'evidence/frozen-harnesses.json').read_text())
for name,sha in hashes.items():assert digest(ship/name)==sha,name
argv=json.loads((ship/'control/benchmark-args.json').read_text())
output=Path(argv[argv.index('--output')+1]);assert not output.exists() or not any(output.iterdir())
commands=subprocess.check_output(['ps','-eo','comm=,args='],text=True)
compiler_commands={'rustc','rustdoc','cargo','wild','ld','ld.bfd','clang','clang++','gcc','g++','cc','cc1','cc1plus'}
assert not [line for line in commands.splitlines() if line.split() and line.split()[0] in compiler_commands],commands
receipt={'time':time.time(),'sources':expected,'correctness_receipt_sha256':checks,'harness_sha256':hashes,'logger_environment':{name:None for name in logger_names},'no_outside_compiler_at_launch':True,'argv':argv,'ordinary_cargo_control':'018a2b93409433dc5bc05c5fce838ae69e9bc396 across all four arms; actual Cargo opt-in validated separately'}
(ev/'benchmark-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n')
with (ev/'benchmark-progress.log').open('w') as log:
 subprocess.run(argv,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},check=True,stdout=log,stderr=subprocess.STDOUT)
status=json.loads((output/'status.json').read_text());assert status['status']=='completed' and status['samples']==312,status
rows=[json.loads(line) for line in (output/'samples.jsonl').read_text().splitlines()]
assert len(rows)==312 and all(row['accepted'] for row in rows)
subprocess.run(['python3',str(ship/'harness/summarize_shipping.py'),str(output),'--output',str(output/'shipping-summary.json')],check=True)
print(json.dumps({'status':'completed','accepted':len(rows),'output':str(output)}),flush=True)
