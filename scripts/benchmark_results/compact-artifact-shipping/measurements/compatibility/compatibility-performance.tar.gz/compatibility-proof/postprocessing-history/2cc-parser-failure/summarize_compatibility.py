#!/usr/bin/env python3
"""Verify and summarize the separate 90-command compatibility confirmation.

Reads portable receipts only. It never builds, runs project binaries, prunes lanes,
or excludes rows. A failed verification produces no successful report.
"""
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import shlex
import shutil
import statistics

HARNESS = '3b159d45e51aa6e46679293b06c020947e5f2cf4b92c4117c195501117039e1f'
REFERENCE = '29435c96104f2e9e65d693fd7fedec2623ff9199761889ee981613e5718dfe43'
CORE = 'ea7867f9f9a0f19ceb7d9c558aa7aa6758ae3e254878685fbc58768c65713cef'
WRAPPER = 'cb972b8f75c9e89a98e76e7e244a39fb616a6c341129650e3745e73df56faad2'
RUST_BASE = '36f01299cd71f6c090150a80fe4a7babb6245a0b'
RUST_PATCH = '4790daedc77c40dc4dc3a0f1789a9579d6aee773b88f4ec968e2884ef42fcc49'
CARGO_BASE = '6333daf7cf99cf80125234c9419cbd36e9bff81a'
CARGO_PATCH = '20b9d1fdf46667b3f65bbcba67bf7358acaeb4653b6df1fd05ed431f46172872'
WILD = '9179eb988df2676342192a24dc337cf9823e9d56'
REMOTE = Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility')
TARGET = Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility/performance-v1')
ORDERS = {'ruff': (('off', 'default', 'adapter'), ('adapter', 'default', 'off')),
          'uv': (('off', 'default'), ('default', 'off'))}
SEQUENCE = [('clean', (0, 0, 0)), ('noop', (0, 0, 0)),
            *[('real-direct', (0, i, 0)) for i in (1, 2, 3)],
            *[('real-library', (0, 3, i)) for i in (1, 2, 3)], ('noop-final', (0, 3, 3))]
PHASE_NAMES = {'clean': 'Fresh build', 'real-direct': 'Application edit',
               'real-library': 'Library edit', 'noop': 'Initial no-op', 'noop-final': 'Final no-op'}
RESERVE = 60 * 1024**3
CAP = 40 * 1024**3
METRICS = {'wall_seconds': lambda r: r['wall_seconds'],
           'user_seconds': lambda r: r['user_seconds'],
           'system_seconds': lambda r: r['system_seconds'],
           'cpu_seconds': lambda r: r['user_seconds'] + r['system_seconds'],
           'max_child_rss_bytes': lambda r: r['max_child_rss_bytes'],
           'sampled_process_tree_peak_rss_bytes': lambda r: r['sampled_process_tree_peak_rss_bytes'],
           'allocated_bytes': lambda r: r['census']['allocated'],
           'logical_bytes': lambda r: r['census']['logical']}

RUFF_DIRECT = ('ruff failed', 'ruff operation failed', 'Ruff command failed', 'Ruff operation failed')
RUFF_LIBRARY = ('Local variable `{name}` is assigned to but never used',
                'Local variable `{name}` is assigned a value but never used',
                'Local variable `{name}` is unused after assignment',
                'Local variable `{name}` has an assigned value that is never used')
UV_DIRECT = ('', 'Cache directory: ', 'Cache path: ', 'Cache location: ')
UV_LIBRARY = ('Expected package name starting with an alphanumeric character, found `{char}`',
              'Package name must start with an alphanumeric character, found `{char}`',
              'Expected an alphanumeric first character in package name, found `{char}`',
              'Invalid package name starting character; expected alphanumeric, found `{char}`')
REMOVED = ('compress-incremental', 'compress-artifacts', 'compact-artifact-store', 'compact-artifact-raw-metadata')



def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


class Checks:
    # Small interface shared with the established independent oracle checker.
    check = staticmethod(require)


def oracle(audit, row):
    value = row['oracle']; cases = value['cases']
    s, d, l = row['state']; project = row['project']
    audit.check(value['passed'] and value['state'] == row['state'], 'oracle state')
    audit.check(re.fullmatch('[0-9a-f]{64}', value['binary_sha256']), 'binary hash')
    audit.check(set(cases) == {'synthetic', 'version', 'direct', 'library', 'linker'}, 'all runtime cases')
    audit.check(cases['synthetic']['code'] == 0 and cases['synthetic']['stdout'].strip() == str(s), 'synthetic value')
    audit.check(cases['version']['code'] == 0 and cases['version']['stdout'].startswith(project + ' '), 'version')
    audit.check(cases['linker']['code'] == 0 and 'Wild' in cases['linker']['stdout'], 'Wild-linked executable')
    paths = [cases[n]['argv'][0] for n in ('synthetic', 'version', 'direct', 'library')]
    audit.check(len(set(paths)) == 1 and paths[0].endswith('/target/debug/' + project), 'one observed binary')
    direct, library = cases['direct'], cases['library']
    if project == 'ruff':
        audit.check(direct['code'] == 2 and RUFF_DIRECT[d] in direct['stderr'], 'Ruff real direct output')
        diagnostics = json.loads(library['stdout'])
        audit.check(library['code'] == 1 and len(diagnostics) == 1, 'Ruff diagnostic count')
        diagnostic = diagnostics[0]
        audit.check(diagnostic['code'] == 'F841' and diagnostic['message'] == RUFF_LIBRARY[l].replace('{name}', 'x'), 'Ruff real library output')
        audit.check(diagnostic['location'] == {'row': 2, 'column': 5}, 'Ruff diagnostic location')
        audit.check(library['input'] == 'def f():\n    x = 1\n', 'Ruff library input')
    else:
        args = direct['argv']; cache = args[args.index('--cache-dir') + 1]
        audit.check(direct['code'] == 0 and direct['stdout'] == UV_DIRECT[d] + cache + '\n', 'uv real direct output')
        audit.check(library['code'] == 2 and UV_LIBRARY[l].replace('{char}', '=') in library['stderr'], 'uv real library output')
        audit.check(library['argv'][1:] == ['--no-config', '--offline', '--color', 'never', '--cache-dir', cache, 'pip', 'install', '--no-index', '=foo'] and library['input'] is None, 'direct offline uv requirement oracle')


def fixture_bytes(snapshots, project, state):
    """Reconstruct expected touched files from retained pre-fixture file bytes."""
    main = f'crates/{project}/src/' + ('main.rs' if project == 'ruff' else 'bin/uv.rs')
    lib = f'crates/{project}/src/lib.rs'
    direct = main if project == 'ruff' else 'crates/uv/src/commands/cache_dir.rs'
    library = ('crates/ruff_linter/src/rules/pyflakes/rules/unused_variable.rs' if project == 'ruff'
               else 'crates/uv-pep508/src/lib.rs')
    files = {p: (snapshots / project / p).read_bytes() for p in {main, lib, direct, library}}
    s, d, l = state
    original = files[main].decode()
    assert original.count('fn main() -> ExitCode {') == 1
    hook = ('fn main() -> ExitCode {\n'
            '    if std::env::var_os("OHM_COMPACT_BENCH_ORACLE").is_some() {\n'
            f'        println!("{{}}", {project}::__ohm_compact_bench_value() + {project}::__ohm_compact_bench_inline_value() + std::hint::black_box(0u32));\n'
            '        return ExitCode::SUCCESS;\n    }')
    files[main] = original.replace('fn main() -> ExitCode {', hook).encode()
    files[lib] += ('\n#[inline(never)]\npub fn __ohm_compact_bench_value() -> u32 { std::hint::black_box(0u32) }\n'
                   f'#[inline]\npub fn __ohm_compact_bench_inline_value() -> u32 {{ std::hint::black_box({s}u32) }}\n').encode()
    old, new = (('"ruff failed"', '"' + RUFF_DIRECT[d] + '"') if project == 'ruff' else
                ('printer.stdout(),\n        "{}",', 'printer.stdout(),\n        "' + UV_DIRECT[d] + '{}",'))
    assert files[direct].count(old.encode()) == 1
    files[direct] = files[direct].replace(old.encode(), new.encode())
    messages = RUFF_LIBRARY if project == 'ruff' else UV_LIBRARY
    old, new = ('"' + messages[0] + '"').encode(), ('"' + messages[l] + '"').encode()
    assert files[library].count(old) == 1
    files[library] = files[library].replace(old, new)
    return files


def pair_metrics(pairs, getter):
    left, right = [getter(a) for a, _ in pairs], [getter(b) for _, b in pairs]
    deltas = [b - a for a, b in zip(left, right)]
    changes = [100 * (b / a - 1) for a, b in zip(left, right) if a > 0]
    return {'reference_mean': statistics.mean(left), 'candidate_mean': statistics.mean(right),
            'reference_median': statistics.median(left), 'candidate_median': statistics.median(right),
            'delta_mean': statistics.mean(deltas),
            'paired_delta_median': statistics.median(deltas),
            'paired_delta_range': [min(deltas), max(deltas)],
            'ratio_of_means_percent': 100 * (sum(right) / sum(left) - 1) if sum(left) else None,
            'n_percent_pairs': len(changes),
            'paired_percent_median': statistics.median(changes) if changes else None,
            'paired_percent_range': [min(changes), max(changes)] if changes else [None, None],
            'increased_pairs': sum(b > a for a, b in zip(left, right))}



def source_manifest(snapshot):
    encoded = json.dumps(snapshot['files'], sort_keys=True, separators=(',', ':')).encode()
    require(hashlib.sha256(encoded).hexdigest() == snapshot['tracked_tree_sha256'], 'source manifest tree hash')
    entries = snapshot['files']
    require(len({r['path'] for r in entries}) == len(entries), 'duplicate source entry')
    for row in entries:
        p = Path(row['path'])
        require(not p.is_absolute() and '..' not in p.parts, 'unsafe source entry')
    return {r['path']: r for r in entries}


def check_budget(value):
    require(value['cap'] == CAP and value['reserve'] == RESERVE, 'budget policy')
    require(0 <= value['owned_allocated'] <= CAP and value['free'] >= RESERVE, 'budget bound')


def check_census(census):
    for field in ('allocated', 'logical'):
        require(census[field] == sum(c[field] for c in census['categories'].values()), 'census sum')
    require(census['files'] + census['directories'] == sum(c['entries'] for c in census['categories'].values()), 'census entries')
    require(not census['categories'].get('compact-store', {}).get('allocated', 0), 'external store is absent')


def compiler_commands(text, rustc, mode, phase):
    commands = [line for line in text.splitlines() if 'Running `' in line and '/bin/rustc ' in line]
    require(not any('-Z' + key in text for key in REMOVED), 'removed research flags')
    require(bool(commands) != phase.startswith('noop'), 'compiler activity/no-op mismatch')
    for line in commands:
        words = shlex.split(line[line.index('Running `') + len('Running `'):].rstrip('`'))
        require(rustc in words, 'unexpected compiler path')
        options = []
        it = iter(words)
        for word in it:
            if word == '-Z':
                word += next(it, '')
            options.append(word)
        if mode == 'off':
            require(not any(w.startswith(('-Zcompact-artifacts', '-Zartifact-compression-profile')) for w in options), 'off flag policy')
        else:
            require('-Zcompact-artifacts=yes' in options and '-Zartifact-compression-profile=fast' in options, 'compact storage flags')
            require(('-Zcompact-artifacts-linker=yes' in options) == (mode == 'default'), 'direct linker capability')
            require(not any(w in options for w in ('-Zembed-metadata=n', '-Zembed-metadata=no', '-Zembed-metadata=off', '-Zembed-metadata=false')), 'self-contained metadata')
    return commands


def verify(root, snapshots):
    matrix = root / 'evidence/performance-v1'
    files = {}
    def read(path, json_data=False):
        path = Path(path)
        require(path.is_relative_to(root) and path.resolve().is_relative_to(root.resolve()) and path.is_file() and not path.is_symlink(), 'bounded regular evidence: ' + str(path))
        files[str(path.relative_to(root))] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
        return load(path) if json_data else path.read_text()
    def remote(path):
        return root / Path(path).relative_to(REMOTE)
    provenance = read(matrix/'provenance.json', True)
    require(provenance['script_sha256'] == HARNESS and provenance['reference_sha256'] == REFERENCE and provenance['core_sha256'] == CORE and provenance['format_wrapper_sha256'] == WRAPPER, 'frozen implementations')
    status = read(matrix/'status.json', True)
    require(status['passed'] and status['samples'] == status['accepted'] == 90 and status['source_and_toolchain_unchanged'], 'complete successful matrix')
    require(not (matrix/'failure.json').exists() and not (matrix/'interrupted.json').exists(), 'no hidden failed run')
    require(provenance['counts'] == {'commands':90,'cells':10,'rounds':2,'commands_per_cell':9}, 'dimensions')
    require(provenance['admission_rules'] == {'outside_user_cores_threshold':0.5,'reject_at_intervals':3,'unrelated_compilers_allowed':False,'free_reserve_bytes':RESERVE,'owned_cap_bytes':CAP,'disk_instrumented':False}, 'fixed admission rules')
    check_budget(status['budget_after']); check_budget(provenance['budget_before'])
    admission = provenance['admission']; toolchain = provenance['toolchain']
    require(admission['passed'] and admission['schema'] == 1 and admission['script_sha256'] == HARNESS and not admission['production_pgo_bolt'] and admission['native_toolchain_matches'], 'admission policy')
    require(admission['toolchain'] == toolchain, 'one toolchain')
    admission_path = root/'evidence/performance-preparation/admission.json'
    require(read(admission_path, True) == admission and digest(admission_path) == provenance['admission_sha256'], 'original admission bytes')
    receipts = {}
    for name, ref in admission['receipts'].items():
        path = remote(ref['path']); receipts[name] = read(path, True)
        require(digest(path) == ref['sha256'] and receipts[name]['passed'], 'native/source admission receipt: '+name)
    require(set(receipts) == {'compiler','cargo','native','source_preparation'}, 'receipt scope')
    compiler,cargo,native,preparation = (receipts[k] for k in ('compiler','cargo','native','source_preparation'))
    # Preserve portable custody of the immediate native proof without reopening
    # older benchmark archives or repeating the component semantic reviews.
    components = native['components']
    require(len(components) == 6, 'native component scope')
    for ref in components.values():
        path = remote(ref['path'])
        require(read(path, True)['passed'] and digest(path) == ref['sha256'], 'native component receipt')
    require(admission['receipts']['compiler'] in components.values() and admission['receipts']['cargo'] in components.values(), 'same native component build receipts')
    require(admission['sources_runtime'] == {'rust':{'base':RUST_BASE,'patch_sha256':RUST_PATCH}, 'cargo':{'base':CARGO_BASE,'patch_sha256':CARGO_PATCH},'wild':WILD}, 'reviewed source identities')
    require(compiler['base'] == RUST_BASE and compiler['patch_sha256'] == RUST_PATCH and compiler['wild_source'] == WILD and compiler['production_pgo_bolt'] is False, 'compiler identity')
    require(cargo['base'] == CARGO_BASE and cargo['patch_sha256'] == CARGO_PATCH, 'Cargo identity')
    require(cargo['compiler_build_sha256'] == native['compiler_build_sha256'] == admission['receipts']['compiler']['sha256'] and native['cargo_build_sha256'] == admission['receipts']['cargo']['sha256'], 'native proof uses measured compiler/Cargo')
    require(cargo['cargo']['path'] == toolchain['cargo'] and cargo['cargo']['sha256'] == toolchain['cargo_sha256'], 'Cargo bytes')
    require(toolchain['drivers'] and toolchain['marker_sha256'] == hashlib.sha256(b'RCOBJ001\n').hexdigest(), 'v2 marker/driver identity')
    for receipt in (compiler,cargo,native):
        t=receipt['toolchain']
        require(t['path'] == toolchain['sysroot'] and all(t[k] == toolchain[k] for k in ('drivers','rustc_sha256','rustdoc_sha256','wild_sha256')), 'compiler bytes in native proof')
        require(t['marker'] == {'name':'compact-artifacts-v2','sha256':toolchain['marker_sha256']}, 'v2 capability')
    require(cargo['toolchain']['cargo_sha256'] == native['toolchain']['cargo_sha256'] == toolchain['cargo_sha256'], 'native Cargo bytes')
    require(preparation['source_originals_unchanged'] and preparation['sources'] == admission['sources'] == provenance['sources'], 'source preparation')
    source_files = {}
    for project in ORDERS:
        before=read(matrix/f'{project}-source-before.json', True); after=read(matrix/f'{project}-source-after.json', True)
        require(before == after, 'tracked source/index restoration')
        source_files[project]=source_manifest(before)
        require({k:v for k,v in before.items() if k!='files'} == {k:v for k,v in admission['sources'][project].items() if k!='path'}, 'source admission identity')
        for name in fixture_bytes(snapshots,project,(0,0,0)):
            # Bind pre-fixture originals themselves, not the generated state.
            original=snapshots/project/name
            require(source_files[project][name]['sha256'] == digest(original), 'original fixture bytes')
    rows=[json.loads(line) for line in read(matrix/'samples.jsonl').splitlines()]
    cells=[(project,mode,r) for project,orders in ORDERS.items() for r,order in enumerate(orders) for mode in order]
    expected=[(project,mode,r,phase,list(state)) for project,mode,r in cells for phase,state in SEQUENCE]
    require([(r['project'],r['mode'],r['round'],r['phase'],r['state']) for r in rows] == expected, 'exact90-row schedule, no exclusions/duplicates')
    require([(c['project'],c['mode'],c['round']) for c in provenance['plan']] == cells, 'exact10-cell order')
    indexed={(r['project'],r['mode'],r['round'],r['phase'],tuple(r['state'])):r for r in rows}
    grouped=defaultdict(list); state_hashes={}; state_patches={}; anomalies=[]
    for cell in provenance['plan']:
        project,mode,r=cell['project'],cell['mode'],cell['round']
        lane=TARGET/project/f'round-{r}'/mode
        argv=[toolchain['cargo'],'-Zohm-defaults=yes']+(['-Zohm-compact-artifacts=no'] if mode=='off' else [])+['build','--offline','--locked','-vv','-p',project,'--bin',project,'-j','8']
        require(cell['argv']==argv and cell['lane']==str(lane), 'same-toolchain planned command')
        env=cell['environment']; require(env['RUSTC']==toolchain['sysroot']+'/bin/rustc' and env['RUSTDOC']==toolchain['sysroot']+'/bin/rustdoc', 'compiler environment')
        require(env['CARGO_TARGET_DIR']==str(lane/'target') and env['CARGO_BUILD_BUILD_DIR']==str(lane/'build'), 'whole-lane output paths')
        require(env['TMPDIR']==str(lane/'scratch') and env['CARGO_HOME']=='/tmp/codex-cargo-home', 'scratch and registry scope')
        require(env['CARGO_INCREMENTAL']=='1' and env['CARGO_BUILD_JOBS']=='8' and env['CARGO_PROFILE_DEV_DEBUG']=='line-tables-only' and env['CARGO_PROFILE_DEV_BUILD_OVERRIDE_DEBUG']=='0', 'fixed build profile')
        require(env.get('CARGO_PROFILE_DEV_OPT_LEVEL')==('1' if project=='ruff' else None), 'project opt level')
        require(env['CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST']==env['CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']=='all', 'fixed trust options')
        wild=['-Clinker-features=-lld','-Clink-self-contained=-linker',f'-Clink-arg=-B{toolchain["sysroot"]}/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld','-Clink-arg=-fuse-ld=bfd']
        require(env['CARGO_ENCODED_RUSTFLAGS']==('\x1f'.join(wild) if mode=='adapter' else ''), 'adapter exact whole-configuration flags')
        for index,(phase,state) in enumerate(SEQUENCE):
            row=indexed[(project,mode,r,phase,state)]
            key=(project,mode,r); grouped[key].append(row)
            require(row['accepted'] and row['returncode']==0 and 'error' not in row and not row.get('preflight',False), 'successful accepted row')
            require(row['argv']==argv and row['cwd']==str(REMOTE/'benchmark-sources'/project), 'actual invocation')
            require(not row['unrelated_compilers'] and not row['disk_reserve_failed'] and len(row['outside_cpu_intervals'])<3 and not row['instrumented_disk'] and row['sampled_peak_allocated_bytes'] is None, 'noise/disk admission')
            check_budget(row['budget_before']); check_budget(row['budget_after'])
            bound=row['budget_before']; require(row['effective_free_reserve']==max(RESERVE,bound['free']-(CAP-bound['owned_allocated'])), 'dynamic task budget')
            for metric,getter in METRICS.items():
                value=getter(row); require(isinstance(value,(int,float)) and math.isfinite(value) and value>=0, 'finite nonnegative '+metric)
            require(row['wall_seconds']>0,'positive wall time')
            stem=matrix/f'{project}-{mode}-{r}'/f'{index:02}-{phase}'
            require(row['log']==str(REMOTE/'evidence/performance-v1'/stem.relative_to(matrix).with_suffix('.log')) and row['resources']==row['log'][:-4]+'.time', 'record paths')
            text=read(stem.with_suffix('.log')); commands=compiler_commands(text,env['RUSTC'],mode,phase)
            require(row['compiler_commands']==len(commands), 'logged compiler count')
            require(row['compiler_crates']==re.findall(r'Running [^\n]*\brustc\b[^\n]*--crate-name ([^\s]+)',text), 'logged crate list')
            time_text=read(stem.with_suffix('.time'))
            for label,field,multiplier in (('User time (seconds)','user_seconds',1),('System time (seconds)','system_seconds',1),('Maximum resident set size (kbytes)','max_child_rss_bytes',1024)):
                match=re.search(r'^\s*'+re.escape(label)+r':\s*(\S+)',time_text,re.M)
                require(match and float(match[1])*multiplier==row[field], 'GNU time '+field)
            require(re.search(r'^\s*Exit status:\s*0\s*$',time_text,re.M),'GNU time status')
            monitor=read(stem.with_suffix('.monitor.json'),True)
            require(monitor and row['sampled_process_tree_peak_rss_bytes']==max(m['rss'] for m in monitor),'sampled tree RSS')
            spikes=[m for m in monitor if m['outside_user_cpu_cores']>0.5]
            require(len(spikes)==len(row['outside_cpu_intervals']),'outside CPU count')
            for actual,recorded in zip(spikes,row['outside_cpu_intervals']):
                require(math.isclose(actual['outside_user_cpu_cores'],recorded['cores'],rel_tol=1e-10) and abs(actual['time']-recorded['time'])<0.1,'outside CPU receipt')
            if spikes: anomalies.append({'project':project,'mode':mode,'round':r,'phase':phase,'state':state,'spikes':spikes})
            require(read(stem.with_suffix('.oracle.json'),True)==row['oracle'],'runtime oracle bytes'); oracle(Checks(),row)
            require(row['oracle']['cases']['synthetic']['argv'][0]==str(lane/'target/debug'/project),'actual lane executable')
            read(stem.with_suffix('.patch')); require(digest(stem.with_suffix('.patch'))==row['patch_sha256'],'source patch bytes')
            skey=(project,state)
            if skey not in state_hashes:
                state_hashes[skey]={p:hashlib.sha256(b).hexdigest() for p,b in fixture_bytes(snapshots,project,state).items()}
                state_patches[skey]=row['patch_sha256']
            require(row['source_sha256']==state_hashes[skey] and row['patch_sha256']==state_patches[skey],'matched reconstructed fixture state')
            check_census(row['census'])
            if phase in ('clean','noop-final'):
                f=row['formats']; metadata=f['metadata_formats']; counts=f['counts']; compact=mode!='off'
                require(f['passed'] and metadata['raw']>0 and metadata['packed']==metadata['other']==0,'raw metadata format')
                require(counts.get('archive',0)>0 and not counts.get('manifest',0) and not counts.get('wrapper',0),'self-contained ar format')
                require((f['archive_member_formats']['compact']>0)==compact and (counts.get('object',0)>0)==compact,'compact member/cache format')
            if phase.startswith('noop'):
                require(row['oracle']['binary_sha256']==grouped[key][-2]['oracle']['binary_sha256'],'no-op binary unchanged')
        cleanup=read(matrix/f'{project}-{mode}-{r}'/'cleanup.json',True)
        require(cleanup['passed'] and cleanup['source_restored'] and cleanup['last_sample_accepted'] and cleanup['path']==str(lane),'owned lane cleanup receipt')
        require(cleanup['census']==grouped[key][-1]['census'],'census archived before cleanup')
        check_budget(cleanup['budget_after'])
    return provenance,rows,files,anomalies


def summarize(rows):
    indexed={(r['project'],r['mode'],r['round'],r['phase'],tuple(r['state'])):r for r in rows}
    comparisons=[]
    for project in ORDERS:
        pairs=[('off','default')]+([('default','adapter'),('off','adapter')] if project=='ruff' else [])
        for reference,candidate in pairs:
            for phase in dict(SEQUENCE):
                matched=[(r,indexed[(project,candidate,r['round'],phase,tuple(r['state']))]) for r in rows if (r['project'],r['mode'],r['phase'])==(project,reference,phase)]
                result={'project':project,'reference':reference,'candidate':candidate,'phase':phase,'n_pairs':len(matched),'metrics':{name:pair_metrics(matched,getter) for name,getter in METRICS.items()},'rounds':[]}
                for i in range(2):
                    subset=[(a,b) for a,b in matched if a['round']==i]
                    result['rounds'].append({'round':i,'n_pairs':len(subset),'metrics':{name:pair_metrics(subset,getter) for name,getter in METRICS.items()},'values':{name:{'reference':[getter(a) for a,b in subset],'candidate':[getter(b) for a,b in subset]} for name,getter in METRICS.items()}})
                comparisons.append(result)
    return comparisons


def number(value, decimals=3, signed=False):
    return 'n/a' if value is None else format(value,('+' if signed else '')+f'.{decimals}f')


def markdown(result):
    lines=['# Compatibility confirmation','',
           'All 90 commands passed receipt verification. Every arm uses the same new compiler, Cargo and Wild; this dataset is separate from earlier measurements. Two fresh forward/reverse rounds provide two clean-build observations and six sequential observations per edit class, project and arm. Ruff defaults remain in the middle position.','',
           '“Off” explicitly disables compact artifacts. “Default” uses automatic compact storage and direct Wild reading. Ruff’s “adapter” supplies the same Wild driver arguments as user configuration, so rustc materializes ordinary linker inputs. That configuration also changes Cargo cache admission; its cost does not isolate decompression.','',
           '| Project | Phase | Comparison | Reference mean (s) | Candidate mean (s) | Δ (s) | Δ (%) | Paired Δ median [range] (s) | Paired % median [range] |',
           '|---|---|---|---:|---:|---:|---:|---|---|']
    def label(g):return f'{g["candidate"]} vs {g["reference"]}'
    for g in result['comparisons']:
        if g['phase'].startswith('noop'):continue
        v=g['metrics']['wall_seconds']; d=v['paired_delta_range']; p=v['paired_percent_range']
        lines.append(f'| {g["project"]} | {PHASE_NAMES[g["phase"]]} | {label(g)} | {number(v["reference_mean"])} | {number(v["candidate_mean"])} | {number(v["delta_mean"],signed=True)} | {number(v["ratio_of_means_percent"],2,True)} | {number(v["paired_delta_median"],signed=True)} [{number(d[0],signed=True)}, {number(d[1],signed=True)}] | {number(v["paired_percent_median"],2,True)} [{number(p[0],2,True)}, {number(p[1],2,True)}] |')
    lines+=['','## Per-round wall time','', 'Each edit value below is one command; the three edits within a round are sequential, not independent rounds.','', '| Project / comparison / phase | Round | Reference seconds | Candidate seconds | Mean Δ (s / %) |','|---|---:|---|---|---|']
    for g in result['comparisons']:
        for r in g['rounds']:
            v=r['metrics']['wall_seconds']; values=r['values']['wall_seconds']
            lines.append(f'| {g["project"]} / {label(g)} / {PHASE_NAMES[g["phase"]]} | {r["round"]+1} | '+', '.join(number(x) for x in values['reference'])+' | '+', '.join(number(x) for x in values['candidate'])+f' | {number(v["delta_mean"],signed=True)} / {number(v["ratio_of_means_percent"],2,True)}% |')
    lines+=['','## Settled allocation','', '| Project | Boundary | Comparison | Reference GiB | Candidate GiB | Δ GiB | Δ % |','|---|---|---|---:|---:|---:|---:|']
    for g in result['comparisons']:
        if g['phase'] not in ('clean','noop-final'):continue
        v=g['metrics']['allocated_bytes']
        lines.append(f'| {g["project"]} | {PHASE_NAMES[g["phase"]]} | {label(g)} | {number(v["reference_mean"]/2**30)} | {number(v["candidate_mean"]/2**30)} | {number(v["delta_mean"]/2**30,signed=True)} | {number(v["ratio_of_means_percent"],2,True)} |')
    lines+=['','## CPU and memory','', '| Project / comparison / phase | CPU mean ref → candidate (s) | CPU Δ % | Largest-child RSS mean ref → candidate (GiB) | Sampled tree RSS mean ref → candidate (GiB) | Tree RSS paired % median [range] |','|---|---|---:|---|---|---|']
    for g in result['comparisons']:
        if g['phase'].startswith('noop'):continue
        m=g['metrics']; cpu=m['cpu_seconds']; child=m['max_child_rss_bytes']; tree=m['sampled_process_tree_peak_rss_bytes']; p=tree['paired_percent_range']
        lines.append(f'| {g["project"]} / {label(g)} / {PHASE_NAMES[g["phase"]]} | {number(cpu["reference_mean"])} → {number(cpu["candidate_mean"])} | {number(cpu["ratio_of_means_percent"],2,True)} | {number(child["reference_mean"]/2**30)} → {number(child["candidate_mean"]/2**30)} | {number(tree["reference_mean"]/2**30)} → {number(tree["candidate_mean"]/2**30)} | {number(tree["paired_percent_median"],2,True)} [{number(p[0],2,True)}, {number(p[1],2,True)}] |')
    lines+=['','## Scope and limits','',
            '- Wall time covers each Cargo command. Runtime oracles, census and cleanup run outside that boundary. No-op rows are retained above and were checked for zero compiler/replay invocations and unchanged executable hashes.',
            '- Allocation includes target/build/scratch and deduplicates hardlinks; it is settled reachable allocation, not peak disk or unique physical CoW extents. Each lane was censused before owned cleanup. Transient adapter decode storage is not measured.',
            '- GNU time reports the largest individual child RSS peak. Sampled tree RSS sums live processes and can count shared mappings repeatedly or miss short peaks; it is not unique physical memory or PSS. Both remain reported without attributing their difference.',
            '- Means, paired medians/ranges, and both fresh-round distributions are descriptive. The six edit observations are not six independent rounds, and there are no confidence or universal-regression claims.',
            '- Non-PGO/BOLT compiler; no cold OS-cache claim. Fixed jobs=8 and the recorded profiles/trust options apply. LTO/plugin/DWARF runtime compatibility is established separately, not timed here.',
            '- Source restoration and lane cleanup are verified from archived receipts and source manifests; removed lane bytes cannot be re-read. Raw rows and referenced logs are retained. No failed row is excluded.',
            '', 'Exact sources and binary identities are in `summary.json`; raw rows are copied byte-for-byte to `samples.jsonl`. This report computes results, not an adoption decision.','']
    return '\n'.join(lines)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path,help='portable compatibility root with evidence/')
    parser.add_argument('--source-snapshots',type=Path,required=True,help='seven original fixture files under ruff/ and uv/')
    parser.add_argument('--output',type=Path,required=True,help='new separate output directory')
    args=parser.parse_args(); require(not args.output.exists(),'output must be new');args.output.mkdir(parents=True)
    validation={'passed':False,'verifier_sha256':digest(__file__),'scope':'Only this90-command dataset and immediate native/source admission receipts; no broad ancestor audit.'}
    try:
        p,rows,files,anomalies=verify(args.root,args.source_snapshots)
        result={'passed':True,'counts':{'commands':90,'accepted':90,'excluded':0,'cells':10,'independent_rounds':2,'commands_per_cell':9},'matrix_sha256':digest(args.root/'evidence/performance-v1/samples.jsonl'),'provenance_sha256':digest(args.root/'evidence/performance-v1/provenance.json'),'verifier_sha256':digest(__file__),'sources_runtime':p['admission']['sources_runtime'],'toolchain':p['toolchain'],'comparisons':summarize(rows),'outside_cpu_intervals':anomalies,'verified_files':files}
        (args.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
        (args.output/'results.md').write_text(markdown(result))
        shutil.copyfile(args.root/'evidence/performance-v1/samples.jsonl',args.output/'samples.jsonl')
        validation.update(passed=True,raw_rows_sha256=result['matrix_sha256'],summary_sha256=digest(args.output/'summary.json'),markdown_sha256=digest(args.output/'results.md'))
    except BaseException as error:
        validation['error']=repr(error);raise
    finally:
        (args.output/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
    print(json.dumps({'passed':True,'commands':90,'output':str(args.output)}))


if __name__=='__main__':main()
