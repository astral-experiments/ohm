#!/usr/bin/env python3
"""Actual Cargo/rustc compatibility checks in one fresh owned namespace; not timings."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path('/home/dev-user/code/oss/ohm-compact-study')
WORK = ROOT / 'shipping/compatibility'
TARGET = Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility')
HOST = 'x86_64-unknown-linux-gnu'
CARGO_PATCH = 'd6a881ad11cb0f3ffe2bd774c4fcb37da1ae076ec6ec3c154ce269c417affe03'
RESERVE = 60 * 1024**3
CAP = 40 * 1024**3


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def snapshot(sysroot, cargo):
    linker = sysroot / 'lib/rustlib' / HOST / 'bin/wild-ld'
    assert (linker / 'compact-artifacts-v2').read_bytes() == b'RCOBJ001\n'
    return {'path': str(sysroot), 'rustc_sha256': digest(sysroot / 'bin/rustc'),
            'rustdoc_sha256': digest(sysroot / 'bin/rustdoc'),
            'drivers': {p.name: digest(p) for p in sorted((sysroot / 'lib').glob('librustc_driver*.so'))},
            'cargo_sha256': digest(cargo), 'wild_sha256': digest(linker / 'ld.bfd'),
            'marker': {'name': 'compact-artifacts-v2', 'sha256': digest(linker / 'compact-artifacts-v2')}}


def archive(path):
    members = []
    with path.open('rb') as stream:
        assert stream.read(8) == b'!<arch>\n', path
        while header := stream.read(60):
            assert len(header) == 60 and header[58:] == b'`\n', path
            size = int(header[48:58]); start = stream.tell(); name = header[:16].strip()
            if name.startswith(b'#1/'):
                n = int(name[3:]); assert 0 <= n <= size
                name = stream.read(n).rstrip(b'\0')
            prefix = stream.read(min(8, start + size - stream.tell()))
            members.append({'name': name.decode(errors='replace'), 'magic_hex': prefix.hex(),
                            'compact': prefix == b'RCOBJ001'})
            stream.seek(start + size + size % 2)
    return {'path': str(path), 'sha256': digest(path), 'members': members,
            'compact_members': sum(m['compact'] for m in members)}


class Checks:
    def __init__(self, args):
        self.args = args
        self.evidence = WORK / 'evidence/cargo-policy-v1'
        self.sources = WORK / 'fixtures/cargo-policy-v1'
        self.target = TARGET / 'cargo-policy-v1'
        for path in (self.evidence, self.sources, self.target):
            assert not path.exists() and not path.is_symlink(), path
            path.mkdir(parents=True)
        (self.target / '.owned').write_text('native_cargo_compatibility.py\n')
        self.compiler = json.loads(args.compiler_receipt.read_text())
        self.built = json.loads(args.cargo_receipt.read_text())
        assert self.compiler['passed'] and self.built['passed']
        assert self.built['patch_sha256'] == CARGO_PATCH
        assert self.built['base'] == '6333daf7cf99cf80125234c9419cbd36e9bff81a'
        assert self.built['compiler_build_sha256'] == digest(args.compiler_receipt)
        self.lld = json.loads(args.lld_receipt.read_text())
        assert self.lld['passed'] and self.lld['compiler_build_sha256'] == digest(args.compiler_receipt)
        assert digest(self.lld['source']) == self.lld['source_sha256']
        self.sysroot = Path(self.compiler['toolchain']['path'])
        self.cargo = Path(self.built['cargo']['path'])
        assert self.sysroot.is_relative_to(WORK / 'toolchains') and self.cargo.is_relative_to(WORK)
        assert self.cargo == self.sysroot / 'bin/cargo'
        self.before = snapshot(self.sysroot, self.cargo)
        for proof in (self.compiler['toolchain'], self.built['toolchain']):
            for key in ('path', 'rustc_sha256', 'rustdoc_sha256', 'drivers', 'wild_sha256', 'marker'):
                assert proof[key] == self.before[key], key
        assert self.before['cargo_sha256'] == self.built['cargo']['sha256']
        for name, item in self.lld['files'].items():
            path = Path(name); assert path.is_relative_to(self.sysroot)
            assert digest(path) == item['sha256']
            if 'symlink' in item: assert path.is_symlink() and os.readlink(path) == item['symlink']
        self.result = {'passed': False, 'script_sha256': digest(__file__), 'started': time.time(),
                       'compiler_build_sha256': digest(args.compiler_receipt),
                       'cargo_build_sha256': digest(args.cargo_receipt), 'toolchain': self.before,
                       'lld_assembly_sha256': digest(args.lld_receipt), 'lld_files': self.lld['files'],
                       'records': [], 'scope': 'Real compiler/linker execution with transparent argv-recording wrappers; not timing or unwrapped shared-cache admission proof.'}
        self.env = {k: v for k, v in os.environ.items() if not k.startswith((
            'RUSTFLAGS', 'RUSTC', 'RUSTDOC', 'RUSTUP_TOOLCHAIN', 'CARGO_PROFILE_', 'CARGO_TARGET_',
            'CARGO_BUILD_', 'CARGO_UNSTABLE_', 'CARGO_ENCODED_'))}
        self.env.update(CARGO_HOME='/tmp/codex-cargo-home', CARGO_INCREMENTAL='1',
                        CARGO_TERM_COLOR='never', CARGO_BUILD_JOBS='4', CARGO_NET_OFFLINE='true')
        self.outer = self.sources / 'outer.py'; self.inner = self.sources / 'inner.py'
        wrapper = '''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
fd=os.open(os.environ['POLICY_ARGV_LOG'],os.O_WRONLY|os.O_APPEND|os.O_CREAT,0o600)
os.write(fd,(json.dumps({'wrapper':Path(__file__).name,'args':sys.argv[1:]})+'\\n').encode());os.close(fd)
os.execv(sys.argv[1],sys.argv[1:])
'''
        for path in (self.outer, self.inner):
            path.write_text(wrapper); path.chmod(0o755)
        self.save()

    def save(self):
        save(self.evidence / 'result.json', self.result)

    def budget(self):
        used = sum(int(line.split()[0]) for line in subprocess.check_output(
            ['du', '-s', '-B1', str(WORK), str(TARGET)], text=True).splitlines())
        free = shutil.disk_usage(TARGET).free
        assert free >= RESERVE and used <= CAP, (free, used)
        return {'free': free, 'owned_allocated': used, 'reserve': RESERVE, 'cap': CAP}

    def fixture(self, name, build_script=False, dylib=False):
        path = self.sources / name; path.mkdir()
        files = {'Cargo.toml': '[workspace]\nmembers=["dep","mac"]\n[package]\nname="policy-app"\nversion="0.0.0"\nedition="2021"\n[dependencies]\npolicy-dep={path="dep"}\n',
                 'src/main.rs': 'fn main() { println!("{}", policy_dep::value()); }\n',
                 'dep/Cargo.toml': '[package]\nname="policy-dep"\nversion="0.0.0"\nedition="2021"\n[dependencies]\npolicy-mac={path="../mac"}\n' + ('[lib]\ncrate-type=["dylib"]\n' if dylib else ''),
                 'dep/src/lib.rs': '/// ```\n/// assert_eq!(policy_dep::value(), 42);\n/// ```\npub fn value() -> u32 { policy_mac::forty!() + 2 }\n',
                 'mac/Cargo.toml': '[package]\nname="policy-mac"\nversion="0.0.0"\nedition="2021"\n[lib]\nproc-macro=true\n',
                 'mac/src/lib.rs': 'extern crate proc_macro; #[proc_macro] pub fn forty(_:proc_macro::TokenStream)->proc_macro::TokenStream { "40".parse().unwrap() }\n'}
        if build_script:
            files['build.rs'] = 'fn main() { println!("cargo::rustc-link-arg=-fuse-ld=bfd"); println!("cargo::rustc-link-arg=-Wl,--no-as-needed"); }\n'
        for name, data in files.items():
            dest = path / name; dest.parent.mkdir(exist_ok=True, parents=True); dest.write_text(data)
        return path

    def run(self, label, source, options=(), command=('build',), flags=None, config=None,
            sysroot=None, cargo=None, expect=0, compact=None, direct=None, fresh=None,
            runtime=True, wrappers=False, crate='policy_app', inspect_archive=True,
            bitcode_archive=False, allow_reuse=False, ordinary_driver=False):
        env = dict(self.env); sysroot = sysroot or self.sysroot; cargo = cargo or self.cargo
        env.update(RUSTC=str(sysroot / 'bin/rustc'), RUSTDOC=str(sysroot / 'bin/rustdoc'),
                   RUSTC_WRAPPER=str(self.outer), CARGO=str(cargo),
                   CARGO_TARGET_DIR=str(self.target / source.name / 'target'),
                   CARGO_BUILD_BUILD_DIR=str(self.target / source.name / 'shared-build'))
        if wrappers: env['RUSTC_WORKSPACE_WRAPPER'] = str(self.inner)
        if flags: env['CARGO_ENCODED_RUSTFLAGS'] = '\x1f'.join(flags)
        if config: env.update(config)
        argvlog = self.evidence / (label + '.argv.jsonl'); env['POLICY_ARGV_LOG'] = str(argvlog)
        args = [str(cargo), '-Zohm-defaults=yes', *options, *command]
        if command[0] in ('build', 'rustc'):
            index = args.index('--') if '--' in args else len(args)
            args[index:index] = ['--offline', '-vv', '--message-format=json']
        elif command[0] == 'test': args += ['--offline', '-vv']
        recorded = {'RUSTC','RUSTDOC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO','CARGO_HOME',
                    'CARGO_INCREMENTAL','CARGO_TERM_COLOR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE',
                    'CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','CARGO_ENCODED_RUSTFLAGS','POLICY_ARGV_LOG'} | set(config or {})
        row = {'label': label, 'argv': args, 'cwd': str(source), 'environment': {k:env[k] for k in sorted(recorded) if k in env},
               'expected_status': expect, 'budget_before': self.budget()}
        self.result['records'].append(row); self.save(); start = time.monotonic()
        stdout = self.evidence / (label + '.stdout'); stderr = self.evidence / (label + '.stderr')
        with stdout.open('wb') as out, stderr.open('wb') as err:
            process = subprocess.Popen(args, cwd=source, env=env, stdout=out, stderr=err, start_new_session=True)
            try:
                while process.poll() is None:
                    try: process.wait(timeout=2)
                    except subprocess.TimeoutExpired: pass
                    assert shutil.disk_usage(TARGET).free >= RESERVE
            except BaseException:
                if process.poll() is None: os.killpg(process.pid, signal.SIGTERM); process.wait()
                raise
        row.update(returncode=process.returncode, seconds=time.monotonic()-start,
                   stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
        self.save(); assert process.returncode == expect, (label, stderr.read_text()[-4000:])
        checked = self.target / source.name
        leftovers = [str(Path(directory)/name) for directory, dirs, files in os.walk(checked, followlinks=False)
                     for name in [*dirs, *files] if name.startswith('rustc-artifacts')
                     or (name.startswith('.compact.') and name.endswith('.tmp'))
                     or name.startswith('.compact-link.')]
        row['scratch_cleanup'] = {'passed': not leftovers, 'root': str(checked), 'leftovers': leftovers}
        self.save(); assert not leftovers, (label, leftovers)
        calls = [json.loads(line) for line in argvlog.read_text().splitlines()] if argvlog.exists() else []
        row['argv_log_sha256'] = digest(argvlog) if argvlog.exists() else None
        emitted = [call for call in calls if '--crate-name' in call['args'] and call['args'][call['args'].index('--crate-name')+1] != '___']
        units = [call for call in emitted if call['args'][call['args'].index('--crate-name')+1] == crate]
        row['crate_invocations'] = len(units)
        if fresh is True:
            assert not emitted and not any('-Zlink-only' in call['args'] or 'link-only' in call['args'] for call in calls), label
        elif expect == 0 and command[0] in ('build', 'rustc') and not allow_reuse:
            assert units, (label, calls)
        if expect:
            row['diagnostic'] = stderr.read_text()
            row['passed'] = True
            self.save(); return row
        if compact is not None and units:
            for unit in units:
                assert ('-Zcompact-artifacts=yes' in unit['args']) == compact, (label,unit)
                assert ('-Zcompact-artifacts-linker=yes' in unit['args']) == direct, (label,unit)
                assert ('-Zartifact-compression-profile=fast' in unit['args']) == compact, (label,unit)
                if ordinary_driver:
                    assert not any('wild-ld' in arg for arg in unit['args']), (label,unit)
        events = []
        for line in stdout.read_text().splitlines():
            try: event = json.loads(line)
            except ValueError: continue
            if event.get('reason') == 'compiler-artifact': events.append(event)
        active = [Path(name) for event in events if event['target']['name'] == 'policy_dep'
                  for name in event['filenames'] if name.endswith('.rlib')]
        if inspect_archive and command[0] in ('build', 'rustc') and compact is not None:
            assert active, (label, events)
            row['archives'] = [archive(path) for path in active]
            if bitcode_archive:
                # Cargo emits plugin-ready IR for dependencies of cross-crate LTO units.
                assert all(item['compact_members'] == 0 and any(
                    member['magic_hex'].startswith(('4243c0de', 'dec0170b'))
                    for member in item['members']) for item in row['archives']), (label,row['archives'])
            else:
                assert all((item['compact_members'] > 0) == compact for item in row['archives']), (label,row['archives'])
        executables = [Path(event['executable']) for event in events if event.get('executable') and event['target']['name'] == 'policy-app']
        if runtime and command[0] in ('build', 'rustc'):
            assert len(executables) == 1, (label,events)
            binary = executables[0]
            runenv = dict(env); libdir = sysroot / 'lib/rustlib' / HOST / 'lib'
            runenv['LD_LIBRARY_PATH'] = ':'.join([str(binary.parent/'deps'),str(libdir),str(sysroot/'lib')])
            actual = subprocess.check_output([binary], env=runenv, text=True)
            assert actual == '42\n', (label,actual)
            row['runtime'] = {'path': str(binary), 'stdout': actual, 'sha256': digest(binary)}
        row['budget_after'] = self.budget(); row['passed'] = True; self.save(); return row

    def all(self):
        basic = self.fixture('toggle')
        first = self.run('default', basic, compact=True, direct=True)
        noop = self.run('default-noop', basic, compact=True, direct=True, fresh=True)
        assert first['runtime']['sha256'] == noop['runtime']['sha256']
        self.run('optout', basic, options=['-Zohm-compact-artifacts=no'], compact=False, direct=False)
        restored = self.run('explicit', basic, options=['-Zohm-compact-artifacts=yes'], compact=True, direct=True, allow_reuse=True)
        assert restored['runtime']['sha256'] == first['runtime']['sha256']
        self.run('doctest', basic, command=['test','--doc','-p','policy-dep'], runtime=False)
        assert 'test result: ok. 1 passed;' in (self.evidence/'doctest.stdout').read_text()
        # This development stage1 sysroot need not bundle rust-lld; use the system driver.
        self.run('defaults-disabled', self.fixture('defaults-disabled'),
                 options=['-Zohm-defaults=no'], flags=['-Clinker-features=-lld'], compact=False, direct=False)

        no_marker = WORK / 'toolchains/cargo-policy-no-v2'; assert not no_marker.exists()
        capacity = self.budget()
        copy_bound = int(subprocess.check_output(['du','-s','-L','-B1',self.sysroot],text=True).split()[0]) + 1024**2
        assert capacity['owned_allocated'] + copy_bound <= CAP and capacity['free'] - copy_bound >= RESERVE
        subprocess.run(['cp','-aL','--reflink=auto',self.sysroot,no_marker],check=True)
        marker_dir = no_marker / 'lib/rustlib' / HOST / 'bin/wild-ld'
        (marker_dir / 'compact-artifacts-v2').unlink()
        (marker_dir / 'compact-artifacts-v1').write_bytes(b'RCOBJ001\n')
        old = self.fixture('no-v2')
        self.run('no-v2-auto', old, sysroot=no_marker, compact=False, direct=False)
        error = self.run('no-v2-explicit', old, sysroot=no_marker, options=['-Zohm-compact-artifacts=yes'],expect=101,runtime=False)
        assert 'compact-artifacts-v2 support' in error['diagnostic']

        meta = self.fixture('metadata-fallback')
        self.run('metadata-fallback', meta, options=['-Zembed-metadata=no'],compact=False,direct=False)
        self.run('metadata-alias-n', self.fixture('metadata-alias-n'),
                 flags=['-Zembed-metadata=n'], compact=False, direct=False)
        self.run('metadata-alias-off-extra', self.fixture('metadata-alias-off-extra'),
                 command=['rustc','--','-Zembed-metadata=off'], compact=False, direct=False,
                 inspect_archive=False)
        for origin in ('env','profile','extra'):
            p = self.fixture('response-'+origin); response=p/'flags'; response.write_text('-Zcompact-artifacts=no\n'); token='@'+str(response)
            flags = [token] if origin=='env' else None
            options=[]; command=['build']
            if origin=='profile':
                (p/'.cargo').mkdir(); (p/'.cargo/config.toml').write_text('[profile.dev]\nrustflags=["'+token+'"]\n');options=['-Zprofile-rustflags']
            if origin=='extra': command=['rustc','--',token]
            # cargo rustc extras apply only to the binary; profile rustflags also apply to dependencies.
            row=self.run('response-'+origin,p,options=options,command=command,flags=flags,compact=False,direct=False,inspect_archive=origin!='extra',ordinary_driver=True)
            assert all('-Zcompact-artifacts=yes' not in c['args'] for c in [json.loads(l) for l in (self.evidence/('response-'+origin+'.argv.jsonl')).read_text().splitlines()] if '--crate-name' in c['args'] and c['args'][c['args'].index('--crate-name')+1]=='policy_app')
            error=self.run('response-'+origin+'-explicit',p,options=[*options,'-Zohm-compact-artifacts=yes'],command=command,flags=flags,expect=101,runtime=False)
            assert 'opaque rustc response file' in error['diagnostic']

        cc=shutil.which('cc');assert cc and shutil.which('ld.bfd') and shutil.which('ld.lld')
        for origin, linker in [('env','bfd'),('env','lld'),('target','bfd'),('ohm','lld'),('profile','bfd'),('extra','bfd'),('build-script','bfd'),('wrappers','bfd')]:
            label=origin+'-'+linker;p=self.fixture(label,build_script=origin in ('build-script','wrappers'))
            flags=[f'-Clinker={cc}',f'-Clink-arg=-fuse-ld={linker}'] if origin=='env' else None
            options=[];command=['build']
            if origin=='target':
                (p/'.cargo').mkdir();(p/'.cargo/config.toml').write_text(f'[target.{HOST}]\nlinker="{cc}"\n')
            if origin=='ohm':options=['-Zohm-linker=lld']
            if origin=='profile':
                (p/'.cargo').mkdir();(p/'.cargo/config.toml').write_text(f'[profile.dev]\nrustflags=["-Clinker={cc}","-Clink-arg=-fuse-ld={linker}"]\n');options=['-Zprofile-rustflags']
            if origin=='extra':command=['rustc','--',f'-Clinker={cc}',f'-Clink-arg=-fuse-ld={linker}']
            self.run(label,p,options=options,command=command,flags=flags,compact=True,direct=False,wrappers=origin=='wrappers',ordinary_driver=True)
            if origin=='target':
                calls=[json.loads(line) for line in (self.evidence/(label+'.argv.jsonl')).read_text().splitlines()]
                assert any('-C' in call['args'] and f'linker={cc}' in call['args'] or f'-Clinker={cc}' in call['args'] for call in calls)
            if origin=='wrappers':
                calls=[json.loads(line) for line in (self.evidence/(label+'.argv.jsonl')).read_text().splitlines()]
                assert any(call['wrapper']=='outer.py' and call['args'][0]==str(self.inner) for call in calls)
                assert any(call['wrapper']=='inner.py' and call['args'][0]==str(self.sysroot/'bin/rustc') for call in calls)

        for lto in ('thin','fat'):
            p=self.fixture('lto-'+lto)
            self.run('lto-'+lto,p,command=['build','--release'],config={'CARGO_PROFILE_RELEASE_LTO':lto},compact=True,direct=True,bitcode_archive=True)
        p=self.fixture('packed')
        packed=self.run('packed',p,config={'CARGO_PROFILE_DEV_DEBUG':'2','CARGO_PROFILE_DEV_SPLIT_DEBUGINFO':'packed'},compact=True,direct=True)
        dwp=Path(packed['runtime']['path']+'.dwp');assert dwp.is_file() and dwp.stat().st_size>0
        self.result['packed_dwp']={'path':str(dwp),'sha256':digest(dwp),'bytes':dwp.stat().st_size}

        # Compare the inherited dylib argv expectation with an actual retained6333 binary.
        old_receipt=ROOT/'shipping/readiness/final-cargo-current/evidence/result.json'
        prior=json.loads(old_receipt.read_text());assert prior['passed'] and prior['sources']['cargo']=='6333daf7cf99cf80125234c9419cbd36e9bff81a'
        old_cargo=ROOT/'shipping/readiness/final-cargo-current/toolchain/bin/cargo'
        assert digest(old_cargo)==prior['toolchain']['cargo_sha256']
        before=digest(old_cargo); comparisons=[]
        for label,cargo in [('base6333',old_cargo),('candidate',self.cargo)]:
            p=self.fixture('dylib-'+label,dylib=True)
            row=self.run('dylib-'+label,p,options=['-Zohm-defaults=no','-Zembed-metadata=no'],flags=['-Clinker-features=-lld'],cargo=cargo,inspect_archive=False)
            calls=[json.loads(line) for line in (self.evidence/('dylib-'+label+'.argv.jsonl')).read_text().splitlines()]
            dep=[c['args'] for c in calls if '--crate-name' in c['args'] and c['args'][c['args'].index('--crate-name')+1]=='policy_dep']
            assert dep and all('embed-metadata=no' in args or '-Zembed-metadata=no' in args for args in dep)
            comparisons.append({'label':label,'cargo_sha256':digest(cargo),'runtime':row['runtime'],'dylib_receives_explicit_no_embed':True})
        assert digest(old_cargo)==before
        self.result['inherited_dylib_fixture']={'base_receipt_sha256':digest(old_receipt),'comparisons':comparisons,'scope':'Actual base/candidate fixture, not an execution of the base6333 integration-test suite.'}
        self.run('clean',basic,command=['clean'],runtime=False)
        assert not Path(first['runtime']['path']).exists()
        assert snapshot(self.sysroot,self.cargo)==self.before
        assert digest(self.args.compiler_receipt)==self.result['compiler_build_sha256']
        assert digest(self.args.cargo_receipt)==self.result['cargo_build_sha256']
        assert digest(self.args.lld_receipt)==self.result['lld_assembly_sha256']
        for name,item in self.lld['files'].items():
            assert digest(name)==item['sha256']
            if 'symlink' in item:assert Path(name).is_symlink() and os.readlink(name)==item['symlink']
        self.result.update(passed=True,toolchain_unchanged=True,finished=time.time(),budget_after=self.budget());self.save()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--compiler-receipt',type=Path,default=WORK/'evidence/compiler-v3/result.json')
    parser.add_argument('--cargo-receipt',type=Path,default=WORK/'evidence/cargo-v1/result.json')
    parser.add_argument('--lld-receipt',type=Path,default=WORK/'evidence/lld-assembly-v1/result.json')
    args=parser.parse_args()
    assert (WORK/'.owned').is_file() and (TARGET/'.owned').is_file()
    checks=Checks(args)
    try: checks.all()
    except BaseException as error:
        checks.result.update(error=repr(error),finished=time.time());checks.save();raise
    print(json.dumps({'passed':True,'records':len(checks.result['records']),'result':str(checks.evidence/'result.json')}))


if __name__=='__main__':main()
