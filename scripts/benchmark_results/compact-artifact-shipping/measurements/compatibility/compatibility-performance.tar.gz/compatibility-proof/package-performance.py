"""Seal a standalone90-command proof after raw custody, verifier and paired-math audits."""
from pathlib import Path
import argparse,gzip,hashlib,json,shutil,tarfile
LOCAL=Path('/private/tmp/ohm-compact-compatibility');REVIEWS=Path('/private/tmp/ohm-compact-compatibility-evidence')
VERIFIER='ca79be2c6ec4d15fc530a9922654ef056d4ff793e645a37753e58365df5687a6'
MATH='7d51b3ea118e67f2467369f6b2ae006c80a608c2e49019e291e7fe778a1d1019'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('--raw-root',type=Path,required=True);p.add_argument('--results',type=Path,required=True);p.add_argument('--math-audit',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
collection=load(a.raw_root/'collection-v1.json');transfer=load(LOCAL/'evidence/verified-performance-transfer.json');summary=load(a.results/'summary.json');validation=load(a.results/'validation.json');math=load(a.math_audit)
assert collection['passed'] and transfer['passed'] and transfer['collection_sha256']==sha(a.raw_root/'collection-v1.json')
assert collection['counts']=={'commands':90,'accepted':90,'excluded':0} and transfer['verified_files']==collection['file_count'] and transfer['verified_bytes']==collection['total_bytes']
assert summary['passed'] and summary['counts']=={'commands':90,'accepted':90,'excluded':0,'cells':10,'independent_rounds':2,'commands_per_cell':9}
assert summary['matrix_sha256']==collection['samples_sha256']==sha(a.raw_root/'evidence/performance-v1/samples.jsonl')==sha(a.results/'samples.jsonl')
assert summary['provenance_sha256']==collection['provenance_sha256'] and summary['verifier_sha256']==VERIFIER
assert validation['passed'] and validation['verifier_sha256']==VERIFIER and validation['raw_rows_sha256']==summary['matrix_sha256'] and validation['summary_sha256']==sha(a.results/'summary.json') and validation['markdown_sha256']==sha(a.results/'results.md')
assert math['passed'] and math['raw_commands']==90 and math['groups']==20 and math['independent_rounds']==2 and math['auditor_sha256']==MATH and math['samples_sha256']==summary['matrix_sha256'] and math['summary_sha256']==sha(a.results/'summary.json')
assert sha(LOCAL/'harness/summarize_compatibility.py')==VERIFIER and sha(LOCAL/'harness/audit_pair_math.py')==MATH
assert not a.output.exists();a.output.mkdir(parents=True);stage=a.output/'stage/compatibility-proof';stage.mkdir(parents=True)
entries={}
def add(src,relative):
 assert src.is_file() and not src.is_symlink(),src
 target=stage/relative;assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
 if relative in entries:assert entries[relative]['sha256']==sha(src),relative;return
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
 entries[relative]={'path':relative,'bytes':target.stat().st_size,'sha256':sha(target)}
for row in collection['files']:
 src=a.raw_root/row['path'];assert src.stat().st_size==row['bytes'] and sha(src)==row['sha256'];add(src,row['path'])
assert len(entries)==collection['file_count']
add(a.raw_root/'collection-v1.json','collection-v1.json');add(LOCAL/'evidence/verified-performance-transfer.json','transfer-verification.json')
for name in ('summary.json','validation.json','results.md'):add(a.results/name,'results/'+name)
add(a.math_audit,'results/independent-pair-math.json')
for name in ('summarize_compatibility.py','audit_pair_math.py','test_summarize_compatibility.py','test_benchmark_compatibility.py','audit_actual_routing.py'):add(LOCAL/'harness'/name,'harness/'+name)
for source,want in [(Path('/private/tmp/ohm-compact-readiness/harness/benchmark_current_cargo.py'),'29435c96104f2e9e65d693fd7fedec2623ff9199761889ee981613e5718dfe43'),(Path('/private/tmp/ohm-compact-shipping/harness/benchmark_shipping.py'),'cb972b8f75c9e89a98e76e7e244a39fb616a6c341129650e3745e73df56faad2'),(Path('/private/tmp/ohm-compact-harness/benchmark.py'),'ea7867f9f9a0f19ceb7d9c558aa7aa6758ae3e254878685fbc58768c65713cef')]:
 assert sha(source)==want;add(source,'harness/origins/'+source.name)
for f in sorted((LOCAL/'fixtures/source-originals').rglob('*')):
 if f.is_file():add(f,str(f.relative_to(LOCAL)))
for name in ('performance-harness-review.json','summary-verifier-peer-review.json','summary-pair-math-review.json','performance-parser-peer-review.json','performance-transfer-independent-review.json','performance-actual-routing-review.json'):
 add(REVIEWS/name,'reviews/'+name)
for f in sorted((LOCAL/'postprocessing-history').rglob('*')):
 if f.is_file() and '__pycache__' not in f.parts:add(f,str(f.relative_to(LOCAL)))
add(LOCAL/'collection-peer-review.json','reviews/collection-peer-review.json')
for name in ('summary-synthetic-validation.json','summary-synthetic-validation.log','pair-math-synthetic-validation.json'):
 add(LOCAL/name,'reviews/'+name)
add(LOCAL/'control/verify-performance-archive.py','verify-performance-archive.py')
add(LOCAL/'publication/performance-README.md','README.md')
add(Path(__file__),'package-performance.py')
inventory={'schema':1,'scope':'Complete remote collection plus local reproducibility/verification inputs; no final767 build proof (separate correctness layer).','file_count':len(entries),'total_bytes':sum(x['bytes'] for x in entries.values()),'files':sorted(entries.values(),key=lambda x:x['path']),'excluded_self':'inventory.json'}
put(stage/'inventory.json',inventory);shutil.copyfile(stage/'inventory.json',a.output/'inventory.json')
archive=a.output/'compatibility-performance.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,filename='',mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for f in sorted(stage.rglob('*')):
    if not f.is_file():continue
    info=tar.gettarinfo(str(f),arcname='compatibility-proof/'+str(f.relative_to(stage)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
    with f.open('rb') as stream:tar.addfile(info,stream)
for src,name in [(a.results/'summary.json','summary.json'),(a.results/'validation.json','validation.json'),(a.results/'results.md','results.md'),(a.math_audit,'independent-pair-math.json')]:shutil.copyfile(src,a.output/name)
receipt={'passed':True,'scope':inventory['scope'],'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'inventory_sha256':sha(a.output/'inventory.json'),'payload_files':inventory['file_count'],'archive_regular_files':inventory['file_count']+1,'payload_bytes':inventory['total_bytes'],'collection_sha256':sha(a.raw_root/'collection-v1.json'),'summary_sha256':sha(a.results/'summary.json'),'validation_sha256':sha(a.results/'validation.json'),'pair_math_sha256':sha(a.math_audit),'packager_sha256':sha(Path(__file__))}
shutil.copyfile(LOCAL/'control/verify-performance-archive.py',a.output/'verify-performance-archive.py')
shutil.copyfile(LOCAL/'publication/performance-README.md',a.output/'README.md')
put(a.output/'package.json',receipt);print(json.dumps(receipt))
