"""Build only the frozen compatibility candidate in new owned sources and cache."""
import hashlib,json,os,shutil,signal,subprocess,time
from pathlib import Path
ROOT=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=ROOT/'shipping/compatibility';INPUTS=WORK/'inputs';EVIDENCE=WORK/'evidence/compiler-v3'
TARGET_ROOT=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility');TARGET=TARGET_ROOT/'bootstrap'
SOURCE=WORK/'compiler/rust';DONOR=ROOT/'shipping/readiness/compiler/rust';OLD=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/bootstrap')
PROOF=ROOT/'shipping/readiness/final-cargo-current/rust-proof.git';CARGO_DONOR=ROOT/'shipping/readiness/final-cargo-current/source'
HOST='x86_64-unknown-linux-gnu';BASE='36f01299cd71f6c090150a80fe4a7babb6245a0b';PATCH='4790daedc77c40dc4dc3a0f1789a9579d6aee773b88f4ec968e2884ef42fcc49';WILD='9179eb988df2676342192a24dc337cf9823e9d56'
CAP=40*1024**3;RESERVE=60*1024**3

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def output(args,cwd=None):return subprocess.check_output(list(map(str,args)),cwd=cwd,text=True).strip()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def allocated(p):return int(output(['du','-s','-B1',p]).split()[0]) if p.exists() else 0
def budget():
 free=shutil.disk_usage(WORK).free;used=allocated(WORK)+allocated(TARGET_ROOT)
 assert free>=RESERVE,('free-space reserve',free)
 assert used<=CAP,('owned-root cap',used)
 return {'free':free,'owned_allocated':used,'cap':CAP,'reserve':RESERVE}
manifest=json.loads((INPUTS/'compiler-v3-manifest.json').read_text());assert manifest['base']==BASE and manifest['patch_sha256']==PATCH==sha(INPUTS/'compiler-v3.patch')
manifest['files']={r['path']:r['sha256'] for r in manifest['files']}
old_evidence=WORK/'evidence/compiler-v2';old=json.loads((old_evidence/'result.json').read_text());assert not old['passed'] and old['phase']=='resume-compiler-build' and old['commands'][-1]['code']==1
assert SOURCE.is_dir() and TARGET.is_dir() and not EVIDENCE.exists();EVIDENCE.mkdir()
previous=json.loads((INPUTS/'compiler-v2-manifest.json').read_text())
for name,h in previous['files'].items():assert sha(SOURCE/name)==h,name
assert output(['git','rev-parse','HEAD'],SOURCE)==BASE and output(['git','config','user.email'],SOURCE)=='charlie.r.marsh@gmail.com'
protected=json.loads((old_evidence/'protected-before.json').read_text())
receipt={'passed':False,'phase':'prepare-v3','started':time.time(),'base':BASE,'patch_sha256':PATCH,'source':str(SOURCE),'target':str(TARGET),'wild_source':WILD,'commands':[],'production_pgo_bolt':False,'budget':budget(),'prior_failed_receipt_sha256':sha(old_evidence/'result.json'),'reused_protected_snapshot_sha256':sha(old_evidence/'protected-before.json'),'preservation_scope':old['preservation_scope'],'protected_files':len(protected)}
def save():put(EVIDENCE/'result.json',receipt)
def run(label,args,cwd=None,env=None):
 row={'label':label,'argv':list(map(str,args)),'cwd':str(cwd) if cwd else None,'started':time.time()};receipt['commands'].append(row);receipt['phase']=label;save();print(json.dumps({'started':label}),flush=True)
 with (EVIDENCE/(label+'.log')).open('w') as log:
  p=subprocess.Popen(row['argv'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   next_budget=time.time()+30
   while p.poll() is None:
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
    assert shutil.disk_usage(WORK).free>=RESERVE,'free-space reserve during '+label
    if time.time()>=next_budget:budget();next_budget=time.time()+30
   row['code']=p.returncode
  except BaseException:
   if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
   row['code']=p.returncode;raise
  finally:row['seconds']=time.time()-row['started'];save()
 row['budget']=budget();save();print(json.dumps({'finished':label,'code':row['code'],'seconds':row['seconds']}),flush=True)
 assert row['code']==0,label

def verify_protected(expected):
 errors=[]
 for name,row in expected.items():
  p=Path(name)
  ok=(p.is_symlink() and os.readlink(p)==row['symlink']) if 'symlink' in row else (p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'])
  if not ok:errors.append(name)
 return {'passed':not errors,'files':len(expected),'changed':errors,'finished':time.time()}

try:
 assert sha(INPUTS/'compiler-v2-to-v3.patch')=='7e5285a947452a28545ef9bfbf34b5425a9f95ee0b7e98b5cf417120a7cdbfaf'
 run('delta-check',['git','apply','--check',INPUTS/'compiler-v2-to-v3.patch'],SOURCE)
 run('delta-apply',['git','apply',INPUTS/'compiler-v2-to-v3.patch'],SOURCE)
 for name,h in manifest['files'].items():assert sha(SOURCE/name)==h,name
 assert set(output(['git','diff','--name-only'],SOURCE).splitlines())==set(manifest['files'])
 put(EVIDENCE/'source-files.json',{'base':BASE,'patch_sha256':PATCH,'files':manifest['files'],'applied_delta_sha256':sha(INPUTS/'compiler-v2-to-v3.patch')})
 receipt['source_manifest_sha256']=sha(EVIDENCE/'source-files.json');save()
 env={k:v for k,v in os.environ.items() if not k.startswith(('RUSTFLAGS','RUSTC','RUSTDOC','CARGO_PROFILE_','CARGO_TARGET_','CARGO_UNSTABLE_','CARGO_ENCODED_','CARGO_BUILD_','RUSTUP_TOOLCHAIN'))}
 env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='12')
 common=['--stage','1','--set','build.submodules=false','--set',f'target.{HOST}.ohm-wild-linker={ROOT}/shipping/final-review/bounds-fix/wild-release']
 run('compiler-build',['python3','x.py','build',*common,'compiler/rustc','src/tools/rustdoc','library'],SOURCE,env)
 sysroot=WORK/'toolchains/compiler-v3';assert not sysroot.exists();sysroot.parent.mkdir(exist_ok=True)
 run('install',['cp','-aL','--reflink=auto',TARGET/HOST/'stage1',sysroot])
 linker=sysroot/'lib/rustlib'/HOST/'bin/wild-ld';linker.mkdir(parents=True,exist_ok=True)
 shutil.copy2(ROOT/'shipping/final-review/bounds-fix/wild-release',linker/'ld.bfd')
 (linker/'compact-artifacts-v1').unlink(missing_ok=True);(linker/'compact-artifacts-v2').write_bytes(b'RCOBJ001\n')
 receipt['toolchain']={'path':str(sysroot),'version':output([sysroot/'bin/rustc','-vV']),'rustc_sha256':sha(sysroot/'bin/rustc'),'rustdoc_sha256':sha(sysroot/'bin/rustdoc'),'drivers':{p.name:sha(p) for p in (sysroot/'lib').glob('librustc_driver*.so')},'wild_sha256':sha(linker/'ld.bfd'),'marker':{'name':'compact-artifacts-v2','sha256':sha(linker/'compact-artifacts-v2')},'linked_libraries':{str(p.relative_to(sysroot)):sha(p) for p in (sysroot/'lib').glob('libLLVM*') if p.is_file()},'dynamic_dependencies':output(['ldd',sysroot/'bin/rustc'])}
 assert 'not found' not in receipt['toolchain']['dynamic_dependencies'];assert list((sysroot/'lib/rustlib'/HOST/'lib').glob('libstd-*.rlib'))
 for name,digest in manifest['files'].items():assert (sha(SOURCE/name) if (SOURCE/name).is_file() else None)==digest,name
 after=verify_protected(protected);put(EVIDENCE/'protected-after.json',after);assert after['passed'],after['changed'][:10]
 receipt['budget']=budget();receipt['passed']=True;receipt['phase']='built-awaiting-test-payload'
except BaseException as e:
 receipt['error']=repr(e);raise
finally:
 receipt['finished']=time.time();save()
print(json.dumps({'passed':receipt['passed'],'evidence':str(EVIDENCE),'toolchain':receipt.get('toolchain')}),flush=True)
