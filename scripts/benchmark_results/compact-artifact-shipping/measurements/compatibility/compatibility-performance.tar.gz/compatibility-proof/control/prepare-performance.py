"""Prepare only new source copies/admission after native proof; never run timings."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

LOCAL = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bench', LOCAL / 'harness/benchmark_compatibility.py')
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
WORK = bench.WORK
PREVIOUS = WORK.parent / 'readiness/evidence/current-cargo-preparation.json'
PREVIOUS_SHA = '0d924f57bc953ba20dfd137e96f26d9fc212383bcd506c4131f3319dc527ca96'


def run(args, cwd=None, input=None):
    subprocess.run(list(map(str, args)), cwd=cwd, input=input, check=True)


def check_previous(source, previous):
    snapshot = bench.source_snapshot(source)
    assert snapshot['head'] == previous['head'] and snapshot['diff_sha256'] == previous['patch_sha256']
    expected = previous['files']
    assert {row['path'] for row in snapshot['files']} == set(expected)
    for row in snapshot['files']:
        old = expected[row['path']]
        if 'symlink' in row:
            value = row['symlink'].encode()
            assert old['kind'] == 'symlink' and old['bytes'] == len(value)
            assert old['sha256'] == hashlib.sha256(value).hexdigest()
        else:
            assert old['kind'] == 'file' and old['sha256'] == row['sha256'] and old['bytes'] == row['bytes']
            assert old['executable'] == (int(row['mode'], 8) & 0o111 != 0)
    return snapshot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--compiler-receipt', type=Path, default=WORK / 'evidence/compiler-v3/result.json')
    parser.add_argument('--cargo-receipt', type=Path, default=WORK / 'evidence/cargo-v1/result.json')
    parser.add_argument('--native-receipt', type=Path, default=WORK / 'evidence/native-v1/result.json')
    args = parser.parse_args()
    destination = WORK / 'benchmark-sources'
    evidence = WORK / 'evidence/performance-preparation'
    assert not destination.exists() and not evidence.exists()
    assert bench.digest(PREVIOUS) == PREVIOUS_SHA
    previous = bench.load(PREVIOUS)
    assert previous['passed']
    refs = {'compiler': args.compiler_receipt, 'cargo': args.cargo_receipt, 'native': args.native_receipt}
    for path in refs.values():
        assert path.is_relative_to(WORK / 'evidence') and bench.load(path)['passed'] and not path.is_symlink()
    compiler, cargo, native = (bench.load(refs[name]) for name in ('compiler', 'cargo', 'native'))
    sysroot = Path(compiler['toolchain']['path'])
    installed = Path(cargo['cargo']['path'])
    assert installed == sysroot / 'bin/cargo'
    expected = bench.toolchain_snapshot(sysroot, installed)
    destination.mkdir()
    evidence.mkdir()
    result = {'passed': False, 'started': time.time(), 'script_sha256': bench.digest(__file__),
              'prior_preparation_sha256': PREVIOUS_SHA, 'sources': {}, 'source_originals_unchanged': False}
    result_path = evidence / 'result.json'
    bench.save(result_path, result)
    try:
        for project in ('ruff', 'uv'):
            source = Path(previous['sources'][project]['path'])
            assert source == WORK.parent / 'readiness/current-cargo-sources' / project
            assert source.resolve() == source and bench.output(['git', 'rev-parse', '--show-toplevel'], source) == str(source)
            assert bench.output(['git', 'config', 'user.email'], source) == 'charlie.r.marsh@gmail.com'
            ignored = subprocess.check_output(['git', 'ls-files', '--others', '--ignored', '--exclude-standard', '-z'], cwd=source).decode().split('\0')
            assert not any(name and ('.cargo' in Path(name).parts or Path(name).name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain', 'rust-toolchain.toml')) for name in ignored)
            before = check_previous(source, previous['sources'][project])
            patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=source)
            target = destination / project
            run(['git', 'clone', '--shared', '--no-checkout', source, target])
            run(['git', 'config', '--local', 'user.name', bench.output(['git', 'config', 'user.name'], source)], target)
            run(['git', 'config', '--local', 'user.email', 'charlie.r.marsh@gmail.com'], target)
            assert bench.output(['git', 'config', 'user.email'], target) == 'charlie.r.marsh@gmail.com'
            run(['git', 'checkout', '--detach', before['head']], target)
            run(['git', 'apply', '--binary', '-'], target, patch)
            after = bench.source_snapshot(target)
            assert after == before and bench.source_snapshot(source) == before
            bench.save(evidence / f'{project}-source.json', after)
            result['sources'][project] = {'path': str(target), **{k: v for k, v in after.items() if k != 'files'}}
            bench.budget()
        result['source_originals_unchanged'] = True
        result['passed'] = True
    except BaseException as error:
        result['error'] = repr(error)
        raise
    finally:
        result['finished'] = time.time()
        bench.save(result_path, result)
    refs['source_preparation'] = result_path
    admission = {'schema': 1, 'passed': True, 'script_sha256': bench.digest(LOCAL / 'harness/benchmark_compatibility.py'),
                 'production_pgo_bolt': False, 'native_toolchain_matches': True,
                 'receipts': {name: {'path': str(path), 'sha256': bench.digest(path)} for name, path in refs.items()},
                 'sources_runtime': {'rust': {'base': compiler['base'], 'patch_sha256': compiler['patch_sha256']},
                                     'cargo': {'base': cargo['base'], 'patch_sha256': cargo['patch_sha256']},
                                     'wild': compiler['wild_source']},
                 'toolchain': expected, 'sources': result['sources']}
    bench.validate_receipts(admission, expected)
    bench.save(evidence / 'admission.json', admission)
    print(json.dumps({'passed': True, 'admission': str(evidence / 'admission.json'), 'source_files': sum(len(bench.load(evidence / f'{project}-source.json')['files']) for project in ('ruff', 'uv'))}))


if __name__ == '__main__':
    main()
