from pathlib import Path
import hashlib,json,time
W=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility');E=W/'evidence';D=E/'native-v1'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
assert not D.exists()
paths={n:E/n/'result.json' for n in ('compiler-v3','cargo-v2','rust-suites-v1','native-supplement-v1','cargo-policy-v1','lld-assembly-v1')}
r={n:load(p) for n,p in paths.items()};assert all(x['passed'] for x in r.values())
cargo=r['cargo-v2'];compiler=r['compiler-v3'];policy=r['cargo-policy-v1'];supp=r['native-supplement-v1'];suites=r['rust-suites-v1']
assert cargo['compiler_build_sha256']==policy['compiler_build_sha256']==suites['compiler_build_sha256']==sha(paths['compiler-v3'])
assert policy['cargo_build_sha256']==sha(paths['cargo-v2']) and policy['lld_assembly_sha256']==sha(paths['lld-assembly-v1'])
assert compiler['patch_sha256']=='4790daedc77c40dc4dc3a0f1789a9579d6aee773b88f4ec968e2884ef42fcc49'
assert cargo['patch_sha256']=='20b9d1fdf46667b3f65bbcba67bf7358acaeb4653b6df1fd05ed431f46172872'
assert len(suites['commands'])==3 and all(row['code']==0 for row in suites['commands'])
assert {x['suite'] for x in suites['commands']}=={'compact-artifact-exports','public-api-hash-artifact','compact-artifact-lto-dwarf'}
assert suites['test_payload_sha256']=='e82105923e1c13d6a7e58b567a3b3e569c25e37f44dd158a51ef840bf155bfeb'
assert suites['toolchain']==compiler['toolchain']
for row in suites['commands']:
 p=paths['rust-suites-v1'].parent/(row['suite']+'.log');assert sha(p)==row['log_sha256'];assert '1 passed; 0 failed; 0 ignored;' in p.read_text()
assert supp['script_sha256']=='adca50008d76ef545e486fb5bb05faf07159915ac856b8f68b85d08a30f26df9'
assert policy['script_sha256']=='52a64ef736cc9a3a438fd34ee6caca0380c8123d87c7af48bcd38f0a209e7e25'
assert supp['sysroot']==compiler['toolchain']['path']
sysroot=Path(supp['sysroot']);tc=compiler['toolchain']
assert supp['protected'][str(sysroot/'bin/rustc')]==tc['rustc_sha256']
assert supp['protected'][str(sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')]==tc['wild_sha256']
for name,h in tc['drivers'].items():assert supp['protected'][str(sysroot/'lib'/name)]==h
assert len(supp['cases'])==6 and all(row['passed'] for row in supp['cases']) and supp['protected_unchanged']
for row in supp['commands']:
 p=Path(row['path']);assert p.is_relative_to(E/'native-supplement-v1') and sha(p)==row['sha256'];actual=load(p);assert actual['code']==row['code']
assert len([x for x in supp['commands'] if x['label'].startswith('before-') and x['code']!=0])==2
assert policy['toolchain_unchanged'] and len(policy['records'])==32 and all(row['passed'] for row in policy['records'])
for row in policy['records']:
 for ext in ('stdout','stderr'):
  p=E/'cargo-policy-v1'/(row['label']+'.'+ext);assert sha(p)==row[ext+'_sha256']
 if row['argv_log_sha256']:assert sha(E/'cargo-policy-v1'/(row['label']+'.argv.jsonl'))==row['argv_log_sha256']
 assert row['returncode']==row['expected_status'] and row['scratch_cleanup']['passed'] and not row['scratch_cleanup']['leftovers']
for proof in (compiler,cargo):
 for k in ('path','rustc_sha256','rustdoc_sha256','drivers','wild_sha256','marker'):assert proof['toolchain'][k]==policy['toolchain'][k]
assert cargo['cargo']['sha256']==policy['toolchain']['cargo_sha256']
result={'passed':True,'scope':'Native compatibility correctness for this exact compiler/Cargo/Wild; non-PGO assembled prefix, not full production release.','compiler_build_sha256':sha(paths['compiler-v3']),'cargo_build_sha256':sha(paths['cargo-v2']),'toolchain':policy['toolchain'],'components':{n:{'path':str(p),'sha256':sha(p)} for n,p in paths.items()},'counts':{'forced_rust_suites':3,'compiler_positive_cases':6,'compiler_old_rejections':2,'compiler_command_records':len(supp['commands']),'cargo_command_records':len(policy['records'])},'finished':time.time()}
D.mkdir();(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
