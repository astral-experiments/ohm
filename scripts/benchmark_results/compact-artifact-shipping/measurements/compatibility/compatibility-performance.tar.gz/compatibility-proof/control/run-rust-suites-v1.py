from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,time
ROOT=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=ROOT/'shipping/compatibility';INPUTS=WORK/'inputs';E=WORK/'evidence/rust-suites-v1';SOURCE=WORK/'compiler/rust';TARGET=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility/bootstrap');HOST='x86_64-unknown-linux-gnu'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
build_path=WORK/'evidence/compiler-v3/result.json';build=json.loads(build_path.read_text());assert build['passed'] and build['patch_sha256']=='4790daedc77c40dc4dc3a0f1789a9579d6aee773b88f4ec968e2884ef42fcc49'
assert not E.exists();E.mkdir();payload=INPUTS/'compiler-tests-v1.tar.gz';assert sha(payload)=='e82105923e1c13d6a7e58b567a3b3e569c25e37f44dd158a51ef840bf155bfeb'
manifest=json.loads((INPUTS/'compiler-tests-v1.json').read_text())
with tarfile.open(payload) as tf:
 members=tf.getmembers();assert {m.name for m in members if m.isfile()}=={r['path'] for r in manifest}
 for m in members:
  assert not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,m.name
  if m.isfile():assert not (SOURCE/m.name).exists(),m.name
 tf.extractall(SOURCE,filter='data')
for row in manifest:assert sha(SOURCE/row['path'])==row['sha256'] and (SOURCE/row['path']).stat().st_size==row['bytes']
paths=[SOURCE/'compiler/rustc_codegen_ssa/src/back/link/compact_artifacts.rs',*list((TARGET/HOST/'stage1/lib').glob('librustc_driver*.so')),*list((Path(build['toolchain']['path'])/'lib').glob('librustc_driver*.so'))]
protected={str(p):sha(p) for p in paths}
r={'passed':False,'compiler_build_sha256':sha(build_path),'patch_sha256':build['patch_sha256'],'toolchain':build['toolchain'],'test_payload_sha256':sha(payload),'test_files':manifest,'started':time.time(),'commands':[],'protected_before':protected}
put(E/'result.json',r)
env={k:v for k,v in os.environ.items() if not k.startswith(('RUSTFLAGS','RUSTC','RUSTDOC','CARGO_PROFILE_','CARGO_TARGET_','CARGO_UNSTABLE_','CARGO_ENCODED_','CARGO_BUILD_','RUSTUP_TOOLCHAIN'))};env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='12')
common=['--stage','1','--set','build.submodules=false','--set',f'target.{HOST}.ohm-wild-linker={ROOT}/shipping/final-review/bounds-fix/wild-release','--force-rerun']
try:
 for suite in ('compact-artifact-exports','public-api-hash-artifact','compact-artifact-lto-dwarf'):
  argv=['python3','x.py','test',*common,'tests/run-make/'+suite];row={'suite':suite,'argv':argv,'started':time.time()};r['commands'].append(row);r['phase']=suite;put(E/'result.json',r)
  assert shutil.disk_usage(WORK).free>=60*1024**3
  with (E/(suite+'.log')).open('w') as f:p=subprocess.run(argv,cwd=SOURCE,env=env,stdout=f,stderr=subprocess.STDOUT)
  row.update(code=p.returncode,seconds=time.time()-row['started'],log_sha256=sha(E/(suite+'.log')));put(E/'result.json',r);print(json.dumps(row),flush=True)
  assert p.returncode==0,suite
 r['protected_after']={p:sha(Path(p)) for p in protected};assert r['protected_after']==protected
 r['passed']=True;r['phase']='passed-three-forced-suites'
except BaseException as error:r['error']=repr(error);raise
finally:r['finished']=time.time();put(E/'result.json',r)
