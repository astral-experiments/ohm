"""Seal complete compatibility receipts after the fixed90-command run; no builds."""
from pathlib import Path
import hashlib,json,os,subprocess,time
W=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility');E=W/'evidence';M=E/'performance-v1'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
status=load(M/'status.json');assert status['passed'] and status['samples']==status['accepted']==90 and status['source_and_toolchain_unchanged']
assert not (M/'failure.json').exists() and not (M/'interrupted.json').exists()
rows=[json.loads(x) for x in (M/'samples.jsonl').read_text().splitlines()];assert len(rows)==90 and all(r['accepted'] for r in rows)
assert len({(r['project'],r['mode'],r['round'],r['phase'],tuple(r['state'])) for r in rows})==90
p=load(M/'provenance.json');a=p['admission'];assert sha(E/'performance-preparation/admission.json')==p['admission_sha256'] and load(E/'performance-preparation/admission.json')==a
assert p['script_sha256']==a['script_sha256']=='3b159d45e51aa6e46679293b06c020947e5f2cf4b92c4117c195501117039e1f'
for ref in a['receipts'].values():
 path=Path(ref['path']);assert path.resolve()==path and path.is_relative_to(E) and not path.is_symlink() and sha(path)==ref['sha256'] and load(path)['passed']
t=a['toolchain'];s=Path(t['sysroot']);assert s.resolve()==s and s.is_relative_to(W/'toolchains') and not s.is_symlink()
assert Path(t['cargo'])==s/'bin/cargo' and Path(t['cargo']).resolve()==Path(t['cargo'])
for path,h in [(s/'bin/rustc',t['rustc_sha256']),(s/'bin/rustdoc',t['rustdoc_sha256']),(Path(t['cargo']),t['cargo_sha256']),(s/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd',t['wild_sha256']),(s/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/compact-artifacts-v2',t['marker_sha256'])]:assert sha(path)==h,str(path)
for name,h in t['drivers'].items():assert sha(s/'lib'/name)==h,name
for project in ('ruff','uv'):
 assert load(M/(project+'-source-before.json'))==load(M/(project+'-source-after.json'))
assert len(p['plan'])==10 and len({(x['project'],x['mode'],x['round']) for x in p['plan']})==10
for cell in p['plan']:
 lane=Path(cell['lane']);assert lane.resolve()==lane and not lane.exists() and lane.is_relative_to(Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility/performance-v1'))
 cleanup=load(M/(cell['project']+'-'+cell['mode']+'-'+str(cell['round']))/'cleanup.json');assert cleanup['passed'] and cleanup['source_restored'] and cleanup['last_sample_accepted'] and cleanup['path']==str(lane)
assert not (W/'collection-v1.json').exists()
files=[]
for name in ('evidence','inputs','control','harness'):
 root=W/name;assert root.is_dir() and not root.is_symlink(),root
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink(),path
  if path.is_file():files.append({'path':str(path.relative_to(W)),'bytes':path.stat().st_size,'sha256':sha(path)})
manifest={'schema':1,'passed':True,'scope':'All compatibility evidence/inputs/stagedcontrols/harness files after90 accepted commands, before any test-only follow-up; no timing binaries changed.','counts':{'commands':90,'accepted':90,'excluded':0},'status_sha256':sha(M/'status.json'),'samples_sha256':sha(M/'samples.jsonl'),'provenance_sha256':sha(M/'provenance.json'),'admission_sha256':sha(E/'performance-preparation/admission.json'),'file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),'files':files,'excluded_self':'collection-v1.json','finished':time.time()}
(W/'collection-v1.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))
