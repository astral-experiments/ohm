"""Supplement run-make coverage with direct Wild DWARF and actual LLVM23 plugin linking."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

HOST = 'x86_64-unknown-linux-gnu'
WORK = Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility')
TARGET = Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility')
DEP = '#[inline(never)] pub fn dependency_value(value: u32) -> u32 { std::hint::black_box(value + 1) }\n'
MAIN = '''extern crate dep;
#[inline(never)] fn application_value(value: u32) -> u32 { dep::dependency_value(value) }
fn main() {
    let input = if cfg!(changed) { 42 } else { 41 };
    let output = application_value(input);
    assert_eq!(output, input + 1);
    println!("{output}");
}
'''
STANDALONE = '#[inline(never)] fn replay_value(x: u32) -> u32 { std::hint::black_box(x + 1) }\nfn main() { assert_eq!(replay_value(41), 42); println!("42"); }\n'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sysroot', type=Path, required=True)
    parser.add_argument('--before-sysroot', type=Path, required=True)
    parser.add_argument('--llvm-bin', type=Path, required=True)
    parser.add_argument('--clang', type=Path, required=True)
    parser.add_argument('--gdb', type=Path, required=True)
    parser.add_argument('--target', type=Path, default=TARGET / 'native-supplement-v1')
    parser.add_argument('--evidence', type=Path, default=WORK / 'evidence/native-supplement-v1')
    args = parser.parse_args()
    assert args.sysroot.is_relative_to(WORK / 'toolchains')
    assert args.target.resolve() == args.target and args.target.is_relative_to(TARGET) and args.target != TARGET and not args.target.exists()
    assert args.evidence.resolve() == args.evidence and args.evidence.is_relative_to(WORK / 'evidence') and not args.evidence.exists()
    assert (TARGET / '.owned').is_file() and (WORK / '.owned').is_file()
    assert shutil.disk_usage(TARGET).free >= 60 * 1024**3
    rustc = args.sysroot / 'bin/rustc'
    before = args.before_sysroot / 'bin/rustc'
    wild_dir = args.sysroot / 'lib/rustlib' / HOST / 'bin/wild-ld'
    assert (wild_dir / 'compact-artifacts-v2').read_bytes() == b'RCOBJ001\n'
    tools = {name: args.llvm_bin / name for name in ('llvm-ar', 'llvm-dwarfdump', 'llvm-bcanalyzer', 'lld', 'llvm-config')}
    for path in (*tools.values(), rustc, before, args.clang, args.gdb):
        assert path.is_file(), path
    protected = {str(path): sha(path) for path in (*tools.values(), rustc, before, args.clang, args.gdb, wild_dir / 'ld.bfd')}
    for root in (args.sysroot, args.before_sysroot):
        protected.update({str(path): sha(path) for path in (root / 'lib').glob('librustc_driver*.so')})
    args.target.mkdir()
    args.evidence.mkdir()
    (args.target / 'scratch').mkdir()
    (args.target / '.owned').write_text('native compiler compatibility supplement\n')
    result = {'passed': False, 'script_sha256': sha(Path(__file__)), 'sysroot': str(args.sysroot),
              'before_sysroot': str(args.before_sysroot), 'protected': protected, 'commands': [], 'cases': [],
              'scope': 'Direct Wild debug-consumer and raw LLVM plugin runtime supplement; no performance measurement.', 'started': time.time()}
    env = {k: v for k, v in os.environ.items() if not k.startswith(('RUSTFLAGS', 'RUSTC_LOG', 'CARGO_ENCODED_RUSTFLAGS'))}
    env['TMPDIR'] = str(args.target / 'scratch')

    def run(label, argv, cwd, expected=0):
        assert shutil.disk_usage(TARGET).free >= 60 * 1024**3
        argv = list(map(str, argv))
        proc = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=180)
        record = {'label': label, 'argv': argv, 'cwd': str(cwd), 'code': proc.returncode,
                  'stdout': proc.stdout, 'stderr': proc.stderr}
        path = args.evidence / f'{len(result["commands"]):03}-{label}.json'
        save(path, record)
        result['commands'].append({'path': str(path), 'sha256': sha(path), 'label': label, 'code': proc.returncode})
        save(args.evidence / 'result.json', result)
        assert (proc.returncode == expected if expected is not None else proc.returncode != 0), record
        return proc

    def cache_links(directory, destination):
        destination.mkdir()
        entries = []
        for index, path in enumerate(sorted(directory.rglob('*.o'))):
            assert path.read_bytes().startswith(b'RCOBJ001'), path
            retained = destination / f'{index}.o'
            os.link(path, retained)
            entries.append({'path': str(retained), 'sha256': sha(retained), 'inode': retained.stat().st_ino})
        assert entries, directory
        return entries

    def assert_cache(entries):
        assert all(Path(row['path']).stat().st_ino == row['inode'] and sha(Path(row['path'])) == row['sha256'] for row in entries)

    def run_app(label, directory, expected):
        value = run(label, [directory / 'app'], directory)
        assert value.stdout == f'{expected}\n', value

    def inspect_debug(label, directory, packaging, kind, expected):
        if packaging == 'packed':
            dwp = directory / 'app.dwp'
            run(label + '-verify', [tools['llvm-dwarfdump'], '--verify', dwp], directory)
            info = run(label + '-info', [tools['llvm-dwarfdump'], '--debug-info', dwp], directory).stdout
            assert 'dependency_value' in info and 'application_value' in info
        else:
            suffix = '*.rcgu.o' if kind == 'single' else '*.rcgu.dwo'
            paths = sorted(directory.glob(suffix))
            assert paths
            assert all(path.read_bytes().startswith(b'\x7fELF') for path in paths)
            info = run(label + '-info', [tools['llvm-dwarfdump'], '--debug-info', *paths], directory).stdout
            assert 'application_value' in info
        gdb = run(label + '-gdb', [args.gdb, '-nx', '--batch', '-ex', 'set pagination off',
                                  '-ex', 'break dep::dependency_value', '-ex', 'run', '-ex', 'info args',
                                  '-ex', 'info line', directory / 'app'], directory)
        assert re.search(r'\bvalue\s*=\s*' + str(expected - 1) + r'\b', gdb.stdout), gdb
        assert 'dep.rs' in gdb.stdout and 'Line ' in gdb.stdout, gdb
        assert 'Could not find DWO' not in gdb.stderr and 'Could not find DWO' not in gdb.stdout

    try:
        version = run('rustc-version', [rustc, '-vV'], args.target).stdout
        llvm = run('llvm-version', [tools['llvm-config'], '--version'], args.target).stdout.strip()
        assert 'LLVM version: 23.' in version and llvm.startswith('23.'), (version, llvm)
        run('gdb-version', [args.gdb, '--version'], args.target)
        run('clang-version', [args.clang, '--version'], args.target)
        wild_flags = ['-Clinker-features=-lld', '-Clink-self-contained=-linker',
                      f'-Clink-arg=-B{wild_dir}', '-Clink-arg=-fuse-ld=bfd', '-Zcompact-artifacts-linker=yes']
        for packaging in ('packed', 'unpacked'):
            for kind in ('split', 'single'):
                name = f'wild-{packaging}-{kind}'
                directory = args.target / name
                directory.mkdir()
                (directory / 'dep.rs').write_text(DEP)
                (directory / 'main.rs').write_text(MAIN)
                producer = directory / 'producer'
                producer.mkdir()
                debug = ['-Cdebuginfo=2', f'-Csplit-debuginfo={packaging}', f'-Zsplit-dwarf-kind={kind}']
                run(name + '-dep', [rustc, 'dep.rs', '--crate-type=rlib', '-Zcompact-artifacts', *debug,
                                   '-o', producer / 'libdep.rlib'], directory)
                dependency = producer / 'libdep.rlib'
                if packaging == 'packed':
                    shutil.copy2(dependency, directory / 'libdep.rlib')
                    shutil.rmtree(producer)
                    dependency = directory / 'libdep.rlib'
                dependency_hash = sha(dependency)
                retained = []
                for round_, changed in enumerate((False, True, True)):
                    label = f'{name}-{round_}'
                    command = [rustc, 'main.rs', '--extern', f'dep={dependency}', '-o', 'app',
                               '-Zcompact-artifacts', '-Cincremental=incr', *debug, *wild_flags]
                    if changed:
                        command += ['--cfg', 'changed']
                    run(label + '-build', command, directory)
                    run_app(label + '-run', directory, 43 if changed else 42)
                    inspect_debug(label, directory, packaging, kind, 43 if changed else 42)
                    comment = run(label + '-linker', ['readelf', '--string-dump=.comment', 'app'], directory).stdout
                    assert 'Wild' in comment
                    if not retained:
                        retained = cache_links(directory / 'incr', directory / 'retained-cache')
                    assert_cache(retained)
                    assert sha(dependency) == dependency_hash
                result['cases'].append({'name': name, 'passed': True, 'rounds': 3, 'dependency_sha256': dependency_hash,
                                        'retained_cache': retained, 'gdb_argument_source_lookup': True})

        directory = args.target / 'packed-replay'
        directory.mkdir()
        (directory / 'standalone.rs').write_text(STANDALONE)
        debug = ['-Cdebuginfo=2', '-Csplit-debuginfo=packed', '-Zsplit-dwarf-kind=single']
        run('replay-prepare', [rustc, 'standalone.rs', '-o', 'app', '-Zcompact-artifacts', '-Zno-link',
                               '-Cincremental=incr', *debug, *wild_flags], directory)
        recipes = list(directory.glob('*.rlink'))
        assert len(recipes) == 1
        retained = cache_links(directory / 'incr', directory / 'retained-cache')
        run('replay-bfd', [rustc, recipes[0], '-Zlink-only', '-Clinker-features=-lld', *debug], directory)
        run_app('replay-run', directory, 42)
        run('replay-dwp', [tools['llvm-dwarfdump'], '--verify', directory / 'app.dwp'], directory)
        assert_cache(retained)
        result['cases'].append({'name': 'packed-compact-recipe-ordinary-bfd', 'passed': True, 'retained_cache': retained})

        directory = args.target / 'plugin'
        directory.mkdir()
        (directory / 'dep.rs').write_text(DEP)
        (directory / 'main.rs').write_text(MAIN)
        lld = directory / 'ld.lld'
        lld.symlink_to(tools['lld'])
        run('lld-version', [lld, '--version'], directory)
        plugin_flags = ['-Clinker-plugin-lto', f'-Clinker={args.clang}', f'-Clink-arg=-fuse-ld={lld}',
                        '-Clinker-features=-lld', '-Clink-self-contained=-linker']
        retained_ir = []
        for round_, changed in enumerate((False, True, True)):
            run(f'plugin-dep-{round_}', [rustc, 'dep.rs', '--crate-type=rlib', '-Zcompact-artifacts',
                                       '-Clinker-plugin-lto', '-Cincremental=dep-incr'], directory)
            members = run(f'plugin-members-{round_}', [tools['llvm-ar'], 't', 'libdep.rlib'], directory).stdout.splitlines()
            assert any(name.endswith('.o') for name in members)
            for index, member in enumerate(name for name in members if name.endswith('.o')):
                data = subprocess.check_output([tools['llvm-ar'], 'p', 'libdep.rlib', member], cwd=directory)
                assert data.startswith((b'BC\xc0\xde', b'\xde\xc0\x17\x0b'))
                path = directory / f'dep-{index}.bc'
                path.write_bytes(data)
                run(f'plugin-ir-{round_}-{index}', [tools['llvm-bcanalyzer'], path], directory)
            command = [rustc, 'main.rs', '--extern', 'dep=libdep.rlib', '-o', 'app', '-Zcompact-artifacts',
                       '-Cincremental=main-incr', *plugin_flags]
            if changed:
                command += ['--cfg', 'changed']
            run(f'plugin-main-{round_}', command, directory)
            run_app(f'plugin-run-{round_}', directory, 43 if changed else 42)
            comment = run(f'plugin-linker-{round_}', ['readelf', '--string-dump=.comment', 'app'], directory).stdout
            assert 'LLD 23.' in comment
            if not retained_ir:
                retained = directory / 'retained-ir'
                retained.mkdir()
                for index, path in enumerate(sorted(directory.glob('*-incr/**/*.o'))):
                    assert path.read_bytes().startswith((b'BC\xc0\xde', b'\xde\xc0\x17\x0b'))
                    target = retained / f'{index}.o'
                    os.link(path, target)
                    retained_ir.append({'path': str(target), 'sha256': sha(target), 'inode': target.stat().st_ino})
                assert retained_ir
            assert_cache(retained_ir)
        result['cases'].append({'name': 'actual-llvm23-plugin-link', 'passed': True, 'rounds': 3, 'retained_raw_ir': retained_ir})

        directory = args.target / 'before'
        directory.mkdir()
        (directory / 'standalone.rs').write_text(STANDALONE)
        for label, flags, diagnostic in [('packed', ['-Cdebuginfo=2', '-Csplit-debuginfo=packed'], 'compact artifacts do not support `-Csplit-debuginfo=packed`'),
                                         ('plugin', ['--crate-type=rlib', '-Clinker-plugin-lto'], 'compact artifacts require cross-crate LTO to be disabled')]:
            failed = run('before-' + label, [before, 'standalone.rs', '-Zcompact-artifacts', *flags], directory, expected=None)
            assert diagnostic in failed.stderr
            assert 'internal compiler error' not in failed.stderr
        assert all(sha(Path(path)) == value for path, value in protected.items())
        result['protected_unchanged'] = True
        result['passed'] = True
    except BaseException as error:
        result['error'] = repr(error)
        raise
    finally:
        result['finished'] = time.time()
        save(args.evidence / 'result.json', result)
    print(json.dumps({'passed': result['passed'], 'cases': len(result['cases']), 'commands': len(result['commands']), 'evidence': str(args.evidence)}))


if __name__ == '__main__':
    main()
