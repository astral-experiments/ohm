"""Build the frozen compatibility Cargo and focused tests without changing prior binaries."""
from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time
ROOT=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=ROOT/'shipping/compatibility';INPUTS=WORK/'inputs';EVIDENCE=WORK/'evidence/cargo-v2'
SOURCE=WORK/'cargo';TARGET_ROOT=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility');TARGET=TARGET_ROOT/'cargo'
DONOR=ROOT/'shipping/readiness/final-cargo-current/source';CACHE=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/final-cargo-current/build/release')
BASE='6333daf7cf99cf80125234c9419cbd36e9bff81a';PATCH='20b9d1fdf46667b3f65bbcba67bf7358acaeb4653b6df1fd05ed431f46172872';HOST='x86_64-unknown-linux-gnu'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def output(a,cwd=None):return subprocess.check_output(list(map(str,a)),cwd=cwd,text=True).strip()
def load(p):return json.loads(p.read_text())
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def budget():
 free=shutil.disk_usage(WORK).free;used=sum(int(output(['du','-s','-B1',p]).split()[0]) for p in (WORK,TARGET_ROOT))
 assert free>=60*1024**3 and used<=40*1024**3,(free,used)
 return {'free':free,'owned_allocated':used}
manifest=load(INPUTS/'cargo-v2-manifest.json');assert manifest['base']==BASE and manifest['patch_sha256']==PATCH==sha(INPUTS/'cargo-v2.patch')
build_path=WORK/'evidence/compiler-v3/result.json';build=load(build_path);assert build['passed'] and build['patch_sha256']=='4790daedc77c40dc4dc3a0f1789a9579d6aee773b88f4ec968e2884ef42fcc49'
sysroot=Path(build['toolchain']['path']);assert sysroot==WORK/'toolchains/compiler-v3'
old_path=WORK/'evidence/cargo-v1/result.json';old=load(old_path)
assert not old['passed'] and old['phase']=='routing-suite' and old['commands'][-1]['code']==101
assert SOURCE.is_dir() and TARGET.is_dir() and not EVIDENCE.exists();EVIDENCE.mkdir()
assert output(['git','rev-parse','HEAD'],SOURCE)==BASE and output(['git','config','user.email'],SOURCE)=='charlie.r.marsh@gmail.com'
previous=load(INPUTS/'cargo-final-manifest.json')
assert previous['patch_sha256']=='d6a881ad11cb0f3ffe2bd774c4fcb37da1ae076ec6ec3c154ce269c417affe03'==sha(INPUTS/'cargo-final.patch')
for row in previous['files']:assert sha(SOURCE/row['path'])==row['sha256'],row['path']
assert sha(WORK/'retained/cargo-d6/cargo')==old['cargo']['sha256']==sha(Path(old['cargo']['path']))
protected=load(WORK/'evidence/cargo-v1/protected-before.json');protected[str(WORK/'retained/cargo-d6/cargo')]=old['cargo']['sha256']
receipt={'passed':False,'scope':'Frozen Cargo build and required focused routing/provenance/wrapper checks; actual policy smoke is a separate receipt.','base':BASE,'patch_sha256':PATCH,'manifest_sha256':sha(INPUTS/'cargo-v2-manifest.json'),'compiler_build_sha256':sha(build_path),'source':str(SOURCE),'target':str(TARGET),'started':time.time(),'commands':[],'budget':budget(),'protected_files':len(protected),'prior_failed_receipt_sha256':sha(old_path)}
put(EVIDENCE/'protected-before.json',protected)
def save():put(EVIDENCE/'result.json',receipt)
def run(name,args,cwd=SOURCE,extra=None,allowed=(0,)):
 row={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'environment_overrides':extra or {},'started':time.time()};receipt['commands'].append(row);receipt['phase']=name;save()
 with (EVIDENCE/(name+'.log')).open('w') as log:
  p=subprocess.Popen(row['argv'],cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   next_budget=time.time()+30
   while p.poll() is None:
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
    assert shutil.disk_usage(WORK).free>=60*1024**3
    if time.time()>=next_budget:budget();next_budget=time.time()+30
  except BaseException:
   if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait()
   raise
  finally:row.update(code=p.returncode,seconds=time.time()-row['started'],log_sha256=sha(EVIDENCE/(name+'.log')));save()
 assert p.returncode in allowed,(name,p.returncode)
 receipt['budget']=budget();save();print(json.dumps({'name':name,'code':p.returncode,'seconds':row['seconds']}),flush=True)
 return row

env={k:v for k,v in os.environ.items() if not k.startswith(('RUST','CARGO_'))};env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='8',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
try:
 run('reverse-prior-check',['git','apply','--reverse','--check',INPUTS/'cargo-final.patch'])
 run('reverse-prior',['git','apply','--reverse',INPUTS/'cargo-final.patch'])
 run('patch-check',['git','apply','--check',INPUTS/'cargo-v2.patch']);run('patch',['git','apply',INPUTS/'cargo-v2.patch'])
 for r in manifest['files']:assert (SOURCE/r['path']).stat().st_size==r['bytes'] and sha(SOURCE/r['path'])==r['sha256'],r['path']
 assert set(output(['git','diff','--name-only'],SOURCE).splitlines())=={r['path'] for r in manifest['files']}
 put(EVIDENCE/'source-files.json',{'base':BASE,'patch_sha256':PATCH,'files':manifest['files']});receipt['source_manifest_sha256']=sha(EVIDENCE/'source-files.json')
 before=sha(SOURCE/'build.rs');os.utime(SOURCE/'build.rs',None);assert sha(SOURCE/'build.rs')==before
 receipt['build_compiler']={'version':output(['rustc','+ohm','-vV']),'path':output(['rustup','which','--toolchain','ohm','rustc'])};save()
 common=['cargo','+ohm','-Zohm-defaults=no']
 run('release-build',[*common,'build','--locked','--offline','--release','--features','ohm-defaults','--bin','cargo'])
 cargo=sysroot/'bin/cargo';assert sha(cargo)==old['cargo']['sha256'];shutil.copy2(TARGET/'release/cargo',cargo)
 receipt['cargo']={'path':str(cargo),'sha256':sha(cargo),'version':output([cargo,'-vV'])};receipt['toolchain']={**build['toolchain'],'cargo_sha256':sha(cargo)};save()
 checks=[('selection-units',['test','--locked','--offline','-p','cargo','--features','ohm-defaults','--lib','ohm_linker','-j8']),('provenance-units',['test','--locked','--offline','-p','cargo','--features','ohm-defaults','--lib','bundled_linker_provenance','-j8']),('wrapper-range',['test','--locked','--offline','-p','cargo-util','--lib','removing_generated_range','-j8']),('routing-suite',['test','--locked','--offline','-p','cargo','--features','ohm-defaults','--test','testsuite','ohm_linker','-j8','--','--test-threads=1'])]
 for name,args in checks:run(name,[*common,*args])
 additional=run('additional-inherited-dylib-test',[*common,'test','--locked','--offline','-p','cargo','--features','ohm-defaults','--test','testsuite','build::embed_metadata_no_dylib_dep','-j8','--','--exact','--test-threads=1'],allowed=(0,101))
 if additional['code']==101:
  diagnostic=(EVIDENCE/'additional-inherited-dylib-test.log').read_text()
  assert all(text in diagnostic for text in ('Could not find expected line in output.', 'Without contents:', '-Z embed-metadata=no', '[FINISHED]', '--crate-name bar')), 'Unexpected inherited-test failure signature'
  assert not any(text in diagnostic for text in ('internal compiler error:', 'error[E', 'could not compile')), 'Unexpected compiler failure in inherited test'
 receipt['additional_inherited_dylib_check']={'code':additional['code'],'scope':'Retained separately from required routing checks; any failure must be assessed against actual base6333 fixture before interpretation.'}
 changed=[p for p,h in protected.items() if not Path(p).is_file() or sha(Path(p))!=h];put(EVIDENCE/'protected-after.json',{'passed':not changed,'changed':changed,'files':len(protected)});assert not changed,changed[:10]
 for r in manifest['files']:assert sha(SOURCE/r['path'])==r['sha256'],r['path']
 receipt['passed']=True;receipt['phase']='ready-for-native-policy-proof'
except BaseException as e:receipt['error']=repr(e);raise
finally:receipt['finished']=time.time();save()
