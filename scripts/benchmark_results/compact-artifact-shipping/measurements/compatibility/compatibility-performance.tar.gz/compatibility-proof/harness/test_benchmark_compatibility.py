"""Small local controls for the new schedule and logged format-admission contracts."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('bench', Path(__file__).with_name('benchmark_compatibility.py'))
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)


class Controls(unittest.TestCase):
    def test_two_fresh_rounds_and_only_existing_real_edits(self):
        commands = [(project, round_, mode, phase, state)
                    for project, orders in bench.ORDERS.items()
                    for round_, modes in enumerate(orders) for mode in modes
                    for phase, state in bench.sequence()]
        self.assertEqual(len(commands), 90)
        self.assertEqual(len(set(commands)), 90)
        self.assertEqual(sum(mode != 'adapter' for _, _, mode, _, _ in commands), 72)
        self.assertTrue(all(project == 'ruff' for project, _, mode, _, _ in commands if mode == 'adapter'))
        self.assertTrue(all(state[0] == 0 for *_, state in commands))
        for orders in bench.ORDERS.values():
            self.assertEqual(tuple(reversed(orders[0])), orders[1])

    def test_replay_is_a_command_and_cannot_pass_as_noop(self):
        rustc = Path('/candidate/bin/rustc')
        replay = 'Running `/candidate/bin/rustc app.rlink -Zlink-only`'
        self.assertEqual(bench.validate_commands(replay, 'off', rustc, 'real-library'), 1)
        with self.assertRaises(AssertionError):
            bench.validate_commands(replay, 'off', rustc, 'noop')

    def test_compact_and_linker_capability_are_separate_contracts(self):
        rustc = Path('/candidate/bin/rustc')
        base = 'Running `/candidate/bin/rustc --crate-name example -Zcompact-artifacts=yes -Zartifact-compression-profile=fast'
        self.assertEqual(bench.validate_commands(base + '`', 'adapter', rustc, 'clean'), 1)
        direct = base + ' -Zcompact-artifacts-linker=yes`'
        self.assertEqual(bench.validate_commands(direct, 'default', rustc, 'clean'), 1)
        for text, mode in [(direct, 'adapter'), (base + '`', 'default'), (direct, 'off'),
                           (base + ' -Z embed-metadata=no`', 'adapter')]:
            with self.assertRaises(AssertionError):
                bench.validate_commands(text, mode, rustc, 'clean')

    def test_snapshot_reads_modified_bytes_and_restored_index(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            bench.output(['git', 'init', '-q'], root)
            # This owned synthetic repository has no commits or network operations.
            bench.output(['git', '-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid',
                          'commit', '--allow-empty', '-qm', 'fixture'], root)
            (root / 'source.rs').write_text('one')
            bench.output(['git', 'add', 'source.rs'], root)
            original = bench.source_snapshot(root)
            (root / 'source.rs').write_text('two')
            changed = bench.source_snapshot(root)
            self.assertEqual(original['head'], changed['head'])
            self.assertEqual(original['index_sha256'], changed['index_sha256'])
            self.assertNotEqual(original['tracked_tree_sha256'], changed['tracked_tree_sha256'])
            (root / 'source.rs').write_text('one')
            self.assertEqual(bench.source_snapshot(root), original)


if __name__ == '__main__':
    unittest.main()
