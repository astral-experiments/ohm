"""Synthetic receipt controls. No compiler execution or measured-result claim."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('summary',Path(__file__).with_name('summarize_compatibility.py'))
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
ORIGINALS=Path(__file__).resolve().parents[1]/'fixtures/source-originals'


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')


def synthetic(root):
    """Build a small wholly synthetic complete90-row record set for verifier controls."""
    matrix=root/'evidence/performance-v1';matrix.mkdir(parents=True)
    budget={'cap':s.CAP,'reserve':s.RESERVE,'free':200*2**30,'owned_allocated':2**30}
    sysroot=str(s.REMOTE/'toolchains/compiler-v3');cargo_path=sysroot+'/bin/cargo';zero='0'*64
    toolchain={'sysroot':sysroot,'cargo':cargo_path,'cargo_sha256':zero,'rustc_sha256':zero,'rustdoc_sha256':zero,'drivers':{'librustc_driver-test.so':zero},'wild_sha256':zero,'marker_sha256':s.hashlib.sha256(b'RCOBJ001\n').hexdigest()}
    tc={'path':sysroot,**{k:toolchain[k] for k in ('cargo_sha256','rustc_sha256','rustdoc_sha256','drivers','wild_sha256')},'marker':{'name':'compact-artifacts-v2','sha256':toolchain['marker_sha256']}}
    sources={}
    for project in s.ORDERS:
        entries=[{'path':str(p.relative_to(ORIGINALS/project)),'mode':'100644','bytes':p.stat().st_size,'sha256':s.digest(p)} for p in sorted((ORIGINALS/project).rglob('*')) if p.is_file()]
        snap={'head':'0'*40,'diff_sha256':zero,'index_sha256':zero,'tracked_tree_sha256':s.hashlib.sha256(json.dumps(entries,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'files':entries}
        save(matrix/f'{project}-source-before.json',snap);save(matrix/f'{project}-source-after.json',snap)
        sources[project]={'path':str(s.REMOTE/'benchmark-sources'/project),**{k:v for k,v in snap.items() if k!='files'}}
    compiler={'passed':True,'base':s.RUST_BASE,'patch_sha256':s.RUST_PATCH,'wild_source':s.WILD,'production_pgo_bolt':False,'toolchain':tc}
    cp=root/'evidence/compiler-v3/result.json';save(cp,compiler)
    cargo={'passed':True,'base':s.CARGO_BASE,'patch_sha256':s.CARGO_PATCH,'compiler_build_sha256':s.digest(cp),'cargo':{'path':cargo_path,'sha256':zero},'toolchain':tc}
    ca=root/'evidence/cargo-v1/result.json';save(ca,cargo)
    components={}
    for name in ('rust-suites-v1','native-supplement-v1','cargo-policy-v1','lld-assembly-v1'):
        path=root/'evidence'/name/'result.json';save(path,{'passed':True})
        components[name]={'path':str(s.REMOTE/path.relative_to(root)),'sha256':s.digest(path)}
    for name,path in [('compiler-v3',cp),('cargo-v1',ca)]:components[name]={'path':str(s.REMOTE/path.relative_to(root)),'sha256':s.digest(path)}
    native={'passed':True,'compiler_build_sha256':s.digest(cp),'cargo_build_sha256':s.digest(ca),'toolchain':tc,'components':components};np=root/'evidence/native-v1/result.json';save(np,native)
    prep={'passed':True,'source_originals_unchanged':True,'sources':sources};pp=root/'evidence/performance-preparation/result.json';save(pp,prep)
    a={'schema':1,'passed':True,'script_sha256':s.HARNESS,'production_pgo_bolt':False,'native_toolchain_matches':True,'toolchain':toolchain,'sources':sources,'sources_runtime':{'rust':{'base':s.RUST_BASE,'patch_sha256':s.RUST_PATCH},'cargo':{'base':s.CARGO_BASE,'patch_sha256':s.CARGO_PATCH},'wild':s.WILD},'receipts':{name:{'path':str(s.REMOTE/path.relative_to(root)),'sha256':s.digest(path)} for name,path in [('compiler',cp),('cargo',ca),('native',np),('source_preparation',pp)]}}
    ap=root/'evidence/performance-preparation/admission.json';save(ap,a)
    p={'script_sha256':s.HARNESS,'reference_sha256':s.REFERENCE,'core_sha256':s.CORE,'format_wrapper_sha256':s.WRAPPER,'counts':{'commands':90,'cells':10,'rounds':2,'commands_per_cell':9},'budget_before':budget,'admission':a,'admission_sha256':s.digest(ap),'toolchain':toolchain,'sources':sources,'plan':[]}
    rows=[]
    p['admission_rules']={'outside_user_cores_threshold':0.5,'reject_at_intervals':3,'unrelated_compilers_allowed':False,'free_reserve_bytes':s.RESERVE,'owned_cap_bytes':s.CAP,'disk_instrumented':False}
    for project,orders in s.ORDERS.items():
        for r,order in enumerate(orders):
            for mode in order:
                lane=s.TARGET/project/f'round-{r}'/mode
                argv=[cargo_path,'-Zohm-defaults=yes']+(['-Zohm-compact-artifacts=no'] if mode=='off' else [])+['build','--offline','--locked','-vv','-p',project,'--bin',project,'-j','8']
                wild=['-Clinker-features=-lld','-Clink-self-contained=-linker',f'-Clink-arg=-B{sysroot}/lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld','-Clink-arg=-fuse-ld=bfd']
                env={'RUSTC':sysroot+'/bin/rustc','RUSTDOC':sysroot+'/bin/rustdoc','CARGO_TARGET_DIR':str(lane/'target'),'CARGO_BUILD_BUILD_DIR':str(lane/'build'),'CARGO_ENCODED_RUSTFLAGS':'\x1f'.join(wild) if mode=='adapter' else '', 'TMPDIR':str(lane/'scratch'),'CARGO_HOME':'/tmp/codex-cargo-home','CARGO_INCREMENTAL':'1','CARGO_BUILD_JOBS':'8','CARGO_PROFILE_DEV_DEBUG':'line-tables-only','CARGO_PROFILE_DEV_BUILD_OVERRIDE_DEBUG':'0','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all'}
                if project=='ruff':env['CARGO_PROFILE_DEV_OPT_LEVEL']='1'
                p['plan'].append({'project':project,'mode':mode,'round':r,'lane':str(lane),'argv':argv,'environment':env})
                for i,(phase,state) in enumerate(s.SEQUENCE):
                    stem=matrix/f'{project}-{mode}-{r}'/f'{i:02}-{phase}';stem.parent.mkdir(parents=True,exist_ok=True)
                    compact=mode!='off';noop=phase.startswith('noop');b=str(lane/'target/debug'/project);cache=str(stem.parent/'cache')
                    cases={'synthetic':{'argv':[b],'code':0,'stdout':'0\n'},'version':{'argv':[b,'--version'],'code':0,'stdout':project+' test\n'},'linker':{'code':0,'stdout':'Linker: Wild'},'direct':{'argv':[b,'--cache-dir',cache],'code':0 if project=='uv' else 2,'stdout':s.UV_DIRECT[state[1]]+cache+'\n' if project=='uv' else '', 'stderr':s.RUFF_DIRECT[state[1]] if project=='ruff' else ''},'library':{'argv':[b,'--no-config','--offline','--color','never','--cache-dir',cache,'pip','install','--no-index','=foo'],'code':2 if project=='uv' else 1,'input':None if project=='uv' else 'def f():\n    x = 1\n','stdout':json.dumps([{'code':'F841','message':s.RUFF_LIBRARY[state[2]].replace('{name}','x'),'location':{'row':2,'column':5}}]) if project=='ruff' else '', 'stderr':s.UV_LIBRARY[state[2]].replace('{char}','=') if project=='uv' else ''}}
                    oracle={'passed':True,'state':list(state),'binary_sha256':zero,'cases':cases}
                    options=' -Zcompact-artifacts=yes -Zartifact-compression-profile=fast' if compact else ''
                    if mode=='default':options+=' -Zcompact-artifacts-linker=yes'
                    log='' if noop else f'Running `{sysroot}/bin/rustc --crate-name {project}{options} src/lib.rs`\n'
                    stem.with_suffix('.log').write_text(log);stem.with_suffix('.time').write_text('User time (seconds): 1\nSystem time (seconds): 0\nMaximum resident set size (kbytes): 1\nExit status: 0\n')
                    save(stem.with_suffix('.monitor.json'),[{'rss':2048,'outside_user_cpu_cores':0,'time':0}]);save(stem.with_suffix('.oracle.json'),oracle)
                    stem.with_suffix('.patch').write_text(json.dumps([project,state]))
                    census={'allocated':4096,'logical':4000,'files':1,'directories':0,'categories':{'.o':{'allocated':4096,'logical':4000,'entries':1}}}
                    row={'project':project,'mode':mode,'round':r,'phase':phase,'state':list(state),'accepted':True,'returncode':0,'argv':argv,'cwd':str(s.REMOTE/'benchmark-sources'/project),'unrelated_compilers':{},'outside_cpu_intervals':[],'disk_reserve_failed':False,'instrumented_disk':False,'sampled_peak_allocated_bytes':None,'budget_before':budget,'budget_after':budget,'effective_free_reserve':budget['free']-(s.CAP-budget['owned_allocated']),'wall_seconds':1+r+(0.1 if compact else 0),'user_seconds':1,'system_seconds':0,'max_child_rss_bytes':1024,'sampled_process_tree_peak_rss_bytes':2048,'log':str(s.REMOTE/'evidence/performance-v1'/stem.relative_to(matrix).with_suffix('.log')),'resources':str(s.REMOTE/'evidence/performance-v1'/stem.relative_to(matrix).with_suffix('.time')),'compiler_commands':0 if noop else 1,'compiler_crates':[] if noop else [project],'oracle':oracle,'source_sha256':{name:s.hashlib.sha256(data).hexdigest() for name,data in s.fixture_bytes(ORIGINALS,project,state).items()},'patch_sha256':s.digest(stem.with_suffix('.patch')),'census':census}
                    if phase in ('clean','noop-final'):row['formats']={'passed':True,'metadata_formats':{'raw':1,'packed':0,'other':0},'counts':{'archive':1,'object':int(compact)},'archive_member_formats':{'compact':int(compact)}}
                    rows.append(row)
                save(stem.parent/'cleanup.json',{'passed':True,'source_restored':True,'last_sample_accepted':True,'path':str(lane),'census':census,'budget_after':budget})
    save(matrix/'provenance.json',p);save(matrix/'status.json',{'passed':True,'samples':90,'accepted':90,'source_and_toolchain_unchanged':True,'budget_after':budget})
    (matrix/'samples.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in rows))
    return rows


class Controls(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);self.rows=synthetic(self.root);self.matrix=self.root/'evidence/performance-v1'
    def verify(self):return s.verify(self.root,ORIGINALS)
    def rewrite(self): (self.matrix/'samples.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in self.rows))
    def test_complete_and_statistics(self):
        p,rows,files,anomalies,counts=self.verify();self.assertEqual(len(rows),90);self.assertFalse(anomalies)
        self.assertEqual(counts,{'recorded_textual_matches':70,'actual_rustc_invocations':70,'cargo_running_records':70})
        groups=s.summarize(rows);self.assertEqual(len(groups),20)
        g=next(g for g in groups if (g['project'],g['reference'],g['candidate'],g['phase'])==('ruff','off','default','real-direct'))
        self.assertEqual(g['n_pairs'],6);self.assertAlmostEqual(g['metrics']['wall_seconds']['delta_mean'],0.1)
        self.assertAlmostEqual(g['metrics']['wall_seconds']['ratio_of_means_percent'],100/15)
        self.assertEqual(g['metrics']['system_seconds']['n_percent_pairs'],0)
        self.assertIsNone(g['metrics']['system_seconds']['ratio_of_means_percent'])
        self.assertEqual([len(r['values']['wall_seconds']['reference']) for r in g['rounds']],[3,3])
        self.assertIn('not an adoption decision',s.markdown({'comparisons':groups}))
    def test_missing_or_rejected_row(self):
        self.rows.pop();self.rewrite()
        with self.assertRaisesRegex(ValueError,'exact90-row'):self.verify()
    def test_hidden_failed_run(self):
        save(self.matrix/'failure.json',{})
        with self.assertRaisesRegex(ValueError,'hidden failed'):self.verify()
    def test_wrong_capability(self):
        path=self.matrix/'ruff-adapter-0/00-clean.log';path.write_text(path.read_text().replace('`\n',' -Zcompact-artifacts-linker=yes`\n'))
        with self.assertRaisesRegex(ValueError,'capability'):self.verify()
    def test_runtime_disagrees(self):
        path=self.matrix/'ruff-off-0/00-clean.oracle.json';r=s.load(path);r['cases']['synthetic']['stdout']='9\n';save(path,r)
        with self.assertRaisesRegex(ValueError,'oracle bytes'):self.verify()
    def test_cleanup_census(self):
        path=self.matrix/'ruff-off-0/cleanup.json';r=s.load(path);r['census']['allocated']+=1;save(path,r)
        with self.assertRaisesRegex(ValueError,'before cleanup'):self.verify()
    def test_source_not_restored(self):
        path=self.matrix/'ruff-source-after.json';r=s.load(path);r['head']='f'*40;save(path,r)
        with self.assertRaisesRegex(ValueError,'restoration'):self.verify()
    def test_resource_disagrees(self):
        path=self.matrix/'ruff-off-0/00-clean.monitor.json';r=s.load(path);r[0]['rss']+=1;save(path,r)
        with self.assertRaisesRegex(ValueError,'tree RSS'):self.verify()
    def test_noop_replay(self):
        path=self.matrix/'ruff-off-0/01-noop.log';path.write_text('Running `'+str(s.REMOTE/'toolchains/compiler-v3/bin/rustc')+' app.rlink -Zlink-only`\n')
        with self.assertRaisesRegex(ValueError,'activity/no-op'):self.verify()
    def test_build_script_environment_is_not_a_compiler_command(self):
        path=self.matrix/'ruff-off-0/00-clean.log'
        rustc=str(s.REMOTE/'toolchains/compiler-v3/bin/rustc')
        original=path.read_text()
        path.write_text(f"Running `RUSTC={rustc} CARGO_PKG_DESCRIPTION='a package' /lane/build_script_build`\n"+original)
        self.rows[0]['compiler_commands']+=1;self.rewrite()
        *_,counts=self.verify()
        self.assertEqual(counts,{'recorded_textual_matches':71,'actual_rustc_invocations':70,'cargo_running_records':71})
        with self.assertRaisesRegex(ValueError,'activity/no-op'):
            s.compiler_commands(f'Running `RUSTC={rustc} /lane/build_script_build`\n',rustc,'off','clean')
    def test_wrong_compiler_is_not_hidden_by_expected_environment(self):
        rustc=str(s.REMOTE/'toolchains/compiler-v3/bin/rustc')
        with self.assertRaisesRegex(ValueError,'unexpected compiler path'):
            s.compiler_commands(f'Running `RUSTC={rustc} /wrong/bin/rustc src/main.rs`\n',rustc,'off','clean')
    def test_multiline_compiler_and_replay_are_not_omitted(self):
        rustc=str(s.REMOTE/'toolchains/compiler-v3/bin/rustc')
        command=f"Running `CARGO_PKG_DESCRIPTION='multiple\nlines with `ticks`' {rustc} --crate-name foo src/lib.rs`\n"
        self.assertEqual(len(s.compiler_commands(command,rustc,'off','clean')),1)
        with self.assertRaisesRegex(ValueError,'activity/no-op'):
            s.compiler_commands(command.replace('--crate-name foo src/lib.rs','app.rlink -Zlink-only'),rustc,'off','noop')
        with self.assertRaisesRegex(ValueError,'activity/no-op'):
            s.compiler_commands(f"Running `CARGO_PKG_DESCRIPTION='multiple\nlines' RUSTC={rustc} /lane/build_script_build`\n",rustc,'off','noop')


if __name__=='__main__':unittest.main()
