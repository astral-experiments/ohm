#!/usr/bin/env python3
"""Bounded same-toolchain default/storage and conventional-linker confirmation."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/home/dev-user/code/oss/ohm-compact-study')
WORK = ROOT / 'shipping/compatibility'
TARGET = Path('/tmp/codex-cargo-targets/ohm/isolated/compact-compatibility')
OUTPUT = WORK / 'evidence/performance-v1'
REFERENCE = ROOT / 'shipping/readiness/harness/benchmark_current_cargo.py'
REFERENCE_SHA = '29435c96104f2e9e65d693fd7fedec2623ff9199761889ee981613e5718dfe43'
RESERVE = 60 * 1024**3
CAP = 40 * 1024**3
HOST = 'x86_64-unknown-linux-gnu'
MARKER = 'compact-artifacts-v2'
ORDERS = {'ruff': (('off', 'default', 'adapter'), ('adapter', 'default', 'off')),
          'uv': (('off', 'default'), ('default', 'off'))}
REMOVED = ('-Zcompress-incremental', '-Zcompress-artifacts', '-Zcompact-artifact-store',
           '-Zcompact-artifact-raw-metadata')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def load(path):
    return json.loads(Path(path).read_text())


def output(argv, cwd=None):
    return subprocess.check_output(list(map(str, argv)), cwd=cwd, text=True).strip()


def source_snapshot(source):
    """Hash actual tracked file bytes, not just the commit or index's blob names."""
    entries = []
    index = subprocess.check_output(['git', 'ls-files', '-s', '-z'], cwd=source)
    for item in index.split(b'\0'):
        if not item:
            continue
        info, raw_name = item.split(b'\t', 1)
        mode, blob, stage = info.decode().split()
        assert stage == '0', 'unmerged source'
        name = raw_name.decode()
        path = source / name
        row = {'path': name, 'mode': mode}
        if mode == '160000':
            row['gitlink'] = blob
        elif path.is_symlink():
            row['symlink'] = os.readlink(path)
        else:
            row.update(bytes=path.stat().st_size, sha256=digest(path))
        entries.append(row)
    encoded = json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()
    diff = subprocess.check_output(['git', 'diff', '--binary'], cwd=source)
    assert not subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=source)
    return {'head': output(['git', 'rev-parse', 'HEAD'], source),
            'diff_sha256': hashlib.sha256(diff).hexdigest(),
            'index_sha256': hashlib.sha256(index).hexdigest(),
            'tracked_tree_sha256': hashlib.sha256(encoded).hexdigest(), 'files': entries}


def toolchain_snapshot(sysroot, cargo):
    linker = sysroot / 'lib/rustlib' / HOST / 'bin/wild-ld'
    assert (linker / MARKER).read_bytes() == b'RCOBJ001\n'
    assert not (linker / 'compact-artifacts-v1').exists()
    drivers = {p.name: digest(p) for p in sorted((sysroot / 'lib').glob('librustc_driver*.so'))}
    assert drivers
    return {'sysroot': str(sysroot), 'cargo': str(cargo), 'cargo_sha256': digest(cargo),
            'rustc_sha256': digest(sysroot / 'bin/rustc'), 'rustdoc_sha256': digest(sysroot / 'bin/rustdoc'),
            'drivers': drivers, 'wild_sha256': digest(linker / 'ld.bfd'),
            'marker_sha256': digest(linker / MARKER),
            'rustc_version': output([sysroot / 'bin/rustc', '-vV']),
            'cargo_version': output([cargo, '-vV'])}


def sequence():
    return [('clean', (0, 0, 0)), ('noop', (0, 0, 0)),
            *[('real-direct', (0, i, 0)) for i in range(1, 4)],
            *[('real-library', (0, 3, i)) for i in range(1, 4)], ('noop-final', (0, 3, 3))]


def wild_flags(sysroot):
    return ['-Clinker-features=-lld', '-Clink-self-contained=-linker',
            f'-Clink-arg=-B{sysroot}/lib/rustlib/{HOST}/bin/wild-ld', '-Clink-arg=-fuse-ld=bfd']


def environment(reference, sysroot, lane, project, mode):
    env = reference.environment(sysroot, lane, project)
    if mode == 'adapter':
        env['CARGO_ENCODED_RUSTFLAGS'] = '\x1f'.join(wild_flags(sysroot))
    return env


def validate_commands(text, mode, rustc, phase):
    assert not any(flag in text for flag in REMOVED)
    commands = [line for line in text.splitlines() if 'Running `' in line and '/bin/rustc ' in line]
    if phase.startswith('noop'):
        assert not commands, 'no-op invoked rustc or a link-only replay'
    else:
        assert commands, 'expected a real compiler or link-only invocation'
    for command in commands:
        assert str(rustc) in command
        if mode == 'off':
            assert '-Zcompact-artifacts' not in command and '-Zartifact-compression-profile' not in command
        else:
            assert '-Zcompact-artifacts=yes' in command and '-Zartifact-compression-profile=fast' in command
            assert '-Zembed-metadata=no' not in command and '-Z embed-metadata=no' not in command
            assert ('-Zcompact-artifacts-linker=yes' in command) == (mode == 'default')
    return len(commands)


def budget():
    # GNU du deduplicates hardlinks across both roots in one traversal.
    lines = output(['du', '-s', '-B1', WORK, TARGET]).splitlines()
    used = sum(int(line.split()[0]) for line in lines)
    free = shutil.disk_usage(TARGET).free
    assert used <= CAP, ('owned-root cap', used, CAP)
    assert free >= RESERVE, ('free reserve', free, RESERVE)
    return {'owned_allocated': used, 'free': free, 'cap': CAP, 'reserve': RESERVE}


def receipt(admission, name):
    item = admission['receipts'][name]
    path = Path(item['path'])
    assert path.is_relative_to(WORK / 'evidence') and not path.is_symlink()
    assert digest(path) == item['sha256'], name
    data = load(path)
    assert data['passed'], name
    return data


def validate_receipts(admission, expected):
    compiler = receipt(admission, 'compiler')
    cargo = receipt(admission, 'cargo')
    native = receipt(admission, 'native')
    preparation = receipt(admission, 'source_preparation')
    assert compiler['base'] == admission['sources_runtime']['rust']['base'] == '36f01299cd71f6c090150a80fe4a7babb6245a0b'
    assert cargo['base'] == admission['sources_runtime']['cargo']['base'] == '6333daf7cf99cf80125234c9419cbd36e9bff81a'
    assert compiler['patch_sha256'] == admission['sources_runtime']['rust']['patch_sha256']
    assert cargo['patch_sha256'] == admission['sources_runtime']['cargo']['patch_sha256']
    assert compiler['wild_source'] == admission['sources_runtime']['wild'] == '9179eb988df2676342192a24dc337cf9823e9d56'
    assert compiler['production_pgo_bolt'] is False
    assert cargo['compiler_build_sha256'] == native['compiler_build_sha256'] == admission['receipts']['compiler']['sha256']
    assert native['cargo_build_sha256'] == admission['receipts']['cargo']['sha256']
    assert cargo['cargo']['path'] == expected['cargo'] and cargo['cargo']['sha256'] == expected['cargo_sha256']
    for proof in (compiler, cargo, native):
        toolchain = proof['toolchain']
        assert toolchain['path'] == expected['sysroot']
        for name in ('drivers', 'rustc_sha256', 'rustdoc_sha256', 'wild_sha256'):
            assert toolchain[name] == expected[name], (name, proof)
        assert toolchain['marker'] == {'name': MARKER, 'sha256': expected['marker_sha256']}
    assert cargo['toolchain']['cargo_sha256'] == native['toolchain']['cargo_sha256'] == expected['cargo_sha256']
    assert preparation['sources'] == admission['sources'] and preparation['source_originals_unchanged']
    return compiler, cargo, native, preparation


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--admission', type=Path, required=True)
    args = parser.parse_args()
    admission = load(args.admission)
    assert admission['passed'] and admission['schema'] == 1
    assert admission['script_sha256'] == digest(__file__)
    assert admission['production_pgo_bolt'] is False
    assert admission['native_toolchain_matches'] is True
    assert digest(REFERENCE) == REFERENCE_SHA
    spec = importlib.util.spec_from_file_location('reference', REFERENCE)
    reference = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reference)
    core, shipping = reference.core, reference.shipping
    expected = admission['toolchain']
    validate_receipts(admission, expected)
    sysroot, cargo = Path(expected['sysroot']), Path(expected['cargo'])
    assert sysroot.is_relative_to(WORK / 'toolchains') and not sysroot.is_symlink()
    assert cargo.is_relative_to(WORK) and not cargo.is_symlink()
    assert toolchain_snapshot(sysroot, cargo) == expected
    assert not OUTPUT.exists()
    matrix_root = TARGET / 'performance-v1'
    assert not matrix_root.exists()
    assert (WORK / '.owned').is_file() and (TARGET / '.owned').is_file()
    lock = (TARGET / 'performance.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    OUTPUT.mkdir()
    matrix_root.mkdir()
    before = budget()
    protected = {item['path']: item['sha256'] for item in admission['receipts'].values()}
    protected[str(args.admission)] = digest(args.admission)
    provenance = {'script_sha256': digest(__file__), 'reference_sha256': REFERENCE_SHA,
                  'core_sha256': reference.CORE_SHA, 'format_wrapper_sha256': reference.WRAPPER_SHA,
                  'admission_sha256': digest(args.admission), 'admission': admission,
                  'toolchain': expected, 'sources': {}, 'plan': [], 'budget_before': before,
                  'counts': {'commands': 90, 'cells': 10, 'rounds': 2, 'commands_per_cell': 9},
                  'scope': 'Same non-PGO/BOLT compiler, Cargo and Wild. Automatic compact defaults versus explicit compact=no; Ruff-only adapter arm supplies identical Wild driver flags as user configuration, which also changes Cargo cache admission. Two fresh forward/reverse rounds; three sequential edits per class, not six independent rounds. One owned lane retained at a time. No cold-OS-cache or production-PGO claim.',
                  'admission_rules': {'outside_user_cores_threshold': 0.5, 'reject_at_intervals': 3,
                                      'unrelated_compilers_allowed': False, 'free_reserve_bytes': RESERVE,
                                      'owned_cap_bytes': CAP, 'disk_instrumented': False}}
    snapshots = {}
    for project in ('ruff', 'uv'):
        source = WORK / 'benchmark-sources' / project
        assert admission['sources'][project]['path'] == str(source) and not source.is_symlink()
        snapshot = source_snapshot(source)
        assert {key: snapshot[key] for key in snapshot if key != 'files'} == {
            key: value for key, value in admission['sources'][project].items() if key != 'path'}
        snapshots[project] = snapshot
        save(OUTPUT / f'{project}-source-before.json', snapshot)
        provenance['sources'][project] = admission['sources'][project]
        for round_index, modes in enumerate(ORDERS[project]):
            for mode in modes:
                lane = matrix_root / project / f'round-{round_index}' / mode
                argv = [str(cargo), '-Zohm-defaults=yes']
                if mode == 'off':
                    argv.append('-Zohm-compact-artifacts=no')
                argv += ['build', '--offline', '--locked', '-vv', '-p', project, '--bin', project, '-j', '8']
                env = environment(reference, sysroot, lane, project, mode)
                provenance['plan'].append({'project': project, 'round': round_index, 'mode': mode,
                                           'lane': str(lane), 'argv': argv,
                                           'environment': {k: env[k] for k in core.RECORDED_ENV if k in env}})
    save(OUTPUT / 'provenance.json', provenance)
    rows = []
    try:
        for cell in provenance['plan']:
            project, mode = cell['project'], cell['mode']
            source, lane = WORK / 'benchmark-sources' / project, Path(cell['lane'])
            assert not lane.exists() and lane.is_relative_to(matrix_root) and not lane.is_symlink()
            lane.mkdir(parents=True)
            (lane / 'scratch').mkdir()
            (lane / '.ohm-compact-benchmark').write_text('owned by benchmark.py\n')
            directory = OUTPUT / f'{project}-{mode}-{cell["round"]}'
            directory.mkdir()
            fixture = reference.Fixture(source, project)
            env = environment(reference, sysroot, lane, project, mode)
            previous_binary = None
            try:
                for index, (phase, state) in enumerate(sequence()):
                    boundary = budget()
                    # The existing constant-time free-space monitor also prevents spending
                    # more than the remaining owned budget during this command. Exclusive
                    # execution is required; all actual owned bytes are rechecked afterward.
                    reserve = max(RESERVE, boundary['free'] - (CAP - boundary['owned_allocated']))
                    hashes = fixture.write(*state)
                    stem = directory / f'{index:02}-{phase}'
                    stem.with_suffix('.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=source))
                    row = {'project': project, 'mode': mode, 'round': cell['round'], 'phase': phase,
                           'state': list(state), 'accepted': False, 'source_sha256': hashes,
                           'patch_sha256': digest(stem.with_suffix('.patch')), 'budget_before': boundary,
                           'effective_free_reserve': reserve}
                    try:
                        row.update(core.timed(cell['argv'], source, env, stem, [lane], False, reserve))
                        assert row['returncode'] == 0, row['log']
                        assert not row['unrelated_compilers'] and len(row['outside_cpu_intervals']) < 3
                        assert not row['disk_reserve_failed']
                        row['compiler_commands'] = validate_commands(stem.with_suffix('.log').read_text(), mode, sysroot / 'bin/rustc', phase)
                        row['oracle'] = reference.oracle(lane / 'target/debug' / project, project, state, stem.with_suffix('.oracle.json'))
                        current_binary = row['oracle']['binary_sha256']
                        if phase.startswith('noop'):
                            assert previous_binary == current_binary, 'no-op changed executable'
                        previous_binary = current_binary
                        row['census'] = core.census([lane])
                        if phase in ('clean', 'noop-final'):
                            row['formats'] = shipping.formats([lane], 'standard' if mode == 'off' else 'compact-archive')
                            assert row['formats']['passed'], row['formats']
                        row['budget_after'] = budget()
                        row['accepted'] = True
                    except BaseException as error:
                        row['error'] = f'{type(error).__name__}: {error}'
                        save(OUTPUT / 'failure.json', row)
                        raise
                    finally:
                        rows.append(row)
                        with (OUTPUT / 'samples.jsonl').open('a') as stream:
                            stream.write(json.dumps(row) + '\n')
                        print(json.dumps({k: row[k] for k in ('project', 'mode', 'round', 'phase', 'accepted')}), flush=True)
            finally:
                fixture.restore()
            # Archive the complete census and source state before deleting only this lane.
            census = core.census([lane])
            save(directory / 'cleanup.json', {'passed': False, 'path': str(lane), 'census': census,
                                              'source_restored': True, 'last_sample_accepted': rows[-1]['accepted']})
            core.owned_cleanup(lane)
            assert not lane.exists()
            save(directory / 'cleanup.json', {'passed': True, 'path': str(lane), 'census': census,
                                              'source_restored': True, 'last_sample_accepted': rows[-1]['accepted'], 'budget_after': budget()})
        assert len(rows) == 90 and all(row['accepted'] for row in rows)
        assert toolchain_snapshot(sysroot, cargo) == expected
        for project, snapshot in snapshots.items():
            after = source_snapshot(WORK / 'benchmark-sources' / project)
            assert after == snapshot
            save(OUTPUT / f'{project}-source-after.json', after)
        assert all(digest(path) == value for path, value in protected.items())
        save(OUTPUT / 'status.json', {'passed': True, 'samples': 90, 'accepted': 90,
                                     'source_and_toolchain_unchanged': True, 'budget_after': budget(), 'finished': time.time()})
    except BaseException as error:
        save(OUTPUT / 'interrupted.json', {'passed': False, 'samples': len(rows), 'accepted': sum(row['accepted'] for row in rows),
                                          'error': repr(error), 'finished': time.time()})
        raise


if __name__ == '__main__':
    main()
