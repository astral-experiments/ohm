#!/usr/bin/env python3
"""Independent command framing/mode audit of the recorded compatibility90 logs."""
import collections
import hashlib
import json
import re
import shlex
from pathlib import Path
ROOT=Path('/private/tmp/ohm-compact-shipping/receipts/compatibility')
REMOTE=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/compatibility')
OUT=Path('/private/tmp/ohm-compact-compatibility-evidence/performance-actual-routing-review.json')

def framed(text):
    pending=None
    for line in text.splitlines():
        if re.match(r'^\s+Running `',line):
            assert pending is None, 'unterminated earlier Cargo command'
            pending=line.split('Running `',1)[1]
        elif pending is not None:
            pending+='\n'+line
        else:
            continue
        if pending.endswith('`'):
            try: words=shlex.split(pending[:-1])
            except ValueError: continue
            i=0
            while i<len(words) and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*=.*',words[i],re.S):i+=1
            if i==len(words):continue
            yield words[i:], '\n' in pending
            pending=None
    assert pending is None, 'unterminated Cargo command'

def main():
    m=ROOT/'evidence/performance-v1'
    samples=(m/'samples.jsonl').read_bytes();rows=[json.loads(x) for x in samples.splitlines()]
    provenance=(m/'provenance.json').read_bytes();p=json.loads(provenance);rustc=p['toolchain']['sysroot']+'/bin/rustc'
    totals=collections.Counter();counts=[]
    for row in rows:
        assert row['accepted'] and row['returncode']==0 and '-Zohm-defaults=yes' in row['argv']
        if row['mode']=='off':assert '-Zohm-compact-artifacts=no' in row['argv']
        log=ROOT/Path(row['log']).relative_to(REMOTE);text=log.read_text()
        historical=sum('Running `' in x and '/bin/rustc ' in x for x in text.splitlines())
        assert historical==row['compiler_commands']
        c=collections.Counter()
        for words,multiline in framed(text):
            exe=words[0]
            if Path(exe).name!='rustc':
                assert Path(exe).name in ('build_script_build','build_script_main'),exe
                c['build_script_executions']+=1
                continue
            assert exe==rustc,(exe,rustc)
            opts=[];it=iter(words[1:])
            for word in it: opts.append(word+next(it,'') if word in ('-Z','-C') else word)
            if row['mode']=='off':
                assert not any(x.startswith('-Zcompact-artifacts') for x in opts)
                assert any(x.startswith('-Clink-arg=-B') and x.endswith('/wild-ld') for x in opts)
            else:
                assert '-Zcompact-artifacts=yes' in opts and '-Zartifact-compression-profile=fast' in opts
                assert ('-Zcompact-artifacts-linker=yes' in opts)==(row['mode']=='default')
            c['actual_compiler_executions']+=1;c['multiline_compiler_executions']+=multiline
        assert bool(c['actual_compiler_executions'])==(not row['phase'].startswith('noop'))
        c['historical_textual_matches']=historical;totals.update(c)
        counts.append({k:row[k] for k in ('project','mode','round','phase','state')}|dict(c))
    result={'passed':True,'scope':'Independent actual90 Cargo log executable classification and final76793 ordinary-guard reachability review; timing arithmetic/source/oracle full verifier separate.',
            'auditor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'samples_sha256':hashlib.sha256(samples).hexdigest(),'provenance_sha256':hashlib.sha256(provenance).hexdigest(),'rows':len(rows),'counts':dict(totals),'records':counts,
            'guard_equivalence':'Every command enables Ohm defaults. Off uses generated Wild; all actual default/adapter compiler invocations enable compact storage. The added !compact && options.ohm_linker()!=Wild early return is false in all measured configurations. No final-binary timing equality inferred.'}
    assert not OUT.exists();OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(OUT),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'counts':dict(totals)},indent=2))
if __name__=='__main__':main()
