#!/usr/bin/env python3
"""Independently recompute the 90-command summary with Decimal arithmetic.

The separate receipt verifier owns source/oracle/resource verification. This
small second calculation reads raw rows directly and imports no summarizer code.
"""
import argparse
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def median(values):
    ordered = sorted(values)
    n = len(ordered)
    return ordered[n // 2] if n % 2 else (ordered[n // 2 - 1] + ordered[n // 2]) / 2


def stats(left, right):
    mean = lambda values: sum(values) / len(values)
    delta = [b - a for a, b in zip(left, right)]
    percent = [100 * (b - a) / a for a, b in zip(left, right) if a > 0]
    return dict(reference_mean=mean(left), candidate_mean=mean(right),
                reference_median=median(left), candidate_median=median(right),
                delta_mean=mean(delta), paired_delta_median=median(delta),
                paired_delta_range=[min(delta), max(delta)],
                ratio_of_means_percent=100 * (sum(right) - sum(left)) / sum(left) if sum(left) else None,
                n_percent_pairs=len(percent), paired_percent_median=median(percent) if percent else None,
                paired_percent_range=[min(percent), max(percent)] if percent else [None, None],
                increased_pairs=sum(b > a for a, b in zip(left, right)))


def equal(actual, expected):
    if isinstance(expected, dict):
        require(actual.keys() == expected.keys(), 'metric field set')
        for key in expected:
            equal(actual[key], expected[key])
    elif isinstance(expected, list):
        require(len(actual) == len(expected), 'distribution length')
        for a, e in zip(actual, expected):
            equal(a, e)
    elif expected is None:
        require(actual is None, 'undefined percentage')
    else:
        require(isinstance(actual, (int, float)) and math.isfinite(actual) and
                math.isclose(actual, float(expected), rel_tol=1e-11, abs_tol=1e-9),
                f'metric mismatch: {actual} vs {expected}')


def value(row, metric):
    if metric == 'cpu_seconds':
        return Decimal(str(row['user_seconds'])) + Decimal(str(row['system_seconds']))
    if metric in ('allocated_bytes', 'logical_bytes'):
        return Decimal(row['census'][metric.removesuffix('_bytes')])
    return Decimal(str(row[metric]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples', type=Path, required=True)
    parser.add_argument('--summary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.samples.read_text().splitlines()]
    summary = json.loads(args.summary.read_text())
    require(summary['passed'] and summary['matrix_sha256'] == sha(args.samples), 'summary/raw binding')
    require(len(rows) == 90 and all(r['accepted'] and r['returncode'] == 0 for r in rows), '90 accepted rows')
    index = {(r['project'], r['mode'], r['round'], r['phase'], tuple(r['state'])): r for r in rows}
    require(len(index) == 90, 'unique matched states')
    phases = ('clean', 'noop', 'real-direct', 'real-library', 'noop-final')
    pairs = [('ruff', 'off', 'default'), ('ruff', 'default', 'adapter'),
             ('ruff', 'off', 'adapter'), ('uv', 'off', 'default')]
    expected = {(p, a, b, phase) for p, a, b in pairs for phase in phases}
    groups = {(g['project'], g['reference'], g['candidate'], g['phase']): g for g in summary['comparisons']}
    require(groups.keys() == expected and len(summary['comparisons']) == 20, '20 groups')
    metrics = ('wall_seconds', 'user_seconds', 'system_seconds', 'cpu_seconds',
               'max_child_rss_bytes', 'sampled_process_tree_peak_rss_bytes', 'allocated_bytes', 'logical_bytes')
    for (project, reference, candidate, phase), group in groups.items():
        left = [r for r in rows if (r['project'], r['mode'], r['phase']) == (project, reference, phase)]
        right = [index[(project, candidate, r['round'], phase, tuple(r['state']))] for r in left]
        require(group['n_pairs'] == len(left) == (6 if phase.startswith('real-') else 2), 'paired observations')
        require(set(group['metrics']) == set(metrics), 'metric scope')
        require([r['round'] for r in group['rounds']] == [0, 1], 'two fresh rounds')
        for metric in metrics:
            a, b = [value(r, metric) for r in left], [value(r, metric) for r in right]
            equal(group['metrics'][metric], stats(a, b))
            for round_info in group['rounds']:
                selected = [i for i, r in enumerate(left) if r['round'] == round_info['round']]
                aa, bb = [a[i] for i in selected], [b[i] for i in selected]
                require(round_info['n_pairs'] == len(aa), 'round sample count')
                equal(round_info['metrics'][metric], stats(aa, bb))
                equal(round_info['values'][metric], {'reference': aa, 'candidate': bb})
    result = dict(passed=True, scope='Independent Decimal recomputation only; source/runtime/noise proof remains in the separate receipt verifier.',
                  samples_sha256=sha(args.samples), summary_sha256=sha(args.summary),
                  auditor_sha256=sha(Path(__file__)), raw_commands=90, groups=20, independent_rounds=2)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
