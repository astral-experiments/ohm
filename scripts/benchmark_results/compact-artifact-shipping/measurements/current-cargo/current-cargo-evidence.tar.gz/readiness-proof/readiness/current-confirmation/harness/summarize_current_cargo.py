#!/usr/bin/env python3
"""Summarize complete matched readiness receipts; retain every round comparison."""
import argparse
import json
from pathlib import Path
import statistics

PAIRS = [('baseline', 'storeless'), ('storeless', 'compact'), ('baseline', 'compact')]
METRICS = ('wall_seconds', 'user_seconds', 'system_seconds', 'cpu_seconds', 'max_child_rss_bytes',
           'sampled_process_tree_peak_rss_bytes', 'allocated_bytes')


def value(row, metric):
    if metric == 'cpu_seconds':
        return row['user_seconds'] + row['system_seconds']
    if metric == 'allocated_bytes':
        return row['census']['allocated']
    return row[metric]


def summary(pairs, metric):
    reference = [value(a, metric) for a, _ in pairs]
    candidate = [value(b, metric) for _, b in pairs]
    first, second = statistics.mean(reference), statistics.mean(candidate)
    changes = [100 * (b / a - 1) if a else None for a, b in zip(reference, candidate)]
    finite = [v for v in changes if v is not None]
    return {'n_percent_pairs': len(finite), 'reference_mean': first, 'candidate_mean': second, 'delta_mean': statistics.mean(b - a for a, b in zip(reference, candidate)),
            'percent': 100 * (second / first - 1) if first else None,
            'paired_percent_median': statistics.median(finite) if finite else None,
            'paired_percent_min': min(finite) if finite else None, 'paired_percent_max': max(finite) if finite else None}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('matrix', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    rows = [json.loads(line) for line in (args.matrix / 'samples.jsonl').read_text().splitlines()]
    assert len(rows) == 156 and all(row['accepted'] for row in rows)
    keys = [(r['project'], r['mode'], r['round'], r['phase'], tuple(r['state'])) for r in rows]
    assert len(set(keys)) == len(keys)
    indexed = dict(zip(keys, rows))
    result = {'counts': {'accepted': len(rows), 'cells': 12, 'projects': 2, 'arms': 3, 'rounds': 2,
                         'edits_per_round': 3, 'independent_rounds': 2},
              'scope': 'Two fresh paired forward/reverse rounds under current Cargo6333. Pair precedence is reversed; ordinal positions are not fully balanced. This is current integration confirmation, not a causal Cargo4a-to-6333 comparison. Three sequential edits within each round; edit samples are not independent rounds. Wall time is whole Cargo command; allocated bytes are inode-deduplicated post-command target+build+scratch, not peak disk.',
              'comparisons': []}
    phases = sorted({row['phase'] for row in rows})
    for project in ('ruff', 'uv'):
        for phase in phases:
            for reference, candidate in PAIRS:
                first = sorted((r for r in rows if (r['project'], r['phase'], r['mode']) == (project, phase, reference)),
                               key=lambda r: (r['round'], r['state']))
                pairs = [(r, indexed[(project, candidate, r['round'], phase, tuple(r['state']))]) for r in first]
                row = {'project': project, 'phase': phase, 'reference': reference, 'candidate': candidate,
                       'n_pairs': len(pairs), 'metrics': {}}
                for metric in METRICS:
                    totals = summary(pairs, metric)
                    totals['rounds'] = []
                    for round_index in range(2):
                        matched = [(a, b) for a, b in pairs if a['round'] == round_index]
                        item = summary(matched, metric)
                        totals['rounds'].append({'round': round_index, 'n_pairs': len(matched),
                                                **{k: item[k] for k in ('reference_mean', 'candidate_mean', 'delta_mean', 'percent')}})
                    row['metrics'][metric] = totals
                result['comparisons'].append(row)
    args.output.write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
