from pathlib import Path
import json,subprocess,sys,time
assert len(sys.argv)==3 and sys.argv[1]=="--job"
execution_job=sys.argv[2]
root=Path('/private/tmp/ohm-compact-readiness');out=root/'monitor-current-cargo';out.mkdir(exist_ok=True)
helper='/private/tmp/ohm-compact-shipping/control/remote.py';progress=root/'control/current-cargo-progress.py'
while True:
 try:
  launched=subprocess.run([sys.executable,helper,'run',str(progress)],capture_output=True,text=True,check=True)
  job=launched.stdout.strip().splitlines()[-1]
  for _ in range(6):
   got=subprocess.run([sys.executable,helper,'get',job],capture_output=True,text=True,check=True);result=json.loads(got.stdout)
   if result['status']!='running':break
   time.sleep(2)
  assert result['status']=='completed' and result['exit_code']==0,result
  data=json.loads(result['stdout']);matrix=data.get('current-cargo-matrix',{});cells=matrix.get('completed_cell_seconds',[])
  compact={'observed':time.time(),'job':job,'rows':matrix.get('rows',0),'accepted':matrix.get('accepted',0),'last':matrix.get('last'),'completed_cells':len(cells),'latest_cell':cells[-1] if cells else None,'freeGiB':data['freeGiB'],'failure':matrix.get('failure'),'status':matrix.get('status')}
  primary_job=subprocess.run([sys.executable,helper,'get',execution_job],capture_output=True,text=True,check=True)
  job_state=json.loads(primary_job.stdout);compact['execution_status']=job_state['status'];compact['execution_exit_code']=job_state['exit_code']
  compact['execution_job']=execution_job
  if job_state['status']=='completed' and job_state['exit_code']!=0 and not compact['failure']:compact['failure']='current Cargo confirmation launcher exited '+str(job_state['exit_code'])
  (out/'latest.json').write_text(json.dumps(compact,indent=2)+'\n')
  with (out/'progress.jsonl').open('a') as f:f.write(json.dumps(compact)+'\n')
  print(json.dumps(compact),flush=True)
  if compact['failure'] or compact['status']:break
 except BaseException as error:
  (out/'error.txt').write_text(repr(error)+'\n');raise
 time.sleep(60)
