"""Seal the complete current-Cargo proof and156-command confirmation as a supplement."""
import argparse,gzip,hashlib,io,json,tarfile
from pathlib import Path

def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def encoded(value):return (json.dumps(value,indent=2)+'\n').encode()
parser=argparse.ArgumentParser();parser.add_argument('--audit',type=Path,required=True);parser.add_argument('--summary',type=Path,required=True);args=parser.parse_args()
root=Path('/private/tmp/ohm-compact-readiness');receipts=Path('/private/tmp/ohm-compact-shipping/receipts');publication=root/'publication'
ancestors=[('current-cut-correctness.tar.gz','3da176a3a30003bbd2a771f2dd31afa2544a4000097964df32be70a0a58dd986','inventory.json','059a0ad37a126c3e39ed316166ebd61a97e3a79134488b73c3d3f015cdb3d229'),
           ('readiness-matrix.tar.gz','9832541221286816eac2055ae93c47c0b2811d0e83cc6dcd39ee7b561e3261a6','matrix-inventory.json','403abcc2b760ae00a715e74ecf38752dce55f9de0c03fd3b18e310d7aec1e18a')]
prior_files={};ancestor_records=[]
for archive_name,archive_hash,inventory_name,inventory_hash in ancestors:
    archive=publication/archive_name;inventory=publication/inventory_name
    assert sha(archive)==archive_hash and sha(inventory)==inventory_hash
    with tarfile.open(archive,'r:gz') as tar:
        assert tar.extractfile('readiness-proof/'+inventory_name).read()==inventory.read_bytes()
    manifest=json.loads(inventory.read_text())
    for entry in manifest['files']:
        assert entry['path'] not in prior_files
        prior_files[entry['path']]=entry
    prior_files[inventory_name]={'path':inventory_name,'bytes':inventory.stat().st_size,'sha256':inventory_hash}
    ancestor_records.append({'archive':archive_name,'sha256':archive_hash,'inventory':inventory_name,'inventory_sha256':inventory_hash})
collection=receipts/'readiness/evidence/current-cargo-collection.json';manifest=json.loads(collection.read_text())
audit=json.loads(args.audit.read_text());summary=json.loads(args.summary.read_text())
assert manifest['passed'] and manifest['samples']==156 and summary['counts']['accepted']==156
assert len(manifest['files'])==manifest['file_count']==len({entry['path'] for entry in manifest['files']})
assert audit['passed'] and audit['commands']==156 and len(audit['comparisons'])==42
assert audit['auditor_sha256']=='6a19dcdc27d98347f07ca0bd375e47de636838f815849c2b51696abf9ad018c9'==sha(root/'harness/audit_current_confirmation.py')
assert audit['shared_auditor_sha256']=='1ca96fce0f17711de6737cf87ddd1c4bb49cbe39d3dff87770952288b45d6f5d'==sha(root/'harness/audit_readiness.py')
assert audit['summary_sha256']==sha(args.summary) and audit['transferred_files_verified']==manifest['file_count']
assert audit['matrix_sha256']==manifest['matrix_samples_sha256']==sha(receipts/'readiness/evidence/current-cargo-matrix/samples.jsonl')
assert audit['current_cargo_receipt_sha256']==manifest['current_cargo_receipt_sha256']==sha(receipts/'readiness/final-cargo-current/evidence/result.json')
assert audit['prior_collection_sha256']==manifest['prior_collection_sha256']==sha(receipts/'readiness/evidence/collection.json')
assert audit['prior_primary_audit_sha256']==manifest['prior_primary_audit_sha256']==sha(receipts/'readiness/final-cargo-current/independent-matrix-audit.json')
native_audit=json.loads((root/'independent-current-cargo-audit.json').read_text())
assert native_audit['passed'] and native_audit['result_sha256']==manifest['current_cargo_receipt_sha256']
assert native_audit['auditor_sha256']=='5433afab2a2ca880a71d1fb32fff44858c078687e6f64b7bf6990f13f7501061'==sha(root/'harness/audit_current_cargo.py')
entries={};overlaps=[]
def add(name,data):
    assert name not in entries,name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    if name in prior_files:
        old=prior_files[name];assert len(data)==old['bytes'] and hashlib.sha256(data).hexdigest()==old['sha256'],name
        overlaps.append(name)
    else:entries[name]=data
for record in manifest['files']:
    path=receipts/record['path'];assert path.is_file() and not path.is_symlink()
    assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256'],record['path']
    add(record['path'],path.read_bytes())
add('readiness/evidence/current-cargo-collection.json',collection.read_bytes())
add('readiness/current-confirmation/readiness-summary.json',args.summary.read_bytes())
add('readiness/current-confirmation/independent-audit.json',args.audit.read_bytes())
local_files=['independent-current-cargo-audit.json','current-cargo-transfer-verification.json',
             'current-collection-peer-review.json','current-auditor-peer-review.json','current-auditor-rust-exports-peer-review.json',
             'current-auditor-test.json','current-auditor-test.log','final-cargo-current-control-review.json',
             'current-cargo-harness.diff','current-cargo-summary.diff','ordinary-path-review.md',
             'harness/audit_current_cargo.py','harness/audit_current_confirmation.py','harness/audit_readiness.py',
             'harness/summarize_current_cargo.py','harness/test_current_auditor.py','harness/package_current_cargo.py',
             'control/collect-current-cargo-proof.py','control/collect-current-confirmation.py','control/current-cargo-progress.py',
             'control/monitor-current-cargo.py','control/start-current-cargo-matrix.py','control/run-final-cargo-current.py']
for name in local_files:
    path=root/name;assert path.is_file() and not path.is_symlink(),name
    add('readiness/current-confirmation/'+name,path.read_bytes())
for directory in ('remote-head-audit','monitor-current-cargo'):
    parent=root/directory;assert parent.is_dir() and not parent.is_symlink()
    for path in sorted(parent.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():add('readiness/current-confirmation/'+str(path.relative_to(root)),path.read_bytes())
files=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())]
inventory={'schema':1,'ancestors':ancestor_records,'file_count':len(files),'total_bytes':sum(f['bytes'] for f in files),
           'static_overlaps_verified':len(overlaps),'files':files,'excluded_self':'current-cargo-inventory.json',
           'scope':'All156 current-Cargo rows and native proof; no omissions. Original443/416 study and its44-byte documented cache exclusion remain in sealed ancestor archives.'}
entries['current-cargo-inventory.json']=encoded(inventory)
archive=publication/'current-cargo-evidence.tar.gz';assert not archive.exists()
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0,compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped,mode='w|') as tar:
            for name,data in sorted(entries.items()):
                info=tarfile.TarInfo('readiness-proof/'+name);info.size=len(data);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    seen=set()
    for member in tar:
        assert member.isfile() and member.name.startswith('readiness-proof/')
        name=member.name.removeprefix('readiness-proof/');assert name not in seen;seen.add(name)
        assert member.size==len(entries[name]) and hashlib.sha256(tar.extractfile(member).read()).digest()==hashlib.sha256(entries[name]).digest(),name
    assert seen==set(entries)
receipt={'passed':True,'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'raw_file_count':len(entries),
         'raw_bytes':sum(map(len,entries.values())),'static_overlaps_verified':len(overlaps),'ancestors':ancestor_records}
(publication/'current-cargo-inventory.json').write_bytes(encoded(inventory))
(publication/'current-cargo-package.json').write_bytes(encoded(receipt));print(json.dumps(receipt,indent=2))
