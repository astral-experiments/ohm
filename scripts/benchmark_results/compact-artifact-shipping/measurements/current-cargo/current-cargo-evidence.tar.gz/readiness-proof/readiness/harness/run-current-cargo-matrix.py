"""Run one bounded156-command current-Cargo confirmation after audited handover."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness');study=work.parent.parent
script=work/'harness/benchmark_current_cargo.py';prepare=work/'harness/prepare-current-cargo.py'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert digest(script)=='29435c96104f2e9e65d693fd7fedec2623ff9199761889ee981613e5718dfe43'
assert digest(prepare)=='ca7a18d2072c1cf0ba31b25ad1823e30a7f7b3aeb8ad697af84f0b71bcd4f992'
review=load(work/'harness/current-cargo-confirmation-review.json')
assert review['passed'] and review['harness_sha256']==digest(script) and review['preparation_sha256']==digest(prepare) and review['launcher_sha256']==digest(Path(__file__))
assert not any(k.startswith('RUSTC_LOG') for k in os.environ)
assert not (work/'evidence/current-cargo-matrix').exists()
collection_path=work/'evidence/collection.json';collection=load(collection_path)
audit_path=work/'final-cargo-current/independent-matrix-audit.json';audit=load(audit_path)
current_path=work/'final-cargo-current/evidence/result.json';current=load(current_path)
assert collection['passed'] and audit['passed'] and audit['commands']==416 and audit['raw_commands']==443
assert audit['transferred_files_verified']==collection['file_count']
assert audit['matrix_sha256']==collection['matrix_samples_sha256']==digest(work/'evidence/real-edit-primary/samples.jsonl')
assert current['passed'] and current['sources']['cargo']=='6333daf7cf99cf80125234c9419cbd36e9bff81a'
assert current['script_sha256']=='7c70ca6bc6c00cdec1d47750bc28889ce146001550c60ea02ba9812370fe4a01'
assert current['input_manifest_sha256']=='ab614ea2c422797fb57498552ccc1c1bbb42a649e11bd7d9b9b1cc62166097b0'
assert current['matrix_handover']['independent_audit_sha256']==digest(audit_path)
assert current['matrix_handover']['collection_sha256']==digest(collection_path)
assert current['default_compact_members']==0 and current['optin_compact_members']>0
protected={str(work.parent/f['path']):f['sha256'] for f in collection['files']}
protected.update({str(p):digest(p) for p in [collection_path,audit_path,current_path]})
prior=load(work/'evidence/real-edit-primary/provenance.json')
for toolchain in prior['toolchains'].values():
    path=Path(toolchain['path']);protected[str(path/'bin/rustc')]=toolchain['rustc_sha256']
    protected[str(path/'lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd')]=prior['wild_sha256']
    protected.update({str(path/'lib'/name):h for name,h in toolchain['drivers'].items()})
protected[prior['cargo']['path']]=prior['cargo']['sha256']
protected[current['cargo']['path']]=current['cargo']['sha256']
for p in (work/'final-cargo-current/toolchain').rglob('*'):
    if p.is_file():protected[str(p)]=digest(p)
def preserve(label):
    destination=work/f'evidence/current-cargo-preservation-{label}.json';assert not destination.exists()
    changed=[path for path,h in protected.items() if not Path(path).is_file() or digest(Path(path))!=h]
    receipt={'passed':not changed,'protected_files':len(protected),'changed':changed,'collection_sha256':digest(collection_path),
             'current_cargo_receipt_sha256':digest(current_path),'prior_primary_audit_sha256':digest(audit_path),
             'original_failed_status_absent':not (work/'evidence/real-edit-matrix/status.json').exists(),'finished':time.time()}
    receipt['passed'] &= receipt['original_failed_status_absent'];save(destination,receipt);assert receipt['passed'],receipt
preserve('before')
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
prep_log=work/'evidence/current-cargo-preparation.log';assert not prep_log.exists()
with prep_log.open('w') as output:
    subprocess.run(['python3',str(prepare)],env=env,stdout=output,stderr=subprocess.STDOUT,check=True)
core_path=study/'harness/benchmark.py';assert digest(core_path)=='ea7867f9f9a0f19ceb7d9c558aa7aa6758ae3e254878685fbc58768c65713cef'
spec=importlib.util.spec_from_file_location('current_cargo_quiet_core',core_path);core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
quiet=work/'evidence/current-cargo-quiet';assert not quiet.exists();quiet.mkdir()
row=core.timed(['/bin/sleep','10'],work,{k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST'))},quiet/'quiet',[Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness')],False,60*1024**3)
row.update(accepted=False,purpose='Resource-only quiet gate before current Cargo confirmation; outside accepted timings',finished=time.time(),script_sha256=digest(Path(__file__)))
row['passed']=row['returncode']==0 and not row['unrelated_compilers'] and len(row['outside_cpu_intervals'])<3 and not row['disk_reserve_failed']
save(quiet/'result.json',row);assert row['passed'],row
log=work/'evidence/current-cargo-matrix.log';assert not log.exists()
try:
    with log.open('w') as output:
        result=subprocess.run(['python3',str(script)],env=env,stdout=output,stderr=subprocess.STDOUT)
    assert result.returncode==0,{'exit_code':result.returncode,'log':str(log)}
    status=load(work/'evidence/current-cargo-matrix/status.json')
    assert status['passed'] and status['samples']==status['accepted']==156
finally:
    preserve('after')
print(json.dumps({'passed':True,'samples':156,'log':str(log)}),flush=True)
