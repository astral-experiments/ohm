"""Audit recorded current Cargo native execution and custody; never execute toolchains."""
import argparse,hashlib,json,re
from pathlib import Path

def digest(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
parser=argparse.ArgumentParser();parser.add_argument('receipts',type=Path);parser.add_argument('--output',required=True,type=Path);args=parser.parse_args()
root=args.receipts;work=root/'readiness';case=work/'final-cargo-current';e=case/'evidence';inputs=case/'inputs'
checks=0
result={'passed':False,'scope':'Independent local audit of recorded Linux execution, source/binary bindings and transferred receipt/log bytes. The reviewer did not rerun native code or directly rehash remote binaries; pinned producer records actual execution and before/after preservation.','auditor_sha256':digest(Path(__file__))}
def check(condition,label):
    global checks
    checks+=1
    assert condition,label
try:
    collection=load(e/'collection.json');proof=load(e/'result.json')
    check(collection['passed'] and collection['result_sha256']==digest(e/'result.json'),'current result collection binding')
    check(len(collection['files'])==collection['file_count']==37 and len({f['path'] for f in collection['files']})==37,'all37 unique transferred files')
    for f in collection['files']:
        relative=Path(f['path']);check(not relative.is_absolute() and '..' not in relative.parts,'bounded receipt path')
        p=root/relative;check(p.is_file() and not p.is_symlink() and p.stat().st_size==f['bytes'] and digest(p)==f['sha256'],f['path'])
    check(sum(f['bytes'] for f in collection['files'])==collection['total_bytes']==44158359,'transferred byte total')
    check(proof['passed'] and proof['script_sha256']==digest(inputs/'validate_final_cargo.py')=='7c70ca6bc6c00cdec1d47750bc28889ce146001550c60ea02ba9812370fe4a01','reviewed executed control')
    check(proof['input_manifest_sha256']==digest(inputs/'inputs.json')=='ab614ea2c422797fb57498552ccc1c1bbb42a649e11bd7d9b9b1cc62166097b0','reviewed executed inputs')
    for name,h in load(inputs/'inputs.json')['sha256'].items():check(digest(inputs/name)==h,('input',name))
    check(proof['sources']=={'rust':'36f01299cd71f6c090150a80fe4a7babb6245a0b','cargo':'6333daf7cf99cf80125234c9419cbd36e9bff81a','wild':'9179eb988df2676342192a24dc337cf9823e9d56'},'current sources')
    check(proof['runtime_source_commit']=='3b84b46e3fb38f80246f744275c69fe608dfb2f3','frozen runtime source')
    handover=load(case/'measurement-handover.json');check(handover==proof['matrix_handover'] and handover['passed'],'exact handover')
    check(handover['collection_sha256']==digest(work/'evidence/collection.json'),'prior collection unchanged')
    prior=load(case/'independent-matrix-audit.json')
    check(handover['independent_audit_sha256']==digest(case/'independent-matrix-audit.json')=='4b33d15915bee9cad2a1d2bdc58dcb67badb51421217c99a27a930363616ddbe','actual prior audit binding')
    check(prior['passed'] and prior['commands']==416 and prior['raw_commands']==443 and prior['transferred_files_verified']==2669,'prior complete audit')
    build=load(work/'evidence/candidate-build/result.json');package=load(work/'evidence/candidate-package/result.json')
    check(proof['candidate_build_sha256']==digest(work/'evidence/candidate-build/result.json') and proof['candidate_package_sha256']==digest(work/'evidence/candidate-package/result.json'),'same compiler and installed-component proof')
    check(proof['toolchain']['drivers']==build['toolchain']['drivers']==package['driver_hashes'],'same compiler driver bytes')
    for name in ['rustc_sha256','wild_sha256']:check(proof['toolchain'][name]==build['toolchain'][name],name)
    check(proof['cargo']['sha256']==proof['toolchain']['cargo_sha256']=='179917c3631239ea29b91aff94d833182fc5be221d1cf012c765d72212ed742f','actual current Cargo bytes')
    check(proof['sources']['cargo'] in proof['cargo']['version'],'actual Cargo exact source version')
    check(proof['source_proof']['cargo_source_review_sha256']==digest(inputs/'cargo-source-review.json') and proof['source_proof']['rust_source_equivalence_sha256']==digest(inputs/'rust-source-equivalence.json'),'reviewed inherited source changes')
    check(proof['source_proof']['verified_runtime_paths']==33 and proof['source_proof']['runtime_matches_frozen_patch'] and proof['source_proof']['published_rust_delta']==['src/tools/cargo'],'runtime source equivalence')
    commands={c['name']:c for c in proof['commands']};check(len(commands)==len(proof['commands']),'unique native commands')
    for name,c in commands.items():
        check(c['exit_code']==(1 if name.startswith('reject-') else 0),('native exit',name))
        check(digest(e/(name+'.log'))==c['log_sha256'],('native log',name))
    check({'cargo-build','defaults-build','defaults-runtime','compact-installed-smoke'}<=commands.keys(),'both modes actually executed')
    check('Finished `release` profile [optimized]' in (e/'cargo-build.log').read_text(),'release Cargo build completed')
    check('Running `' in (e/'compact-installed-smoke.log').read_text(),'opt-in executable actually ran')
    shell=(inputs/'smoke-test-release.sh').read_text()
    fixture={}
    for relative,h in proof['fixture_sha256'].items():
        pieces=re.findall(r'cat > "\$smoke_crate/'+re.escape(relative)+r'" <<\x27EOF\x27\n(.*?)\nEOF\n',shell,re.DOTALL)
        check(len(pieces)==1 and hashlib.sha256((pieces[0]+'\n').encode()).hexdigest()==h,('exact runtime fixture',relative));fixture[relative]=pieces[0]
    for assertion in ['assert!(invert(false));','assert_eq!(answer(), 42);','assert_eq!(ohm_smoke::library_answer(), 42);']:check(assertion in fixture['src/main.rs'],'runtime assertion')
    check('ohm_smoke_macros::make_answer!();' in fixture['src/main.rs'],'proc-macro expansion used')
    check(proof['default_compact_members']==0 and proof['optin_compact_members']==1,'ordinary/compact archive members')
    removed={'compress-artifacts','compress-incremental','compact-artifact-store','compact-artifact-raw-metadata'}
    check(set(proof['removed_options'])==removed,'all4 removed options')
    for name,row in proof['removed_options'].items():
        text=(e/('reject-'+name+'.log')).read_text();check(row=={'exit_code':1,'diagnostic':'unknown unstable option','no_output':True},('removed option contract',name))
        check('unknown unstable option' in text and name in text and 'internal compiler error' not in text and 'panicked' not in text,('ordinary unsupported-option diagnostic',name))
    protected=load(e/'protected-before.json');check(len(protected)==proof['protected_files']==165822,'complete before snapshot')
    check(proof['timing_and_original_installed_binaries_unchanged'] and proof['original_sources_unchanged'] and proof['interrupted_original_status_remains_absent'],'producer preservation checks passed')
    check(proof['release_cache_symlinks_rejected_before_copy'],'copy cannot write through source cache symlinks')
    check(not (work/'evidence/real-edit-matrix/status.json').exists(),'no fabricated original success status')
    result.update(passed=True,checks=checks,files_verified=37,transferred_bytes=collection['total_bytes'],result_sha256=digest(e/'result.json'),collection_sha256=digest(e/'collection.json'),cargo_sha256=proof['cargo']['sha256'],drivers=proof['toolchain']['drivers'],wild_sha256=proof['toolchain']['wild_sha256'],protected_files=165822,default_compact_members=0,optin_compact_members=1,removed_options=sorted(removed),native_command_count=len(commands))
except BaseException as error:
    result.update(checks=checks,error=f'{type(error).__name__}: {error}')
    raise
finally:args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
