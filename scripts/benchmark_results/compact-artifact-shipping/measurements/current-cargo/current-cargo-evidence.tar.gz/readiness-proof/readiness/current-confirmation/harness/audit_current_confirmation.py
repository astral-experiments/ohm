#!/usr/bin/env python3
"""Independent audit for the156-command actual-current integration confirmation.

Shared raw-receipt helpers stay byte-pinned to the original study auditor.
"""
import argparse
from collections import defaultdict
import hashlib
import itertools
import json
from pathlib import Path
import re

import audit_readiness as base
from audit_readiness import Audit, digest, load, oracle, fixture_bytes, pair_metrics
from audit_readiness import CORE, WRAPPER, BASE, CURRENT, PATCH, CARGO, WILD, PROJECTS, SEQUENCE, REMOVED

SHARED_AUDITOR = '1ca96fce0f17711de6737cf87ddd1c4bb49cbe39d3dff87770952288b45d6f5d'
HARNESS = '29435c96104f2e9e65d693fd7fedec2623ff9199761889ee981613e5718dfe43'
CURRENT_CARGO = '6333daf7cf99cf80125234c9419cbd36e9bff81a'
PUBLISHED_RUST = '36f01299cd71f6c090150a80fe4a7babb6245a0b'
CUT = '3b84b46e3fb38f80246f744275c69fe608dfb2f3'
ARMS = ('baseline', 'storeless', 'compact')
ORDERS = (ARMS, tuple(reversed(ARMS)))
PAIRINGS = (('baseline', 'storeless'), ('storeless', 'compact'), ('baseline', 'compact'))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--original-build', type=Path, required=True)
    parser.add_argument('--current-cargo-receipt', type=Path, required=True)
    parser.add_argument('--prior-primary-audit', type=Path, required=True)
    parser.add_argument('--prior-collection', type=Path, required=True)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--source-snapshots', type=Path, required=True)
    parser.add_argument('--summary', type=Path)
    parser.add_argument('--transfer-manifest', type=Path)
    parser.add_argument('--transfer-root', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    audit = Audit(); check = audit.check
    root = args.evidence; matrix = root / 'current-cargo-matrix'
    result = {'passed': False, 'auditor_sha256': digest(Path(__file__))}
    try:
        if args.transfer_manifest:
            check(args.transfer_root is not None, 'transfer root required with manifest')
            transfer = load(args.transfer_manifest)
            entries = transfer['files']
            records = entries.items() if isinstance(entries, dict) else ((entry['path'], entry) for entry in entries)
            for relative, record in records:
                file = args.transfer_root / relative
                check(not Path(relative).is_absolute() and '..' not in Path(relative).parts, 'bounded transfer entry')
                check(file.is_file() and not file.is_symlink(), ('transferred regular file', relative))
                check(file.stat().st_size == record['bytes'] and digest(file) == record['sha256'], ('transferred bytes', relative))
            result['transferred_files_verified'] = len(transfer['files'])
        check(digest(args.harness) == HARNESS, 'frozen current integration harness')
        check(digest(args.harness.with_name('current-cargo-confirmation-review.json')) == 'fdb8bb94cf2581e65a9059f366b6c306d5e179288c82ff040d11667f0a01139e', 'prospective current integration admission')
        check(digest(Path(base.__file__)) == SHARED_AUDITOR, 'unchanged shared receipt helpers')
        p = load(matrix / 'provenance.json'); built = load(root / 'candidate-build/result.json')
        package = load(root / 'candidate-package/result.json'); original = load(args.original_build)
        check(p['script_sha256'] == HARNESS and p['core_sha256'] == CORE and p['format_wrapper_sha256'] == WRAPPER, 'frozen timing/format implementations')
        check(p['candidate_build_receipt_sha256'] == digest(root / 'candidate-build/result.json'), 'candidate receipt binding')
        check(p['candidate_package_receipt_sha256'] == digest(root / 'candidate-package/result.json'), 'package receipt binding')
        check(p['final_review_build_receipt_sha256'] == digest(args.original_build), 'prior compiler receipt binding')
        check(built['passed'] and package['passed'] and original['passed'], 'build/package proof passed')
        check(built['base'] == p['candidate_manifest']['base'] == CURRENT, 'candidate base')
        check(built['patch_sha256'] == package['patch_sha256'] == p['candidate_manifest']['patch_sha256'] == PATCH, 'candidate source patch')
        check(original['sources'] == {'rust': CURRENT, 'wild': WILD, 'cargo': CARGO}, 'current source pins')
        current_cargo = load(args.current_cargo_receipt); prior_audit = load(args.prior_primary_audit); collection = load(args.prior_collection)
        check(p['current_cargo_receipt_sha256'] == digest(args.current_cargo_receipt), 'actual current Cargo integration proof')
        check(p['prior_primary_audit_sha256'] == digest(args.prior_primary_audit) and p['prior_collection_sha256'] == digest(args.prior_collection), 'sealed prior study prerequisites')
        check(prior_audit['passed'] and prior_audit['commands'] == 416 and prior_audit['raw_commands'] == 443, 'prior443 raw/416 primary independently audited')
        check(collection['passed'] and prior_audit['transferred_files_verified'] == collection['file_count'], 'prior full collection verified')
        check(prior_audit['matrix_sha256'] == collection['matrix_samples_sha256'], 'prior primary sample identity')
        check(current_cargo['passed'] and current_cargo['sources'] == {'rust': PUBLISHED_RUST, 'cargo': CURRENT_CARGO, 'wild': WILD}, 'actual current source pins')
        check(current_cargo['runtime_source_commit'] == CUT, 'runtime compiler source remains frozen cut')
        check(current_cargo['script_sha256'] == '7c70ca6bc6c00cdec1d47750bc28889ce146001550c60ea02ba9812370fe4a01' and current_cargo['input_manifest_sha256'] == 'ab614ea2c422797fb57498552ccc1c1bbb42a649e11bd7d9b9b1cc62166097b0', 'reviewed actual current Cargo control')
        toolchain = current_cargo['toolchain']
        check(toolchain['drivers'] == built['toolchain']['drivers'] and toolchain['rustc_sha256'] == built['toolchain']['rustc_sha256'] and toolchain['wild_sha256'] == built['toolchain']['wild_sha256'], 'actual installed compiler/Wild copied byte-for-byte')
        check(toolchain['cargo_sha256'] == current_cargo['cargo']['sha256'] and toolchain['cargo_source'] == CURRENT_CARGO and toolchain['published_rust_source'] == PUBLISHED_RUST and toolchain['runtime_source_commit'] == CUT, 'actual integration toolchain boundary')
        commands = current_cargo['commands']
        check(len({c['name'] for c in commands}) == len(commands), 'unique current integration commands')
        for command in commands:
            check(command['exit_code'] == (1 if command['name'].startswith('reject-') else 0), ('current integration command exit', command['name']))
            check(digest(args.current_cargo_receipt.parent / (command['name'] + '.log')) == command['log_sha256'], ('actual current integration log bytes', command['name']))
        check({'defaults-build', 'defaults-runtime', 'compact-installed-smoke'} <= {c['name'] for c in commands}, 'both actual modes and library/proc-macro assertions executed')
        check(current_cargo['smoke_contract'] == {'modes': ['default', 'compact-optin'], 'executable_runtime': True, 'library_runtime': True, 'proc_macro_expansion_runtime': True, 'compact_linked_by_wild': True}, 'current integration smoke coverage')
        check(current_cargo['installed_compiler_matches_candidate'] and current_cargo['source_gitlink_consistency'] and current_cargo['timing_and_original_installed_binaries_unchanged'] and current_cargo['original_sources_unchanged'], 'current integration preserves timing inputs')
        check(current_cargo['default_compact_members'] == 0 and current_cargo['optin_compact_members'] > 0, 'installed ordinary/compact modes')
        check(current_cargo['candidate_build_sha256'] == p['candidate_build_receipt_sha256'] and current_cargo['candidate_package_sha256'] == p['candidate_package_receipt_sha256'], 'current Cargo smoke exact compiler/package binding')
        check(current_cargo['matrix_handover']['independent_audit_sha256'] == digest(args.prior_primary_audit) and current_cargo['matrix_handover']['collection_sha256'] == digest(args.prior_collection), 'integration gate same prior study custody')
        check(p['cargo']['sha256'] == current_cargo['cargo']['sha256'], 'same actual current Cargo bytes')
        check(p['cargo']['version']['stdout'].strip() == current_cargo['cargo']['version'].strip() and CURRENT_CARGO in current_cargo['cargo']['version'], 'actual current Cargo version')
        check(p['wild_sha256'] == original['wild_sha256'] == built['toolchain']['wild_sha256'], 'same Wild bytes')
        check(p['toolchains']['storeless']['drivers'] == p['toolchains']['compact']['drivers'] == built['toolchain']['drivers'] == package['driver_hashes'], 'same cut/compact compiler bytes')
        driver_sets = [set(p['toolchains'][arm]['drivers'].values()) for arm in ('baseline', 'storeless')]
        check(all(a.isdisjoint(b) for a, b in itertools.combinations(driver_sets, 2)), 'distinct baseline/cut compiler bytes, not inferred from version strings')
        check(p['baseline_original_build']['source_base'] == BASE and p['toolchains']['baseline']['drivers'] == p['baseline_original_build']['drivers'], 'baseline compiler bytes')
        check(all(t['drivers'] and t['version']['returncode'] == 0 for t in p['toolchains'].values()), 'compiler identities complete')
        check(not original['production_pgo_bolt'] and not built['production_pgo_bolt'], 'non-PGO/BOLT scope')
        preparation = load(root / 'preparation.json')
        current_preparation = load(root / 'current-cargo-preparation.json')
        check(p['current_preparation_sha256'] == digest(root / 'current-cargo-preparation.json'), 'actual source-copy preparation')
        check(current_preparation['passed'] and current_preparation['prior_preparation_sha256'] == digest(root / 'preparation.json'), 'source copies retain prior frozen preparation')
        check(current_preparation['current_cargo_receipt_sha256'] == digest(args.current_cargo_receipt), 'source-copy preparation current Cargo binding')
        check(current_preparation['script_sha256'] == 'ca7a18d2072c1cf0ba31b25ad1823e30a7f7b3aeb8ad697af84f0b71bcd4f992', 'reviewed source-copy preparation')
        check(current_preparation['prior_collection_sha256'] == digest(args.prior_collection) and current_preparation['prior_primary_audit_sha256'] == digest(args.prior_primary_audit), 'source preparation sealed-study boundary')
        quiet_path = root / 'current-cargo-quiet/result.json'; quiet = load(quiet_path)
        check(quiet['passed'] and not quiet['accepted'] and quiet['returncode'] == 0 and quiet['script_sha256'] == '3b6845ded13e94c5c67682bf692093827d8141f9428b2a2974feb8b00c5ac552', 'reviewed single-run launcher and separate unaccepted quiet gate')
        check(quiet['argv'] == ['/bin/sleep', '10'] and not quiet['unrelated_compilers'] and len(quiet['outside_cpu_intervals']) < 3 and not quiet['disk_reserve_failed'], 'quiet gate same resource rules')
        quiet_monitor = load(quiet_path.with_name('quiet.monitor.json'))
        check(sum(m['outside_user_cpu_cores'] > 0.5 for m in quiet_monitor) == len(quiet['outside_cpu_intervals']), 'quiet monitor agrees')
        for stage in ('before', 'after'):
            preservation = load(root / f'current-cargo-preservation-{stage}.json')
            check(preservation['passed'] and not preservation['changed'] and preservation['original_failed_status_absent'], ('prior study/binary preservation', stage))
            check(preservation['collection_sha256'] == digest(args.prior_collection) and preservation['prior_primary_audit_sha256'] == digest(args.prior_primary_audit) and preservation['current_cargo_receipt_sha256'] == digest(args.current_cargo_receipt), ('preservation custody anchors', stage))
            check(preservation['protected_files'] >= collection['file_count'], ('collected files included in preservation', stage))
        snapshots = load(args.source_snapshots / 'manifest.json')
        for project in PROJECTS:
            source = p['sources'][project]
            check(source['head']['stdout'].strip() == preparation['sources'][project]['head'], 'project source head')
            check(hashlib.sha256(source['diff']['stdout'].encode()).hexdigest() == preparation['sources'][project]['patch_sha256'], 'compatibility patch')
            check(snapshots[project]['head'] == preparation['sources'][project]['head'], 'snapshot source head')
            copied = current_preparation['sources'][project]
            check(copied['head'] == preparation['sources'][project]['head'] and copied['patch_sha256'] == preparation['sources'][project]['patch_sha256'], 'fresh source-copy identity')
            check(copied['path'].endswith('/current-cargo-sources/' + project) and copied['original'].endswith('/sources/' + project), 'fresh source-copy namespace')
            check(copied['tracked_tree_identical'] and copied['original_unchanged'] and not copied['unexpected_untracked_files'], 'source-copy contracts')
            check(copied['tracked_files'] == len(copied['files']) and copied['tracked_bytes'] == sum(f['bytes'] for f in copied['files'].values()), 'complete copied tracked-file manifest')
            for name, record in snapshots[project]['files'].items():
                file = args.source_snapshots / project / name
                check(digest(file) == record['sha256'] and file.stat().st_size == record['bytes'], ('original fixture bytes', project, name))
                check(copied['files'][name]['sha256'] == record['sha256'] and copied['files'][name]['bytes'] == record['bytes'], ('copied fixture bytes', project, name))
        preflight = load(root / 'fixture-preflight-v2/provenance.json')
        status = load(root / 'fixture-preflight-v2/status.json')
        check(p['fixture_preflight_receipt_sha256'] == digest(root / 'fixture-preflight-v2/status.json'), 'preflight receipt binding')
        check(status['passed'] and status['samples'] == 26 and status['accepted'] == 0, '26 unaccepted fixture preflight commands')
        check(preflight['script_sha256'] == base.HARNESS and preflight['cargo']['sha256'] == original['cargo']['sha256'], 'prior fixture preflight explicitly used old Cargo')
        check(all(preflight['toolchains'][arm]['drivers'] == p['toolchains'][arm]['drivers'] for arm in ARMS), 'prior fixture preflight same compiler implementations')
        preflight_rows = [json.loads(line) for line in (root / 'fixture-preflight-v2/samples.jsonl').read_text().splitlines()]
        check([(r['project'], r['mode'], r['round'], r['phase'], r['state']) for r in preflight_rows] == [(project, 'storeless', 0, phase, list(state)) for project in PROJECTS for phase, state in SEQUENCE], '26 unique preflight states')
        for row in preflight_rows:
            check(row['preflight'] and not row['accepted'] and row['returncode'] == 0 and 'error' not in row, 'preflight succeeded without admission')
            oracle(audit, row)
            wanted = {name: hashlib.sha256(contents).hexdigest() for name, contents in fixture_bytes(args.source_snapshots, row['project'], row['state']).items()}
            check(row['source_sha256'] == wanted, 'preflight source bytes')
        expected_order = [(project, mode, r) for project in PROJECTS for r, order in enumerate(ORDERS) for mode in order]
        check([(c['project'], c['mode'], c['round']) for c in p['plan']] == expected_order, '12 fresh forward/reverse cells')
        plans = {(c['project'], c['mode'], c['round']): c for c in p['plan']}
        for key, c in plans.items():
            env = c['environment']; project, mode, _ = key
            argv = [p['cargo']['path'], '-Zohm-defaults=yes'] + (['-Zohm-compact-artifacts=yes'] if mode == 'compact' else [])
            argv += ['build', '--offline', '--locked', '-vv', '-p', project, '--bin', project, '-j', '8']
            check(c['argv'] == argv, ('exact real Cargo argv', key))
            check(not env['CARGO_ENCODED_RUSTFLAGS'] and not c['logger_environment'], ('no manual flags/logger', key))
            check(env['RUSTC'] == p['toolchains'][mode]['path'] + '/bin/rustc', ('compiler selection', key))
            check(env['RUSTDOC'] == p['toolchains'][mode]['path'] + '/bin/rustdoc', ('rustdoc selection', key))
            for name, child in (('CARGO_TARGET_DIR', 'target'), ('CARGO_BUILD_BUILD_DIR', 'build'), ('TMPDIR', 'scratch')):
                check(env[name] == c['lane'] + '/' + child, ('whole-lane paths', key, name))
            check(env['CARGO_INCREMENTAL'] == '1' and env['CARGO_BUILD_JOBS'] == '8', ('incremental/jobs', key))
            check(env['CARGO_PROFILE_DEV_DEBUG'] == 'line-tables-only' and env['CARGO_PROFILE_DEV_BUILD_OVERRIDE_DEBUG'] == '0', ('debug profile', key))
            check(env.get('CARGO_PROFILE_DEV_OPT_LEVEL') == ('1' if project == 'ruff' else None), ('optimization profile', key))
            check(env.get('CARGO_UNSTABLE_EMBED_METADATA') is None, ('embedding only actual Cargo option', key))
            check(env['CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST'] == env['CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'] == 'all', ('development trust scope', key))
        rows = [json.loads(line) for line in (matrix / 'samples.jsonl').read_text().splitlines()]
        expected = [(project, mode, r, phase, list(state)) for project, mode, r in expected_order for phase, state in SEQUENCE]
        check([(r['project'], r['mode'], r['round'], r['phase'], r['state']) for r in rows] == expected, 'all156 ordered unique samples')
        status = load(matrix / 'status.json')
        check(status['passed'] and status['samples'] == status['accepted'] == 156 and not (matrix / 'failure.json').exists(), 'complete matrix, no discarded failure')
        state_sources = {}; state_patches = {}; grouped = defaultdict(list); anomalies = []; log_scope = []
        for row in rows:
            key = (row['project'], row['mode'], row['round']); cell = plans[key]; grouped[key].append(row)
            context = (*key, row['phase'], row['state'])
            check(row['accepted'] and not row['preflight'] and row['returncode'] == 0 and 'error' not in row, ('accepted', context))
            check(row['argv'] == cell['argv'], ('command matches plan', context))
            check(not row['unrelated_compilers'] and not row['disk_reserve_failed'], ('compiler/disk gates', context))
            check(len(row['outside_cpu_intervals']) < 3 and not row['instrumented_disk'] and row['sampled_peak_allocated_bytes'] is None, ('resource admission', context))
            check(row['wall_seconds'] > 0 and row['user_seconds'] >= 0 and row['system_seconds'] >= 0, ('times', context))
            remote = Path(row['log']); local = matrix / remote.parent.name / remote.name
            check(local.parent.name == f'{key[0]}-{key[1]}-{key[2]}', ('per-cell receipt path', context))
            text = local.read_text(errors='replace'); check(not any('-Z' + f in text for f in REMOVED), ('no research flags', context))
            crates = re.findall(r'Running [^\n]*\brustc\b[^\n]*--crate-name ([^\s]+)', text)
            check(crates == row['compiler_crates'], ('compiler log receipt', context))
            commands = [line for line in text.splitlines() if 'Running `' in line and '/bin/rustc ' in line]
            if row['phase'].startswith('noop'):
                check(not commands, ('no compiler or link-only invocation during noop', context))
            for command in commands:
                check(cell['environment']['RUSTC'] in command, ('right compiler invoked', context))
                if row['mode'] == 'compact':
                    check('-Zcompact-artifacts=yes' in command and '-Zartifact-compression-profile=fast' in command, ('generated compact/fast flags', context))
                    check('-Zembed-metadata=no' not in command, ('self-contained metadata', context))
                else:
                    check('-Zcompact-artifacts' not in command and '-Zartifact-compression-profile' not in command, ('ordinary generated flags', context))
            monitor = load(local.with_suffix('.monitor.json'))
            check(monitor and row['sampled_process_tree_peak_rss_bytes'] == max(x['rss'] for x in monitor), ('summed RSS receipt', context))
            spikes = [x for x in monitor if x['outside_user_cpu_cores'] > 0.5]
            check(len(spikes) == len(row['outside_cpu_intervals']), ('interference sample count', context))
            for sample, recorded in zip(spikes, row['outside_cpu_intervals']):
                audit.close(sample['outside_user_cpu_cores'], recorded['cores'], ('outside CPU value', context))
                check(abs(sample['time'] - recorded['time']) < 0.1, ('outside CPU time', context))
            if spikes:
                anomalies.append({'cell': key, 'phase': row['phase'], 'state': row['state'], 'spikes': spikes})
            resources = local.with_suffix('.time').read_text()
            for label, field, multiplier in (('User time (seconds)', 'user_seconds', 1), ('System time (seconds)', 'system_seconds', 1), ('Maximum resident set size (kbytes)', 'max_child_rss_bytes', 1024)):
                match = re.search(r'^\s*' + re.escape(label) + r':\s*(\S+)', resources, re.M)
                check(match and float(match[1]) * multiplier == row[field], ('GNU time metric', context, field))
            check(re.search(r'^\s*Exit status:\s*0\s*$', resources, re.M), ('GNU time exit', context))
            check(load(local.with_suffix('.oracle.json')) == row['oracle'], ('raw oracle receipt', context)); oracle(audit, row)
            check(digest(local.with_suffix('.patch')) == row['patch_sha256'], ('saved source patch', context))
            skey = (row['project'], tuple(row['state']))
            if skey not in state_sources:
                state_sources[skey] = {name: hashlib.sha256(contents).hexdigest() for name, contents in fixture_bytes(args.source_snapshots, *skey).items()}
                state_patches[skey] = row['patch_sha256']
            check(row['source_sha256'] == state_sources[skey], ('reconstructed source bytes', context))
            check(row['patch_sha256'] == state_patches[skey], ('same full source diff for matched state', context))
            census = row['census']
            for field in ('allocated', 'logical'):
                check(census[field] == sum(c[field] for c in census['categories'].values()), ('storage category sums', context, field))
            check(census['files'] + census['directories'] == sum(c['entries'] for c in census['categories'].values()), ('census entries', context))
            check(not census['categories'].get('compact-store', {}).get('allocated', 0), ('no external object store', context))
            if row['phase'] in ('clean', 'noop-final'):
                f = row['formats']; counts = f['counts']; metadata = f['metadata_formats']
                check(f['passed'] and metadata['raw'] > 0 and metadata['packed'] == metadata['other'] == 0, ('raw metadata', context))
                check(counts.get('archive', 0) > 0 and not counts.get('manifest', 0) and not counts.get('wrapper', 0), ('ordinary self-contained ar', context))
                check((f['archive_member_formats']['compact'] > 0) == (row['mode'] == 'compact'), ('compact members', context))
                check((counts.get('object', 0) > 0) == (row['mode'] == 'compact'), ('incremental object format', context))
            if row['phase'] in ('synthetic-inline', 'real-direct', 'real-library'):
                check(commands, ('real rebuild occurred', context))
                log_scope.append({'cell': key, 'phase': row['phase'], 'state': row['state'], 'compiler_crates': crates, 'link_only_commands': sum('-Zlink-only' in c or '-Z link-only' in c for c in commands), 'log_sha256': digest(local)})
        for key, cell in grouped.items():
            for i in (1, 12):
                check(not cell[i]['compiler_crates'] and cell[i]['oracle']['binary_sha256'] == cell[i - 1]['oracle']['binary_sha256'], ('no-op binary identity', key, i))
        metrics = {'wall_seconds': lambda r: r['wall_seconds'], 'user_seconds': lambda r: r['user_seconds'], 'system_seconds': lambda r: r['system_seconds'], 'cpu_seconds': lambda r: r['user_seconds'] + r['system_seconds'], 'max_child_rss_bytes': lambda r: r['max_child_rss_bytes'], 'sampled_process_tree_peak_rss_bytes': lambda r: r['sampled_process_tree_peak_rss_bytes'], 'allocated_bytes': lambda r: r['census']['allocated'], 'logical_bytes': lambda r: r['census']['logical']}
        index = {(r['project'], r['mode'], r['round'], r['phase'], tuple(r['state'])): r for r in rows}
        comparisons = []
        for (left, right), project, phase in itertools.product(PAIRINGS, PROJECTS, dict(SEQUENCE)):
            pairs = [(r, index[(project, right, r['round'], phase, tuple(r['state']))]) for r in rows if (r['project'], r['mode'], r['phase']) == (project, left, phase)]
            group = {'reference': left, 'candidate': right, 'project': project, 'phase': phase, 'n': len(pairs)}
            check(len(pairs) == (6 if phase in ('synthetic-inline', 'real-direct', 'real-library') else 2), 'paired sample count')
            group.update({name: pair_metrics(pairs, getter) for name, getter in metrics.items()})
            group['rounds'] = [{'round': i, 'n': len(part), **{name: pair_metrics(part, getter) for name, getter in metrics.items()}} for i in range(2) if (part := [(a, b) for a, b in pairs if a['round'] == i])]
            comparisons.append(group)
        if args.summary:
            summary = load(args.summary)
            check(summary['counts'] == {'accepted': 156, 'cells': 12, 'projects': 2, 'arms': 3, 'rounds': 2, 'edits_per_round': 3, 'independent_rounds': 2}, 'summary exact current confirmation dimensions')
            ours = {(g['reference'], g['candidate'], g['project'], g['phase']): g for g in comparisons}
            theirs = {(g['reference'], g['candidate'], g['project'], g['phase']): g for g in summary['comparisons']}
            check(len(summary['comparisons']) == len(theirs) and set(ours) == set(theirs), 'all independent summary comparisons')
            names = {'reference_mean': 'reference_mean', 'candidate_mean': 'candidate_mean', 'delta_mean': 'delta_mean', 'percent': 'ratio_of_means_percent', 'paired_percent_median': 'paired_percent_median'}
            for key, expected in ours.items():
                actual = theirs[key]; check(actual['n_pairs'] == expected['n'], ('summary count', key))
                check(set(actual['metrics']) == set(metrics) - {'logical_bytes'}, ('complete summary metrics', key))
                for metric, values in actual['metrics'].items():
                    check(metric in metrics, ('known summary metric', metric))
                    for theirs_name, our_name in names.items():
                        audit.close(values[theirs_name], expected[metric][our_name], ('summary metric', key, metric, theirs_name))
                    audit.close(values['paired_percent_min'], expected[metric]['paired_percent_range'][0], ('summary minimum', key, metric))
                    audit.close(values['paired_percent_max'], expected[metric]['paired_percent_range'][1], ('summary maximum', key, metric))
                    check(values['n_percent_pairs'] == expected[metric]['n_percent_pairs'], ('defined percentage pairs', key, metric))
                    check([r['round'] for r in values['rounds']] == list(range(2)), ('summary all rounds', key, metric))
                    for r, e in zip(values['rounds'], expected['rounds']):
                        check(r['n_pairs'] == e['n'], ('round pair count', key, metric))
                        for theirs_name, our_name in list(names.items())[:4]:
                            audit.close(r[theirs_name], e[metric][our_name], ('independent round metric', key, metric, r['round'], theirs_name))
            result['summary_sha256'] = digest(args.summary)
        result.update(passed=True, shared_auditor_sha256=digest(Path(base.__file__)), current_cargo_receipt_sha256=digest(args.current_cargo_receipt), prior_primary_audit_sha256=digest(args.prior_primary_audit), prior_collection_sha256=digest(args.prior_collection), commands=len(rows), preflight_commands=len(preflight_rows), checks=audit.checks, matrix_sha256=digest(matrix / 'samples.jsonl'), comparisons=comparisons, interference=anomalies, edit_log_scope=log_scope,
                      scope='Two fresh forward/reverse rounds per project/arm; three sequential edits per class, not six independent rounds. Pair precedence is balanced but the ordinary-cut arm remains in the middle position. All arms use currentCargo6333 and Wild9179. This confirms current integration; it does not isolate the Cargo4a-to6333 change. Full-lane allocated bytes include target/build/scratch and deduplicate hardlinks; they exclude source/download caches and are not peak disk or unique CoW extents. Summed sampled RSS is not PSS.')
    except BaseException as error:
        result.update(error=f'{type(error).__name__}: {error}', checks=audit.checks)
        raise
    finally:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('comparisons', 'interference', 'edit_log_scope')}, indent=2))


if __name__ == '__main__':
    main()
