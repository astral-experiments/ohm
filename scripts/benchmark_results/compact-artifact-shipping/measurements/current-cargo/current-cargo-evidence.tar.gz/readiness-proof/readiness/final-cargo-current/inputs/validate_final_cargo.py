"""Post-matrix functional alignment with published Cargo. Never changes timing binaries."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,platform,re,shutil,subprocess,time
ROOT=Path('/home/dev-user/code/oss/ohm-compact-study');WORK=ROOT/'shipping/readiness'
DEST=WORK/'final-cargo-current';EVIDENCE=DEST/'evidence';INPUTS=Path(__file__).resolve().parent
TARGET=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/final-cargo-current')
RUST='36f01299cd71f6c090150a80fe4a7babb6245a0b';CUT='3b84b46e3fb38f80246f744275c69fe608dfb2f3'
CARGO='6333daf7cf99cf80125234c9419cbd36e9bff81a';PRIOR_CARGO='0d39870c83ccf09a250e55d9dd13a83d606b72be';OLD_CARGO='4a2813050da607ca5cfe7b5cf3a17ba7c9676be1'
WILD='9179eb988df2676342192a24dc337cf9823e9d56';TRIPLE='x86_64-unknown-linux-gnu'
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(path):return json.loads(path.read_text())
def output(args,cwd=None):return subprocess.check_output(list(map(str,args)),cwd=cwd,text=True).strip()
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def snapshot(root):
 return {str(p):digest(p) for p in sorted(root.rglob('*')) if p.is_file()}
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute-after-matrix-handover',action='store_true',required=True);parser.parse_args()
assert platform.system()=='Linux' and platform.machine()=='x86_64'
status_path=WORK/'evidence/real-edit-primary/status.json';samples_path=status_path.with_name('samples.jsonl')
selection_path=status_path.with_name('selection.json');audit_path=DEST/'independent-matrix-audit.json'
status=load(status_path)
assert status['passed'] and status['samples']==status['accepted']==416
assert status['raw_samples']==443 and status['excluded']==27 and status['derived']
collection_path=WORK/'evidence/collection.json';collection=load(collection_path)
handover_path=DEST/'measurement-handover.json';handover=load(handover_path);audit=load(audit_path)
assert collection['passed'] and handover['passed'] and handover['verified_files']==collection['file_count']>0
assert handover['collection_sha256']==digest(collection_path)
assert handover['independent_audit_sha256']==digest(audit_path)
assert audit['passed'] and audit['commands']==416 and audit['raw_commands']==443
assert audit['transferred_files_verified']==handover['verified_files']
assert audit['auditor_sha256']=='8b881f0708ffc8901382ff7e53d6a9c3dc846bdd6a34ee44e8ac3fd740b4a69d'
assert audit['selection_auditor_sha256']=='aef2ba23bf68e1a8e8f6380ef7a61d8fd806f1c47039ee860aa30d05e639d89c'
assert audit['shared_auditor_sha256']=='1ca96fce0f17711de6737cf87ddd1c4bb49cbe39d3dff87770952288b45d6f5d'
assert audit['matrix_sha256']==digest(samples_path)
for key,path in [('matrix_status_sha256',status_path),('matrix_samples_sha256',samples_path),('selection_sha256',selection_path)]:
 assert collection[key]==handover[key]==digest(path)
assert handover['raw_runs']==collection['raw_runs']
selection=load(selection_path)
assert selection['source_runs']==collection['raw_runs']
assert selection['counts']=={'raw':443,'primary':416,'excluded':27,'excluded_accepted':26,'excluded_rejected':1}
assert selection['primary_samples_sha256']==digest(samples_path)
assert len(selection['selected_rows'])==416 and len(selection['excluded_rows'])==27
selected=audit['continuation_selection']
assert selected['excluded']=={'rows':27,'accepted':26,'rejected':1,'original_indices':list(range(312,339))}
custody_paths=[status_path,samples_path,selection_path,collection_path,handover_path,audit_path]
for label,directory,rows,accepted in [('initial','real-edit-matrix',339,338),('continuation','real-edit-continuation',104,104),('primary','real-edit-primary',416,416)]:
 row=selected[label];run=WORK/'evidence'/directory
 assert Path(row['directory']).name==directory and row['rows']==rows and row['accepted']==accepted
 for field,name in [('samples_sha256','samples.jsonl'),('provenance_sha256','provenance.json')]:
  path=run/name;assert row[field]==digest(path);custody_paths.append(path)
 if label=='initial':
  assert row['status_absent'] and not (run/'status.json').exists()
  path=run/'failure.json';assert row['failure_sha256']==digest(path);custody_paths.append(path)
 else:
  path=run/'status.json';assert row['status_sha256']==digest(path);custody_paths.append(path)
  observed=load(path);assert observed['passed'] and observed['samples']==rows and observed['accepted']==accepted
 if label!='primary':
  raw=collection['raw_runs'][label]
  assert raw['rows']==rows and raw['accepted']==accepted and raw['samples_sha256']==row['samples_sha256']
assert selected['primary']['selection_sha256']==digest(selection_path)
quiet_path=WORK/'evidence/continuation-quiet/result.json'
assert selected['quiet_receipt_sha256']==digest(quiet_path);custody_paths.append(quiet_path)
for key,path in [('policy_sha256',WORK/'harness/continuation-plan.json'),('continuation_harness_sha256',WORK/'harness/benchmark_readiness_continuation.py')]:
 assert selected[key]==digest(path);custody_paths.append(path)
assert load(WORK/'evidence/correctness/result.json')['passed']
assert not EVIDENCE.exists() and not TARGET.exists()
for name in ['source','rust-proof.git','toolchain','fixture']:assert not (DEST/name).exists()
assert shutil.disk_usage(WORK).free>15*1024**3
inputs=load(INPUTS/'inputs.json');assert inputs['sources']=={'rust':RUST,'cargo':CARGO,'wild':WILD} and inputs['runtime_source']==CUT
for name,h in inputs['sha256'].items():assert Path(name).name==name and digest(INPUTS/name)==h
build_path=WORK/'evidence/candidate-build/result.json';build=load(build_path);package_path=WORK/'evidence/candidate-package/result.json';package=load(package_path)
assert build['passed'] and package['passed'] and build['patch_sha256']==package['patch_sha256']==load(INPUTS/'candidate-manifest.json')['patch_sha256']
assert package['driver_hashes']==build['toolchain']['drivers'] and build['wild']==WILD
sysroot=Path(build['toolchain']['path']);assert sysroot==WORK/'toolchains/storeless'
installed=Path(package['prefix']);assert installed==Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness/installed-smoke/toolchain')
old_cargo=ROOT/'shipping/final-review/bin/cargo';assert digest(old_cargo)==build['toolchain']['cargo_sha256']
assert package['cargo_sha256']==build['toolchain']['cargo_sha256']
for prefix in (sysroot,installed):
 for name,h in build['toolchain']['drivers'].items():assert digest(prefix/'lib'/name)==h
 assert digest(prefix/'bin/rustc')==build['toolchain']['rustc_sha256']
 linker=prefix/('lib/rustlib/'+TRIPLE+'/bin/wild-ld')
 assert digest(linker/'ld.bfd')==build['toolchain']['wild_sha256']==package['wild_sha256']
 assert (linker/'compact-artifacts-v1').read_bytes()==b'RCOBJ001\n'
assert digest(installed/'bin/rustdoc')==digest(sysroot/'bin/rustdoc')
original_sources={'cargo':ROOT/'shipping/cargo','rust':ROOT/'rust','wild':ROOT/'wild'}
source_heads={}
for name,path in original_sources.items():
 assert output(['git','rev-parse','--show-toplevel'],path)==str(path)
 assert output(['git','config','user.email'],path)=='charlie.r.marsh@gmail.com'
 assert not output(['git','status','--porcelain','--ignore-submodules=all'],path)
 source_heads[name]=output(['git','rev-parse','HEAD'],path)
assert source_heads=={'cargo':OLD_CARGO,'rust':inputs['bases']['rust'],'wild':WILD}
# Snapshot existing sysroots, installed prefix, and timing Cargo; all writes use new paths.
protected={**snapshot(sysroot),**snapshot(installed),str(old_cargo):digest(old_cargo),**{str(p):digest(p) for p in custody_paths}}
EVIDENCE.mkdir();TARGET.mkdir()
receipt={'passed':False,'started':time.time(),'sources':inputs['sources'],'runtime_source_commit':CUT,'timing_cargo_source':OLD_CARGO,'scope':'Post-matrix published-Cargo functional alignment only. Existing non-PGO compiler and actual installed component are reused byte-for-byte; no compiler rebuild, timing rerun, full release or credential setup.','input_manifest_sha256':digest(INPUTS/'inputs.json'),'script_sha256':digest(Path(__file__)),'matrix_handover':handover,'candidate_build_sha256':digest(build_path),'candidate_package_sha256':digest(package_path),'protected_files':len(protected),'commands':[]}
write(EVIDENCE/'protected-before.json',protected)
def save():write(EVIDENCE/'result.json',receipt)
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST'))};env.update(CARGO_HOME='/tmp/codex-cargo-home',CARGO_BUILD_JOBS='6',PYTHONDONTWRITEBYTECODE='1')
def run(name,args,cwd=DEST,extra=None,expected=0):
 log=EVIDENCE/(name+'.log');assert not log.exists();row={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'environment_overrides':extra or {}};receipt['commands'].append(row);save();start=time.monotonic()
 with log.open('w') as stream:result=subprocess.run(row['argv'],cwd=cwd,env={**env,**(extra or {})},stdout=stream,stderr=subprocess.STDOUT)
 row.update(exit_code=result.returncode,seconds=time.monotonic()-start,log_sha256=digest(log));save();assert result.returncode==expected,(name,result.returncode,log)
 print(json.dumps(row),flush=True);return log
save()
try:
 source=DEST/'source';proof=DEST/'rust-proof.git'
 run('cargo-clone',['git','clone','--shared','--no-checkout',original_sources['cargo'],source])
 run('cargo-oss-name',['git','config','--local','user.name',output(['git','config','user.name'],original_sources['cargo'])],source)
 run('cargo-oss-email',['git','config','--local','user.email','charlie.r.marsh@gmail.com'],source)
 assert output(['git','config','user.email'],source)=='charlie.r.marsh@gmail.com'
 run('cargo-bundle-verify',['git','bundle','verify',INPUTS/'cargo.bundle'],source)
 run('cargo-bundle-fetch',['git','fetch','--no-tags','--no-recurse-submodules',INPUTS/'cargo.bundle','refs/heads/charlie/current-proof','refs/heads/charlie/prior-proof'],source)
 run('cargo-checkout',['git','checkout','--detach',CARGO],source)
 assert output(['git','rev-parse','HEAD'],source)==CARGO and not output(['git','status','--porcelain'],source)
 run('rust-proof-clone',['git','clone','--bare','--shared',original_sources['rust'],proof])
 run('rust-proof-bundle-verify',['git','bundle','verify',INPUTS/'rust.bundle'],proof)
 run('rust-proof-bundle-fetch',['git','fetch','--no-tags','--no-recurse-submodules',INPUTS/'rust.bundle','refs/heads/charlie/current-proof','refs/heads/charlie/prior-proof'],proof)
 assert output(['git','rev-parse',RUST+':src/tools/cargo'],proof)==CARGO
 assert output(['git','diff','--no-renames','--name-only',CUT,RUST],proof)=='src/tools/cargo'
 assert output(['git','rev-parse',CUT+'^'],proof)==inputs['bases']['rust']
 manifest=load(INPUTS/'candidate-manifest.json')
 assert set(output(['git','diff','--no-renames','--name-only',inputs['bases']['rust'],CUT],proof).splitlines())==set(manifest['files'])
 for name,h in manifest['files'].items():
  blob=subprocess.run(['git','show',CUT+':'+name],cwd=proof,capture_output=True)
  assert (hashlib.sha256(blob.stdout).hexdigest() if blob.returncode==0 else None)==h,name
 assert output(['git','diff','--name-only',OLD_CARGO,PRIOR_CARGO],source)=='src/compiler/ohm_linker.rs'
 cargo_audit=load(INPUTS/'cargo-source-review.json');rust_audit=load(INPUTS/'rust-source-equivalence.json')
 assert cargo_audit['sources']['current_cargo']==CARGO and cargo_audit['sources']['prior_published_cargo']==PRIOR_CARGO and cargo_audit['sources']['measured_cargo']==OLD_CARGO
 for revision,tree in cargo_audit['trees'].items():assert output(['git','rev-parse',revision+'^{tree}'],source)==tree
 cargo_paths=output(['git','diff','--no-renames','--name-only',PRIOR_CARGO,CARGO],source).splitlines()
 assert set(cargo_paths)==set(cargo_audit['changed_paths'])
 for name in cargo_audit['compact_files_byte_identical']+['Cargo.lock']:
  assert output(['git','rev-parse',PRIOR_CARGO+':'+name],source)==output(['git','rev-parse',CARGO+':'+name],source),name
 assert rust_audit['remote_tip']==RUST
 for name,blobs in rust_audit['trees_and_blobs'].items():
  assert blobs['before']==blobs['after']==output(['git','rev-parse',RUST+':'+name],proof)==output(['git','rev-parse',CUT+':'+name],proof),name
 consistency={'sources':{'rust':{'repository':'https://github.com/astral-sh/ohm-rust','revision':RUST},'cargo':{'repository':'https://github.com/astral-sh/ohm-cargo','revision':CARGO}},'bundled_tools':{'wild':{'version':'0.10.0','source':{'repository':'https://github.com/astral-sh/ohm-wild','revision':WILD}}},'validation_scope':'Exact source/gitlink consistency and installed smoke only; this source subset is not a complete production release manifest.'}
 source_manifest=EVIDENCE/'source-manifest.json';write(source_manifest,consistency)
 receipt['source_proof']={'rust_cargo_gitlink':CARGO,'runtime_matches_frozen_patch':True,'published_rust_delta':['src/tools/cargo'],'cargo_delta':output(['git','diff','--stat',OLD_CARGO,CARGO],source),'verified_runtime_paths':len(manifest['files']),'wild_compact_tree':output(['git','rev-parse','HEAD:compact-artifact'],original_sources['wild']),'cargo_tip_to_tip_paths':cargo_paths,'cargo_tree':output(['git','rev-parse',CARGO+'^{tree}'],source),'cargo_source_review_sha256':digest(INPUTS/'cargo-source-review.json'),'rust_source_equivalence_sha256':digest(INPUTS/'rust-source-equivalence.json'),'current_cargo_has_unmeasured_inherited_scheduler_changes':True};save()
 # Copy only the compatible release cache, capped at 10 GiB allocated. Never mutate its source.
 old_cache=Path('/tmp/codex-cargo-targets/ohm/isolated/compact-objects/shipping-cargo/release');assert old_cache.is_dir()
 assert not old_cache.is_symlink(), 'release cache root must not be a symlink'
 assert not any(p.is_symlink() for p in old_cache.rglob('*')), 'release cache must not contain symlinks'
 receipt['release_cache_symlinks_rejected_before_copy']=True;save()
 cache_bytes=int(output(['du','-s','-B1',old_cache]).split()[0]);assert cache_bytes<=10*1024**3
 assert shutil.disk_usage(TARGET).free>cache_bytes+8*1024**3
 cache=TARGET/'build';cache.mkdir()
 run('copy-release-cache',['cp','-a','--reflink=auto',old_cache,cache/'release'])
 before_build_rs=digest(source/'build.rs');os.utime(source/'build.rs',None);assert digest(source/'build.rs')==before_build_rs
 run('cargo-build',['cargo','+ohm','-Zohm-defaults=no','build','--locked','--offline','--release','--features','ohm-defaults','--bin','cargo'],source,{'CARGO_TARGET_DIR':str(cache)})
 prefix=DEST/'toolchain';run('copy-installed-prefix',['cp','-aL','--reflink=auto',installed,prefix])
 shutil.copy2(cache/'release/cargo',prefix/'bin/cargo')
 version=output([prefix/'bin/cargo','-vV']);assert CARGO in version
 for p,h in protected.items():
  path=Path(p)
  if path.is_relative_to(installed) and path.relative_to(installed)!=Path('bin/cargo'):assert digest(prefix/path.relative_to(installed))==h
 receipt['cargo']={'path':str(prefix/'bin/cargo'),'version':version,'sha256':digest(prefix/'bin/cargo'),'build_target':str(cache),'cache_copy_allocated_bytes':cache_bytes}
 receipt['toolchain']={'path':str(prefix),'drivers':build['toolchain']['drivers'],'rustc_sha256':digest(prefix/'bin/rustc'),'rustdoc_sha256':digest(prefix/'bin/rustdoc'),'wild_sha256':build['toolchain']['wild_sha256'],'cargo_sha256':receipt['cargo']['sha256'],'runtime_source_commit':CUT,'published_rust_source':RUST,'cargo_source':CARGO,'wild_source':WILD};save()
 crate=DEST/'fixture';fixture={}
 for relative in ['Cargo.toml','macros/Cargo.toml','macros/src/lib.rs','src/main.rs','src/lib.rs']:
  expression=r'cat > "\$smoke_crate/'+re.escape(relative)+r'" <<\x27EOF\x27\n(.*?)\nEOF\n';found=re.findall(expression,(INPUTS/'smoke-test-release.sh').read_text(),re.DOTALL);assert len(found)==1,relative
  p=crate/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(found[0]+'\n');fixture[relative]=digest(p)
 case=TARGET/'smoke';case.mkdir();extra={'RUSTC':str(prefix/'bin/rustc'),'RUSTDOC':str(prefix/'bin/rustdoc'),'CARGO_TARGET_DIR':str(case/'defaults-target'),'CARGO_BUILD_BUILD_DIR':str(case/'defaults-build')}
 run('defaults-build',[prefix/'bin/cargo','build','--offline','--manifest-path',crate/'Cargo.toml'],crate,extra)
 run('defaults-runtime',[case/'defaults-target/debug/ohm-smoke'],crate)
 run('compact-installed-smoke',['python3',INPUTS/'smoke_test_compact.py',source_manifest,TRIPLE,prefix,crate,case],crate,extra)
 spec=importlib.util.spec_from_file_location('smoke',INPUTS/'smoke_test_compact.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
 receipt['default_compact_members']=helper.compact_members(case/'defaults-target/debug/libohm_smoke.rlib');receipt['optin_compact_members']=helper.compact_members(case/'compact-target/debug/libohm_smoke.rlib')
 assert receipt['default_compact_members']==0 and receipt['optin_compact_members']>0
 # The removed research flags must fail clearly at the compiler boundary, without output.
 rejected=case/'removed-options';rejected.mkdir();lib=rejected/'lib.rs';lib.write_text('pub fn value() -> u32 { 42 }\n')
 receipt['removed_options']={}
 for option,value in [('compress-artifacts','yes'),('compress-incremental','no'),('compact-artifact-store',str(rejected/'unused-store')),('compact-artifact-raw-metadata','yes')]:
  artifact=rejected/(option+'.rmeta')
  log=run('reject-'+option,[prefix/'bin/rustc','-Z'+option+'='+value,'--crate-type=lib','--emit=metadata',lib,'-o',artifact],rejected,{'RUSTC_BOOTSTRAP':'1'},1)
  error=log.read_text();assert 'unknown unstable option' in error and option in error and 'internal compiler error' not in error and 'panicked' not in error and not artifact.exists()
  receipt['removed_options'][option]={'exit_code':1,'diagnostic':'unknown unstable option','no_output':True}
 assert not (rejected/'unused-store').exists()
 assert not output(['git','status','--porcelain'],source)
 receipt.update(passed=True,fixture_sha256=fixture,installed_compiler_matches_candidate=True,source_gitlink_consistency=True,smoke_contract={'modes':['default','compact-optin'],'executable_runtime':True,'library_runtime':True,'proc_macro_expansion_runtime':True,'compact_linked_by_wild':True})
except BaseException as error:receipt['error']=f'{type(error).__name__}: {error}';raise
finally:
 unchanged=all(Path(p).is_file() and digest(Path(p))==h for p,h in protected.items());receipt['timing_and_original_installed_binaries_unchanged']=unchanged
 receipt['original_sources_unchanged']=all(output(['git','rev-parse','HEAD'],p)==source_heads[n] and not output(['git','status','--porcelain','--ignore-submodules=all'],p) for n,p in original_sources.items())
 receipt['interrupted_original_status_remains_absent']=not (WORK/'evidence/real-edit-matrix/status.json').exists()
 if not unchanged or not receipt['original_sources_unchanged'] or not receipt['interrupted_original_status_remains_absent']:receipt['passed']=False
 receipt['finished']=time.time();save();assert unchanged and receipt['original_sources_unchanged'] and receipt['interrupted_original_status_remains_absent']
