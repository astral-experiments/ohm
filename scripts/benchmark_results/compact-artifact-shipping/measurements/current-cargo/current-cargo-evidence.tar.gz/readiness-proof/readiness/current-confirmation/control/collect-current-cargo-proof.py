from pathlib import Path
import hashlib,json,time
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping')
dest=root/'readiness/final-cargo-current'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
result=json.loads((dest/'evidence/result.json').read_text())
assert result['passed'] and result['sources']['cargo']=='6333daf7cf99cf80125234c9419cbd36e9bff81a'
assert result['script_sha256']=='7c70ca6bc6c00cdec1d47750bc28889ce146001550c60ea02ba9812370fe4a01'
manifest=dest/'evidence/collection.json';assert not manifest.exists()
paths=['readiness/final-cargo-current/evidence','readiness/final-cargo-current/inputs',
       'readiness/final-cargo-current/independent-matrix-audit.json','readiness/final-cargo-current/measurement-handover.json']
files=[]
for name in paths:
    p=root/name
    for f in sorted(p.rglob('*')) if p.is_dir() else [p]:
        assert not f.is_symlink(),str(f)
        if f.is_file():files.append({'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':digest(f)})
receipt={'passed':True,'result_sha256':digest(dest/'evidence/result.json'),'file_count':len(files),
         'total_bytes':sum(f['bytes'] for f in files),'paths':paths,'files':files,'created':time.time()}
manifest.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
