"""Local synthetic integration-auditor control; never produces timing evidence."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
EVIDENCE = Path('/private/tmp/ohm-compact-shipping/receipts/readiness/evidence')
sys.path.insert(0, str(HERE))
import audit_current_confirmation as audit


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


result = {'passed': False, 'synthetic_test_only': True,
          'scope': 'Relabels prior real156 rows into a synthetic current-Cargo fixture and fabricates current build/preparation gates solely to test the auditor. No generated row, hash identity, smoke result, or statistic is an actual current-Cargo measurement; temporary data is removed.'}
with tempfile.TemporaryDirectory(prefix='current-audit-unit-', dir='/private/tmp') as temp:
    work = Path(temp); evidence = work / 'evidence'; evidence.mkdir()
    for path in EVIDENCE.iterdir():
        if not path.name.startswith('current-cargo-'):
            (evidence / path.name).symlink_to(path, target_is_directory=path.is_dir())
    matrix = evidence / 'current-cargo-matrix'; matrix.mkdir()
    original = audit.load(EVIDENCE / 'real-edit-primary/provenance.json')
    old_rows = [json.loads(line) for line in (EVIDENCE / 'real-edit-primary/samples.jsonl').read_text().splitlines()]
    candidate = audit.load(EVIDENCE / 'candidate-build/result.json')
    prior_audit = ROOT / 'independent-primary-audit.json'; collection = EVIDENCE / 'collection.json'
    cargo_dir = work / 'current-proof'; cargo_dir.mkdir(); cargo_path = cargo_dir / 'result.json'
    cargo = '/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/final-cargo-current/toolchain/bin/cargo'
    version = 'synthetic cargo version; commit ' + audit.CURRENT_CARGO
    current = {'passed': True, 'sources': {'rust': audit.PUBLISHED_RUST, 'cargo': audit.CURRENT_CARGO, 'wild': audit.WILD},
               'runtime_source_commit': audit.CUT, 'script_sha256': '7c70ca6bc6c00cdec1d47750bc28889ce146001550c60ea02ba9812370fe4a01',
               'input_manifest_sha256': 'ab614ea2c422797fb57498552ccc1c1bbb42a649e11bd7d9b9b1cc62166097b0',
               'installed_compiler_matches_candidate': True, 'source_gitlink_consistency': True,
               'timing_and_original_installed_binaries_unchanged': True, 'original_sources_unchanged': True,
               'default_compact_members': 0, 'optin_compact_members': 1,
               'cargo': {'path': cargo, 'sha256': 'f' * 64, 'version': version},
               'candidate_build_sha256': sha(EVIDENCE / 'candidate-build/result.json'),
               'candidate_package_sha256': sha(EVIDENCE / 'candidate-package/result.json'),
               'matrix_handover': {'independent_audit_sha256': sha(prior_audit), 'collection_sha256': sha(collection)},
               'smoke_contract': {'modes': ['default', 'compact-optin'], 'executable_runtime': True, 'library_runtime': True, 'proc_macro_expansion_runtime': True, 'compact_linked_by_wild': True}}
    current['toolchain'] = {'drivers': candidate['toolchain']['drivers'], 'rustc_sha256': candidate['toolchain']['rustc_sha256'],
                            'wild_sha256': candidate['toolchain']['wild_sha256'], 'cargo_sha256': 'f' * 64,
                            'cargo_source': audit.CURRENT_CARGO, 'published_rust_source': audit.PUBLISHED_RUST, 'runtime_source_commit': audit.CUT}
    current['commands'] = []
    for name in ['defaults-build', 'defaults-runtime', 'compact-installed-smoke']:
        log = cargo_dir / (name + '.log'); log.write_text('synthetic test-only fixture\n')
        current['commands'].append({'name': name, 'exit_code': 0, 'log_sha256': sha(log)})
    save(cargo_path, current)
    preparation = {'passed': True, 'script_sha256': 'ca7a18d2072c1cf0ba31b25ad1823e30a7f7b3aeb8ad697af84f0b71bcd4f992',
                   'prior_preparation_sha256': sha(EVIDENCE / 'preparation.json'), 'current_cargo_receipt_sha256': sha(cargo_path),
                   'prior_collection_sha256': sha(collection), 'prior_primary_audit_sha256': sha(prior_audit), 'sources': {}}
    snapshots = audit.load(EVIDENCE / 'fixture-originals/manifest.json')
    for project, snapshot in snapshots.items():
        files = {name: {'kind': 'file', 'executable': False, **record} for name, record in snapshot['files'].items()}
        prepared = audit.load(EVIDENCE / 'preparation.json')['sources'][project]
        preparation['sources'][project] = {'head': prepared['head'], 'patch_sha256': prepared['patch_sha256'],
            'path': '/synthetic/current-cargo-sources/' + project, 'original': '/synthetic/sources/' + project,
            'tracked_tree_identical': True, 'original_unchanged': True, 'unexpected_untracked_files': [],
            'files': files, 'tracked_files': len(files), 'tracked_bytes': sum(f['bytes'] for f in files.values())}
    save(evidence / 'current-cargo-preparation.json', preparation)
    for stage in ['before', 'after']:
        save(evidence / f'current-cargo-preservation-{stage}.json', {'passed': True, 'changed': [], 'original_failed_status_absent': True,
             'collection_sha256': sha(collection), 'prior_primary_audit_sha256': sha(prior_audit),
             'current_cargo_receipt_sha256': sha(cargo_path), 'protected_files': audit.load(collection)['file_count']})
    quiet = evidence / 'current-cargo-quiet'; quiet.mkdir()
    save(quiet / 'result.json', {'passed': True, 'accepted': False, 'returncode': 0,
        'script_sha256': '3b6845ded13e94c5c67682bf692093827d8141f9428b2a2974feb8b00c5ac552', 'argv': ['/bin/sleep', '10'],
        'unrelated_compilers': {}, 'outside_cpu_intervals': [], 'disk_reserve_failed': False})
    save(quiet / 'quiet.monitor.json', [{'outside_user_cpu_cores': 0}])
    p = copy.deepcopy(original)
    for key in ['kind', 'base_script_sha256', 'continuation_script_sha256', 'raw_provenance_sha256', 'derivation_script_sha256', 'selection_manifest_sha256']:
        p.pop(key, None)
    p.update(script_sha256=audit.HARNESS, current_cargo_receipt_sha256=sha(cargo_path), prior_primary_audit_sha256=sha(prior_audit),
             prior_collection_sha256=sha(collection), current_preparation_sha256=sha(evidence / 'current-cargo-preparation.json'))
    p['cargo'] = {'path': cargo, 'sha256': 'f' * 64, 'version': {'stdout': version, 'returncode': 0}}
    p['toolchains'] = {arm: p['toolchains'][arm] for arm in audit.ARMS}; p['plan'] = []
    rows = []
    for project in audit.PROJECTS:
        for round_index, order in enumerate(audit.ORDERS):
            for mode in order:
                cell = next(c for c in original['plan'] if (c['project'], c['mode'], c['round']) == (project, mode, round_index))
                def rewrite(text):
                    return text.replace('/real-edit-matrix/', '/current-cargo-matrix/').replace(original['cargo']['path'], cargo)
                p['plan'].append(json.loads(rewrite(json.dumps(cell))))
                folder = matrix / f'{project}-{mode}-{round_index}'; folder.mkdir()
                chosen = [r for r in old_rows if (r['project'], r['mode'], r['round']) == (project, mode, round_index)]
                assert len(chosen) == 13
                for row in chosen:
                    remote = Path(row['log']); source = EVIDENCE / remote.parts[-3] / remote.parent.name / remote.name
                    for file in source.parent.glob(source.stem + '.*'):
                        (folder / file.name).write_text(rewrite(file.read_text()))
                    rows.append(json.loads(rewrite(json.dumps(row))))
    save(matrix / 'provenance.json', p); save(matrix / 'status.json', {'passed': True, 'samples': 156, 'accepted': 156})
    (matrix / 'samples.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in rows))
    summary = work / 'synthetic-summary.json'; env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    subprocess.run([sys.executable, HERE / 'summarize_current_cargo.py', matrix, '--output', summary], env=env, check=True)
    args = [sys.executable, HERE / 'audit_current_confirmation.py', evidence,
            '--original-build', '/private/tmp/ohm-compact-shipping/receipts/readiness/anchors/original-current-compiler-build.json',
            '--current-cargo-receipt', cargo_path, '--prior-primary-audit', prior_audit, '--prior-collection', collection,
            '--harness', HERE / 'benchmark_current_cargo.py', '--source-snapshots', EVIDENCE / 'fixture-originals',
            '--summary', summary, '--output', work / 'synthetic-audit.json']
    process = subprocess.run(list(map(str, args)), text=True, capture_output=True, env=env)
    (ROOT / 'current-auditor-test.log').write_text(process.stdout + process.stderr)
    assert process.returncode == 0, process.stderr
    proof = audit.load(work / 'synthetic-audit.json')
    assert proof['passed'] and proof['commands'] == 156 and len(proof['comparisons']) == 42
    result.update(checks=proof['checks'], synthetic_commands=156, summary_groups_compared=42)
    negatives = []
    original_samples = (matrix / 'samples.jsonl').read_bytes(); original_p = (matrix / 'provenance.json').read_bytes(); original_current = cargo_path.read_bytes()
    for name in ['changed-cargo-hash', 'missing-row', 'changed-runtime-oracle', 'missing-round']:
        cargo_path.write_bytes(original_current); (matrix / 'samples.jsonl').write_bytes(original_samples); (matrix / 'provenance.json').write_bytes(original_p)
        if name == 'changed-cargo-hash':
            value = audit.load(cargo_path); value['cargo']['sha256'] = '0' * 64; save(cargo_path, value)
        elif name == 'missing-row':
            (matrix / 'samples.jsonl').write_bytes(b''.join(original_samples.splitlines(keepends=True)[:-1]))
        elif name == 'missing-round':
            value = audit.load(matrix / 'provenance.json'); value['plan'] = value['plan'][:3]; save(matrix / 'provenance.json', value)
        else:
            value = [json.loads(line) for line in original_samples.splitlines()]; value[2]['oracle']['cases']['synthetic']['stdout'] = '0\n'
            (matrix / 'samples.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in value))
        proc = subprocess.run(list(map(str, args)), text=True, capture_output=True, env=env)
        assert proc.returncode != 0, name
        negatives.append({'case': name, 'rejected': True, 'error': audit.load(work / 'synthetic-audit.json')['error']})
    result.update(passed=True, negative_cases=negatives, auditor_sha256=sha(HERE / 'audit_current_confirmation.py'), shared_auditor_sha256=sha(HERE / 'audit_readiness.py'))
save(ROOT / 'current-auditor-test.json', result)
print(json.dumps(result, indent=2))
