"""Prepare bounded source copies for the current Cargo integration confirmation."""
from pathlib import Path
import hashlib,json,os,shutil,stat,subprocess,time

ROOT=Path('/home/dev-user/code/oss/ohm-compact-study')
WORK=ROOT/'shipping/readiness'
DEST=WORK/'current-cargo-sources'
RECEIPT=WORK/'evidence/current-cargo-preparation.json'
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(path):return json.loads(path.read_text())
def output(argv,cwd):return subprocess.check_output(argv,cwd=cwd)
def tracked(root):
    paths=output(['git','ls-files','-z'],root).decode().split('\0')
    result={}
    for name in sorted(set(paths)-{''}):
        relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
        path=root/relative;mode=path.lstat().st_mode
        if stat.S_ISLNK(mode):
            contents=os.readlink(path).encode();kind='symlink'
        else:
            assert stat.S_ISREG(mode),name
            contents=path.read_bytes();kind='file'
        result[name]={'kind':kind,'executable':bool(mode&0o111),'bytes':len(contents),'sha256':hashlib.sha256(contents).hexdigest()}
    return result

assert not DEST.exists() and not RECEIPT.exists()
assert shutil.disk_usage(WORK).free>70*1024**3
prior_path=WORK/'evidence/preparation.json';prior=load(prior_path)
current_path=WORK/'final-cargo-current/evidence/result.json';current=load(current_path)
assert current['passed'] and current['sources']['cargo']=='6333daf7cf99cf80125234c9419cbd36e9bff81a'
assert current['timing_and_original_installed_binaries_unchanged'] and current['original_sources_unchanged']
collection_path=WORK/'evidence/collection.json';collection=load(collection_path)
audit_path=WORK/'final-cargo-current/independent-matrix-audit.json';audit=load(audit_path)
assert collection['passed'] and audit['passed'] and audit['commands']==416 and audit['raw_commands']==443
assert audit['transferred_files_verified']==collection['file_count']
assert current['matrix_handover']['collection_sha256']==digest(collection_path)
assert current['matrix_handover']['independent_audit_sha256']==digest(audit_path)
receipt={'passed':False,'started':time.time(),'script_sha256':digest(Path(__file__)),
         'prior_preparation_sha256':digest(prior_path),'current_cargo_receipt_sha256':digest(current_path),
         'prior_collection_sha256':digest(collection_path),'prior_primary_audit_sha256':digest(audit_path),
         'scope':'Fresh tracked source copies and identical compatibility patches; original sources and fixture snapshots preserved.',
         'sources':{}}
DEST.mkdir()
def save():RECEIPT.write_text(json.dumps(receipt,indent=2)+'\n')
save()
try:
    for project in ('ruff','uv'):
        source=WORK/'sources'/project;destination=DEST/project;expected=prior['sources'][project]
        assert source.resolve()==source and output(['git','rev-parse','--show-toplevel'],source).decode().strip()==str(source)
        assert output(['git','config','user.email'],source).decode().strip()=='charlie.r.marsh@gmail.com'
        head=output(['git','rev-parse','HEAD'],source).decode().strip();assert head==expected['head']
        assert not output(['git','ls-files','--others','--exclude-standard','-z'],source)
        # Reject ignored repository-local Cargo inputs too; targets live outside these source roots.
        ignored=output(['git','ls-files','--others','--ignored','--exclude-standard','-z'],source).decode().split('\0')
        assert not any(name and ('.cargo' in Path(name).parts or Path(name).name in ('Cargo.toml','Cargo.lock','rust-toolchain','rust-toolchain.toml')) for name in ignored),ignored
        patch=output(['git','diff','--binary'],source);assert hashlib.sha256(patch).hexdigest()==expected['patch_sha256']
        before=tracked(source)
        subprocess.run(['git','clone','--shared','--no-checkout',str(source),str(destination)],check=True)
        subprocess.run(['git','config','--local','user.name',output(['git','config','user.name'],source).decode().strip()],cwd=destination,check=True)
        subprocess.run(['git','config','--local','user.email','charlie.r.marsh@gmail.com'],cwd=destination,check=True)
        assert output(['git','config','user.email'],destination).decode().strip()=='charlie.r.marsh@gmail.com'
        subprocess.run(['git','checkout','--detach',head],cwd=destination,check=True)
        subprocess.run(['git','apply','--binary','-'],cwd=destination,input=patch,check=True)
        assert output(['git','diff','--binary'],destination)==patch
        assert output(['git','rev-parse','HEAD'],destination).decode().strip()==head
        assert not output(['git','ls-files','--others','--exclude-standard','-z'],destination)
        after=tracked(destination);assert after==before and tracked(source)==before
        assert output(['git','diff','--binary'],source)==patch
        receipt['sources'][project]={'original':str(source),'path':str(destination),'head':head,'patch_sha256':hashlib.sha256(patch).hexdigest(),
            'tracked_files':len(before),'tracked_bytes':sum(row['bytes'] for row in before.values()),'files':before,
            'tracked_tree_identical':True,'original_unchanged':True,'unexpected_untracked_files':[]}
        save()
    receipt['passed']=True
except BaseException as error:
    receipt['error']=f'{type(error).__name__}: {error}'
    raise
finally:
    receipt['finished']=time.time();save()
print(json.dumps({'passed':receipt['passed'],'sources':{k:{n:v for n,v in row.items() if n!='files'} for k,row in receipt['sources'].items()}}))
