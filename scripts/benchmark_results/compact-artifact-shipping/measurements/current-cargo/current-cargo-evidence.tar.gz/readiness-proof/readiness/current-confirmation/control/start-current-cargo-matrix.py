from pathlib import Path
import hashlib,subprocess
script=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/harness/run-current-cargo-matrix.py')
assert hashlib.sha256(script.read_bytes()).hexdigest()=='3b6845ded13e94c5c67682bf692093827d8141f9428b2a2974feb8b00c5ac552'
raise SystemExit(subprocess.run(['python3',str(script)],env={**__import__('os').environ,'PYTHONDONTWRITEBYTECODE':'1'}).returncode)
