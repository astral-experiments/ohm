from pathlib import Path
import hashlib,subprocess
script=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/final-cargo-current/inputs/validate_final_cargo.py')
assert hashlib.sha256(script.read_bytes()).hexdigest()=='7c70ca6bc6c00cdec1d47750bc28889ce146001550c60ea02ba9812370fe4a01'
raise SystemExit(subprocess.run(['python3',str(script),'--execute-after-matrix-handover']).returncode)
