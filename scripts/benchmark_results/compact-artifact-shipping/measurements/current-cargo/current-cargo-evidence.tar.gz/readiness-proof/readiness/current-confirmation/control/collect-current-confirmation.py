"""Collect every completed current-Cargo confirmation receipt without selecting rows."""
from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/home/dev-user/code/oss/ohm-compact-study/shipping');work=root/'readiness'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
matrix=work/'evidence/current-cargo-matrix';status_path=matrix/'status.json';samples_path=matrix/'samples.jsonl'
status=load(status_path);assert status['passed'] and status['samples']==status['accepted']==156
assert not (matrix/'failure.json').exists()
rows=[json.loads(line) for line in samples_path.read_text().splitlines()]
assert len(rows)==156 and all(row['accepted'] for row in rows)
keys=[(row['project'],row['mode'],row['round'],row['phase'],tuple(row['state'])) for row in rows]
assert len(set(keys))==156
provenance=load(matrix/'provenance.json')
assert provenance['script_sha256']=='29435c96104f2e9e65d693fd7fedec2623ff9199761889ee981613e5718dfe43'
prior_path=work/'evidence/collection.json';prior=load(prior_path)
audit_path=work/'final-cargo-current/independent-matrix-audit.json'
current_path=work/'final-cargo-current/evidence/result.json';current=load(current_path)
assert current['passed'] and provenance['current_cargo_receipt_sha256']==digest(current_path)
assert provenance['prior_collection_sha256']==digest(prior_path) and provenance['prior_primary_audit_sha256']==digest(audit_path)
for stage in ('before','after'):
    receipt=load(work/f'evidence/current-cargo-preservation-{stage}.json')
    assert receipt['passed'] and not receipt['changed'] and receipt['original_failed_status_absent']
    assert receipt['collection_sha256']==digest(prior_path)
    assert receipt['current_cargo_receipt_sha256']==digest(current_path) and receipt['prior_primary_audit_sha256']==digest(audit_path)
    assert receipt['protected_files']>prior['file_count']
copies=load(work/'evidence/current-cargo-preparation.json')
assert copies['passed'] and provenance['current_preparation_sha256']==digest(work/'evidence/current-cargo-preparation.json')
for row in copies['sources'].values():
    for key in ('original','path'):
        source=Path(row[key])
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==row['head']
        assert hashlib.sha256(subprocess.check_output(['git','diff','--binary'],cwd=source)).hexdigest()==row['patch_sha256']
        assert not subprocess.check_output(['git','diff','--cached'],cwd=source)
        assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=source)
assert not (work/'evidence/real-edit-matrix/status.json').exists()
paths=['readiness/evidence/current-cargo-matrix','readiness/evidence/current-cargo-matrix.log',
       'readiness/evidence/current-cargo-preservation-before.json','readiness/evidence/current-cargo-preservation-after.json',
       'readiness/evidence/current-cargo-preparation.json','readiness/evidence/current-cargo-preparation.log',
       'readiness/evidence/current-cargo-quiet','readiness/final-cargo-current/evidence','readiness/final-cargo-current/inputs',
       'readiness/final-cargo-current/independent-matrix-audit.json','readiness/final-cargo-current/measurement-handover.json',
       'readiness/harness/benchmark_current_cargo.py','readiness/harness/prepare-current-cargo.py',
       'readiness/harness/run-current-cargo-matrix.py','readiness/harness/current-cargo-confirmation-review.json']
manifest=work/'evidence/current-cargo-collection.json';assert not manifest.exists()
files=[]
for name in paths:
    p=root/name
    assert p.exists() and not p.is_symlink() and (p.is_file() or p.is_dir()),name
    for f in sorted(p.rglob('*')) if p.is_dir() else [p]:
        assert not f.is_symlink(),str(f)
        if f.is_file():files.append({'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':digest(f)})
receipt={'passed':True,'samples':156,'matrix_status_sha256':digest(status_path),'matrix_samples_sha256':digest(samples_path),
         'matrix_provenance_sha256':digest(matrix/'provenance.json'),'current_cargo_receipt_sha256':digest(current_path),
         'prior_collection_sha256':digest(prior_path),'prior_primary_audit_sha256':digest(audit_path),
         'file_count':len(files),'total_bytes':sum(f['bytes'] for f in files),'paths':paths,'files':files,'created':time.time()}
manifest.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
