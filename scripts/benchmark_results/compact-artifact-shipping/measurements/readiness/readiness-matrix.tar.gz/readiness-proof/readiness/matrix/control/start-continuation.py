from pathlib import Path
import hashlib,subprocess
p=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness/harness/run-continuation.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='b81c88db8dc5c258a09414c68a5fc4327746ea9f1a198beb9557387d8efe3b83'
raise SystemExit(subprocess.run(['python3',str(p)]).returncode)
