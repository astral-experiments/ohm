"""Create a deterministic evidence supplement; preserve every existing proof file."""
import argparse,gzip,hashlib,io,json,tarfile
from pathlib import Path

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def encoded(value):return (json.dumps(value,indent=2)+'\n').encode()
p=argparse.ArgumentParser();p.add_argument('--audit',type=Path,required=True);p.add_argument('--summary',type=Path,required=True);args=p.parse_args()
root=Path('/private/tmp/ohm-compact-readiness');receipts=Path('/private/tmp/ohm-compact-shipping/receipts');publication=root/'publication'
base_archive=publication/'current-cut-correctness.tar.gz';assert sha(base_archive)=='3da176a3a30003bbd2a771f2dd31afa2544a4000097964df32be70a0a58dd986'
assert sha(publication/'inventory.json')=='059a0ad37a126c3e39ed316166ebd61a97e3a79134488b73c3d3f015cdb3d229'
base_inventory=json.loads((publication/'inventory.json').read_text());base={f['path']:f for f in base_inventory['files']}
with tarfile.open(base_archive,'r:gz') as tar:
 exclusions=tar.extractfile('readiness-proof/provenance/exclusions.json').read()
assert hashlib.sha256(exclusions).hexdigest()==base['provenance/exclusions.json']['sha256']
excluded={f['path']:f for f in json.loads(exclusions)['omitted_cache_bookkeeping']}
collection=receipts/'readiness/evidence/collection.json';manifest=json.loads(collection.read_text());assert manifest['passed']
assert json.loads(args.summary.read_text())['counts']['accepted']==416
# The caller supplies the independently passed audit, and this archive preserves its exact bytes.
audit=json.loads(args.audit.read_text());assert audit['passed']
assert audit['commands']==416 and audit['raw_commands']==443 and audit['summary_sha256']==sha(args.summary)
assert audit['continuation_selection']['primary']['selection_sha256']==manifest['selection_sha256']
assert audit['auditor_sha256']==sha(root/'harness/audit_readiness_continued.py')
assert audit['selection_auditor_sha256']==sha(root/'harness/audit_continuation_selection.py')
assert audit['shared_auditor_sha256']==sha(root/'harness/audit_readiness.py')
assert audit['matrix_sha256']==manifest['matrix_samples_sha256']==sha(receipts/'readiness/evidence/real-edit-primary/samples.jsonl')
assert audit['transferred_files_verified']==manifest['file_count']
entries={};overlaps=[]
for f in manifest['files']:
 path=receipts/f['path'];assert path.stat().st_size==f['bytes'] and sha(path)==f['sha256'],f['path']
 if f['path'] in excluded:
  assert f['bytes']==excluded[f['path']]['bytes'] and f['sha256']==excluded[f['path']]['sha256']
 elif f['path'] in base:
  assert f['bytes']==base[f['path']]['bytes'] and f['sha256']==base[f['path']]['sha256'],('static proof changed',f['path'])
  overlaps.append(f['path'])
 else:entries[f['path']]=path.read_bytes()
entries['readiness/evidence/collection.json']=collection.read_bytes()
entries['readiness/matrix/readiness-summary.json']=args.summary.read_bytes()
entries['readiness/matrix/independent-audit.json']=args.audit.read_bytes()
for name in ('summarize_readiness.py','decision_extract.py','package_primary.py','audit_readiness_continued.py','audit_continuation_selection.py','audit_readiness.py'):
 entries['readiness/matrix/harness/'+name]=(root/'harness'/name).read_bytes()
for name in ('run-matrix-v2.py','monitor-matrix.py','study-progress-v2.py','run-continuation.py','start-continuation.py','monitor-continuation.py','continuation-progress.py','derive-primary.py','preservation-primary.py','collect-primary.py'):
 entries['readiness/matrix/control/'+name]=(root/'control'/name).read_bytes()
entries['readiness/matrix/monitor-progress.jsonl']=(root/'monitor/progress.jsonl').read_bytes()
entries['readiness/matrix/continuation-monitor-progress.jsonl']=(root/'monitor-continuation/progress.jsonl').read_bytes()
# Retain the failed strict-summary comparison and exact pre-correction bytes.
correction=json.loads((root/'summary-history/correction.json').read_text())
assert correction['prior_summary_sha256']==sha(root/'summary-history/readiness-summary.json')
assert correction['prior_summarizer_sha256']==sha(root/'summary-history/summarize_readiness.py')
assert correction['new_summarizer_sha256']==sha(root/'harness/summarize_readiness.py')
failed=root/'independent-primary-audit-summary-cancellation.json'
assert not json.loads(failed.read_text())['passed']
for name in ('readiness-summary.json','summarize_readiness.py','correction.json'):
 entries['readiness/matrix/summary-history/'+name]=(root/'summary-history'/name).read_bytes()
entries['readiness/matrix/summary-history/'+failed.name]=failed.read_bytes()
entries['readiness/matrix/harness/package_primary_with_history.py']=Path(__file__).read_bytes()
for name in entries:assert name not in base,('supplement would overwrite',name)
files=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())]
inv={'schema':1,'base_archive':base_archive.name,'base_archive_sha256':sha(base_archive),'base_inventory_sha256':sha(publication/'inventory.json'),'static_overlaps_verified':len(overlaps),'retained_static_exclusions':list(excluded.values()),'file_count':len(files),'total_bytes':sum(f['bytes'] for f in files),'files':files,'excluded_self':'matrix-inventory.json'}
entries['matrix-inventory.json']=encoded(inv)
archive=publication/'readiness-matrix.tar.gz';assert not archive.exists()
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0,compresslevel=9) as zipped:
  with tarfile.open(fileobj=zipped,mode='w|') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo('readiness-proof/'+name);info.size=len(data);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 seen=set()
 for member in tar:
  assert member.isfile() and member.name.startswith('readiness-proof/')
  name=member.name.removeprefix('readiness-proof/');assert name not in seen;seen.add(name)
  assert member.size==len(entries[name]) and hashlib.sha256(tar.extractfile(member).read()).digest()==hashlib.sha256(entries[name]).digest(),name
 assert seen==set(entries)
receipt={'passed':True,'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'raw_file_count':len(entries),'raw_bytes':sum(map(len,entries.values())),'base_archive_sha256':inv['base_archive_sha256'],'static_overlaps_verified':len(overlaps)}
(publication/'matrix-inventory.json').write_bytes(encoded(inv));(publication/'matrix-package.json').write_bytes(encoded(receipt));print(json.dumps(receipt,indent=2))
