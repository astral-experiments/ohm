from pathlib import Path
import hashlib,json,time
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness');e=work/'evidence';dest=e/'real-edit-primary'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
def save(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
policy_path=work/'harness/continuation-plan.json';assert digest(policy_path)=='ea6b319bca5687cb508eaf1220c23879c2b8f88fc9a6d7098f9ae7db0ce0b1c4';policy=load(policy_path)
a=e/'real-edit-matrix';b=e/'real-edit-continuation'
assert not dest.exists() and not (a/'status.json').exists() and not (b/'failure.json').exists()
for name,sha in policy['initial_files_sha256'].items():assert digest(a/name)==sha
assert digest(work/'harness/benchmark_readiness_continuation.py')==policy['continuation_script_sha256']
bs=load(b/'status.json');assert bs['passed'] and bs['samples']==bs['accepted']==104
assert load(e/'continuation-quiet/result.json')['passed']
raw={'initial':(a/'samples.jsonl').read_bytes().splitlines(keepends=True),'continuation':(b/'samples.jsonl').read_bytes().splitlines(keepends=True)}
rows={k:[json.loads(line) for line in lines] for k,lines in raw.items()}
assert len(rows['initial'])==339 and sum(r['accepted'] for r in rows['initial'])==338
assert len(rows['continuation'])==104 and all(r['accepted'] for r in rows['continuation'])
mapping=[('initial',i) for i in policy['primary_original_rows']]+[('continuation',i) for i in range(104)]
primary=[rows[k][i] for k,i in mapping];data=b''.join(raw[k][i] for k,i in mapping)
assert len(primary)==416 and all(r['accepted'] for r in primary)
for x in policy['excluded_rows']:
 line=raw[x['raw_run']][x['raw_index']];row=json.loads(line)
 assert hashlib.sha256(line).hexdigest()==x['raw_line_sha256'] and row['accepted']==x['accepted']
source_runs={'initial':{'namespace':'real-edit-matrix','samples_sha256':digest(a/'samples.jsonl'),'provenance_sha256':digest(a/'provenance.json'),'failure_sha256':digest(a/'failure.json'),'status_absent':True,'rows':339,'accepted':338},'continuation':{'namespace':'real-edit-continuation','samples_sha256':digest(b/'samples.jsonl'),'provenance_sha256':digest(b/'provenance.json'),'status_sha256':digest(b/'status.json'),'rows':104,'accepted':104}}
selection={'schema':1,'policy_sha256':digest(policy_path),'source_runs':source_runs,'selected_rows':[{'primary_index':j,'raw_run':k,'raw_index':i,'raw_line_sha256':hashlib.sha256(raw[k][i]).hexdigest()} for j,(k,i) in enumerate(mapping)],'excluded_rows':policy['excluded_rows'],'counts':{'raw':443,'primary':416,'excluded':27,'excluded_accepted':26,'excluded_rejected':1},'primary_samples_sha256':hashlib.sha256(data).hexdigest(),'selection_reason':policy['selection_reason']}
p=load(a/'provenance.json');q=load(b/'provenance.json')
assert p['script_sha256']==policy['parent_script_sha256'] and q['script_sha256']==policy['continuation_script_sha256']
assert q['continuation']==policy and q['continuation_plan_sha256']==digest(policy_path)
for name in policy['identical_provenance_fields']:assert p[name]==q[name],name
plans=[c for c in p['plan'] if c['project']=='ruff' or c['round']<2]+q['plan'];assert len(plans)==32
sequence=[(r['phase'],r['state']) for r in rows['initial'][:13]]
expected=[(c['project'],c['mode'],c['round'],phase,state) for c in plans for phase,state in sequence]
assert [(r['project'],r['mode'],r['round'],r['phase'],r['state']) for r in primary]==expected
assert len({(r['project'],r['mode'],r['round'],r['phase'],tuple(r['state'])) for r in primary})==416
p.pop('script_sha256');p['plan']=plans
p.update(kind='derived-primary',base_script_sha256=policy['parent_script_sha256'],continuation_script_sha256=policy['continuation_script_sha256'],raw_provenance_sha256={k:v['provenance_sha256'] for k,v in source_runs.items()},derivation_script_sha256=digest(Path(__file__)))
p['scope']+=' Derived primary selection: original312complete-block rows plus104new whole uv rounds3/4. All443rawrows retained;27interrupted-round rows excluded prospectively, including26originally accepted and1resource-rejected command.'
dest.mkdir();(dest/'samples.jsonl').write_bytes(data);save(dest/'selection.json',selection)
p['selection_manifest_sha256']=digest(dest/'selection.json');save(dest/'provenance.json',p)
save(dest/'status.json',{'passed':True,'samples':416,'accepted':416,'raw_samples':443,'excluded':27,'derived':True,'finished':time.time()})
print(json.dumps({'passed':True,'primary_samples_sha256':digest(dest/'samples.jsonl'),'selection_sha256':digest(dest/'selection.json'),'raw_samples':443,'primary_samples':416,'excluded':27}))
