"""Render decision inputs from the full audited summary; no adoption threshold."""
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('summary',type=Path);args=p.parse_args();value=json.loads(args.summary.read_text())
assert value['counts']['accepted']==416
for row in value['comparisons']:
 if row['phase'] not in ('clean','synthetic-inline','real-direct','real-library','noop-final'):continue
 if (row['reference'],row['candidate']) not in (('baseline','storeless'),('current','storeless'),('storeless','compact'),('baseline','compact')):continue
 m=row['metrics'];wall=m['wall_seconds'];cpu=m['cpu_seconds'];disk=m['allocated_bytes']
 out={k:row[k] for k in ('project','phase','reference','candidate','n_pairs')}
 out.update(wall_seconds=[wall['reference_mean'],wall['candidate_mean']],wall_delta_seconds=wall['delta_mean'],wall_percent=wall['percent'],wall_round_percent=[r['percent'] for r in wall['rounds']],cpu_percent=cpu['percent'],allocated_GiB=[disk['reference_mean']/2**30,disk['candidate_mean']/2**30],allocated_percent=disk['percent'])
 print(json.dumps(out))
