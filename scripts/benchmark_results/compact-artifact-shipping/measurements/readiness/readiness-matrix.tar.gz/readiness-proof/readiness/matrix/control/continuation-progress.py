from pathlib import Path
import json,time,shutil
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness')
result={'freeGiB':shutil.disk_usage(work).free/1024**3}
for label in ('real-edit-continuation',):
 folder=work/'evidence'/label
 if folder.exists():
  rows=[json.loads(line) for line in (folder/'samples.jsonl').read_text().splitlines()] if (folder/'samples.jsonl').exists() else []
  result[label]={'rows':len(rows),'accepted':sum(r['accepted'] for r in rows),'last':{k:rows[-1][k] for k in ('project','mode','round','phase','accepted')} if rows else None,'status':json.loads((folder/'status.json').read_text()) if (folder/'status.json').exists() else None,'failure':json.loads((folder/'failure.json').read_text()).get('error') if (folder/'failure.json').exists() else None}
  cells={}
  for row in rows:cells.setdefault((row['project'],row['mode'],row['round']),[]).append(row)
  result[label]['completed_cell_seconds']=[{'project':k[0],'mode':k[1],'round':k[2],'seconds':sum(r.get('wall_seconds',0) for r in cell)} for k,cell in cells.items() if len(cell)==13]
  log=work/'evidence'/(label+'.log')
  if log.exists(): result[label]['log_tail']='\n'.join(log.read_text().splitlines()[-5:])[-1500:]
print(json.dumps(result,indent=2),flush=True)
