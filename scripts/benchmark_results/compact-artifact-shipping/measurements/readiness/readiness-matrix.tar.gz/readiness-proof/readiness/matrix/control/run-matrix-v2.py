from pathlib import Path
import hashlib,json,os,subprocess,time
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness')
script=work/'harness/benchmark_readiness_v2.py';review=json.loads((work/'harness/harness-review-v2.json').read_text())
assert review['passed'] and hashlib.sha256(script.read_bytes()).hexdigest()==review['script_sha256']=='4ddd91a0cc2003347f789fce4722da9bb4b27e264abff1266d6e9c0ca0732588'
status=json.loads((work/'evidence/fixture-preflight-v2/status.json').read_text());assert status['passed'] and status['samples']==26
correctness=json.loads((work/'evidence/correctness/result.json').read_text())
assert correctness['passed'] and correctness['binaries_unchanged'] and correctness['old_image_unchanged']
assert correctness['patch_sha256']=='8c24f6cf911c0829de90e5ec49b0ae04598f00d983168c9e1d126bef1d555275'
assert correctness['preflight_sha256']==hashlib.sha256((work/'evidence/fixture-preflight-v2/status.json').read_bytes()).hexdigest()
assert correctness['script_sha256']=='3a86821e3aa91c019bc78aff137c41d4ffd679fb05ab0d2022d67bf3a30a586d'
assert not any(name.startswith('RUSTC_LOG') for name in os.environ)
log=work/'evidence/real-edit-matrix.log';assert not log.exists()
with log.open('w') as output:
 result=subprocess.run(['python3',str(script)],env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=output,stderr=subprocess.STDOUT)
print(json.dumps({'exit_code':result.returncode,'log':str(log)}),flush=True)
raise SystemExit(result.returncode)
