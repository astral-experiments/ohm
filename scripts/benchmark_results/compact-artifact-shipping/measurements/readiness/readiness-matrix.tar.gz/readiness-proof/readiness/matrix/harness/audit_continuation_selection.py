"""Independent raw-row selection and provenance checks for the bounded continuation."""
import hashlib
import json
from pathlib import Path

import audit_readiness as base

CONTINUATION = 'a30167fbffd5ea662696685575f4d58f242d5b3b666f088cdac805976f67f41c'
POLICY = 'ea6b319bca5687cb508eaf1220c23879c2b8f88fc9a6d7098f9ae7db0ce0b1c4'
LAUNCHER = 'b81c88db8dc5c258a09414c68a5fc4327746ea9f1a198beb9557387d8efe3b83'
REVIEW = '04282800b83fa3a3d917eb467bb1ff76fc1d0e8b22b971ca74df8073126d49d4'
RUNS = {'initial': 'real-edit-matrix', 'continuation': 'real-edit-continuation'}
IDENTICAL = ('core_sha256', 'format_wrapper_sha256', 'cargo', 'wild_sha256', 'toolchains',
             'sources', 'admission', 'candidate_manifest', 'candidate_build_receipt_sha256',
             'candidate_package_receipt_sha256', 'final_review_build_receipt_sha256',
             'baseline_original_build', 'fixture_preflight_receipt_sha256')


def key(row):
    return row['project'], row['mode'], row['round']


def row_key(row):
    return (*key(row), row['phase'], row['state'])


def validate(audit, root, primary, harness, policy_path):
    check = audit.check; load = base.load; digest = base.digest
    check(digest(harness) == CONTINUATION and digest(policy_path) == POLICY, 'exact continuation harness and prospective policy')
    check(digest(harness.with_name('continuation-review.json')) == REVIEW, 'prospective independent review bytes')
    policy = load(policy_path)
    check(policy['parent_script_sha256'] == base.HARNESS and policy['continuation_script_sha256'] == CONTINUATION, 'policy harness identities')
    check(policy['primary_original_rows'] == list(range(312)) and policy['continuation_rounds'] == [2, 3] and policy['continuation_project'] == 'uv', 'predeclared block selection')
    check((policy['initial_rows'], policy['initial_accepted'], policy['continuation_rows'], policy['primary_rows'], policy['raw_rows']) == (339, 338, 104, 416, 443), 'prospective row counts')
    check(tuple(policy['identical_provenance_fields']) == IDENTICAL and policy['admission_unchanged'], 'all shared controls bound')
    raw = {run: (root / directory / 'samples.jsonl').read_bytes().splitlines(keepends=True) for run, directory in RUNS.items()}
    rows = {run: list(map(json.loads, lines)) for run, lines in raw.items()}
    contexts = {run: load(root / directory / 'provenance.json') for run, directory in RUNS.items()}
    first, later = contexts['initial'], contexts['continuation']
    check(first['script_sha256'] == base.HARNESS and later['script_sha256'] == CONTINUATION, 'both actual execution harnesses identified')
    check(not (root / RUNS['initial'] / 'status.json').exists(), 'original interrupted run has no synthetic success status')
    for name, sha in policy['initial_files_sha256'].items():
        check(digest(root / RUNS['initial'] / name) == sha, ('original frozen raw evidence', name))
    check(len(rows['initial']) == 339 and all(r['accepted'] for r in rows['initial'][:338]) and not rows['initial'][338]['accepted'], 'original339/338 preserved')
    failed = rows['initial'][338]
    check(failed == load(root / RUNS['initial'] / 'failure.json'), 'original failed row and partial receipt identical')
    check(row_key(failed) == ('uv', 'baseline', 2, 'clean', [0, 0, 0]) and failed['returncode'] == 0 and failed['oracle']['passed'] and failed['formats']['passed'], 'original failure only after successful compile/oracle/format')
    check(len(failed['outside_cpu_intervals']) == 3 and not failed['unrelated_compilers'] and not failed['disk_reserve_failed'] and failed['error'].startswith('AssertionError:'), 'exact resource admission rejection retained')
    check(len(rows['continuation']) == 104 and all(r['accepted'] for r in rows['continuation']), '104 fresh continuation rows accepted')
    status = load(root / RUNS['continuation'] / 'status.json')
    check(status['passed'] and status['samples'] == status['accepted'] == 104 and not (root / RUNS['continuation'] / 'failure.json').exists(), 'single bounded continuation complete')
    check(later['continuation_plan_sha256'] == POLICY and later['continuation'] == policy, 'actual continuation bound to prospective policy')
    for field in IDENTICAL:
        check(first[field] == later[field] == primary[field], ('unchanged shared controls', field))
    expected_cells = [(project, mode, round_index) for project in base.PROJECTS for round_index, order in enumerate(base.ORDERS) for mode in order]
    expected_rows = [(*cell, phase, list(state)) for cell in expected_cells for phase, state in base.SEQUENCE]
    check([row_key(r) for r in rows['initial']] == expected_rows[:339], 'original interrupted exact ordered prefix')
    check([row_key(r) for r in rows['continuation']] == expected_rows[312:], 'continuation exactly uv rounds3/4 in balanced order')
    check([key(c) for c in first['plan']] == expected_cells, 'original32-cell plan')
    check([key(c) for c in later['plan']] == expected_cells[24:], 'continuation8-cell plan')
    original_plans = {key(c): c for c in first['plan']}
    for cell in later['plan']:
        wanted = json.loads(json.dumps(original_plans[key(cell)]))
        old_lane = wanted['lane']; new_lane = old_lane.replace('/real-edit-matrix/', '/real-edit-continuation/')
        check(new_lane != old_lane, 'distinct fresh lane namespace')
        wanted['lane'] = new_lane
        for name, suffix in [('CARGO_TARGET_DIR', 'target'), ('CARGO_BUILD_BUILD_DIR', 'build'), ('TMPDIR', 'scratch')]:
            wanted['environment'][name] = new_lane + '/' + suffix
        check(cell == wanted, ('only lane paths differ in continuation plan', key(cell)))
    check(primary['plan'] == first['plan'][:24] + later['plan'], 'primary plans independently selected')
    check(primary['kind'] == 'derived-primary' and 'script_sha256' not in primary, 'primary is explicitly derived, not a claimed single execution')
    check(primary['base_script_sha256'] == base.HARNESS and primary['continuation_script_sha256'] == CONTINUATION, 'truthful dual-harness primary provenance')
    provenance_hashes = {run: digest(root / directory / 'provenance.json') for run, directory in RUNS.items()}
    check(primary['raw_provenance_sha256'] == provenance_hashes, 'both raw provenance hashes bound')
    matrix = root / 'real-edit-primary'; selection_path = matrix / 'selection.json'; selection = load(selection_path)
    check(primary['selection_manifest_sha256'] == digest(selection_path) and selection['policy_sha256'] == POLICY, 'derived selection policy/hash')
    source_runs = {}
    for run, directory in RUNS.items():
        source_runs[run] = {'namespace': directory, 'rows': len(rows[run]), 'accepted': sum(r['accepted'] for r in rows[run]),
                            'samples_sha256': digest(root / directory / 'samples.jsonl'), 'provenance_sha256': provenance_hashes[run]}
        if run == 'initial':
            source_runs[run].update(failure_sha256=digest(root / directory / 'failure.json'), status_absent=True)
        else:
            source_runs[run]['status_sha256'] = digest(root / directory / 'status.json')
    check(selection['source_runs'] == source_runs, 'raw-run counts/hash custody')
    chosen = [('initial', i) for i in range(312)] + [('continuation', i) for i in range(104)]
    expected_mapping = [{'primary_index': i, 'raw_run': run, 'raw_index': index, 'raw_line_sha256': hashlib.sha256(raw[run][index]).hexdigest()}
                        for i, (run, index) in enumerate(chosen)]
    check(selection['selected_rows'] == expected_mapping, 'independently reconstructed416 raw-line mapping')
    expected_bytes = b''.join(raw[run][index] for run, index in chosen)
    check((matrix / 'samples.jsonl').read_bytes() == expected_bytes, 'primary samples preserve exact selected raw bytes')
    check(selection['primary_samples_sha256'] == hashlib.sha256(expected_bytes).hexdigest(), 'primary sample hash')
    check(selection['counts'] == {'raw': 443, 'primary': 416, 'excluded': 27, 'excluded_accepted': 26, 'excluded_rejected': 1}, 'all443 raw rows accounted for')
    check(selection['excluded_rows'] == policy['excluded_rows'] and len(selection['excluded_rows']) == 27, 'exact prospective exclusions retained')
    for index, excluded in zip(range(312, 339), selection['excluded_rows']):
        check(excluded['raw_run'] == 'initial' and excluded['raw_index'] == index and excluded['raw_line_sha256'] == hashlib.sha256(raw['initial'][index]).hexdigest(), 'excluded rawline mapping')
        for field in ('project', 'mode', 'round', 'phase', 'state', 'accepted'):
            check(excluded[field] == rows['initial'][index][field], ('excluded row unmodified', index, field))
    quiet_path = root / 'continuation-quiet/result.json'; quiet = load(quiet_path)
    check(quiet['passed'] and not quiet['accepted'] and quiet['returncode'] == 0 and quiet['script_sha256'] == LAUNCHER and quiet['plan_sha256'] == POLICY, 'separate unaccepted quiet gate')
    check(not quiet['unrelated_compilers'] and len(quiet['outside_cpu_intervals']) < 3 and not quiet['disk_reserve_failed'], 'quiet gate same resource thresholds')
    check(quiet['argv'] == ['/bin/sleep', '10'], 'quiet gate runs no build')
    quiet_monitor = load(quiet_path.with_name('quiet.monitor.json'))
    check(sum(m['outside_user_cpu_cores'] > 0.5 for m in quiet_monitor) == len(quiet['outside_cpu_intervals']), 'quiet raw monitor binding')
    for run in RUNS:
        for i, row in enumerate(rows[run]):
            log = Path(row['log'])
            check(log.parts[-3] == RUNS[run] and log.parent.name == f'{row["project"]}-{row["mode"]}-{row["round"]}', ('raw log namespace', run, i))
    selected = set(chosen)
    population = [(run, i, row, (run, i) in selected) for run in RUNS for i, row in enumerate(rows[run])]
    plans = {run: {key(c): c for c in contexts[run]['plan']} for run in RUNS}
    report = {run: {'directory': value['namespace'], **{k: v for k, v in value.items() if k != 'namespace'}} for run, value in source_runs.items()}
    report.update(primary={'directory': 'real-edit-primary', 'rows': 416, 'accepted': 416, 'samples_sha256': digest(matrix / 'samples.jsonl'),
                           'provenance_sha256': digest(matrix / 'provenance.json'), 'status_sha256': digest(matrix / 'status.json'), 'selection_sha256': digest(selection_path)},
                  excluded={'rows': 27, 'accepted': 26, 'rejected': 1, 'original_indices': list(range(312, 339))},
                  policy_sha256=POLICY, continuation_harness_sha256=CONTINUATION, quiet_receipt_sha256=digest(quiet_path))
    return report, population, plans
