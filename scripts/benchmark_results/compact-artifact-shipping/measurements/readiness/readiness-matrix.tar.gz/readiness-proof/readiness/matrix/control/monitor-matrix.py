from pathlib import Path
import json,subprocess,sys,time
root=Path('/private/tmp/ohm-compact-readiness');out=root/'monitor';out.mkdir(exist_ok=True)
helper='/private/tmp/ohm-compact-shipping/control/remote.py';progress=root/'control/study-progress-v2.py'
while True:
 try:
  launched=subprocess.run([sys.executable,helper,'run',str(progress)],capture_output=True,text=True,check=True)
  job=launched.stdout.strip().splitlines()[-1]
  for _ in range(6):
   got=subprocess.run([sys.executable,helper,'get',job],capture_output=True,text=True,check=True);result=json.loads(got.stdout)
   if result['status']!='running':break
   time.sleep(2)
  assert result['status']=='completed' and result['exit_code']==0,result
  data=json.loads(result['stdout']);matrix=data.get('real-edit-matrix',{});cells=matrix.get('completed_cell_seconds',[])
  compact={'observed':time.time(),'job':job,'rows':matrix.get('rows',0),'accepted':matrix.get('accepted',0),'last':matrix.get('last'),'completed_cells':len(cells),'latest_cell':cells[-1] if cells else None,'freeGiB':data['freeGiB'],'failure':matrix.get('failure'),'status':matrix.get('status')}
  (out/'latest.json').write_text(json.dumps(compact,indent=2)+'\n')
  with (out/'progress.jsonl').open('a') as f:f.write(json.dumps(compact)+'\n')
  print(json.dumps(compact),flush=True)
  if compact['failure'] or compact['status']:break
 except BaseException as error:
  (out/'error.txt').write_text(repr(error)+'\n');raise
 time.sleep(60)
