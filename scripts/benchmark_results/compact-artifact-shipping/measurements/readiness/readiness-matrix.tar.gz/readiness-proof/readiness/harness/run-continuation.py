from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
work=Path('/home/dev-user/code/oss/ohm-compact-study/shipping/readiness');study=work.parent.parent
script=work/'harness/benchmark_readiness_continuation.py';plan_path=work/'harness/continuation-plan.json'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert digest(script)=='a30167fbffd5ea662696685575f4d58f242d5b3b666f088cdac805976f67f41c'
assert digest(plan_path)=='ea6b319bca5687cb508eaf1220c23879c2b8f88fc9a6d7098f9ae7db0ce0b1c4'
review=json.loads((work/'harness/continuation-review.json').read_text())
assert review['passed'] and review['harness_sha256']==digest(script) and review['plan_sha256']==digest(plan_path) and review['launcher_sha256']==digest(Path(__file__))
plan=json.loads(plan_path.read_text());initial=work/'evidence/real-edit-matrix'
assert not (initial/'status.json').exists()
for name,sha in plan['initial_files_sha256'].items():assert digest(initial/name)==sha
assert json.loads((work/'evidence/correctness/result.json').read_text())['passed']
preflight=json.loads((work/'evidence/fixture-preflight-v2/status.json').read_text());assert preflight['passed'] and preflight['samples']==26 and preflight['accepted']==0
assert not (work/'evidence/real-edit-continuation').exists()
assert not any(k.startswith('RUSTC_LOG') for k in os.environ)
core_path=study/'harness/benchmark.py';assert digest(core_path)=='ea7867f9f9a0f19ceb7d9c558aa7aa6758ae3e254878685fbc58768c65713cef'
spec=importlib.util.spec_from_file_location('readiness_quiet_core',core_path);core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
quiet=work/'evidence/continuation-quiet';assert not quiet.exists();quiet.mkdir()
row=core.timed(['/bin/sleep','10'],work,{k:v for k,v in os.environ.items() if not k.startswith(('CARGO_','RUST'))},quiet/'quiet',[Path('/tmp/codex-cargo-targets/ohm/isolated/compact-readiness')],False,60*1024**3)
row.update(accepted=False,purpose='Resource-only quiet gate before continuation; outside accepted timings',finished=time.time(),script_sha256=digest(Path(__file__)),plan_sha256=digest(plan_path))
row['passed']=row['returncode']==0 and not row['unrelated_compilers'] and len(row['outside_cpu_intervals'])<3 and not row['disk_reserve_failed']
(quiet/'result.json').write_text(json.dumps(row,indent=2)+'\n');assert row['passed'],row
for name,sha in plan['initial_files_sha256'].items():assert digest(initial/name)==sha
log=work/'evidence/real-edit-continuation.log';assert not log.exists()
with log.open('w') as output:
 result=subprocess.run(['python3',str(script)],env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=output,stderr=subprocess.STDOUT)
print(json.dumps({'exit_code':result.returncode,'log':str(log)}),flush=True)
raise SystemExit(result.returncode)
