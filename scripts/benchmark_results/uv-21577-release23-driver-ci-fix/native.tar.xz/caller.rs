#![feature(rustc_private)]
extern crate rustc_codegen_ssa;
extern crate rustc_middle;
use rustc_codegen_ssa::CrateInfo;
use rustc_middle::ty::TyCtxt;
#[unsafe(no_mangle)]
pub fn downstream_constructor(tcx: TyCtxt<'_>, cpu: String) -> CrateInfo {
    CrateInfo::new(tcx, cpu)
}
