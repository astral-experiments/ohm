; ModuleID = 'consumer.d85a78f98d536bb2-cgu.0'
source_filename = "consumer.d85a78f98d536bb2-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nonlazybind uwtable
define void @downstream_constructor(ptr dead_on_unwind noalias nofree noundef writable sret([592 x i8]) align 8 captures(none) dereferenceable(592) %_0, ptr noundef nonnull align 8 %tcx, ptr dead_on_return noalias nofree noundef align 8 captures(address) dereferenceable(24) %cpu) unnamed_addr #0 {
start:
; call <rustc_codegen_ssa::CrateInfo>::new
  tail call void @_RNvMNtCsdgtrZ2TShmM_17rustc_codegen_ssa4baseNtB4_9CrateInfo3new(ptr noalias nofree noundef nonnull sret([592 x i8]) align 8 captures(none) dereferenceable(592) %_0, ptr noundef nonnull align 8 %tcx, ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(24) %cpu)
  ret void
}

; <rustc_codegen_ssa::CrateInfo>::new
; Function Attrs: nonlazybind uwtable
declare void @_RNvMNtCsdgtrZ2TShmM_17rustc_codegen_ssa4baseNtB4_9CrateInfo3new(ptr dead_on_unwind noalias nofree noundef writable sret([592 x i8]) align 8 captures(none) dereferenceable(592), ptr noundef nonnull align 8, ptr dead_on_return noalias nofree noundef align 8 captures(address) dereferenceable(24)) unnamed_addr #0

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 2, !"RtLibUseGOT", i32 1}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{!"rustc version 1.98.0 (88d9e12ae 2026-08-18)"}
