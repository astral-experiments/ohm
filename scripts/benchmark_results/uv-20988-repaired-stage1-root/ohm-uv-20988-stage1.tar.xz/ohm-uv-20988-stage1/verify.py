"""Replay the archived clocks and the stable-output / qualification checks, offline."""
import hashlib
import json
import re
import statistics
import sys
import zipfile
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STOCK, STACK = "stock_ctfe318", "fa7a_stack_ctfe318"
ROLES = (STOCK, STACK)
COMMAND = ["/tmp/uv-workflow-search/sdk/bin/cargo", "check", "--locked", "--offline", "-j8"]
SHA = re.compile("[0-9a-f]{64}")
STATES = {"A", "incremental-B", "cold-B1", "cold-B2"}
SAME_B = {"incremental-B/cold-B1", "incremental-B/cold-B2", "cold-B1/cold-B2"}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads((ROOT / path).read_bytes())


def check(condition, description):
    if not condition:
        raise ValueError(description)


def metadata(raw, crate):
    header, deps = raw.decode().split("=External Dependencies=\n")
    lines = header.splitlines()
    check(lines[0] == "Crate info:" and re.fullmatch("name " + re.escape(crate) + "-[0-9a-f]+", lines[1]), "crate name")
    private, sid = re.fullmatch(r"private hash ([0-9a-f]{32}) stable_crate_id StableCrateId\((\d+)\)", lines[2]).groups()
    public, = re.findall(r"^public_hash ([0-9a-f]{32})$", header, re.M)
    check("triple x86_64-unknown-linux-gnu" in lines and len(lines) >= 11, "target")
    records = []
    for i, line in enumerate(deps.strip().splitlines(), 1):
        n, record = line.split(" ", 1)
        check(int(n) == i and all(t in record for t in (" hash ", " host_hash ", " kind ")), "dependency entry")
        records.append(record)
    return sid, public, private, lines[:2] + lines[3:], sorted(records)


def check_history(role, source, h):
    pre = f"roles/{role}/"
    history = pre + "history/"
    complete = read(history + "complete.json")
    check(complete["role"] == role and digest((ROOT / history / "complete.json").read_bytes()) ==
          h["native_evidence"][role] == source["native_history"], "four-state completion")
    check(complete["ordinary"] == digest((ROOT / history / "ordinary-complete.json").read_bytes()), "ordinary four-state receipt")
    check(read(history + "ordinary-complete.json")["role"] == role, "four-state role")
    for state, expected in complete["fixtures"].items():
        p = ROOT / history / ("fixture-" + state) / "receipt.json"
        f = json.loads(p.read_bytes())
        check(digest(p.read_bytes()) == expected and f["private_target"] and f["passed"], "A/B native fixture")
    check(set(complete["fixtures"]) == {"A", "B"}, "fixture states")
    detail = h["per_role"][role]["details"]
    for k in ("incremental_public_agrees_with_both_cold", "cold_public_agree", "same_B_allocation_multisets_agree",
              "cold_allocation_multisets_agree", "same_B_literal_counts_agree"):
        check(detail[k] is True, k)
    check(detail["unavailable_decoding"] == {} and detail["decoded_surface_differences"] == {k: {} for k in SAME_B}, "same-B decoded surfaces")
    comparisons = detail["per_definition_and_allocation_comparisons"]
    check(set(comparisons) == SAME_B, "three same-B comparisons")
    for v in comparisons.values():
        for k, count in (("stable_defs", 8291), ("stable_expansions", 3448)):
            check(v[k] == {"same": count, "changed": 0, "only_fresh": 0, "only_warm": 0}, k)
        check(v["allocations"]["multisets_equal"], "allocation multiset")


def verify():
    listing = read("FILES.json")
    files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()}
    check(files == set(listing) | {"FILES.json"}, "packet member set")
    for name, sha in listing.items():
        check(digest((ROOT / name).read_bytes()) == sha, "packet file " + name)
    c, replay = read("case.json"), read("receipts/discovery.json")
    closed, independent = read("receipts/closed.json"), read("receipts/independent-clocks.json")
    h, sv, qa = read("receipts/four-state.json"), read("receipts/stable-visits.json"), read("receipts/qa.json")
    check(c["command"] == COMMAND and c["selection"] == "root" and closed["registration"] == c["registration_sha256"], "case")
    check(c["edit"]["A"] == "b60da7ad468d5bb8a6b3dee7d7e54a47981f23c7" and c["edit"]["B"] ==
          "1979349b68dbaa936b98c0f409c1df0598fa72f1" and len(c["edit"]["changed_paths"]) == 2, "source edit")
    check(closed["pairs"] == listing["receipts/pairs.jsonl"] and all(v == listing["receipts/qa.json"] for v in closed["qa"].values()), "closed session")
    check(h["eligible_for_independent_plain_root_wall"] and h["source_and_fixture_matches"] and
          h["full_within_compiler_checks"] == dict.fromkeys(ROLES, True) and c["history"] == listing["receipts/four-state.json"], "admission")
    check(set(h["cross_compiler_observations"]) == STATES and qa["native_witness"], "history states / native QA")
    fixture = "workspace::tests::exclude_package"
    check(qa["A"]["witness"]["passing_native_fixtures"] == [fixture] and qa["B"]["witness"] == qa["clean_B"]["witness"] and
          qa["B"]["witness"]["passing_native_fixtures"] == [fixture, fixture + "_with_normalized_glob_and_escaped_root"],
          "unchanged and changed uv behavior")
    for state in STATES:
        z = h["cross_compiler_observations"][state]
        check(z["same_enrolled_crates"] == 641 and z["cross_compiler_matching_public_hashes"] == 70 and
              z["same_paths"] and z["same_downstream_witness"][0] == ["compiled"] and
              z["same_downstream_witness"][1][0] == "E0308", "cross-compiler history " + state)
    check(len(read("receipts/641-roster.json")) == 641, "target-feature roster")
    ledger = [json.loads(l, parse_float=Decimal) for l in (ROOT / "receipts/pairs.jsonl").read_text().splitlines()]
    order = [list(v) for v in ledger]
    check(len(ledger) == 6 and order == c["orders"] == [list(ROLES if i % 2 == 0 else ROLES[::-1]) for i in range(6)], "actual order")
    ns, drift, public_by_arm = {}, {}, {}
    used_dumps = set()

    def decode(ref, name):
        check(SHA.fullmatch(ref), "root digest")
        p = "dumps/" + ref + ".txt"
        check(listing[p] == ref, "content-addressed root text")
        used_dumps.add(p)
        return metadata((ROOT / p).read_bytes(), name)

    for role in ROLES:
        pre = f"roles/{role}/"
        source, identity, sdk = c["roles"][role], read(pre + "identity.json"), read(pre + "sdk-files.json")
        cargo = c["signed_cargo"]["sha256"]
        check(cargo == "3ce4e300d4463dfc769b6c18e138d1c951b02dfb15416a39cb5301303d168871" and
              cargo == source["effective_cargo_sha256"] == source["cargo_sha256"] == identity["cargo"] == sdk["bin/cargo"][0], "signed Cargo")
        driver = source["driver_relative"]
        check(source["inventory"] == listing[pre + "sdk-files.json"] and len(sdk) == source["complete_sdk_count"] == 66 and
              source["driver_sha256"] == sdk[driver][0] == identity["linked"][Path(driver).name]["sha256"] and
              source["launcher_sha256"] == sdk["bin/rustc"][0] == identity["launcher"], "SDK and selected compiler")
        check(source["qualification"] == h["stock_sdk" if role == STOCK else "treatment_sdk"], "qualified SDK")
        check_history(role, source, h)
        tree = source["source"]
        if role == STOCK:
            check(tree["source_base"] == "008a21ac0d750dc9a1c18b7959d7e7984c03d887" and
                  tree["source_tree"] == "1a0e58a855e1782a93cdf8c56b337fb4354142ef" and tree["epoch"] == 43310, "stock source")
        else:
            check(tree["base"] == "fa7a7899837d6a0f700f1df11f4a3a74a7a0f637" and
                  tree["tree"] == "cb977189205aa931f080b57b9a8bb62ef98a316e" and tree["epoch"] == 43309, "stack source")
        surface, mc = read(pre + "surfaces.json"), read(pre + "metadata-comparison.json")
        records, decoded = {}, {}
        for phase, key in (("edited", "incremental_archive_sha256"), ("clean-child", "cold_archive_sha256")):
            data = surface[phase]
            check(data["archive_sha256"] == mc[key] and data["roster_sha256"] == listing["receipts/641-roster.json"] and
                  [q["verdict"] for q in data["consumer"]] == mc["downstream"], "metadata evidence provenance")
            records[phase], decoded[phase] = {}, {}
            for m, ref in data["roots"]:
                rel, name = m["rel"], m["name"]
                check(rel not in records[phase] and rel.endswith(".rmeta") and m["bytes"] > 0, "distinct artifact")
                view = decode(ref, name)
                check(view[:3] == (m["stable_crate_id"], m["public_hash"], m["private_hash"]), "metadata headers")
                records[phase][rel] = [name, m["bytes"], m["sha256"]]
                decoded[phase][rel] = view
            check(len(records[phase]) == 70, "metadata files")
        check(decoded["edited"] == decoded["clean-child"] and len(mc["downstream"]) == 2, "all canonical root fields and dependent verdicts")
        public_by_arm[role] = {k: v[:2] for k, v in decoded["edited"].items()}
        delta = sorted(k for k in records["edited"] if records["edited"][k] != records["clean-child"][k])
        drift[role] = len(delta)
        checks = sv["visits"][role]
        check(delta == mc["differing_raw_rmeta_with_matching_decoded_roots"] == checks["cold_layout_differences"] and
              checks["first_edit_workspace_files_per_visit"] == checks["actual_dump_count"] == 70, "layout drift")
        reference, product_reference, by_visit = None, None, []
        for i in range(6):
            archive = pre + f"pair-{i+1}.zip"
            check(listing[archive] == independent["zip_sha256"][role][i], "original visit ZIP digest")
            with zipfile.ZipFile(ROOT / archive) as z:
                clock = json.loads(z.read("edit-D.json"), parse_float=Decimal)
                roots = json.loads(z.read("edit-D-workspace-metadata.json"))
                products = json.loads(z.read("edit-D-products.json"))
                check(len(products) == 19 and (product_reference is None or products == product_reference), "background product set")
                for unit, entries in products.items():
                    if json.loads(unit)[2] == ["lib"]:
                        check(all(roots[p][1:] == [size, sha] for p, size, sha in entries), "background library raw product")
                product_reference = products
            row = ledger[i][role]
            check(clock["cmd"] == COMMAND and clock["unit_source"] == "ordinary Cargo progress" and
                  clock["wall_s"] == row["edit"] and clock["dirty_units"] == row["dirty"] and
                  row["state"] == "measured" and row["trial"] == str(i + 1), "ordinary Cargo clock and argv")
            elapsed = Fraction(clock["wall_s"]) * 10**9
            check(elapsed.denominator == 1 and elapsed > 0, "exact nanoseconds")
            by_visit.append(int(elapsed))
            check(roots == records["edited"] and (reference is None or roots == reference), "all timed raw manifests")
            for rel, (name, _, raw_hash) in roots.items():
                check(decode(surface["timed_raw_sha256_to_dump_sha256"][raw_hash], name) == decoded["edited"][rel],
                      "actual timed metadata vs independent cold")
            reference = roots
        check(by_visit == independent["nanoseconds"][role], "independent clock extraction")
        ns[role] = by_visit
    check({p for p in listing if p.startswith("dumps/")} == used_dumps, "decoded dump coverage")
    check(drift == independent["cold_raw_layout_differences"] == {STOCK: 14, STACK: 10}, "layout counts")
    check(public_by_arm[STOCK] == public_by_arm[STACK], "cross-arm public identities")
    stable = digest(json.dumps(public_by_arm[STOCK], sort_keys=True, separators=(",", ":")).encode())
    check(stable == sv["stable_B"] and set(c["stable_B_history"].values()) == {stable}, "four-state / timed stable root digest")
    ratios = [Fraction(a, b) for a, b in zip(ns[STOCK], ns[STACK])]
    med = statistics.median(ratios)
    rng = [min(ratios), max(ratios)]
    strata = {r: statistics.median(q for q, v in zip(ratios, order) if v[0] == r) for r in ROLES}
    phase = replay["phases"]["discovery"]
    check(phase["orders"] == order and phase["background_subtracted"] is False and
          all([Fraction(str(t)) * 10**9 for t in phase["raw_seconds"][r]] == ns[r] for r in ROLES), "published phase clocks")
    check(str(med) == independent["paired_median_exact"] and abs(float(med) - replay["discovery_median"]) < 1e-12 and
          all(abs(float(x) - y) < 1e-12 for x, y in zip(rng, replay["discovery_96_875_interval"])) and
          all(abs(float(v) - independent["order_median"][k]) < 1e-12 for k, v in strata.items()), "published statistics")
    wins = [sum(r > threshold for r in ratios) for threshold in (1, 2)]
    check(wins == [6, 0] and replay["stage1_only"] and not replay["qualified_2x"] and not replay["opens_confirmation"], "stage1 discovery threshold")
    print("pair  first arm             stock seconds  stack seconds  paired speedup")
    for i, (a, b, ratio) in enumerate(zip(ns[STOCK], ns[STACK], ratios)):
        print(f"{i+1:>4}  {order[i][0]:<20} {a/1e9:>12.9f}  {b/1e9:>12.9f}  {float(ratio):.9f}x")
    seconds = {r: Decimal(sum(sorted(v)[2:4])) / Decimal(2_000_000_000) for r, v in ns.items()}
    print(f"Arm medians: {seconds[STOCK]}s and {seconds[STACK]}s")
    print(f"Median paired speedup: {float(med):.9f}x; exact median {med}")
    coverage = 1 - Fraction(2, 2**len(ratios))
    print(f"{float(coverage)*100:.3f}% median interval: [{float(rng[0]):.9f}, {float(rng[1]):.9f}]x")
    print("Order-stratified medians:", ", ".join(f"{k} first {float(v):.9f}x" for k, v in strata.items()))
    print("6/6 faster than parity; 0/6 over 2x. Local stage1 discovery; no confirmation opened.")
    print("70 stable workspace roots on every visit. Independent cold raw layout differences: stock 14, stack 10.")


if __name__ == "__main__":
    try:
        verify()
    except (ValueError, OSError, KeyError, TypeError, zipfile.BadZipFile) as error:
        sys.exit(f"Evidence rejected: {error}")
