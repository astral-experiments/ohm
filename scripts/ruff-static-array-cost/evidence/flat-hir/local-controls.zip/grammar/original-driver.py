"""Compare a fixed mixed grammar and all boundary sizes across real rustc type and native receivers."""
from pathlib import Path
import hashlib,json,os,random,subprocess as sp
u=Path(__file__).resolve().parent;root=u/"uniform-grammar-entropy";root.mkdir(exist_ok=True)
seed=20261104;roles={"P":u/"bulk-pair-41738460962/candidate/rustup","C":u/"uniform-pair-41743833358/candidate/rustup"}
matrix=[(s,t,m) for s in (1023,1024,1025)for t in ("u8","u16","u32")for m in ("bare","suffix","expr","attr")]
def write(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+"\n")
def sha(b):return hashlib.sha256(b).hexdigest()
def make(edited=False,invalid=False):
 rng=random.Random(seed);lines=["#![feature(stmt_expr_attributes)]","#![deny(overflowing_literals)]","#![allow(unused_parens)]","macro_rules! value { ($e:expr) => { $e } }"];expect=[];main=[];bad_range=None
 for ix,(size,t,mode)in enumerate(matrix):
  maximum=(1<<int(t[1:]))-1;values=[rng.randrange(maximum+1)for _ in range(size)];names=[]
  if edited and (ix%3)==0:values[-1]^=1
  for j,n in enumerate(values):
   text=([str(n),hex(n),oct(n),bin(n)][(ix+j)%4])
   if mode!="bare" and j==size//2:
    text={"suffix":text+t,"expr":"value!({ "+text+" + 0 })","attr":"#[allow(unused_parens)] ("+text+")"}[mode]
   if invalid and (size,t,mode,j)==(1024,"u8","bare",512):text="256"
   names.append(text)
  decl=f"static T{ix}: [{t};{size}] = ["+", ".join(names)+"];"
  if invalid and (size,t,mode)==(1024,"u8","bare"):
   offset=sum(len(l)+1 for l in lines)+len(decl.split("[",2)[0])+0
   # Derive the exact source offset from preceding array fields, never from an ambiguous digit search.
   pref=decl[:decl.index(" = [")+4]+", ".join(names[:512])+", "
   assert decl[len(pref):len(pref)+3]=="256"
   bad_range=(sum(len(l)+1 for l in lines)+len(pref),sum(len(l)+1 for l in lines)+len(pref)+3)
  lines.append(decl);h=1469598103934665603
  for n in values:h=((h^n)*1099511628211)&((1<<64)-1)
  expect.append(f"{ix} {h:016x}\n")
  main.append(f'println!("{ix} {{:016x}}", T{ix}.iter().fold(1469598103934665603u64, |h, &n| (h ^ u64::from(n)).wrapping_mul(1099511628211)));')
 lines+=["fn main() {",*main,"}"]
 return ("\n".join(lines)+"\n").encode(),"".join(expect).encode(),bad_range
sources={};src=root/"tables.rs";report={}
for rev in ("old","edit","error"):
 rust,want,bad=make(rev=="edit",rev=="error");sources[rev]={"source":sha(rust),"stdout":sha(want),"bad":bad}
write(root/"enrollment.json",{"seed":seed,"tables":matrix,"sources":sources})
for role,tc in roles.items():
 out=root/role;out.mkdir(exist_ok=True);env={k:os.environ[k]for k in ("PATH","HOME","USER","TZ","LANG")if k in os.environ};env["RUSTUP_HOME"]=str(tc)
 cmds=[];verdict={}
 def call(tag,args,ok=True):
  p=sp.run(["rustc","+ohm","--edition=2024",src,*args],cwd=root,env=env,capture_output=True);(out/(tag+".stderr")).write_bytes(p.stderr);(out/(tag+".stdout")).write_bytes(p.stdout)
  assert (p.returncode==0)==ok,(role,tag,p.stderr[-1100:]);cmds.append([tag,p.returncode]);return p
 for label,rev,inc in (("old","old","incr"),("edit","edit","incr"),("incorrect","error","incr"),("incorrect-again","error","incr"),("repaired","edit","incr"),("empty","edit","empty-incr")):
  code,want,bad=make(rev=="edit",rev=="error");assert sha(code)==sources[rev]["source"];src.write_bytes(code)
  if rev=="error":
   p=call(label,["--error-format=json","-C","incremental="+str(out/inc),"-o",out/"table"],False)
   errors=[json.loads(l)for l in p.stderr.splitlines()if l.startswith(b"{")]
   actual=[e for e in errors if (e.get("code") or {}).get("code")=="overflowing_literals"];assert len(actual)==1
   assert [(s["byte_start"],s["byte_end"])for s in actual[0]["spans"]if s["is_primary"]]==[bad]
   verdict[label]=actual;continue
  if label=="edit":
   hir=call("typed-hir",["-Zunpretty=hir,typed"]).stdout;verdict["typed_hir"]=sha(hir)
   thir=call("thir",["-Zunpretty=thir-tree"]).stdout
   n=thir.count(b"IntArrayLiteral(");assert n==6,(role,n);verdict["packed"]=n
  call(label,["-C","incremental="+str(out/inc),"-o",out/"table"])
  result=sp.check_output([out/"table"],cwd=root,env=env);assert result==want
  verdict[label]=dict(stdout=sha(result),elf=sha((out/"table").read_bytes()))
 assert verdict["edit"]==verdict["repaired"]==verdict["empty"] and verdict["old"]["stdout"]!=verdict["edit"]["stdout"]
 assert verdict["incorrect"]==verdict["incorrect-again"]
 write(out/"calls.json",cmds);write(out/"verdict.json",verdict);report[role]=verdict
assert report["P"]["typed_hir"]==report["C"]["typed_hir"] and report["P"]["incorrect"]==report["C"]["incorrect"]
write(root/"verified.json",report);print("36 tables; 6 compact; typed HIR, repeated diagnostics, 36 old/new native checks and empty ELFs agree.")
