"""Switch both compiler directions on populated Cargo state and compare every valid ELF."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

u = Path(__file__).resolve().parent
at = u/"uniform-format-guard"
work = at/"source"
(work/"src").mkdir(parents=True)
(work/"Cargo.toml").write_text('[package]\nname="uniform_guard"\nversion="0.1.0"\nedition="2024"\n')
p = u/"bulk-pair-41738460962/candidate"
c = u/"uniform-pair-41743833358/candidate"
template = (u/"runmake-product/candidate/table.rs").read_text()
assert template.count("0,254]") == 1 and template.count("static BYTES: &[u8]") == 1
src = work/"src/main.rs"
base = {k:os.environ[k] for k in ("PATH","HOME","TZ","LANG","USER") if k in os.environ}
base.update(CARGO_NET_OFFLINE="true", CARGO_HOME=str(at/"cargo-home"))
def call(argv,env):
    return subprocess.run(argv, cwd=work, env=env, capture_output=True)
def compile(stage,root,invalid):
    env = dict(base, RUSTUP_HOME=str(stage/"rustup"), CARGO_TARGET_DIR=str(root/"target"), CARGO_BUILD_BUILD_DIR=str(root/"shared"))
    result = call(["cargo","+ohm","build","--offline","--message-format=json"],env)
    msgs = [json.loads(line) for line in result.stdout.splitlines()]
    if invalid:
        diag, = [m["message"] for m in msgs if m["reason"] == "compiler-message" and (m["message"].get("code") or {}).get("code") == "overflowing_literals"]
        prim, = [s for s in diag["spans"] if s["is_primary"]]
        assert result.returncode == 101 and src.read_bytes()[prim["byte_start"]:prim["byte_end"]] == b"256"
        return {"status":101,"diagnostic":diag["code"]["code"],"span":[prim["byte_start"],prim["byte_end"]]}
    assert result.returncode == 0, (result.stderr,msgs[-2:])
    a, = [m for m in msgs if m["reason"] == "compiler-artifact"]
    elf = Path(a["executable"])
    native = call([str(elf)],env)
    assert native.returncode == 0
    return {"status":0,"elf":hashlib.sha256(elf.read_bytes()).hexdigest(),"output":native.stdout.decode().strip(),"fresh":a["fresh"]}
records = []
for i,(role,t,word) in enumerate([
    ("P","u8","255"),("C","u8","255"),("C","u8","254"),("P","u8","254"),
    ("C","u8","256"),("P","u8","256"),("P","u8","253"),("C","u16","299"),
    ("P","u16","299"),("C","u8","255"),("P","u8","255")
]):
    stage = {"P":p,"C":c}[role]
    src.write_text(template.replace("0,254]", "0,"+word+"]").replace("static BYTES: &[u8]","static BYTES: &["+t+"]"))
    bad = t == "u8" and word == "256"
    row = {"compiler":role,"type":t,"last":word}
    row["ordinary"] = compile(stage,at/"ordinary",bad)
    row["repeat"] = compile(stage,at/"ordinary",bad)
    row["empty"] = compile(stage,at/("empty-"+str(i)),bad)
    if bad:
        assert row["ordinary"] == row["repeat"] == row["empty"]
    else:
        assert row["ordinary"]["elf"] == row["repeat"]["elf"] == row["empty"]["elf"]
        assert row["ordinary"]["output"] == row["empty"]["output"] == word and row["repeat"]["fresh"]
    records.append(row)
    print(i,role,t,word,row["ordinary"],flush=True)
    (at/"verified.json").write_text(json.dumps(records,indent=2,sort_keys=True)+"\n")
