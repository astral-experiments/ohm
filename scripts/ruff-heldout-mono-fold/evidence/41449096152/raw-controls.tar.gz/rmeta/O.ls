Crate info:
name annotate_snippets-505afd119b4de8d0
private hash f2256c8ac4b814cc81faad28f099dc91 stable_crate_id StableCrateId(8857098455413326838)
public_hash 0d3912fab66d14216bcfedb2a8f98bc7
proc_macro false
triple x86_64-unknown-linux-gnu
edition 2024
symbol_mangling_version V0
required_panic_strategy None panic_in_drop_strategy Unwind
has_global_allocator false has_alloc_error_handler false has_panic_handler false has_default_lib_allocator false
compiler_builtins false needs_allocator false needs_panic_runtime false no_builtins false panic_runtime false profiler_runtime false
=External Dependencies=
1 std-2ce2949fc8825be5 hash f5035208c9ddf10c2d507989f325a228 host_hash None kind Unconditional public
2 core-f40666ee6546e2ee hash fa01f0a0184e594d6d697efaf91bedc4 host_hash None kind Unconditional public
3 alloc-0897f55eb35fbe1e hash 038d1854ffe182021cb937595078709f host_hash None kind Unconditional public
4 compiler_builtins-f340bea5124064d0 hash 238d907f11c7b14a1a13f172b328c989 host_hash None kind Unconditional private
5 libc-589d477f8c390763 hash 2af5aa7adeb9da178f8c6bb28710e05a host_hash None kind Unconditional public
6 rustc_std_workspace_core-a3bdb0ab04d4eadc hash 1fa061b8e4786a34ef6c60dec34e8e6b host_hash None kind Unconditional public
7 unwind-3e914a72b4232b7d hash ef729804916e82bde900360c4c1a3daa host_hash None kind Unconditional private
8 miniz_oxide-86c6307b8aa18b19 hash 599d770b7a4d42a027aea37d9562d414 host_hash None kind Unconditional private
9 adler2-a2fd55ade1936294 hash 68f9ffab5137d6e0cae0e1d53a076a73 host_hash None kind Unconditional private
10 hashbrown-d2a50e628217e10a hash fef56d0239a34f0fb2669d55b60532e9 host_hash None kind Unconditional private
11 rustc_std_workspace_alloc-0a5b6e2db130c737 hash 4a2f4989eb4175b7cd973e854b33e7ee host_hash None kind Unconditional public
12 std_detect-60bbe981d1547d9e hash 52bc3c636ab3285eb0d5934d8271f0cf host_hash None kind Unconditional public
13 rustc_demangle-dfad363bc67c7609 hash a15f0bb98a9ded6d55839cff0cd2eb27 host_hash None kind Unconditional private
14 cfg_if-842ad700bf392974 hash e6078a25acbed650ed54058747808842 host_hash None kind Unconditional private
15 addr2line-319ab9ba5de9a3e1 hash db824da742650429c15f94b29feea941 host_hash None kind Unconditional private
16 gimli-8fe263766806f8ff hash 5ccf04eb2f1945859dd3e3823cd6cd77 host_hash None kind Unconditional private
17 object-0129bff590479925 hash a03dfd7233a8e257393f1baa46ab4402 host_hash None kind Unconditional private
18 memchr-efc45e3fc6b0750f hash fb44d7aaa69437a569c36ba9a94db5aa host_hash None kind Unconditional public
19 panic_unwind-abc6b7174b8ee71b hash 1185108a469931c8b36a5cef24d0a013 host_hash None kind Conditional private
20 anstyle-50373ade54f8fc0b hash 257c1fff2e80fd16d9dab0c84f5785e4 host_hash None kind Unconditional public
21 unicode_width-df7b80bc13a63b37 hash 0a67fed623b42e880298c11082647358 host_hash None kind Unconditional public
22 memchr-92419361db95f4a0 hash b5251659c104790f44075ffd180d5c5c host_hash None kind Unconditional public

=Lang items=

=Lib features=

=Items=
Public Mod crate {
    Public Mod level {
        Public Const { is_type_const: false } ERROR {}
        Public Const { is_type_const: false } WARNING {}
        Public Const { is_type_const: false } INFO {}
        Public Const { is_type_const: false } NOTE {}
        Public Const { is_type_const: false } HELP {}
        Public Struct Level {}
    }
    Public Mod renderer {
        Public Const { is_type_const: false } DEFAULT_TERM_WIDTH {}
        Public Const { is_type_const: false } DEFAULT_ERROR_STYLE {}
        Public Const { is_type_const: false } DEFAULT_WARNING_STYLE {}
        Public Const { is_type_const: false } DEFAULT_INFO_STYLE {}
        Public Const { is_type_const: false } DEFAULT_NOTE_STYLE {}
        Public Const { is_type_const: false } DEFAULT_HELP_STYLE {}
        Public Const { is_type_const: false } DEFAULT_LINE_NUM_STYLE {}
        Public Const { is_type_const: false } DEFAULT_EMPHASIS_STYLE {}
        Public Const { is_type_const: false } DEFAULT_NONE_STYLE {}
        Public Const { is_type_const: false } DEFAULT_CONTEXT_STYLE {}
        Public Const { is_type_const: false } DEFAULT_ADDITION_STYLE {}
        Public Const { is_type_const: false } DEFAULT_REMOVAL_STYLE {}
        Public Struct Renderer {}
        Public Enum DecorStyle {
            Public Variant Ascii {}
            Public Ctor(Variant, Const) ??? {}
            Public Variant Unicode {}
            Public Ctor(Variant, Const) ??? {}
        }
    }
    Public Fn normalize_untrusted_str {}
}

=Target modifiers=
Public hash: 0d3912fab66d14216bcfedb2a8f98bc7

