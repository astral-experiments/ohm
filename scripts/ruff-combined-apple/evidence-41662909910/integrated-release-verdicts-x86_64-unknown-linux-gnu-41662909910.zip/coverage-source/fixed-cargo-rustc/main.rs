fn main() {
    let answer = 29;
    println!("answer={answer}");
}
