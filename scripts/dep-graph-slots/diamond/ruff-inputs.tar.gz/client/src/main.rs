fn main() {
    let offset = facade::TextSize::new(5);
    println!("{} {}", facade::line_start("one\ntwo", offset).to_u32(), offset.to_u32());
}
