#[doc(inline)]
pub use ruff_text_size::TextSize;

/// Returns the start of the line that contains the given byte offset.
pub fn line_start(text: &str, offset: TextSize) -> TextSize {
    let index = ruff_source_file::LineIndex::from_source_text(text);
    let code = ruff_source_file::SourceCode::new(text, &index);
    code.line_start(code.line_index(offset))
}
