"""Offline opening checks for canonical-path, ordinary-root uv #20991 products."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
from types import SimpleNamespace
import gzip
import importlib.util
import json
import re
import shlex


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod


def sha(path):
    with path.open('rb') as f:
        import hashlib
        return hashlib.file_digest(f,'sha256').hexdigest()


def read(p):return json.loads(p.read_bytes())
def digest(v):return sha256(json.dumps(v,separators=(',',':'),sort_keys=True).encode()).hexdigest()
def ordered(xs):return sorted(xs,key=lambda v:json.dumps(v,sort_keys=True))


class Opening:
    def __init__(self,package):
        base=package/'check-root-20261101'
        self.s=load('exact_rmeta_surface',base/'rc23-production-root-surface/surface.py')
        self.p=load('direct_ordinary_readback',base/'ctfe318-matched/next-20991/products.py')
        self.decoder=load('terminal_cold_B_history',base/'ctfe-root-attribution/metadata.py')
        self.fx=load('actual_quiet_fixture',base/'second-edit-20991/fixture.py')
        self.arm=SimpleNamespace(core=SimpleNamespace(READ=read),a=SimpleNamespace(sha=sha),c=SimpleNamespace(st=vars(self.s)))

    def witness(self,path,state,case):
        q=read(path/'receipt.json');assert q['source']==case[state] and q['upstream_test_source_sha256']==case['test'][state]
        assert q['official_tests']==self.fx.NAMES
        assert q['official_argv']==['/tmp/uv-workflow-search/sdk/bin/cargo','test','--locked','--offline','-j4','-p','uv','--test','workspace','--',*self.fx.NAMES,'--exact','--test-threads=1']
        out=gzip.decompress((path/'official.stdout.gz').read_bytes())
        assert sorted(re.findall(rb'^test (\S+) \.\.\. ok$',out,re.M))==[x.encode() for x in self.fx.NAMES]
        assert re.search(rb'^test result: ok\. 2 passed; 0 failed;',out,re.M)
        assert re.fullmatch(r'[0-9a-f]{64}',q['uv_sha256']) and q['query_argv']==['workspace','metadata']
        for arg,label in [('--quiet','quiet'),('-qq','qq')]:
            so=gzip.decompress((path/(label+'.stdout.gz')).read_bytes());se=gzip.decompress((path/(label+'.stderr.gz')).read_bytes())
            folder=Path('/unseen')
            if state=='C' and arg=='--quiet':
                use=json.loads(so)['workspace_root'];assert re.fullmatch(r'/tmp/uv-workflow-search/fixture-runtime/tmp[\w-]+/foo',use);folder=Path(use)
            assert self.fx.expected(so,0,se,state,case['snapshot'],folder,arg)==q['observed'][arg]
        return q['observed']

    def roster(self,diag):
        calls=read(diag/'all-rustc-argv.json')
        stderr=gzip.decompress((diag/'cargo.stderr.gz').read_bytes()).decode()
        actual=[]
        for line in stderr.splitlines():
            strip=line.strip()
            if strip.startswith('Running `') and strip.endswith('`'):
                argv=shlex.split(strip[9:-1]);compiler='/tmp/uv-workflow-search/sdk/bin/rustc'
                if compiler in argv:actual.append(argv[argv.index(compiler):])
        assert actual==calls
        def logical(v):return [v[v.index('--crate-name')+1],v[v.index('--crate-type')+1]]
        assert sorted(map(logical,actual))==[['build_script_build','bin'],['uv','lib'],['uv_python','lib']]
        rows=self.s.rows(diag/'edited-cargo.jsonl.gz');shape=self.s.inputs(rows)
        dirty=[{'name':v['target']['name'],'kind':v['target']['kind'],'package':v['package_id'],'features':v['features'],'filenames':v['filenames']} for v in rows if not v['fresh']]
        q=read(diag/'diagnostic.json');assert ordered(q['typed_nonfresh'])==ordered(dirty) and len(dirty)==19
        assert len(q['progress'])==16 and q['progress']==sorted(s.decode() for s in re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',stderr.encode(),re.M))
        assert len(shape[0])==641 and len(shape[1])==70
        return {'argv':ordered(actual),'shape':digest(shape[0]),'dirty':ordered(dirty),'progress':q['progress']},shape

    def terminal(self,path):
        q=read(path/'uv-product.json');p=path/q['file']
        assert p.parent==path and sha(p)==q['raw_sha256'] and p.stat().st_size==q['bytes'] and sha(path/'uv-root.txt')==q['full_root_dump_sha']
        header,defs,exps,alloc,_=self.decoder.parse(str(p))
        assert (header['public_svh'],header['private_svh'],header['stable_crate_id'])==(q['public'],q['private'],format(int(q['stable']),'016x'))
        assert header['target']=='x86_64-unknown-linux-gnu' and header['raw_sha256']==q['raw_sha256']
        reachable={k:bytes.fromhex(v[0]).ljust(17,b'\x00')[1:].hex() for k,v in defs.items() if any(bytes.fromhex(v[0]))}
        assert reachable and exps and alloc
        key_fields=('target','crate_name','private_svh','public_svh','stable_crate_id','global_public_hash','definition_count','reachable_expansions','allocation_records','distinct_allocation_records','allocation_tags','allocation_order_sha256')
        return (tuple(header[k] for k in key_fields),set(defs),reachable,exps,alloc),q

    def audit(self,path,ref,case,ordinary='C-from-independent-B-ordinary',typed='C-from-independent-B-diagnostic',cold='C-independent-cold'):
        o,t,c=(path/x for x in (ordinary,typed,cold))
        actual,shape=self.roster(t);assert actual==ref,'actual rustc, features, target, output or native work changed'
        ov=self.p.plain(self.arm,o,shape);tv=self.p.typed(self.arm,t);cv=self.p.plain(self.arm,c,shape)
        assert tv['roster']==shape[0] and set(ov['raws'])==set(cv['raws'])==set(tv['raws'])
        for k in ('raws','surfaces','consumer'):assert ov[k]==tv[k],('literal versus typed replay from same B changed',k)
        assert ov['surfaces']==cv['surfaces'] and ov['consumer']==cv['consumer'],'one or more warm/cold C root headers, public/private hashes, dependencies or downstream diagnoses changed'
        assert len(ov['consumer'])==2 and ov['consumer'][0]==['compiled'] and ov['consumer'][1][0]=='E0308'
        orig=read(o/'source.json')
        assert orig==read(t/'source.json')==read(c/'source.json') and orig['head']==case['B'] and orig['index_tree']==case['B_tree'] and orig['working_tree']==case['C_tree'] and orig['patch']==case['patch'] and orig['lock']==case['lock']
        proj,q=self.terminal(o);tp,_=self.terminal(t);cp,_=self.terminal(c)
        assert proj==tp==cp,'terminal definition keys, fingerprints, expansions, global/crate identities or allocation contents/order differ'
        fx={s:self.witness(path/('witness-'+s),s,case) for s in ('B','C')}
        drift={k:[ov['raws'][k],cv['raws'][k]] for k in ov['raws'] if ov['raws'][k]!=cv['raws'][k]}
        return {'same_seed_raw':70,'same_C_decoded_and_consumed':70,'ordinary':str(o.name),'cold':str(c.name),'raw_processes':len(actual['argv']),'typed_shape':actual['shape'],
                'terminal_reachable_definitions':len(proj[2]),'terminal_expansions':len(proj[3]),'allocation_records':sum(proj[4].values()),
                'terminal_public':q['public'],'terminal_private':q['private'],'real_separate_fixtures':fx,'cold_raw_drift':dict(sorted(drift.items())),
                'raw_byte_identity':not drift,'perf_authority':False}
