"""Run upstream's two native tests, then retain stdout from the built uv CLI."""
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip
import json
import os
import re
import subprocess

NAMES = ["workspace_metadata::workspace_metadata_extra_quiet","workspace_metadata::workspace_metadata_quiet"]

def save_streams(folder,stem,p):
    for suffix,data in (("stdout",p.stdout),("stderr",p.stderr)):
        with gzip.open(folder/(stem+"."+suffix+".gz"),"xb",compresslevel=2) as z:z.write(data)

def expected(raw,rc,stderr,state,snapshot,root,quiet):
    assert rc==0 and stderr==b"", (rc,stderr[-700:])
    if state=="B" or quiet=="-qq":
        assert raw==b"", ("unexpected quiet stdout",len(raw))
        return "empty"
    assert raw.strip() and raw.endswith(b"\n")
    actual=json.loads(raw.decode().replace(str(root),"[TEMP_DIR]/foo"))
    assert actual==snapshot,("quiet JSON differed from upstream snapshot",actual)
    return "upstream-full-json"

def run(core,a,out,env,reg,state,target):
    import source
    rev={"B":source.B,"C":source.C}[state]
    assert source.sha((core.SRC/source.TEST).read_bytes())==reg["source"]["files"][rev][source.TEST]["sha256"]
    out.mkdir()
    tmpbase=core.LANE/"fixture-runtime";tmpbase.mkdir(exist_ok=True)
    with TemporaryDirectory(dir=tmpbase) as td:
        w=Path(td);(w/"home").mkdir();(w/"tmp").mkdir()
        t=env|{"HOME":str(w/"home"),"TMPDIR":str(w/"tmp"),"CARGO_TARGET_DIR":str(target),"CARGO_INCREMENTAL":"0",
               "CARGO_PROFILE_TEST_DEBUG":"0","CARGO_PROFILE_DEV_DEBUG":"0","INSTA_UPDATE":"no",
               "UV_PYTHON_DOWNLOADS":"never","UV_OFFLINE":"true","UV_CACHE_DIR":str(w/"cache")}
        cmd=[str(core.SDK/"bin/cargo"),"test","--locked","--offline","-j4","-p","uv","--test","workspace","--",*NAMES,
             "--exact","--test-threads=1"]
        p=subprocess.run(cmd,cwd=core.SRC,env=t,capture_output=True,timeout=1800)
        save_streams(out,"official",p)
        names=sorted(re.findall(rb"^test (\S+) \.\.\. ok$",p.stdout,re.M))
        assert p.returncode==0 and names==[n.encode() for n in NAMES], (p.returncode,names,p.stderr[-1000:],p.stdout[-1200:])
        exe=target/"debug/uv";assert exe.is_file()
        init=[str(exe),"init","foo","--python","3.12"]
        q=subprocess.run(init,cwd=w,env=t,capture_output=True,timeout=90)
        save_streams(out,"init",q); assert q.returncode==0, q.stderr[-900:]
        results={}
        for level in ("--quiet","-qq"):
            argv=[str(exe),"workspace","metadata",level]
            r=subprocess.run(argv,cwd=w/"foo",env=t,capture_output=True,timeout=90)
            save_streams(out,level.lstrip("-"),r)
            results[level]=expected(r.stdout,r.returncode,r.stderr,state,reg["source"]["official_C_snapshot"],w/"foo",level)
        a.save(out/"receipt.json",{"source":rev,"official_tests":NAMES,"official_argv":cmd,"uv_sha256":a.sha(exe),
                "query_argv":["workspace","metadata"],"observed":results,"upstream_test_source_sha256":a.sha(core.SRC/source.TEST)})
