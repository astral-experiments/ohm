"""Authenticate the local three-commit source and the two observed quiet snapshots."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import tempfile
import tomllib

A = "b60da7ad468d5bb8a6b3dee7d7e54a47981f23c7"
B = "1979349b68dbaa936b98c0f409c1df0598fa72f1"
C = "5d4a62d7461c7708f3e65d08cef0e99bad94c004"
PROD = "crates/uv/src/commands/workspace/metadata.rs"
TEST = "crates/uv/tests/workspace/workspace_metadata.rs"
FIRST = ("crates/uv-bench/benches/workspace_discovery.rs", "crates/uv-workspace/src/workspace.rs")
TRACK = (PROD, TEST, *FIRST, "Cargo.lock")
SCOPE = {"GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_GLOBAL":"/dev/null","GIT_NO_LAZY_FETCH":"1","GIT_ALLOW_PROTOCOL":"file",
         "PATH":"/usr/bin:/bin","LC_ALL":"C"}
def sha(data): return hashlib.sha256(data).hexdigest()
def raw(bank,*args): return subprocess.check_output(["git","--git-dir",bank/"uv.git",*args],env=SCOPE)
def blob(bank,rev,path): return raw(bank,"show",f"{rev}:{path}")

def fixture_text(data,child):
    text = data.decode()
    quiet = text.split("fn workspace_metadata_quiet() {",1)[1].split("\n}",1)[0]
    extra = text.split("fn workspace_metadata_extra_quiet() {",1)[1].split("\n}",1)[0]
    assert 'test_context!("3.12")' in quiet and '.arg("foo")' in quiet and '.arg("--quiet")' in quiet
    assert 'exit_code: 0 (success)' in quiet and 'exit_code: 0 (success)' in extra and '----- stdout -----' not in extra
    assert ('----- stdout -----' in quiet) == child
    if not child:return None
    snapshot = json.loads(quiet.split("----- stdout -----",1)[1].rsplit('"#);',1)[0].strip())
    assert snapshot["workspace_root"]=="[TEMP_DIR]/foo" and len(snapshot["members"])==1 and snapshot["members"][0]["name"]=="foo"
    assert snapshot["schema"]=={"version":"preview"} and snapshot["requires_python"]==">=3.12" and len(snapshot["resolution"])==2
    return snapshot

def source(bank):
    assert raw(bank,"rev-parse",B+"^",C+"^").decode().splitlines()==[A,B]
    trees={r:raw(bank,"rev-parse",r+"^{tree}").decode().strip() for r in (A,B,C)}
    deltas={}; objects={}
    for old,new,files in ((A,B,FIRST),(B,C,(PROD,TEST))):
        assert raw(bank,"diff","--name-only",old,new).decode().splitlines()==list(files)
        text=raw(bank,"diff","--binary","--full-index",old,new)
        assert raw(bank,"diff","--numstat",B,C,"--",PROD).decode().strip()==f"1\t1\t{PROD}"
        deltas[old+".."+new]=sha(text)
    for rev in (A,B,C):
        rev_files={}
        for rel in TRACK:
            data=blob(bank,rev,rel);info=raw(bank,"rev-parse",rev+":"+rel).decode().strip()
            assert hashlib.sha1(f"blob {len(data)}\0".encode()+data).hexdigest()==info
            rev_files[rel]={"blob":info,"sha256":sha(data)}
        objects[rev]=rev_files
    assert len({objects[r]["Cargo.lock"]["sha256"] for r in trees})==1
    base=blob(bank,B,PROD); child=blob(bank,C,PROD)
    before=b'if printer.stdout() == Stdout::Enabled {'; after=b'if printer.stdout_important() == Stdout::Enabled {'
    assert base.count(before)==1 and base.replace(before,after)==child
    assert fixture_text(blob(bank,B,TEST),False) is None
    snapshot=fixture_text(blob(bank,C,TEST),True)
    entries=tomllib.loads(blob(bank,C,"Cargo.lock").decode())["package"]
    registry={x["name"]+"-"+x["version"]:x["checksum"] for x in entries if x.get("source","").startswith("registry+")}
    receipt=json.loads((bank/"receipt.json").read_bytes())
    assert len(registry)==receipt["registry"]["locked"]==658
    cache,=(bank/"registry/cache").iterdir()
    assert all((cache/(k+".crate")).is_file() for k in registry)
    return {"revisions":[A,B,C],"trees":trees,"patches":deltas,"files":objects,"official_C_snapshot":snapshot,
            "registry_archives":len(registry),"registry_inventory_sha256":receipt["registry"]["sha256"],
            "locked_checksums_sha256":sha(json.dumps(registry,sort_keys=True).encode()),
            "bank_receipt_sha256":sha((bank/"receipt.json").read_bytes()),
            "verified_source_receipt_sha256":sha((bank/"verified-source.json").read_bytes())}

def worktree(core,env,reg,head,working,delta):
    f=reg["source"]
    assert core.git(env,"rev-parse","HEAD").decode().strip()==head
    assert core.git(env,"write-tree").decode().strip()==f["trees"][head]
    assert core.git(env,"diff","--binary","--full-index")==delta
    assert not core.git(env,"ls-files","--others","--exclude-standard")
    for rel in TRACK: assert sha((core.SRC/rel).read_bytes())==f["files"][working][rel]["sha256"]
    return {"head":head,"index_tree":f["trees"][head],"working_revision":working,"working_tree":f["trees"][working],
            "patch":sha(delta),"lock":f["files"][working]["Cargo.lock"]["sha256"]}
