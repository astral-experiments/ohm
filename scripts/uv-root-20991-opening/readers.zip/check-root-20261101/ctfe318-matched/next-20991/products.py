"""Inventory real plain products without replaying Cargo. CPU clocks have already stopped."""
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile,ZIP_DEFLATED
import gzip,json,re,subprocess

def capture_plain(r,path,shape,env):
    st=r.c.st;core=r.core;registered,workspace,externs,dirs=shape
    raw=r.core.READ(path/'workspace-products.json')
    assert len(registered)==641 and len(workspace)==70 and raw.keys()==workspace.keys()
    zpath=path/'ordinary-surfaces.zip';args=st['consumer_args'](externs,dirs)
    e=env|{'RUSTC_BOOTSTRAP':'1'}
    with ZipFile(zpath,'x',ZIP_DEFLATED,compresslevel=2) as z:
        z.writestr('raw-inventory.json',st['canon'](raw));z.writestr('downstream-argv.json',st['canon'](args))
        for i,(rel,info) in enumerate(sorted(workspace.items())):
            p=core.TARGET/rel;assert p.resolve(strict=True)==p and p.is_relative_to(core.TARGET)
            assert [p.stat().st_size,r.a.sha(p)]==raw[rel]
            rc=subprocess.run([core.RUSTC,'-Zls=root',p],cwd=core.SRC,env=e,capture_output=True,timeout=60)
            assert rc.returncode==0 and not rc.stderr
            st['decode'](rc.stdout,info['name'])
            z.writestr(f'{i}.txt',rc.stdout)
        with TemporaryDirectory(dir=core.LANE,prefix='actual-plain-surface-') as loc:
            loc=Path(loc)
            for label,body in [('positive',st['POS']),('negative',st['NEG'])]:
                (loc/'consumer.rs').write_text(body)
                output=loc/'consumer.rmeta';output.unlink(missing_ok=True)
                rc=subprocess.run(args,cwd=loc,env=e,capture_output=True,timeout=90)
                assert not rc.stdout and output.exists()==(label=='positive')
                st['consumer_result'](rc.stderr,rc.returncode,label=='positive')
                z.writestr(label+'.stderr',rc.stderr);z.writestr(label+'.code',str(rc.returncode))
    assert all([r.core.TARGET.joinpath(rel).stat().st_size,r.a.sha(core.TARGET/rel)]==v for rel,v in raw.items())
    r.a.save(path/'ordinary-surface-receipt.json',{'archive':r.a.sha(zpath),'workspace_files':70,'workspace_product_receipt':r.a.sha(path/'workspace-products.json'),
        'ordinary_command':r.a.sha(path/'ordinary.json'),'post_clock':True,'shape':'70 registered workspace products at their actual paths. The 641-unit Cargo journal is from a separate identical-source diagnostic.'})

def plain(r,p,shape):
    q=r.core.READ(p/'ordinary-surface-receipt.json');z=p/'ordinary-surfaces.zip';ws=shape[1];st=r.c.st
    assert q['archive']==r.a.sha(z) and q['workspace_product_receipt']==r.a.sha(p/'workspace-products.json') and q['ordinary_command']==r.a.sha(p/'ordinary.json') and q['post_clock']
    roots={}
    with ZipFile(z) as f:
        raw=json.loads(f.read('raw-inventory.json'));assert raw==r.core.READ(p/'workspace-products.json') and set(raw)==set(ws)
        assert json.loads(f.read('downstream-argv.json'))==st['consumer_args'](shape[2],shape[3])
        for i,(rel,val) in enumerate(sorted(ws.items())):roots[rel]=st['decode'](f.read(f'{i}.txt'),val['name'])
        result=[st['consumer_result'](f.read(label+'.stderr'),int(f.read(label+'.code')),label=='positive') for label in ('positive','negative')]
    return {'surfaces':roots,'raws':raw,'consumer':result,'observed_cargo_roster':False}

def typed(r,p):
    q=r.core.READ(p/'diagnostic.json')
    assert q['surfaces_sha256']==r.a.sha(p/'edited-rmeta-surface.zip')
    actual=r.c.st['verify'](p,'edited');assert actual['raws']==r.core.READ(p/'workspace-products.json') and len(actual['roster'])==641 and len(actual['surfaces'])==70
    return actual|{'observed_cargo_roster':True}

def compare(x,y):
    assert x['surfaces'].keys()==y['surfaces'].keys() and len(x['surfaces'])==70
    public=[];decoded={};raw=[]
    for k,a in x['surfaces'].items():
        b=y['surfaces'][k]
        if a['public_hash']!=b['public_hash']:public.append(k)
        if a!=b:decoded[k]=[f for f in a if a[f]!=b[f]]
        if x['raws'][k]!=y['raws'][k]:raw.append(k)
    semantic=x['consumer']==y['consumer'] and x['consumer'][0]==['compiled'] and x['consumer'][1][0]=='E0308'
    same_roster=x['roster']==y['roster'] if x['observed_cargo_roster'] and y['observed_cargo_roster'] else None
    return {'all_70_decoded_and_behavior_agree':not decoded and semantic and same_roster is not False,'public_hash_differences':public,
            'decoded_root_differences':decoded,'raw_byte_differences':raw,'downstream_matches':semantic,'both_typed_rosters_match':same_roster}

def unit(argv):
    def one(flag):return argv[argv.index(flag)+1] if flag in argv else None
    vals=lambda flag:[v for p,v in zip(argv,argv[1:]) if p==flag]
    src=[v for v in argv if v.endswith('.rs') and not v.startswith('-')]
    assert len(src)==1 and one('--crate-name')
    features=sorted(x for x in vals('--cfg') if x.startswith('feature='))
    flags=sorted(x for x in vals('-C') if x.startswith(('metadata=','extra-filename=')))
    return json.dumps([one('--crate-name'),one('--crate-type'),src[0],features,flags,one('--target'),'--test' in argv,one('--emit')],separators=(',',':'))

def work(r,p):
    q=r.core.READ(p/'diagnostic.json')
    with gzip.open(p/'cargo.stderr.gz','rt') as f:stderr=f.read()
    with gzip.open(p/'cargo.stdout.gz','rb') as f:events,owners=r.c.io.events(f.read())
    calls=r.c.io.commands(stderr,r.core.RUSTC) if ' --crate-name ' in stderr else []
    assert calls==r.core.READ(p/'all-rustc-argv.json')
    rows=[v for v in events if v['reason']=='compiler-artifact'];assert r.c.st['inputs'](rows)==r.c.reference()[3]
    progress=r.observe.package_lines(stderr.encode());assert q['progress']==progress
    expected=[(v['target']['name'],v['target']['kind'],v['package_id'],v['features'],v['filenames']) for v in rows if not v['fresh']]
    assert expected==[(v['name'],v['kind'],v['package'],v['features'],v['filenames']) for v in q['typed_nonfresh']]
    with gzip.open(p/'timings.html.gz','rt') as f:intervals=r.observe.intervals(f.read())
    assert json.loads(json.dumps(intervals))==q['cargo_timing']
    return {'actual_rustc_multiset':dict(sorted(Counter(map(unit,calls)).items())),'actual_rustc_count':len(calls),'reported_nonfresh':len(expected),'reported_units':expected,
       'argv_archive':r.a.sha(p/'all-rustc-argv.json'),'progress':progress,'descriptive_sole_cs':intervals['units'][:12]}

def diff(base,test):return dict(sorted((Counter(base)-Counter(test)).items()))

def intervention(bw,bc,fw,fc):
    candidate=diff(bw,fw)
    removed={k:min(v,bw.get(k,0)-bc.get(k,0)) for k,v in candidate.items() if bw.get(k,0)>bc.get(k,0) and bc.get(k,0)==fc.get(k,0)==fw.get(k,0)}
    return {'removed_actual_warm_units':candidate,'added_actual_warm_units':diff(fw,bw),'both_cold_B_histories_same_units':bc==fc,
            'parent_warm_excess_that_both_fixed_and_independent_histories_avoid':removed,'parent_warm_vs_own_coldB_extra':diff(bw,bc),'fixed_warm_vs_own_coldB_extra':diff(fw,fc)}
