"""Check all actual workspace metadata roots and a downstream caller from the sealed #20988 graph."""
import gzip,hashlib,json,re,subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path('/tmp/uv-workflow-search');TARGET=ROOT/'target';SDK=ROOT/'sdk'
LIBS=('uv_workspace','uv_resolver')
POS='pub fn make_cache() -> uv_workspace::WorkspaceCache { uv_workspace::WorkspaceCache::default() }\npub fn keep(x: uv_resolver::Options) -> uv_resolver::Options { x }\n'
NEG=POS+'pub fn wrong(x: uv_resolver::Options) -> uv_workspace::WorkspaceCache { x }\n'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
def rows(p):
    with gzip.open(p,'rb') as f:rs=[json.loads(l) for l in f if l.strip()]
    assert rs[-1]=={'reason':'build-finished','success':True}
    return [r for r in rs if r['reason']=='compiler-artifact']
def inputs(art):
    roster=sorted(canon({k:e[k] for k in ('package_id','target','features','profile','filenames','executable')}).decode() for e in art)
    assert len(roster)==len(set(roster))==641
    workspace={};externs={};dirs=set()
    for e in art:
        for p in map(Path,e['filenames']):
            assert p.is_relative_to(TARGET);dirs.add(str(p.parent))
            if e['target']['kind']!=['lib'] or p.suffix!='.rmeta' or not Path(e['target']['src_path']).is_relative_to(ROOT/'uv/crates'):continue
            rel=str(p.relative_to(TARGET));name=e['target']['name'];assert rel not in workspace
            workspace[rel]=dict(name=name,features=sorted(e['features']),package=e['package_id'])
            if name in LIBS:
                assert name not in externs and sorted(e['features'])==['clap','schemars'];externs[name]=str(p)
    assert len(workspace)==70 and set(externs)==set(LIBS)
    return roster,workspace,externs,sorted(dirs)
def decode(raw,want):
    header,deps=raw.decode().split('=External Dependencies=\n');lines=header.splitlines()
    assert lines[0]=='Crate info:' and re.fullmatch('name '+re.escape(want)+r'-[0-9a-f]+',lines[1])
    priv,sid=re.fullmatch(r'private hash ([0-9a-f]{32}) stable_crate_id StableCrateId\((\d+)\)',lines[2]).groups()
    public,=re.findall(r'^public_hash ([0-9a-f]{32})$',header,re.M)
    assert 'triple x86_64-unknown-linux-gnu' in lines and len(lines)>=11
    named=[]
    for n,line in enumerate(deps.strip().splitlines(),1):
        number,record=line.split(' ',1)
        assert int(number)==n and ' hash ' in record and ' host_hash ' in record and ' kind ' in record;named.append(record)
    # Normalize only the ordinal in rustc's local dependency table.
    return dict(public_hash=public,private_hash=priv,stable_crate_id=sid,header=lines[:2]+lines[3:],dependencies=sorted(named))
def consumer_args(externs,dirs):
    return [str(SDK/'bin/rustc'),'--crate-name','ohm_uv_20988_surface','--edition=2024','--crate-type=lib','--error-format=json','--emit=metadata','-o','consumer.rmeta',
            *(arg for name in LIBS for arg in ('--extern',name+'='+externs[name])),
            *(arg for d in dirs for arg in ('-L','dependency='+d)),'consumer.rs']
def consumer_result(raw,code,positive):
    ds=[json.loads(l) for l in raw.splitlines() if l.strip()]
    if positive:
        assert code==0 and not ds
        return ['compiled']
    e=[d for d in ds if d.get('level')=='error' and d.get('code')]
    assert code!=0 and [(d['code']['code'],d['message']) for d in e]==[('E0308','mismatched types')]
    s,=[s for s in e[0]['spans'] if s['is_primary']]
    assert s['file_name']=='consumer.rs' and s['line_start']==3
    label=s['label'];assert 'expected' in label and 'WorkspaceCache' in label and 'Options' in label
    return ['E0308','mismatched types',label]
def capture(out,label):
    roster,workspace,externs,dirs=inputs(rows(out/(label+'-cargo.jsonl.gz')))
    env={'PATH':str(SDK/'bin')+':/usr/bin:/bin','HOME':str(ROOT/'home'),'RUSTC_BOOTSTRAP':'1','LC_ALL':'C.UTF-8'}
    with ZipFile(out/(label+'-rmeta-surface.zip'),'x',ZIP_DEFLATED,compresslevel=2) as z:
        z.writestr('roster.json',canon(roster))
        for n,(rel,info) in enumerate(sorted(workspace.items())):
            p=TARGET/rel;assert p.resolve(strict=True).is_relative_to(TARGET) and p.is_file() and p.stat().st_size>0
            r=subprocess.run([str(SDK/'bin/rustc'),'-Zls=root',str(p)],cwd=ROOT/'uv',env=env,capture_output=True,timeout=60)
            assert r.returncode==0 and not r.stderr,(rel,r.stderr[-900:])
            d=decode(r.stdout,info['name']);z.writestr(f'{n}.root.txt',r.stdout)
            z.writestr(f'{n}.json',canon(info|dict(rel=rel,bytes=p.stat().st_size,sha256=sha(p))|{k:d[k] for k in ('public_hash','private_hash','stable_crate_id')}))
        argv=consumer_args(externs,dirs);z.writestr('argv.json',canon(argv))
        with TemporaryDirectory(dir=ROOT,prefix='ohm-20988-metadata-') as loc:
            work=Path(loc)
            for name,src in [('positive',POS),('negative',NEG)]:
                (work/'consumer.rs').write_text(src);product=work/'consumer.rmeta';product.unlink(missing_ok=True)
                r=subprocess.run(argv,cwd=work,env=env,capture_output=True,timeout=150);assert not r.stdout
                verdict=consumer_result(r.stderr,r.returncode,name=='positive')
                if name=='positive':assert product.is_file() and product.stat().st_size>0
                z.writestr(name+'.rs',src);z.writestr(name+'.stderr',r.stderr);z.writestr(name+'.json',canon(dict(exit=r.returncode,verdict=verdict)))
    return verify(out,label)
def verify(out,label):
    assert label in ('edited','clean-child','parent')
    roster,workspace,externs,dirs=inputs(rows(out/(label+'-cargo.jsonl.gz')));surfaces={};raws={}
    with ZipFile(out/(label+'-rmeta-surface.zip')) as z:
        assert z.testzip() is None and json.loads(z.read('roster.json'))==roster
        for n,(rel,info) in enumerate(sorted(workspace.items())):
            d=decode(z.read(f'{n}.root.txt'),info['name']);m=json.loads(z.read(f'{n}.json'))
            assert all(m[k]==v for k,v in info.items()) and m['rel']==rel and m['bytes']>0 and re.fullmatch('[0-9a-f]{64}',m['sha256'])
            assert all(m[k]==d[k] for k in ('public_hash','private_hash','stable_crate_id'))
            surfaces[rel]=d;raws[rel]=[m['bytes'],m['sha256']]
        assert json.loads(z.read('argv.json'))==consumer_args(externs,dirs)
        verdicts=[]
        for name,src in [('positive',POS),('negative',NEG)]:
            assert z.read(name+'.rs')==src.encode();m=json.loads(z.read(name+'.json'))
            assert m['verdict']==consumer_result(z.read(name+'.stderr'),m['exit'],name=='positive')
            verdicts.append(m['verdict'])
        assert len(z.namelist())==2*len(workspace)+8
    products=json.loads((out/(label+'-background-products.json')).read_bytes())
    for k,files in products.items():
        if json.loads(k)[2]==['lib']:
            assert all(raws[rel]==[size,sha] for rel,size,sha in files)
    return dict(roster=roster,surfaces=surfaces,raws=raws,consumer=verdicts,background=products)
def judgments(b,c):
    assert b['roster']==c['roster'] and b['surfaces'].keys()==c['surfaces'].keys() and b['consumer']==c['consumer']
    for rel,bd in b['surfaces'].items():
        cd=c['surfaces'][rel]
        assert bd['public_hash']==cd['public_hash'],('CURRENT/COLD PUBLIC MISMATCH',rel,bd['public_hash'],cd['public_hash'])
        assert bd==cd,('current/cold metadata root differs beyond byte encoding',rel,[k for k in bd if bd[k]!=cd[k]])
    assert b['background'].keys()==c['background'].keys() and len(b['background'])==19
    for key,records in b['background'].items():
        other=c['background'][key];assert [r[0] for r in records]==[r[0] for r in other]
        if json.loads(key)[2]!=['lib']:assert records==other,('nonlibrary product changed',key)
    return sorted(rel for rel in b['raws'] if b['raws'][rel]!=c['raws'][rel])
def compare(out):
    b,c=[verify(out,v) for v in ('edited','clean-child')];changed=judgments(b,c)
    return dict(complete_crate_target_feature_artifacts=len(b['roster']),workspace_library_metadata=len(b['surfaces']),
                differing_raw_rmeta_with_matching_decoded_roots=changed,downstream=b['consumer'],
                incremental_archive_sha256=sha(out/'edited-rmeta-surface.zip'),cold_archive_sha256=sha(out/'clean-child-rmeta-surface.zip'))
