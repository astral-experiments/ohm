pub fn field(x:&ruff::args::FormatCommand)->bool{x.extend_exclude.is_some()}
