pub fn field(x:&ruff::args::CheckCommand)->bool{x.extend_exclude.is_some()}
