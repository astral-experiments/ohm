
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
int main(int argc, char **argv) {
    if (argc != 3) return 10;
    int d = atoi(argv[1]); unsigned long long n = strtoull(argv[2], 0, 10);
    if (d) {
        pid_t c = fork(); int status; char depth[16];
        if (c < 0) return 11;
        if (!c) {
            snprintf(depth, sizeof(depth), "%d", d-1);
            execl(argv[0], argv[0], depth, argv[2], NULL); _exit(12);
        }
        if (waitpid(c, &status, 0) != c || !WIFEXITED(status)) return 13;
        return WEXITSTATUS(status);
    }
#if defined(__aarch64__)
    if (n) __asm__ volatile("1: subs %0, %0, #1\nb.ne 1b" : "+r"(n) : : "cc");
#else
    return 14;
#endif
    return 0;
}
