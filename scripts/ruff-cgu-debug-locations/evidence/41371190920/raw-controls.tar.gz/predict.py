from pathlib import Path
from collections import Counter
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import json,os,re,time
from old_inputs import *
from patch_dwarf import Image,Lines,SourceMap,abbrevs,reconstruct

def negatives(fixture,src,old,new):
 results={}
 def refuse(name,fn):
  try:fn()
  except (ValueError,OverflowError,IndexError)as e:results[name]=str(e);return
  raise AssertionError('negative did not refuse: '+name)
 omit=dict(src.map);del omit[1095];refuse('required_line_missing',lambda:SourceMap(PR,omit,old,new));damaged=list(new);damaged[src.map[1101]-1]=b' '+damaged[src.map[1101]-1];refuse('column_only_edit',lambda:SourceMap(PR,src.map,old,damaged));refuse('unbound_absolute_alias',lambda:src.location('/other-checkout/'+PR,1105,3));check(src.location('crates/other/src/options.rs',1105,3)==1105 and src.location(PR,1105,3)==1109 and src.location(PR,0,0)==0,'same-basename or line-zero sentinel');check([src.location(PR,i,0)for i in (1094,1095,1104,1105)]==[1094,1097,1106,1109],'wrong change boundary');e=Image(fixture);line=Lines(e.contents('.debug_line'));refuse('missing_line_table_file_reference',lambda:line.file(len(line.files)));ab=bytearray(e.contents('.debug_abbrev'));check(ab[:2]==b'\x01\x11','unexpected old abbreviation');ab[1]=0x34;refuse('variable_bearing_DWARF',lambda:reconstruct(e.replace({'.debug_abbrev':ab}),src));alternative=old[:100]+[b'\n']*70000+old[100:];extra=SourceMap(PR,{i:(i+70000 if i>100 else i)for i in range(1,len(old)+1)},old,alternative);refuse('encoding_width_or_relocation_offset_change',lambda:reconstruct(fixture,extra));return results

def main():
 mem=1024*int(re.search(r'^MemAvailable:\s*(\d+)',Path('/proc/meminfo').read_text(),re.M)[1]);check(mem>8*2**30+110_000_000,'wait for 8 GiB memory reserve');sources,mp,old,new=source();src=SourceMap(PR,mp,old,new);identity=SourceMap(PR,{i:i for i in range(1,len(old)+1)},old,old);plan,bodies=old_objects();predictions={}
 for k,b in sorted(bodies.items()):
  ctl,_=reconstruct(b,identity);check(ctl==b,'full original ELF does not roundtrip')
  try:
   out,d=reconstruct(b,src);d['predicted_bytes']=len(out)
  except (ValueError,OverflowError)as exc:d={'refusal':str(exc),'old_elf_sha':sha(b)}
  d['original_bytes']=len(b);d['old_identity_exact']=True;predictions[k]=d;print(k.split('.')[-1],d.get('refusal','predicted'),flush=True)
 controls=negatives(bodies[sorted(bodies)[0]],src,old,new);files=['old_inputs.py','patch_dwarf.py','predict.py','roster.txt'];llvm=D.parent/'strict-llvm-tree';commit=subprocess.check_output(['git','-C',llvm,'rev-parse','HEAD'],text=True).strip();check(commit=='1b9c0d5ff9bbe7634aead059efe6b11a7eeba145','wrong LLVM source');rel='llvm/lib/MC/MCDwarf.cpp';srcblob=subprocess.check_output(['git','-C',llvm,'show',commit+':'+rel]);check(sha(srcblob)==sha((llvm/rel).read_bytes()),'canonical LLVM source changed');packet=dict(scope='Old rlib predictions generated without opening warm New or empty New rlibs',old_plan='capture/old/cgus.json',old_archive_sha256=plan['archive']['sha256'],original_zip_sha256=ZIP_HASH,source_old=OLD,source_new=NEW,physical_source=sources,compiler_llvm=commit,llvm_mc_sha256=sha(srcblob),predictor_sha256={f:sha((D/f).read_bytes())for f in files},negative_controls=controls,rows=predictions);out=(json.dumps(packet,indent=1,sort_keys=True)+'\n').encode();(D/'predictions.json').write_bytes(out);print('SEALED',sha(out),len(predictions),'old-only full ELFs;',sum(bool(r.get('changed_bytes'))for r in predictions.values()),'changed projections;',controls,flush=True)
if __name__=='__main__':main()
