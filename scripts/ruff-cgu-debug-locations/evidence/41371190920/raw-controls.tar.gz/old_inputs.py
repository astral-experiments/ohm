"""This module only opens the OLD rustc plan and the archive named by that plan."""
from pathlib import Path
import gzip,hashlib,io,json,re,struct,subprocess,sys,zipfile
D=Path(__file__).resolve().parent;ROOT=D.parent;SOURCE=Path('/home/dev-user/code/oss/ruff');PR='crates/ruff_workspace/src/options.rs';OLD='3c77dcc2a5c04fc0c54ce95cd51068734015f3e0';NEW='088b7b5f77fcb05994fd2a17cbc940cd9edb341a';ZIP=Path('/run/ohm-first-a-leaves-v2-20261101/41371190920/ordinary-13109144871.zip');ZIP_HASH='53ede61bc14ac8e524813b6cac9d1cfbbcd595b5380fae363e681406aa7b404b';sys.path.insert(0,str(ROOT.parent/'ohm-ruff-first-a-cgu-budget-20261101'));from native_sections import iter_archive
sha=lambda data:hashlib.sha256(data).hexdigest()
def check(ok,reason):
 if not ok:raise ValueError(reason)
def old_objects():
 with ZIP.open('rb')as f:check(hashlib.file_digest(f,'sha256').hexdigest()==ZIP_HASH,'original ZIP changed')
 with zipfile.ZipFile(ZIP)as z:
  plan=json.loads(z.read('capture/old/cgus.json'))['ruff_workspace'];a=plan['archive'];check(a['sha256']=='2e7b9912290964a811f1ab91935f7d4a6808bfc1be37d6791ff1e37788af1af8'and a['stat'][2]<28_000_000,'wrong old rlib')
  with z.open('cgu-originals/'+a['sha256']+'.gz')as f,gzip.GzipFile(fileobj=f)as g:raw=g.read(a['stat'][2]+1)
  check(len(raw)==a['stat'][2]and sha(raw)==a['sha256'],'old archive digest');roster=set((D/'roster.txt').read_text().splitlines());check(len(roster)==21,'wrong registered new compile roster')
  objects={k:v for k,v in iter_archive(raw,'ruff_workspace')if k in roster};check(set(objects)==roster,'unavailable old unit');return plan,objects

def source():
 def git(*args):return subprocess.check_output(['git','--no-lazy-fetch','-C',SOURCE,*args]);
 parts=[git('show',commit+':'+PR)for commit in (OLD,NEW)];d=git('diff','--no-ext-diff','--no-textconv','--unified=0',OLD,NEW,'--',PR);hunks=[(int(m[1]),int(m[2]),int(m[3]))for m in re.finditer(rb'^@@ -(\d+),0 \+(\d+),(\d+) @@',d,re.M)];check(len(hunks)==d.count(b'\n@@ ') and hunks, 'source change is not pure whole-line insertion');old,new=[s.splitlines(keepends=True)for s in parts];check(all(b==a+1+sum(z for i,_,z in hunks if i<a)for a,b,_ in hunks),'ambiguous hunk coordinates');mapping={i:i+sum(n for a,_,n in hunks if i>a)for i in range(1,len(old)+1)};check(len(new)==len(old)+sum(n for _,_,n in hunks)and all(old[i-1]==new[j-1]for i,j in mapping.items()),'mapped source bytes differ');return dict(old_sha=sha(parts[0]),new_sha=sha(parts[1]),old_n=len(old),new_n=len(new),hunks=hunks,path=PR),mapping,old,new
