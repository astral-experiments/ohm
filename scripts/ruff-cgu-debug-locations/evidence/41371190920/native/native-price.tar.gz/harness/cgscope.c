#include <valgrind/callgrind.h>
void ohm_ordinal_begin(void) { CALLGRIND_START_INSTRUMENTATION; CALLGRIND_ZERO_STATS; }
void ohm_ordinal_end(void) { CALLGRIND_STOP_INSTRUMENTATION; }
