// Inserted verbatim into the externally measured QA crate. The backend files are read directly from the product checkout.
#[cfg(feature = "qa-counter")]
mod counter;
#[path = "/home/dev-user/code/oss/ohm-rust-source-coordinate-codegen-20261102/compiler/rustc_codegen_llvm/src/back/source_placement/mod.rs"]
mod source_placement;
use std::{
    env, fs,
    io::{self, Write},
    path::Path,
};
type Gate<T> = Result<T, &'static str>;
fn require(ok: bool, reason: &'static str) -> Gate<()> {
    if ok { Ok(()) } else { Err(reason) }
}

#[inline(never)]
#[unsafe(export_name = "ohm_product_rewrite")]
fn rehydrate(old: &[u8], a: &[u8], b: &[u8]) -> Gate<Vec<u8>> {
    source_placement::rewrite(old, a, b).ok_or("checked source placement refused")
}
fn input(path: &str, limit: u64) -> Gate<Vec<u8>> {
    let metadata = fs::metadata(Path::new(path)).map_err(|_| "input path inaccessible")?;
    require(
        metadata.is_file() && metadata.len() <= limit,
        "invalid input extent",
    )?;
    let data = fs::read(path).map_err(|_| "input read failed")?;
    require(
        data.len() as u64 == metadata.len(),
        "input changed during read",
    )?;
    Ok(data)
}
fn run() -> Gate<()> {
    let args: Vec<_> = env::args().skip(1).collect();
    match args.as_slice() {
        #[cfg(feature = "qa-counter")]
        [cmd, rest @ ..] if cmd == "meter" => counter::measure(rest),
        [cmd, old, a, b] if cmd == "rebase" => {
            let out = rehydrate(
                &input(old, 32 << 20)?,
                &input(a, 16 << 20)?,
                &input(b, 16 << 20)?,
            )?;
            io::stdout()
                .lock()
                .write_all(&out)
                .map_err(|_| "write failed")
        }
        _ => Err("usage: rebase/meter native old-OSP new-OSP"),
    }
}
fn main() {
    if let Err(e) = run() {
        eprintln!("fallthrough: {e}");
        std::process::exit(2)
    }
}
