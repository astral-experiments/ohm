use super::{Gate, input, rehydrate};
use std::io::{self, Write};
unsafe extern "C" {
    fn ohm_ordinal_begin();
    fn ohm_ordinal_end();
}

#[inline(never)]
#[unsafe(export_name = "ohm_native_open_and_read")]
fn open_three(old: &str, a: &str, b: &str) -> Gate<(Vec<u8>, Vec<u8>, Vec<u8>)> {
    Ok((
        input(old, 32 << 20)?,
        input(a, 16 << 20)?,
        input(b, 16 << 20)?,
    ))
}
#[inline(never)]
#[unsafe(export_name = "ohm_native_emit_then_drop")]
fn publish(v: Vec<u8>) -> Gate<()> {
    let mut stdout = io::stdout().lock();
    stdout
        .write_all(&v)
        .and_then(|()| stdout.flush())
        .map_err(|_| "scored output write failed")?;
    drop(v);
    Ok(())
}
#[inline(never)]
#[unsafe(export_name = "ohm_native_destroy_inputs")]
fn destroy(x: (Vec<u8>, Vec<u8>, Vec<u8>)) {
    drop(x)
}
#[inline(never)]
#[unsafe(export_name = "ohm_native_measured_call")]
fn body(old: &str, a: &str, b: &str) -> Gate<()> {
    let data = open_three(old, a, b)?;
    let out = rehydrate(&data.0, &data.1, &data.2).and_then(publish);
    destroy(data);
    out
}
pub fn measure(args: &[String]) -> Gate<()> {
    // argv and process startup are outside; opening, all allocations, complete output and all drops are inside.
    unsafe { ohm_ordinal_begin() };
    let res = match args {
        [] => Ok(()),
        [old, a, b] => body(old, a, b),
        _ => Err("wrong scoped actor arguments"),
    };
    unsafe { ohm_ordinal_end() };
    res
}
