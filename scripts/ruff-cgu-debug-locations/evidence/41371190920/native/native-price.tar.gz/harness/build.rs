use std::{env, path::PathBuf, process::Command};
fn main() {
    println!("cargo:rerun-if-changed=cgscope.c");
    if env::var_os("CARGO_FEATURE_QA_COUNTER").is_none() {
        return;
    }
    let dir = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let o = dir.join("scope.o");
    assert!(
        Command::new("cc")
            .args(["-std=c11", "-O2", "-c", "cgscope.c", "-o"])
            .arg(&o)
            .status()
            .unwrap()
            .success()
    );
    assert!(
        Command::new("ar")
            .arg("rcs")
            .arg(dir.join("libohm_ordinal_scope.a"))
            .arg(&o)
            .status()
            .unwrap()
            .success()
    );
    println!("cargo:rustc-link-search=native={}", dir.display());
    println!("cargo:rustc-link-lib=static=ohm_ordinal_scope");
}
