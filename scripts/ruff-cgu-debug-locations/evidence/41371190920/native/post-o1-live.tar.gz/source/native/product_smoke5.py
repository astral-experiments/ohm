from pathlib import Path
import copy,gzip,json,struct,sys
q=Path(__file__).resolve().parent;sys.path.insert(0,str(q));from product_inputs_v5 import *;from patch_dwarf import Image,Lines,leb;from ordinal_wire import var,read

def roundtrip(w):
 assert w[:4]==b'OSP\x01'and w[36:53]==b'CGU-GLOBAL-LINES\x01';p=53
 def n():
  nonlocal p
  a,p=read(w,p);return a
 def raw():
  nonlocal p
  z=n();b=w[p:p+z];assert len(b)==z;p+=z;return b
 def seq():
  v=0;xs=[]
  for i in range(n()):v+=n();xs.append(v)
  return xs
 lines=seq();files=[]
 for _ in range(n()):files.append([raw(),raw(),n(),raw(),seq()]);
 assert p==len(w);return lines,files

def encode(h,rows):
 lines,files=rows
 def seq(xs):return var(len(xs))+b''.join(var(x-(xs[i-1] if i else 0))for i,x in enumerate(xs))
 def s(b):return var(len(b))+b
 return h+seq(lines)+var(len(files))+b''.join(s(dr)+s(f)+var(kind)+s(md)+seq(rk)for dr,f,kind,md,rk in files)

def main():
 old,warm,empty,wires,prop,wa,ea=evidence();program,build=exe();result={};neg={};
 def run(*parts):
  with resident(*parts)as fds:r=subprocess.run([str(program),'rebase',*('/proc/self/fd/'+str(n)for n in fds)],capture_output=True,pass_fds=fds,timeout=20)
  check(r.returncode in(0,2)and (r.returncode==0 or r.stdout==b''), 'panic or published partial output');return r
 for k in sorted(old):
  a,b=wires[k];v=bytes(old[k]);w=warm[k];e=empty[k];assert encode(a[:53],roundtrip(a))==a and encode(b[:53],roundtrip(b))==b;s=prop[k]['status']=='native exact';f=run(v,a,b);r=run(w,b,a);iold=run(v,a,a);inew=run(e,b,b);check((f.returncode==0)==s and (r.returncode==0)==s,'prospective product native roster differed for '+k);check(not s or (f.stdout==w==e and r.stdout==v),'whole original/empty debugger bytes disagree');check(iold.returncode or iold.stdout==v,'nonidentity old projection');check(inew.returncode or inew.stdout==e,'nonidentity new projection');result[k]=dict(admitted=s,old_native_sha=sha(v),warm_native_sha=sha(w),empty_native_sha=sha(e),forward_sha=sha(f.stdout)if s else None,inverse_sha=sha(r.stdout)if s else None,previous_identity=iold.returncode==0,current_identity=inew.returncode==0,previous_envelope=sha(a),current_envelope=sha(b),forward_bytes=len(f.stdout));print('product',k.split('.')[-1],s,iold.returncode==inew.returncode==0,flush=True)
 k=next(k for k in sorted(old)if result[k]['admitted']and result[k]['old_native_sha']!=result[k]['warm_native_sha']);v=bytes(old[k]);a,b=wires[k];fields=roundtrip(b);im=Image(v);raw=im.contents('.debug_line');line=Lines(raw);assert raw[line.start]==0;
 def deny(name,fields):
  rr=run(*fields);check(rr.returncode==2 and not rr.stdout,'unsupported product input admitted: '+name);neg[name]='zero output, fallthrough'
 for label,bad in [('truncated envelope',b[:9]),('unknown envelope',b'OSP\x02'+b[4:]),('bad table format',b[:36]+b'WRONG'+b[41:]),('excess table bytes',b+b'\0'),('oversized table varint',b[:53]+b'\xff'*9+b[54:]),('noncanonical table varint',b[:53]+b'\x80\x00'+b[54:])]:deny(label,(v,a,bad))
 for which in ('missing global anchor','duplicate global line','changed file membership','missing typed file checksum','conflicting file identity','invalid digest type','bad digest bytes','unknown raw source path','global ordinal out of range'):
  gl,rows=copy.deepcopy(fields);f=next(f for f in rows if f[4] and f[4][-1]>0 and f[1].endswith(b'options.rs'))
  if which=='missing global anchor':gl[0]=1
  if which=='duplicate global line':gl[2]=gl[1]
  if which=='changed file membership':f[-1].pop()
  if which=='missing typed file checksum':f[2:4]=[0,b'']
  if which=='conflicting file identity':rows.insert(rows.index(f),copy.deepcopy(f))
  if which=='invalid digest type':f[2]=8
  if which=='bad digest bytes':f[3]=b'z'*len(f[3])
  if which=='unknown raw source path':f[1]+=b'.changed'
  if which=='global ordinal out of range':f[4].append(len(gl)+1)
  deny(which,(v,a,encode(b[:53],(gl,rows))))
 def change(sec,off,buf):
  r=im.rows[im.n[sec]];check(0<=off and off+len(buf)<=r[5],'corrupt control out of bounds');x=bytearray(v);x[r[4]+off:r[4]+off+len(buf)]=buf;return x
 ab=im.contents('.debug_abbrev');p=0;tag_off=None;at_off=None
 while p<len(ab):
  code,p=leb(ab,p)
  if not code:break
  at=p;tag,p=leb(ab,p);p+=1
  if tag==0x2e:tag_off=at
  while True:
   at=p;name,p=leb(ab,p);form,p=leb(ab,p)
   if not name:break
   if name==0x57:at_off=at
 assert tag_off and at_off;deny('variable-bearing scope',(change('.debug_abbrev',tag_off,b'\x34'),a,b));deny('unrecognized column-related attr',(change('.debug_abbrev',at_off,b'\x60'),a,b));deny('oversized DWARF row length',(change('.debug_line',line.start+1,b'\xff'*12),a,b));off,typ,add=struct.unpack_from('<QQq',im.contents('.rela.debug_line'));deny('displaced line relocation',(change('.rela.debug_line',0,struct.pack('<Q',off+1)),a,b));deny('mismatched line section addend',(change('.rela.debug_line',16,struct.pack('<q',add+1)),a,b));raw=bytearray(v);sh=struct.unpack_from('<Q',v,40)[0];struct.pack_into('<Q',raw,sh+64*im.n['.debug_line']+24,im.rows[im.n['.debug_info']][4]);deny('overlapping sections',(raw,a,b));
 stack_bytes=b'.note.GNU-stack\0';check(v.count(stack_bytes)>0,'no actual ELF stack-note name');
 for label,t in [('external debug link',b'.gnu_debuglink'),('embedded IR',b'.llvmbc'),('unregistered note',b'.note.gnu.foo')]:
  mutated=v.replace(stack_bytes,t+b'\0'*(len(stack_bytes)-len(t)));deny(label,(mutated,a,b))
 zz=json.loads((q.parent/'option-cgu-forensics-v1/ordinal-negative-controls.json').read_bytes());start=bytes.fromhex(zz['independently_shifted']);aa=a[:4]+start+a[36:]
 for label,seq in zz['mutated'].items():
  if seq=='rejected':neg[label]='refused by real typed key producer';continue
  deny('changed current '+label,(v,aa,b[:4]+bytes.fromhex(seq)+b[36:]))
 # Independent signed LLVM objects cover both sides of DIEInteger::BestForm. Hold only the test
 # semantic key fixed to isolate native encoding. The original registration comes from the real Ruff IR.
 width=q/'die-width';observed=json.loads((width/'receipt.json').read_bytes());vals={};native={}
 for text_,rr in observed.items():
  point=int(text_);original=(width/f'line-{point}.o').read_bytes();assert sha(original)==rr['elf'];native[point]=original;coords={b'a.rs':[12,70,91,92,point],b'b.rs':[50,51]};gl=sorted({0,1,*coords[b'a.rs'],*coords[b'b.rs']});mrows=[[b'/source',f,1,(b'1'if f==b'a.rs'else b'2')*32,[gl.index(i)for i in points]]for f,points in coords.items()];head=b'OSP\x01'+bytes.fromhex(sha(b"native QA only: constant inline scopes and ranks"))+b'CGU-GLOBAL-LINES\x01';vals[point]=encode(head,(gl,mrows));base=run(original,vals[point],vals[point]);check(base.returncode==0 and base.stdout==original,'signed inline-width original failed: '+str(point));
 for x,y in ((254,255),(255,254),(256,257),(257,256)):
  same=run(native[x],vals[x],vals[y]);check(same.returncode==0 and same.stdout==native[y],'same-DIE-width emitted object differs');neg[f'signed same-form {x} to {y}']='byte-identical signed LLVM native object'
 for x,y in ((255,256),(256,255),(65535,65536),(65536,65535)):deny(f'signed DIE BestForm boundary {x} to {y}',(native[x],vals[x],vals[y]))
 report=dict(compiler_files=build['product_sources'],helper=build['sha256'],parent_rust='531eb1980c08c75ccbf3f6b77adbee53cd9b8bd5',old_new_native_oracle=RAW_CHECK,cpp_wire_manifest=SUM,actual_product_ffi=F3,warm_native=wa,clean_native=ea,actual=sum(x['admitted']for x in result.values()),previous_identity=sum(x['previous_identity']for x in result.values()),current_identity=sum(x['current_identity']for x in result.values()),units=result,negative_controls=neg);body=(json.dumps(report,indent=1,sort_keys=True)+'\n').encode();(q/'product-physical-05.json').write_bytes(body);print('PRODUCT NATIVE',sha(body),report['actual'],report['previous_identity'],report['current_identity'],len(neg),flush=True)
if __name__=='__main__':main()
