from product_inputs import *
from product_inputs import evidence as first_evidence
P=q.parent/'native-ordinal-cgu-contact-v1';L=P/'pure-post-o1-c2-live-v1';R=P/'pure-post-o1-c2-v1';F3='ed8aebeafdbeea7a33b109c6165d388c5b3b9f6fd559f76ec85c87091da7d3a2';INDEX='17444da8424fb3925919e107ba51f192c8cdb0252887dc838ba11d92870dba1f';SUM=INDEX;V=q.parent/'hostile-placement-native-01/v2'
def evidence():
 old,warm,clean,_,_,wa,ea=first_evidence();assert sha((L/'result.json').read_bytes())==F3 and sha((L/'WIRE-SHA256SUMS').read_bytes())==INDEX;rows=json.loads((L/'result.json').read_bytes())['rows'];slots={x.split()[1].lstrip('*'):x.split()[0]for x in(L/'WIRE-SHA256SUMS').read_text().splitlines()};assert len(slots)==42 and set(rows)==set(old);wires={};prop={}
 for k,row in rows.items():
  vals=[]
  for role in ('old','new'):
   name='wires/'+role+'/'+k+'.wire';w=(L/name).read_bytes();pr=(R/name).read_bytes();assert sha(w)==slots[name]and w[:4]==b'OSP\x01'and w[4:36].hex()==row[role]['key']and sha(w[36:])==row[role]['placements']and w[4:36]!=pr[4:36]and w[36:]==pr[36:];vals.append(w)
  assert (vals[0][4:36]==vals[1][4:36])==row['equal'];wires[k]=vals;prop[k]=dict(status='native exact'if row['equal']else 'unequal live post-O1 key')
 return old,warm,clean,wires,prop,wa,ea
def exe():
 x=json.loads((q/'product-build-05.json').read_bytes());prog=Path(x['executable']);assert sha(prog.read_bytes())==x['sha256']and all(sha((V/'harness/src/source_placement'/k).read_bytes())==v for k,v in x['product_sources'].items());return prog,x
