import gzip,hashlib,json,os,resource,subprocess,tempfile,zipfile,time
from pathlib import Path
out=Path(__file__).resolve().parent
reg=json.loads((out/'result.json').read_bytes())
base=out.parents[1]/'root-replay/public-residual-01/alias-source/bottomup-v2/optimized-ir-21'
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
actor=out/'actor';policy=out.parent/'pure-post-o1-c2-v1/pure.so'
units=list(sorted(reg['rows']))
order=[('policy',k) for k in units]+[('policy-repeat',units[i]) for i in (20,10,0)]
spec={'sha256':{'actor':file_sha(actor),'source':file_sha(out/'actor.c'),'policy':file_sha(policy),'bitcode':file_sha(out/'result.json')},'order':order, 'parser':'Separate interval starts before LLVMContextCreate/current memory buffer allocation, includes parsing the complete captured O1 input and restoring the real ModuleIdentifier. It ends before policy, original module destruction, and original external input decompression. The actual codegen hook already owns the LLVMModuleRef, so parse is excluded from replacement.','event':'whole native LLVMRustGetSourcePlacement from the continuously live LLVMModuleRef after real ordinary O1 and before any serialization, including original eligibility and verification, CloneModule, current debug normalization and actual bitcode serialization/placement hash, destruction of the scratch module and local OSP callback memcpy+free. Parse, independent custody and destruction of existing original live module excluded. Callgrind 3.22.0 guest Ir.'}
(out/'price-registration.json').write_text(json.dumps(spec,sort_keys=True,indent=2)+'\n')
inputs={json.loads((d/'signed.json').read_bytes())['source']:d for d in base.glob('[0-9][0-9]')}
rows=[]
trace_store=out/'counter-originals';trace_store.mkdir(exist_ok=False)
for kind,k in order:
 p=reg['rows'][k]['new'];cap=Path('/run/ohm-first-a-leaves-v2-20261101/41371190920/ordinary-13109144871.zip')
 with zipfile.ZipFile(cap) as source:obs=gzip.decompress(source.read('cgu-originals/'+p['input']+'.gz'))
 assert sha(obs)==p['input']
 assert int(next(l for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')).split()[1])>4*1024*1024
 fd=os.memfd_create('scoped-signed-optimized-input');t=os.memfd_create('bounded-Callgrind-result')
 try:
  assert os.write(fd,obs)==len(obs);os.lseek(fd,0,0)
  cmd=['/usr/bin/valgrind','--tool=callgrind','--quiet','--instr-atstart=no','--trace-children=no','--callgrind-out-file=/proc/self/fd/'+str(t),str(actor),str(policy),str(fd),k,kind]
  v=subprocess.run(cmd,capture_output=True,pass_fds=[fd,t],timeout=170,check=True)
  a=v.stdout.decode().strip().split();assert a[:3]==[k,kind,p['key']] and int(a[3])>=53
  os.lseek(t,0,0);b=os.read(t,(24<<20)+1);assert len(b)<24<<20 and b.count(b'events: Ir\n')==1
  lines=[l for l in b.splitlines() if l.startswith(b'totals: ')];assert len(lines)==1
  total=int(lines[0][8:]);assert total>1000
  with gzip.open(trace_store/(kind+'-'+k[-25:]+'.cg.gz'),'xb',compresslevel=4) as f:f.write(b)
  rows.append({'cohort':kind,'unit':k,'input_sha':sha(obs),'output_key':a[2],'size':int(a[3]),'raw_sha':sha(b),'count':total})
  (out/'counter-progress.jsonl').open('a').write(json.dumps(rows[-1],sort_keys=True)+'\n')
  print(kind,k[-25:],total,flush=True)
 finally:os.close(fd);os.close(t)
original={(v['unit'],v['cohort']):v['count']for v in rows if v['cohort'] in ('policy','parse')};assert len(original)==21
assert all(original[v['unit'],v['cohort'].split('-')[0]]==v['count'] for v in rows if v['cohort'].endswith('-repeat'))
total=sum(v for (u,mode),v in original.items() if mode=='policy');parse=sum(v for (u,mode),v in original.items() if mode=='parse');result={'policy_cost_all_21_guest_Ir':total,'gross_matched_machine_Ir':reg['gross_matched_machine_Ir'],'parser_in_this_region':False,'all21':rows,'registration':file_sha(out/'price-registration.json')};(out/'counter-complete.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print('complete',total,reg['gross_matched_machine_Ir']-total,flush=True)
