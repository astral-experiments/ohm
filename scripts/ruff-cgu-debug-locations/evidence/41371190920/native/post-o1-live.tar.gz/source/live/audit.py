import ctypes as C,gzip,importlib.util,json,sys,zipfile
from pathlib import Path
out=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('pure_contact',out.parent/'pure-post-o1-c2-v1/contact.py');p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
P,S,PP=p.P,p.S,p.PP
def read(path):return json.loads(Path(path).read_bytes())
def sig(n,r,*args):return p.ffi(n,r,*args)
for name in ('TargetInfo','Target','TargetMC','AsmPrinter','AsmParser'):sig('InitializeX86'+name,None)()
gettarget=sig('GetTargetFromTriple',C.c_int,S,PP,PP);target=P();err=P()
triple=b'x86_64-unknown-linux-gnu';assert gettarget(triple,C.byref(target),C.byref(err))==0
create=sig('CreateTargetMachine',P,P,S,S,S,C.c_int,C.c_int,C.c_int);dispose=sig('DisposeTargetMachine',None,P); newopts=sig('CreatePassBuilderOptions',P);delopts=sig('DisposePassBuilderOptions',None,P)
run=sig('RunPasses',P,P,S,P,P)
def optimize(raw,text=False,features=b''):
 c=p.CTX();b=p.BUF(raw,len(raw),b'pinned-ruff-cgu');m=P();note=P();tm=create(target,triple,b'x86-64',features,1,2,0);opts=newopts()
 try:
  if text:
   assert p.LL(c,b,C.byref(m),C.byref(note))==0
   p.SET(m,b'candidate.rs',len(b'candidate.rs'))
  else:assert p.BC(c,b,C.byref(m))==0
  size=C.c_size_t(); name=p.NAME(m,C.byref(size)); original_name=C.string_at(name,size.value);p.SET(m,original_name,len(original_name))
  assert not run(m,b'default<O1>',tm,opts)
  results=[]
  @p.CB
  def offer(ctx,buffer,length):
   assert ctx==0x1357 and 0<length<=16<<20
   results.append(C.string_at(buffer,length))
  success=bool(p.F(m,0x1357,C.cast(offer,P)))
  assert success==bool(results) and len(results)<=1
  live=results[0] if success else None
  b2=p.WRITE(m)
  try:return live,C.string_at(p.START(b2),p.SIZE(b2))
  finally:p.DB(b2)
 finally:
  delopts(opts);dispose(tm);p.DM(m)
  if not text:p.DB(b)
  p.DC(c)
weights=read(out.parents[1]/'option-cgu-forensics-v1/native-phase-edges.json')
seeds=read(out.parent/'all.json')
product=out.parents[1]/'root-replay/public-residual-01/alias-source/bottomup-v2/optimized-ir-21'
reg=read(out.parent/'registration.json')
assert p.fs_hash(p.LLVM)==reg['signed_llvm'] and len(seeds)==21
dirs={read(d/'signed.json')['source']:d for d in sorted(product.glob('[0-9][0-9]'))}
assert len(dirs)==21
rows={}
for cur in ("old","new"): (out/"wires"/cur).mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(p.CAP) as z:
 for k,roles in seeds.items():
  v={}; anchor=dirs[roles['new']['input']];info=read(anchor/'signed.json')
  native=(anchor/'signed.bc.gz').read_bytes();orig=gzip.decompress(native)
  assert p.SHA(native)==info['bitcode']['gzip_sha256'] and p.SHA(orig)==info['bitcode']['raw_sha256']
  for role in ['new','old']:
   src=roles[role]['input'];raw=gzip.decompress(z.read('cgu-originals/'+src+'.gz'));assert p.SHA(raw)==src
   wire,opt=optimize(raw);digest=p.SHA(opt)
   if role=='new':assert opt==orig,(k,digest,p.SHA(orig))
   reparsed=p.visit(opt)
   if wire:
    stored=out/"wires"/role/(k+".wire")
    if stored.exists():assert stored.read_bytes()==wire
    else:stored.write_bytes(wire)
   previous=(out.parent/"pure-post-o1-v1/wires"/role/(k+".wire")).read_bytes()
   assert previous==reparsed and wire and previous[36:]==wire[36:], (k,role,"wrong previous actor or different source-placement coordinates")
   v[role]={'input':src,'O1':digest,'length':len(opt),'archived_new_sha':info['bitcode']['raw_sha256'] if role=='new' else None,'eligible':bool(wire),'key':wire[4:36].hex() if wire else None,'placements':p.SHA(wire[36:]) if wire else None,'reparsed_key':reparsed[4:36].hex() if reparsed else None,'live_wire_sha256':p.SHA(wire) if wire else None}
  eq=v['old']['eligible'] and v['new']['eligible'] and v['old']['key']==v['new']['key'];v['equal']=eq
  v['machine_only_Ir']=weights[k]['machine_emission'];v['entire_backend_Ir']=weights[k]['total']
  rows[k]=v;print(k[-25:],v['old']['eligible'],v['new']['eligible'],eq,v['machine_only_Ir'],flush=True)
ctrl={};al=out.parents[1]/'dae-allocation-observability-root-01';original=read(al/'observed.json')
for fn in ('definition-only','definition-and-call','no-allocsize'):
 ctrl[fn]={}
 for m in ('16','32'):
  body=(al/(fn+'-'+m+'.ll')).read_bytes();wire,bc=optimize(body,True,b'+sse,+sse2')
  ctrl[fn][m]={'input':p.SHA(body),'O1':p.SHA(bc),'eligible':bool(wire),'key':wire[4:36].hex() if wire else None,'native':original[fn][m]['value']}
 if ctrl[fn]['16']['native']!=ctrl[fn]['32']['native']:
  assert not (ctrl[fn]['16']['eligible'] and ctrl[fn]['32']['eligible'] and ctrl[fn]['16']['key']==ctrl[fn]['32']['key'])
num=sum(v['equal'] for v in rows.values());saved=sum(v['machine_only_Ir'] for v in rows.values() if v['equal']);total=sum(v['entire_backend_Ir'] for v in rows.values());machine=sum(v['machine_only_Ir'] for v in rows.values())
result={'scope':'The actual C2 callback on the continuously live LLVM module, immediately after signed LLVM default<O1> and before any post-O1 serialization or parse, with the identical x86 TargetMachine from the original per-CGU machine replay; all 21 regenerated NEW post-O1 bitcode bodies checked against the original complete archived output. The original Ruff Cargo rustc roots supplied the 42 pre-O1 inputs. This is not a full ordinary Cargo compiler counter.','rows':rows,'physical_allocation_controls':ctrl,'pass_untouched_qashape':p.fs_hash(out.parent/'pure-post-o1-c2-v1/pure.so'),'source':reg['source_archive'],'llvm':p.fs_hash(p.LLVM),'pairs':num,'all_machine_Ir':machine,'gross_matched_machine_Ir':saved,'full_backend_Ir':total,'zero_replacement_ceiling':total/(total-saved)}
(out/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print('terminal',num,saved,machine,total,result['zero_replacement_ceiling'],ctrl,flush=True)
