"""Replay the independent allocsize/key counterexample at the exact Rust boundary and run every fresh result."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,time
B=Path(__file__).resolve().parent;Q=B.parent/'old-only-dwarf-rebase-28106';X=B.parent/'dae-allocation-observability-root-01';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_bytes());floor=8*1024**3;authority=read(Q/'product-physical.json')['compiler_files'];h=lambda p:sha(p.read_bytes());preds={k:{n:h(X/f'{k}-{n}.ll')for n in(16,32)}for k in('definition-and-call','definition-only','no-allocsize')};expected_argv=(X/'main.c').read_bytes();assert b'extern uint64_t observed(void);'in expected_argv
while True:
 exe=None
 for m,p in ((Q/'quick-product-actor.json',Q/'quick-product-actor'),(Q/'relocated-public-actor.json',Q/'relocated-public-actor'),(B/'built.json',B/'native-actor')):
  if not m.is_file()or not p.is_file():continue
  meta=read(m);key=meta.get('sha')or meta.get('actor')or meta.get('rust_actor');assert h(p)==key
  if 'product'in meta:assert meta['product']==authority
  exe=p;break
 if exe and int(next(l for l in Path('/proc/meminfo').read_text().splitlines()if l.startswith('MemAvailable')).split()[1])*1024>floor+85_000_000:break
 time.sleep(1.0)
output={}
with tempfile.TemporaryDirectory(prefix='ohm-allocsize-product-',dir='/dev/shm')as tmp:
 tmp=Path(tmp);main=tmp/'main.c';main.write_bytes(expected_argv)
 def run_native(o):
  elf=tmp/'consumer';subprocess.run(['cc','-O0',str(main),str(o),'-o',str(elf)],check=True,capture_output=True);return int(subprocess.check_output([str(elf)]))
 for kind in preds:
  observed={n:run_native(X/f'{kind}-{n}.o')for n in(16,32)};assert observed==({16:16,32:32}if 'no-'not in kind else {16:2**64-1,32:2**64-1});values={}
  for old,new in[(16,32),(32,16)]:
   base=X/f'{kind}-{old}.o';want=X/f'{kind}-{new}.o';a=X/f'{kind}-{old}.wire';b=X/f'{kind}-{new}.wire';aw=a.read_bytes();bw=b.read_bytes();assert aw.startswith(b'OSP\x01')and aw[4:36]==bw[4:36];r=subprocess.run([str(exe),'rebase',str(base),str(a),str(b)],capture_output=True,check=False);assert r.returncode in(0,2)and(r.stdout or r.returncode==2);value=None;output_sha=None
   if r.returncode==0:
    made=tmp/'product.o';made.write_bytes(r.stdout);value=run_native(made);output_sha=h(made)
   values[f'{old}-to-{new}']=dict(previous_object=h(base),clean_object=h(want),old_osp=h(a),new_osp=h(b),equal_core=aw[4:36].hex(),returncode=r.returncode,projected=output_sha,old_value=observed[old],clean_value=observed[new],projected_value=value,stale=r.returncode==0 and value!=observed[new],identical=r.returncode==0 and r.stdout==want.read_bytes());
  output[kind]=values
r=dict(cpp_source_input_sha=preds,consumer_sha=sha(expected_argv),actual_frozen_rust_sources=authority,actor=str(exe),actor_sha=h(exe),rows=output,stale_directions=sum(row['stale']for d in output.values()for row in d.values()));payload=(json.dumps(r,sort_keys=True,indent=1)+'\n').encode();p=B/'allocsize-native-actual.json';p.write_bytes(payload);print('ACTUAL FROZEN RUST',p,h(p),r['stale_directions'],flush=True)
