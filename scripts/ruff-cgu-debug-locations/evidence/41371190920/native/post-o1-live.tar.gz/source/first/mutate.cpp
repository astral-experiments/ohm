// Research contact for a fully typed LLVM module. Existing filesystem caches are not opened.
#include "llvm/ADT/StringSet.h"
#include "llvm/Support/ErrorHandling.h"
#include "llvm/ADT/DenseMap.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/StringExtras.h"
#include "llvm/Bitcode/BitcodeWriter.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DebugInfoMetadata.h"
#include "llvm/IR/DebugProgramInstruction.h"
#include "llvm/IR/GlobalObject.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Metadata.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/TrackingMDRef.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IRReader/IRReader.h"
#include "llvm/Support/JSON.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/FileSystem.h"
#include "llvm/Support/MemoryBuffer.h"
#include "llvm/Support/SHA256.h"
#include "llvm/Support/SourceMgr.h"
#include "llvm/TargetParser/Triple.h"
#include "llvm/Transforms/Utils/Cloning.h"
#include "llvm-c/Transforms/PassBuilder.h"
#include <valgrind/callgrind.h>
#include <algorithm>
#include <map>
#include <set>
#include <string>
#include <vector>

namespace llvm { extern LLVM_ABI cl::opt<bool> PickMergedSourceLocations; }
using namespace llvm;
using File = std::pair<std::string, std::string>;

static void beginCount() {
  CALLGRIND_START_INSTRUMENTATION;
  CALLGRIND_ZERO_STATS;
  CALLGRIND_TOGGLE_COLLECT;
}
static void endCount() {
  CALLGRIND_TOGGLE_COLLECT;
  CALLGRIND_STOP_INSTRUMENTATION;
}
static std::string hash(StringRef Bytes) {
  return toHex(SHA256::hash(arrayRefFromStringRef(Bytes)), true);
}
static void uleb(std::string &Buffer, uint64_t Value) {
  do {
    uint8_t Byte = Value & 127;
    Value >>= 7;
    Buffer.push_back(Byte | (Value ? 128 : 0));
  } while (Value);
}
static void field(std::string &Buffer, StringRef S) {
  uleb(Buffer, S.size());
  Buffer.append(S.begin(), S.end());
}
static bool matchesAny(StringRef S, std::initializer_list<StringRef> Names) {
  return llvm::is_contained(Names, S);
}

// Verify the compiler mode independently of the input IR. The complete ordinary
// argv is also part of the comparison key, so target/codegen changes miss.
static std::string compilerMode(StringRef Bytes) {
  SmallVector<StringRef> AR;
  Bytes.split(AR, '\0', -1, false);
  StringSet<> C, Z, Single;
  bool Emit = false;
  for (size_t I=0; I<AR.size(); ++I) {
    StringRef V = AR[I];
    if (V.starts_with("@")) return "response-file";
    if (V=="--codegen" || V.starts_with("--codegen=") || V=="--unstable-options") return "unsupported-context-spelling";
    if (V.starts_with("--emit") && V!="--emit=dep-info,metadata,link") return "compiler-emit-mode";
    if (V == "--emit=dep-info,metadata,link") Emit = true;
    bool CG = V.starts_with("-C"), ZZ=V.starts_with("-Z");
    if (!CG && !ZZ) continue;
    if (V.size()==2) {
      if (++I>=AR.size()) return "missing-argument";
      V=AR[I];
    } else V=V.drop_front(2);
    StringRef K=V.split('=').first;
    if (CG) {
      if (matchesAny(K,{"opt-level","lto","embed-bitcode","debuginfo","debug-assertions","incremental"}) && !Single.insert(K).second) return "duplicate-codegen-option";
      if (!matchesAny(K,{"opt-level","lto","embed-bitcode","debuginfo","debug-assertions","metadata","extra-filename","incremental","linker-features","link-self-contained","link-arg"}))
        return ("compiler-context-" + K).str();
      C.insert(V);
    } else {
      if (!matchesAny(K,{"ohm-shared-stages","public-api-hash","threads","ohm-caller-local-cgus","ohm-stable-cgu-merging","ohm-incremental-mono-partitions","remap-cwd-prefix","ohm-early-metadata","checksum-hash-algorithm","ohm-check-relink-inputs"}))
        return ("compiler-context-" + K).str();
      Z.insert(V);
    }
  }
  for (StringRef R: {"opt-level=1","lto=off","embed-bitcode=no","debuginfo=line-tables-only","debug-assertions=on"})
    if (!C.contains(R)) return "compiler-profile";
  if (!Emit || !llvm::any_of(C,[](auto &KV){return KV.getKey().starts_with("incremental=");})) return "compiler-emit-mode";
  return {};
}
using Coordinate=std::pair<File,unsigned>;
struct InputChange {
  std::map<Coordinate,unsigned> Values;
  std::map<File,std::string> FileDigest;
  const DILocation *Column = nullptr;
  unsigned ChangedFiles=0;
};
static InputChange *CurrentChange;
static const DIFile *sourceFile(const MDNode *N) {
  if (auto *S=dyn_cast<DISubprogram>(N)) return S->getFile();
  if (auto *L=dyn_cast<DILocation>(N)) return L->getFile();
  if (auto *B=dyn_cast<DILexicalBlock>(N)) return B->getFile();
  return nullptr;
}
static File fileId(const DIFile *F){return {F->getDirectory().str(),F->getFilename().str()};}
static unsigned alteredLine(const MDNode *N,unsigned V) {
  auto *F=sourceFile(N);if(!CurrentChange||!F)return V;
  auto I=CurrentChange->Values.find({fileId(F),V});return I==CurrentChange->Values.end()?V:I->second;
}

struct Placements {
  // In the representation the order/equality is shared across *all* files.
  // 0 and 1 are always reserved and can never become another physical line.
  std::set<unsigned> Lines = {0,1};
  std::map<unsigned,unsigned> Ranks;
  std::vector<unsigned> Original;
  std::map<File, std::set<unsigned>> FileLines;
  std::map<File, std::pair<unsigned,std::string>> Checks;
  static File id(DIFile *F) { return {F->getDirectory().str(),F->getFilename().str()}; }
  void line(DIFile *F,unsigned L) { if(F)FileLines[id(F)].insert(L); Lines.insert(L); }
  unsigned rank(unsigned L) const { return Ranks.at(L); }
  bool file(DIFile *F) {
    const auto C = F->getChecksum();
    if(C){unsigned Expected=C->Kind==DIFile::CSK_MD5?32:C->Kind==DIFile::CSK_SHA1?40:C->Kind==DIFile::CSK_SHA256?64:0; if(C->Value.size()!=Expected || !llvm::all_of(C->Value,[](char V){return isHexDigit(V);}))return false;}
    auto S = C ? std::make_pair(unsigned(C->Kind), C->Value.str()) : std::pair<unsigned,std::string>{0,""};
    auto Ent = Checks.emplace(id(F), S);
    return Ent.second || Ent.first->second == S;
  }
  void finish() {
    for(unsigned L : Lines) {Ranks.emplace(L,Original.size());Original.push_back(L);}
  }
  std::string encode() const {
    std::string B("CGU-GLOBAL-LINES\x01",17);
    uleb(B,Lines.size()); unsigned Last=0;
    for(unsigned L:Lines) { uleb(B,L-Last);Last=L; }
    uleb(B,Checks.size());
    for(auto &[F,C]:Checks) {
      field(B,F.first);field(B,F.second);uleb(B,C.first);field(B,C.second);
      auto I=FileLines.find(F); uleb(B,I==FileLines.end()?0:I->second.size());Last=0;
      if(I!=FileLines.end())for(unsigned L:I->second){unsigned R=rank(L);uleb(B,R-Last);Last=R;}
    }
    return B;
  }
};

struct Graph {
  std::vector<MDNode *> Nodes;
  DenseMap<MDNode *,unsigned> IDs;
  Placements P;
  std::string Why;

  void add(MDNode *N) {
    if(N && IDs.try_emplace(N,Nodes.size()).second)Nodes.push_back(N);
  }
  bool collect(Module &M) {
    if (M.getTargetTriple().str()!="x86_64-unknown-linux-gnu") return fail("target");
    if (!M.getModuleInlineAsm().empty()) return fail("module-asm");
    unsigned CUs=0;
    SmallVector<MDNode*,64> Ordinary;
    for(auto &N:M.named_metadata()) {
      if(!matchesAny(N.getName(),{"llvm.dbg.cu","llvm.module.flags","llvm.ident"}))return fail("unknown-named-metadata");
      for(MDNode *Op:N.operands()){add(Op);if(N.getName()!="llvm.dbg.cu")Ordinary.push_back(Op);}
    }
    SmallVector<Module::ModuleFlagEntry> Flags; M.getModuleFlagsMetadata(Flags);
    for(auto &V:Flags) {
      StringRef K=V.Key->getString();
      if(!matchesAny(K,{"CodeView","Dwarf Version","Debug Info Version","PIC Level","PIE Level","RtLibUseGOT","wchar_size","uwtable","frame-pointer","override-stack-alignment","MaxTLSAlign"}))
        return fail(("module-flag-"+K).str());
      if(K=="CodeView")return fail("codeview");
    }
    SmallVector<std::pair<unsigned,MDNode *>,8> Attached;
    for(auto &GO:M.global_objects()) {
      if(GO.getName().starts_with("__llvm_prf")||GO.getName().starts_with("__llvm_cov")||GO.getName().starts_with("__llvm_profile"))return fail("instrumentation-global");
      Attached.clear();GO.getAllMetadata(Attached);
      for(auto &A:Attached){add(A.second);if(A.first!=LLVMContext::MD_dbg)Ordinary.push_back(A.second);if(A.first==LLVMContext::MD_prof)return fail("function-profile-metadata");}
    }
    for(auto &F:M) {
      StringRef N=F.getName();
      if(N.starts_with("llvm.pseudoprobe") || N.starts_with("llvm.instrprof") || N.starts_with("__llvm_profile") || N.starts_with("__sanitizer") || N.starts_with("__asan_") || N.starts_with("__msan_") || N.starts_with("__tsan_") || N.starts_with("__ubsan_"))return fail("instrumentation-function");
      for(Attribute A:F.getAttributes().getFnAttrs()){
        std::string S=A.getAsString();StringRef V(S);
        if(V.contains("sanitiz") || V.contains("profile")||V.contains("sample")||V.contains("pseudo-probe") || V.contains("patchable-function")) return fail("instrumentation-attribute");
      }
      for(auto &B:F) {
        if(B.getTrailingDbgRecords() && !B.getTrailingDbgRecords()->empty())return fail("trailing-debug-record");
        for(auto &I:B) {
          if(I.hasDbgRecords())return fail("debug-record");
          if(auto *C=dyn_cast<CallBase>(&I); C && C->isInlineAsm())return fail("inline-asm");
          Attached.clear();I.getAllMetadata(Attached);for(auto &A:Attached){add(A.second);if(A.first!=LLVMContext::MD_dbg)Ordinary.push_back(A.second); if(A.first==LLVMContext::MD_prof){auto *Tag=A.second->getNumOperands()?dyn_cast_or_null<MDString>(A.second->getOperand(0)):nullptr;if(!Tag || Tag->getString()!="branch_weights")return fail("instruction-profile-metadata");}}
          for(Value *V:I.operands())if(auto *MV=dyn_cast<MetadataAsValue>(V))if(auto *NN=dyn_cast<MDNode>(MV->getMetadata())){add(NN);Ordinary.push_back(NN);}
        }
      }
    }
    SmallPtrSet<MDNode*,32> Visited;
    while(!Ordinary.empty()){auto *N=Ordinary.pop_back_val();if(!Visited.insert(N).second)continue;
      if(isa<DINode,DILocation>(N))return fail("debug-referenced-by-semantic-metadata");
      for(auto &O:N->operands())if(auto *K=dyn_cast_or_null<MDNode>(O.get()))Ordinary.push_back(K);}
    for(size_t I=0;I<Nodes.size();++I){
      MDNode *N=Nodes[I];
      if(N->isTemporary())return fail("unresolved-metadata");
      for(auto &O:N->operands())if(auto *M=dyn_cast_or_null<MDNode>(O.get()))add(M);
      if(auto *C=dyn_cast<DICompileUnit>(N)) {
        ++CUs;
        if(C->getEmissionKind()!=DICompileUnit::LineTablesOnly || C->getDebugInfoForProfiling() || !C->getSplitDebugFilename().empty() || C->getDWOId() || !C->getMacros().empty() || !C->getGlobalVariables().empty() || !C->getRetainedTypes().empty())return fail("custom-or-full-debug");
      }else if(auto *F=dyn_cast<DIFile>(N)){
        if(F->getSource().has_value())return fail("embedded-source");
        if(!P.file(F))return fail("ambiguous-file-checksum");
      }else if(auto *S=dyn_cast<DISubprogram>(N)){
        if(!S->getFile()||!S->getRetainedNodes().empty()||!S->getAnnotations().empty()||S->getKeyInstructionsEnabled())return fail("subprogram-debug-state");
        P.line(S->getFile(),S->getLine());P.line(S->getFile(),S->getScopeLine());
      }else if(auto *L=dyn_cast<DILocation>(N)){
        if(!L->getFile())return fail("fileless-location");
        P.line(L->getFile(),L->getLine());
      }else if(auto *L=dyn_cast<DILexicalBlock>(N)){
        if(!L->getFile())return fail("fileless-block");
        P.line(L->getFile(),L->getLine());
      }else if(!isa<MDTuple,DINamespace,DILexicalBlockFile,DISubroutineType>(N)){
        return fail("unsupported-metadata-kind");
      }
    }
    if(!CUs)return fail("missing-line-unit");
    P.finish();return true;
  }
  bool fail(std::string S) { Why=std::move(S);return false; }
  TempMDNode fresh(MDNode *N,const Placements *Recover) const {
    auto line=[&](unsigned V){return CurrentChange ? alteredLine(N,V) : Recover ? Recover->Original.at(V) : P.rank(V);};
    auto &C=N->getContext();
    if(auto *F=dyn_cast<DIFile>(N)){
      auto Check=F->getChecksum();
      // The kind and absence are significant. The actual current bytes travel in placements.
      std::string Z;
      if(CurrentChange){if(Check){auto I=CurrentChange->FileDigest.find(fileId(F));if(I!=CurrentChange->FileDigest.end()){Z=I->second;Check->Value=Z;}}}
      else if(Check){if(Recover){auto &Exact=Recover->Checks.at(Placements::id(F));if(Exact.first!=unsigned(Check->Kind))report_fatal_error("checksum kind changed");Z=Exact.second;}else Z.assign(Check->Value.size(),'0');Check->Value=Z;}
      return DIFile::getTemporary(C,F->getFilename(),F->getDirectory(),Check,F->getSource());
    }
    if(auto *S=dyn_cast<DISubprogram>(N))return DISubprogram::getTemporary(C,S->getScope(),S->getName(),S->getLinkageName(),S->getFile(),line(S->getLine()),S->getType(),line(S->getScopeLine()),S->getContainingType(),S->getVirtualIndex(),S->getThisAdjustment(),S->getFlags(),S->getSPFlags(),S->getUnit(),S->getTemplateParams(),S->getDeclaration(),S->getRetainedNodes(),S->getThrownTypes(),S->getAnnotations(),S->getTargetFuncName(),S->getKeyInstructionsEnabled());
    if(auto *L=dyn_cast<DILocation>(N))return DILocation::getTemporary(C,line(L->getLine()),L->getColumn()+(CurrentChange && CurrentChange->Column==L),L->getScope(),L->getInlinedAt(),L->isImplicitCode(),L->getAtomGroup(),L->getAtomRank());
    if(auto *L=dyn_cast<DILexicalBlock>(N))return DILexicalBlock::getTemporary(C,L->getScope(),L->getFile(),line(L->getLine()),L->getColumn());
    return N->clone();
  }
  bool rewrite(Module &M,const Placements *Recover=nullptr) const {
    std::vector<TempMDNode> Temp;std::vector<TrackingMDNodeRef> New;
    Temp.reserve(Nodes.size());New.reserve(Nodes.size());
    for(auto *N:Nodes) {Temp.push_back(fresh(N,Recover));New.emplace_back(Temp.back().get());}
    for(auto &T:Temp) {
      for(unsigned I=0,E=T->getNumOperands();I<E;++I)
        if(auto *N=dyn_cast_or_null<MDNode>(T->getOperand(I))){auto P=IDs.find(N);if(P==IDs.end())return false;T->replaceOperandWith(I,New[P->second].get());}
    }
    for(unsigned I=0;I<Nodes.size();++I) {
      MDNode *N=Nodes[I]->isDistinct()?MDNode::replaceWithDistinct(std::move(Temp[I])):MDNode::replaceWithUniqued(std::move(Temp[I]));
      New[I].reset(N);
    }
    for(auto &N:New)if (!N->isResolved())N->resolveCycles();
    auto mapped=[&](MDNode *N)->MDNode*{auto Pos=IDs.find(N);if(Pos==IDs.end())report_fatal_error("unregistered metadata root");return New[Pos->second].get();};
    for(auto &N:M.named_metadata())for(unsigned I=0;I<N.getNumOperands();++I)N.setOperand(I,mapped(N.getOperand(I)));
    SmallVector<std::pair<unsigned,MDNode *>,8> A;
    for(auto &GO:M.global_objects()){A.clear();GO.getAllMetadata(A);GO.clearMetadata();for(auto &KV:A)GO.addMetadata(KV.first,*mapped(KV.second));}
    for(auto &F:M)for(auto &B:F)for(auto &I:B){
      A.clear();I.getAllMetadata(A);for(auto &KV:A)I.setMetadata(KV.first,mapped(KV.second));
      for(auto &O:I.operands())if(auto *V=dyn_cast<MetadataAsValue>(O.get()))if(auto *N=dyn_cast<MDNode>(V->getMetadata()))O.set(MetadataAsValue::get(M.getContext(),mapped(N)));
    }
    return !verifyModule(M,&errs());
  }
};

// Change actual debug nodes only. All reachable ordinary metadata is cloned exactly by the frozen LLVM mapper.
static bool planChange(const Graph &G,StringRef Mode,InputChange &R){
  const auto &P=G.P;auto &Lines=P.Original;std::map<unsigned,std::vector<File>> Owners;
  for(auto &[F,Values]:P.FileLines)for(unsigned V:Values)Owners[V].push_back(F);
  if(Lines.size()<10)return false;
  auto room=[&](unsigned V){auto I=std::upper_bound(Lines.begin(),Lines.end(),V);return V>1 && (I==Lines.end()||*I>V+1);};
  auto every=[&](unsigned V,unsigned W){for(auto &F:Owners[V])R.Values[{F,V}]=W;};
  if(Mode=="identity")return true;
  if(Mode=="last-gap")every(Lines.back(),Lines.back()+1);
  else if(Mode=="two-files"){
    std::set<File> Chosen;
    for(const auto &[F,Values]:P.FileLines){for(auto V:Values)if(room(V)&&Owners[V].size()==1){R.Values[{F,V}]=V+1;Chosen.insert(F);break;}if(Chosen.size()==2)break;}
    if(Chosen.size()!=2)return false;
  }else if(Mode=="inline-chain"){
    std::set<std::pair<Coordinate,Coordinate>> Pairs;
    for(auto *N:G.Nodes)if(auto *L=dyn_cast<DILocation>(N))if(room(L->getLine()))for(auto *A=L->getInlinedAt();A;A=A->getInlinedAt()){
      if(A->getLine()!=L->getLine() && room(A->getLine()))Pairs.emplace(Coordinate{fileId(L->getFile()),L->getLine()},Coordinate{fileId(A->getFile()),A->getLine()});
    }
    if(Pairs.empty())return false;auto [Child,Parent]=*Pairs.begin();every(Child.second,Child.second+1);every(Parent.second,Parent.second+1);
  }else if(Mode=="three-quarters"||Mode=="jump-8192"){
    size_t N=Lines.size()-2;
    for(size_t I=2;I<Lines.size();++I){size_t J=I-2;unsigned D=Mode=="jump-8192"?(J>=7*N/8?8192:0):(J>=3*N/4?20:J>=N/2?4:J>=N/4?1:0);if(D)every(Lines[I],Lines[I]+D);}
  }else if(Mode=="die-256"||Mode=="die-65536"){
    unsigned Cut=Mode=="die-256"?256:65536;auto I=std::lower_bound(Lines.begin(),Lines.end(),Cut);if(I==Lines.begin())return false;--I;auto Delta=Cut-*I;if(*I<=1)return false;for(;I!=Lines.end();++I)every(*I,*I+Delta);
  }else if(Mode=="split-files"){
    auto I=std::find_if(Owners.begin(),Owners.end(),[](auto &P){return P.first>1&&P.second.size()>=2;});if(I==Owners.end())return false;R.Values[{I->second.front(),I->first}]=I->first+1;
  }else if(Mode=="order-inversion"){
    unsigned I=std::max<size_t>(2,Lines.size()/2);every(Lines[I],Lines[I+1]);every(Lines[I+1],Lines[I]);
  }else if(Mode=="zero-one"){every(0,1);every(1,0);}
  else if(Mode=="column"){
    for(auto *N:G.Nodes)if(auto *L=dyn_cast<DILocation>(N))if(L->getColumn()<65535){R.Column=L;break;}if(!R.Column)return false;
  }else return false;
  if(R.Values.empty()&&!R.Column)return false;
  std::set<File> Changed;for(const auto &[P,V]:R.Values){if(V>=1u<<24)return false;Changed.insert(P.first);}if(R.Column)Changed.insert(fileId(R.Column->getFile()));
  for(const auto &F:Changed){auto C=P.Checks.at(F);if(C.first){std::string Seed=C.second+"/"+Mode.str()+"/"+F.first+"/"+F.second;auto H=hash(Seed);R.FileDigest[F]=H.substr(0,C.second.size());}}
  R.ChangedFiles=Changed.size();return true;
}
extern "C" int OhmHostileInput(void *Module_,const char *Kind,unsigned *NumCoords,unsigned *NumFiles){
  auto &M=*static_cast<Module*>(Module_); Graph G;if(!G.collect(M))return -1;InputChange R;if(!planChange(G,Kind,R))return 0;
  CurrentChange=&R;bool OK=G.rewrite(M);CurrentChange=nullptr;*NumCoords=R.Values.size()+!!R.Column;*NumFiles=R.ChangedFiles;return OK?1:-2;
}
