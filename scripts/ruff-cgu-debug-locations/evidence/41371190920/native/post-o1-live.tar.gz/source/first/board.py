"""Resume the independently enrolled board one complete real source module and input change at a time."""
from pathlib import Path
import fcntl,hashlib,json,os,signal,subprocess,sys,time
B=Path(__file__).resolve().parent;Q=B.parent/'old-only-dwarf-rebase-28106';J=lambda p:json.loads(p.read_bytes());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();reg=J(B/'registered.json');assert h(B/'registered.json')=='dcccae695bb36426c738adab82db11dcc4d35e0cdf7510db4f0fb60ec8293aa3';floor=8*1024**3
# Only the registered case script and small immutable source inputs may run inside the budget.
def free():return int(next(l for l in Path('/proc/meminfo').read_text().splitlines()if l.startswith('MemAvailable:')).split()[1])*1024
def run(args,need):
 last=0
 while True:
  if free()<floor+need:
   if time.monotonic()-last>100:print('holding memory reserve',free(),flush=True);last=time.monotonic()
   time.sleep(6);continue
  with (Q/'one-native-heavy-operation.lock').open('a')as lock:
   fcntl.flock(lock,fcntl.LOCK_EX)
   if free()<floor+need:continue
   p=subprocess.Popen([sys.executable,'-IB',*map(str,args)],start_new_session=True);stopped=False
   while p.poll()is None:
    if free()<floor and p.poll()is None:os.killpg(p.pid,signal.SIGTERM);stopped=True;print('holding after shared RAM dropped',flush=True);break
    time.sleep(.12)
   status=p.wait()
  if not stopped and status:return status
  if not stopped:return 0
  time.sleep(6)
if not (B/'built.json').is_file():
 rc=run([B/'build.py'],600_000_000)
 if rc:raise SystemExit(rc)
casefiles=[];rids=sorted(reg['inputs'],key=lambda k:reg['inputs'][k]['actual_old_native_bytes']);ops=['identity','last-gap','two-files','inline-chain','three-quarters','jump-8192','die-256','die-65536','split-files','order-inversion','zero-one','column'];assert set(ops)==set(reg['cases'])
for op in ops:
 for k in rids:
  p=B/'cases'/(k.rsplit('.',1)[-1]+'--'+op+'.json');casefiles.append(p)
  if p.is_file():assert J(p)['registration']==h(B/'registered.json')and J(p)['status']!='MISMATCH';continue
  rc=run([B/'case.py',k,op],350_000_000)
  if rc:raise SystemExit(rc)
rows=[J(p)for p in casefiles];report=dict(registration=h(B/'registered.json'),build=h(B/'built.json'),attempted_pairs=len(rows),missing=sum(r['status']!='complete'for r in rows),signed_replay_parent_native_matches=sum(all(r.get('old_fresh_matches_captured')for r in rows if r['unit']==u and r['status']=='complete')for u in rids),directions_admitted=sum(x=='byte exact'for r in rows for x in r.get('branches',{}).values()),directions_refused=sum(x=='refused'for r in rows for x in r.get('branches',{}).values()),input_pairs_genuine_native_changes=sum(r['status']=='complete'and r['old_fresh']['elf']!=r['new_fresh']['elf']for r in rows),nondebug_change_pairs=sum(r['status']=='complete'and r['old_fresh']['nondebug']!=r['new_fresh']['nondebug']for r in rows),rows=rids,receipt_sha={p.name:h(p)for p in casefiles});assert report['directions_admitted']+report['directions_refused']==2*(len(rows)-report['missing']);f=B/'terminal.json';f.write_text(json.dumps(report,sort_keys=True,indent=1)+'\n');print('TERMINAL',json.dumps({k:v for k,v in report.items()if k not in('receipt_sha','rows')}),flush=True)
