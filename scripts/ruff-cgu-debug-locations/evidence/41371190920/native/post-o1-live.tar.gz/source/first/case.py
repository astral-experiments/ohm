"""One independently generated actual LLVM packet and native A/B. Each attempt runs in a bounded separate process."""
from pathlib import Path
from collections import Counter
from contextlib import contextmanager
import ctypes as c,fcntl,gzip,hashlib,importlib.util,json,os,resource,struct,subprocess,sys,zipfile
B=Path(__file__).resolve().parent;D=B.parent;PROD=D/'native-ordinal-cgu-contact-v1';REG=json.loads((B/'registered.json').read_bytes());BUILT=json.loads((B/'built.json').read_bytes());SHA=lambda b:hashlib.sha256(b).hexdigest();assert SHA((B/'registered.json').read_bytes())==BUILT['registered'];assert SHA((B/'mutator.so').read_bytes())==BUILT['mutator'];assert SHA((B/'native-actor').read_bytes())==BUILT['rust_actor'];assert SHA((PROD/'production-contact.so').read_bytes())==BUILT['actual_ffi']==REG['sdk']['producer_dso_sha'];spec=importlib.util.spec_from_file_location('actual_product_source_placement',PROD/'production-contact.py');host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
P=c.c_void_p;PS=c.POINTER(P);S=c.c_char_p;U=c.c_uint;Z=c.c_size_t;I=c.c_int;llvm=host.LIB;cb=c.CDLL(str(B/'mutator.so'));mut=cb.OhmHostileInput;mut.restype=I;mut.argtypes=[P,S,c.POINTER(U),c.POINTER(U)];ffi=host.ffi
for suffix in ('TargetInfo','Target','TargetMC','AsmPrinter','AsmParser'):ffi('InitializeX86'+suffix,None)()
triple=b'x86_64-unknown-linux-gnu';target=P();msg=P();assert ffi('GetTargetFromTriple',I,S,PS,PS)(triple,c.byref(target),c.byref(msg))==0;create=ffi('CreateTargetMachine',P,P,S,S,S,I,I,I);dtm=ffi('DisposeTargetMachine',None,P);opts=ffi('CreatePassBuilderOptions',P);dopts=ffi('DisposePassBuilderOptions',None,P);run=ffi('RunPasses',P,P,S,P,P);geterr=ffi('GetErrorMessage',P,P);dmsg=ffi('DisposeErrorMessage',None,P);emit=ffi('TargetMachineEmitToMemoryBuffer',I,P,P,I,PS,PS);write=host.WRITE;BUF=host.BUF
@contextmanager
def module(bits):
 ctx=host.CTX();buf=BUF(bits,len(bits),b'hostile-input');m=P();assert host.BC(ctx,buf,c.byref(m))==0
 try:
  size=Z();name=host.NAME(m,c.byref(size));v=c.string_at(name,size.value);host.SET(m,v,len(v));yield m
 finally:host.DM(m);host.DB(buf);host.DC(ctx)
def extract(h):
 try:return c.string_at(host.START(h),host.SIZE(h))
 finally:host.DB(h)
def change(bits,mode):
 with module(bits)as m:
  cols=U();files=U();k=mut(m,mode.encode(),c.byref(cols),c.byref(files));assert k in(0,1),('verified LLVM mutator failure',k);return (extract(write(m))if k else None),cols.value,files.value
def generate(bits):
 with module(bits)as m:
  tm=create(target,triple,b'x86-64',b'',1,2,0);assert tm;p=opts();assert p
  try:
   err=run(m,b'default<O1>',tm,p)
   if err:
    msg=geterr(err);value=c.string_at(msg);dmsg(msg);raise RuntimeError(value)
   out=P();message=P();code=emit(tm,m,1,c.byref(message),c.byref(out));assert code==0,c.string_at(message)if message else code;return extract(out)
  finally:dopts(p);dtm(tm)
def physical(obj):
 assert len(obj)>=64 and obj[:6]==b'\x7fELF\x02\x01'and int.from_bytes(obj[16:18],'little')==1;table=int.from_bytes(obj[40:48],'little');entsize,n,st=struct.unpack_from('<HHH',obj,58);assert entsize==64 and 0<st<n and table+n*64<=len(obj);rows=[struct.unpack_from('<IIQQQQIIQQ',obj,table+i*64)for i in range(n)];sh=rows[st];names=obj[sh[4]:sh[4]+sh[5]];parts={};normal={};alloc={};reloc={};syms={}
 for idx,(name,typ,flags,addr,off,size,link,info,align,es)in enumerate(rows):
  assert name<len(names);sym=names[name:names.index(b'\0',name)].decode();assert sym not in parts;data=b'' if typ==8 else obj[off:off+size];assert typ==8 or len(data)==size
  rec=[typ,flags,addr,size,link,info,align,es,SHA(data)];parts[sym]=rec
  if not sym.startswith(('.debug','.rela.debug','.rel.debug')):normal[sym]=rec
  if flags&2:alloc[sym]=rec
  if typ in(4,9) and not sym.startswith(('.rela.debug','.rel.debug')):reloc[sym]=rec
  if typ in(2,11) or sym in('.strtab','.symstrtab'):syms[sym]=rec
 def h(x):return SHA(json.dumps(x,sort_keys=True,separators=(',',':')).encode())
 return {'elf':SHA(obj),'bytes':len(obj),'all_sections':h(parts),'nondebug':h(normal),'allocated':h(alloc),'relocations':h(reloc),'symbol_registry':h(syms),'n_sections':n,'section_content':{k:x[-1]for k,x in parts.items()}}
def project(obj,a,b):
 if a is None or b is None:return None
 fds=[]
 try:
  for blob in (obj,a,b):
   n=os.memfd_create('frozen-qa-product',os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING);fds.append(n);assert os.write(n,blob)==len(blob);os.lseek(n,0,0);fcntl.fcntl(n,1033,15);assert fcntl.fcntl(n,1034)&15==15
  r=subprocess.run([str(B/'native-actor'),'rebase',*[f'/proc/self/fd/{n}'for n in fds]],capture_output=True,pass_fds=fds,timeout=40);assert r.returncode in(0,2)and(r.returncode==0 or not r.stdout),('invalid native result',r.returncode,r.stderr[:180]);return r.stdout if r.returncode==0 else None
 finally:
  for f in fds:os.close(f)
def casename(unit,op):return unit.rsplit('.',1)[-1]+'--'+op

def main():
 unit,op=sys.argv[1:];desc=REG['inputs'][unit];assert op in REG['cases'];name=casename(unit,op);out=B/'cases'/(name+'.json');out.parent.mkdir(exist_ok=True);assert not out.exists();resource.setrlimit(resource.RLIMIT_AS,(2<<30,2<<30));resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.sched_setaffinity(0,{12});
 with zipfile.ZipFile(host.CAP)as z:bits=gzip.decompress(z.read('cgu-originals/'+desc['old_bitcode_sha']+'.gz'))
 assert SHA(bits)==desc['old_bitcode_sha'];baseline_wire=host.visit(bits);amendment=json.loads((B/'ffi-amendment.json').read_bytes());assert baseline_wire is not None and SHA(baseline_wire)==amendment['original_ffi_observed'][unit] and SHA(baseline_wire)!=desc['original_old_OSP'];mutated,n,f=change(bits,op);r=dict(registration=BUILT['registered'],build=BUILT,unit=unit,case=op,custody_amendment=SHA((B/'ffi-amendment.json').read_bytes()),old_input=SHA(bits),old_wire=SHA(baseline_wire),old_key=baseline_wire[4:36].hex(),changed_coordinates=n,changed_files=f,archive_native=desc['old_original_native']);fail=False
 if mutated is None:r['status']='no matching pattern in supplier input'
 else:
  after_wire=host.visit(mutated);r['mutated_input']=SHA(mutated);r['new_wire']=SHA(after_wire)if after_wire else None;r['new_key']=after_wire[4:36].hex()if after_wire else None;r['keys_equal']=bool(after_wire and baseline_wire[4:36]==after_wire[4:36]);old=generate(bits);new=generate(mutated);o=physical(old);v=physical(new);look=project(old,baseline_wire,baseline_wire);assert look is not None and look==old,('unsupported or unpreserved old fresh object',o['elf'],len(old));cur=project(new,after_wire,after_wire)if after_wire else None;assert cur is None or cur==new,('incorrect new identity',v['elf']);r.update(current_identity_eligible=cur is not None,old_fresh=o,new_fresh=v,old_fresh_matches_captured=o['elf']==desc['old_original_native'],changed_sections=sorted(k for k in set(o['section_content'])|set(v['section_content'])if o['section_content'].get(k)!=v['section_content'].get(k)));check={};branches={}
  for direction,data,left,right,target_bytes in [('forward',old,baseline_wire,after_wire,new),('reverse',new,after_wire,baseline_wire,old)]:
   projected=project(data,left,right);check[direction]=(SHA(projected)if projected is not None else None);branches[direction]='refused'if projected is None else 'byte exact'if projected==target_bytes else 'MISMATCH'
   if projected is not None and projected!=target_bytes:
    fail=True;target_dir=B/('counterexample-'+name);target_dir.mkdir(exist_ok=True)
    for kind_,payload in [('base',data),('expected',target_bytes),('projected',projected),('left-osp',left),('right-osp',right)]:assert len(payload)<8<<20;(target_dir/f'{direction}-{kind_}.gz').write_bytes(gzip.compress(payload,6,mtime=0))
    r['wrong_output_'+direction]=physical(projected)
  if any(s!='refused'for s in branches.values()):assert generate(mutated)==new and generate(bits)==old,('independent fresh emission differs',name);r['independent_new_old_complete_elf']=True
  if op=='identity':assert n==f==0 and after_wire==baseline_wire and new==old and all(v=='byte exact'for v in branches.values()),('identity gate',r)
  r.update(projected=check,branches=branches,status='MISMATCH'if fail else 'complete');r['old_fresh'].pop('section_content');r['new_fresh'].pop('section_content')
 data=(json.dumps(r,indent=1,sort_keys=True)+'\n').encode();tmp=out.with_suffix('.partial');tmp.write_bytes(data);os.replace(tmp,out);print(name,r['status'],r.get('branches'),r.get('keys_equal'),len(r.get('changed_sections',[])),flush=True);return int(fail)
if __name__=='__main__':sys.exit(main())
