from pathlib import Path
import ctypes as c,gzip,hashlib,json,sys,zipfile
v=Path(__file__).resolve().parent;sys.path.insert(0,str(v));import case2 as cc
k=next(k for k in cc.c1.REG['inputs'] if k.endswith('0qy8lp2jbveczg1y68dapnzjn'));x=cc.c1.REG['inputs'][k];p=cc.where;record=cc.read(p/'result.json')['rows'][k]['old'];
with zipfile.ZipFile(cc.c1.host.CAP)as z:bits=gzip.decompress(z.read('cgu-originals/'+x['old_bitcode_sha']+'.gz'))
with cc.c1.module(bits)as m:
 cf=cc.c1;tm=cf.create(cf.target,cf.triple,b'x86-64',b'',1,2,0);opts=cf.opts();assert not cf.run(m,b'default<O1>',tm,opts);post=cf.extract(cf.write(m));a=[]
 @cc.c2.CB
 def out(_,ptr,n):a.append(c.string_at(ptr,n))
 good=bool(cc.c2.F(m,0x1287,c.cast(out,cc.c2.P)));logical=[]
 for fun in ('GetModuleIdentifier','GetSourceFileName'):
  sz=c.c_size_t();fn=cf.ffi(fun,cf.P,cf.P,c.POINTER(c.c_size_t));addr=fn(m,c.byref(sz));logical.append(c.string_at(addr,sz.value).decode())
 via=cc.c2.visit(post);f=cc.c1.P();err=cc.c1.P();assert not cf.emit(tm,m,1,c.byref(err),c.byref(f));elf=cf.extract(f);cf.dopts(opts);cf.dtm(tm)
 s=lambda x: [len(x),cc.h(x),x[4:36].hex(),cc.h(x[36:])]if x else None;obs=dict(unit=k,normal_post_optimization=cc.h(post),expected_post=record['O1'],expected_key=record['key'],expected_placements=record['placements'],live_status=good,live=s(a[0]if a else None),serialize_parse=s(via),live_module_id_and_source=logical,ordinary_native=cc.h(elf));dest=v/'live-reference-diagnostic.json';dest.write_text(json.dumps(obs,indent=1,sort_keys=True)+'\n');print(json.dumps(obs,indent=1),flush=True)
