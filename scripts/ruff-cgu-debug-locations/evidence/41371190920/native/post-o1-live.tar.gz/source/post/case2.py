from pathlib import Path
import ctypes as c,fcntl,gzip,hashlib,importlib.util,json,os,resource,subprocess,sys,zipfile
v=Path(__file__).resolve().parent;b=v.parent;sys.path.insert(0,str(b));import case as c1
h=lambda r:hashlib.sha256(r).hexdigest();read=lambda p:json.loads(p.read_bytes());reg=read(v/'registered.json');compiled=read(v/'built.json');assert h((v/'native-actor').read_bytes())==compiled['binary']and all(h((v/'harness/src/source_placement'/n).read_bytes())==sha for n,sha in reg['new_rust'].items());where=b.parent/'native-ordinal-cgu-contact-v1/pure-post-o1-c2-v1';assert h((where/'pure.so').read_bytes())==reg['actual_dso'] and h((where/'contact.py').read_bytes())==reg['actual_api'];src=importlib.util.spec_from_file_location('true_c2',where/'contact.py');c2=importlib.util.module_from_spec(src);src.loader.exec_module(c2)
def ordinary(raw):
 with c1.module(raw)as m:
  tm=c1.create(c1.target,c1.triple,b'x86-64',b'',1,2,0);options=c1.opts();assert tm and options
  try:
   assert not c1.run(m,b'default<O1>',tm,options);optimized=c1.extract(c1.write(m));before=h(optimized);parsed=c2.visit(optimized);values=[]
   @c2.CB
   def capture(owner,buf,n):assert owner==0x1287;values.append(c.string_at(buf,n))
   answer=bool(c2.F(m,0x1287,c.cast(capture,c2.P)));assert answer==(len(values)==1) and len(values)<=1 and h(c1.extract(c1.write(m)))==before;out=c1.P();msg=c1.P();assert c1.emit(tm,m,1,c.byref(msg),c.byref(out))==0;return before,(values[0]if values else None),c1.extract(out),parsed
  finally:c1.dopts(options);c1.dtm(tm)
def project(obj,left,right):
 if left is None or right is None:return None
 f=[]
 try:
  for s in(obj,left,right):
   n=os.memfd_create('ohm-actual-post-o1',os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING);f.append(n);assert os.write(n,s)==len(s);os.lseek(n,0,0);fcntl.fcntl(n,1033,15);assert fcntl.fcntl(n,1034)&15==15
  r=subprocess.run([str(v/'native-actor'),'rebase',*[f'/proc/self/fd/{n}'for n in f]],pass_fds=f,capture_output=True,timeout=25);assert r.returncode in(0,2)and(r.returncode==0 or not r.stdout);return r.stdout if r.returncode==0 else None
 finally:
  for n in f:os.close(n)
def main():
 k,op=sys.argv[1:];case=c1.casename(k,op);cpath=b/'cases'/(case+'.json');base=read(cpath);assert base['registration']==reg['original_enrollment'] and base['custody_amendment']==reg['original_ffi_amendment'];r=dict(live_domain_amendment=h((v/'live-domain-amendment.json').read_bytes()),registration=h((v/'registered.json').read_bytes()),previous_case=h(cpath.read_bytes()),unit=k,case=op,old_source=base['old_input'],c1_keys_equal=base.get('keys_equal'),c1_decisions=base.get('branches'));resource.setrlimit(resource.RLIMIT_AS,(2<<30,2<<30));resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.sched_setaffinity(0,{12})
 with zipfile.ZipFile(c1.host.CAP)as z:raw=gzip.decompress(z.read('cgu-originals/'+base['old_input']+'.gz'))
 assert h(raw)==base['old_input'];changed,n,f=c1.change(raw,op);assert(n,f)==(base['changed_coordinates'],base['changed_files']);fail=False
 if changed is None:assert base['status']=='no matching pattern in supplier input';r['status']=base['status']
 else:
  assert h(changed)==base['mutated_input'];r['changed_source']=h(changed);prev,a,old,ar=ordinary(raw);current,cc,new,cr=ordinary(changed);r.update(old_opt=prev,new_opt=current,old_elf=h(old),new_elf=h(new),old_osp=h(a)if a else None,new_osp=h(cc)if cc else None,c2_keys_equal=bool(a and cc and a[4:36]==cc[4:36]),nondebug_same=c1.physical(old)['nondebug']==c1.physical(new)['nondebug']);root=read(where/'result.json')['rows'][k]['old'];assert prev==root['O1'] and ar and ar[4:36].hex()==root['key'] and h(ar[36:])==root['placements'],('shifted registered parent at post-O1',k,prev,root['O1']);assert h(old)==base['old_fresh']['elf']and h(new)==base['new_fresh']['elf'],('ordinary compiler differs between C1 prerequisite and source-built C2 callback',k,op,base['old_fresh']['elf'],h(old),base['new_fresh']['elf'],h(new));events={}
  for label,obj,left,right,expected in [('old_identity',old,a,a,old),('new_identity',new,cc,cc,new),('forward',old,a,cc,new),('reverse',new,cc,a,old),('reparsed_forward',old,ar,cr,new),('reparsed_reverse',new,cr,ar,old)]:
   out=project(obj,left,right);status='refused'if out is None else 'byte exact'if out==expected else 'MISMATCH';events[label]=dict(status=status,actual=h(out)if out is not None else None)
   if status=='MISMATCH':
    fail=True;temp=v/('counterexample-'+case);temp.mkdir(exist_ok=True)
    for role,d in [('input',obj),('projected',out),('clean',expected),('from',left),('to',right)]:(temp/(label+'-'+role+'.gz')).write_bytes(gzip.compress(d,6,mtime=0))
  if any(events[s]['status']!='refused'for s in('forward','reverse','reparsed_forward','reparsed_reverse')):post0,again0,fresh0,parsed0=ordinary(raw);post1,again1,fresh1,parsed1=ordinary(changed);assert(old,a,prev,ar,new,cc,current,cr)==(fresh0,again0,post0,parsed0,fresh1,again1,post1,parsed1);r['independently_clean_replicated']=True
  r.update(status='MISMATCH'if fail else 'complete',events=events,c2_reparsed_keys_equal=bool(ar and cr and ar[4:36]==cr[4:36]),old_reparsed_osp=h(ar)if ar else None,new_reparsed_osp=h(cr)if cr else None,old_live_equals_reparsed=a==ar,new_live_equals_reparsed=cc==cr,old_placement_equal=bool(a and ar and a[36:]==ar[36:]),new_placement_equal=bool(cc and cr and cc[36:]==cr[36:]))
 out=v/'cases';out.mkdir(exist_ok=True);p=out/(case+'.json');x=p.with_suffix('.partial');x.write_text(json.dumps(r,indent=1,sort_keys=True)+'\n');os.replace(x,p);print(case,r['status'],r.get('c2_keys_equal'),[a['status']for a in r.get('events',{}).values()][2:],flush=True);return int(fail)
if __name__=='__main__':sys.exit(main())
