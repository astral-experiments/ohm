"""Resume the independently enrolled board one complete real source module and input change at a time."""
from pathlib import Path
import fcntl,hashlib,json,os,signal,subprocess,sys,time
V=Path(__file__).resolve().parent;B=V.parent;Q=B.parent/'old-only-dwarf-rebase-28106';J=lambda p:json.loads(p.read_bytes());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();reg=J(B/'registered.json');assert h(B/'registered.json')=='dcccae695bb36426c738adab82db11dcc4d35e0cdf7510db4f0fb60ec8293aa3';floor=8*1024**3
# Only the registered case script and small immutable source inputs may run inside the budget.
def free():return int(next(l for l in Path('/proc/meminfo').read_text().splitlines()if l.startswith('MemAvailable:')).split()[1])*1024
def run(args,need):
 last=0
 while True:
  if free()<floor+need:
   if time.monotonic()-last>100:print('holding memory reserve',free(),flush=True);last=time.monotonic()
   time.sleep(6);continue
  with (Q/'one-native-heavy-operation.lock').open('a')as lock:
   fcntl.flock(lock,fcntl.LOCK_EX)
   if free()<floor+need:continue
   p=subprocess.Popen([sys.executable,'-IB',*map(str,args)],start_new_session=True);stopped=False
   while p.poll()is None:
    if free()<floor and p.poll()is None:os.killpg(p.pid,signal.SIGTERM);stopped=True;print('holding after shared RAM dropped',flush=True);break
    time.sleep(.12)
   status=p.wait()
  if not stopped and status:return status
  if not stopped:return 0
  time.sleep(6)
if not(V/'built.json').is_file():
 rc=run([V/'build.py'],450_000_000)
 if rc:raise SystemExit(rc)
old=J(B/'terminal.json');assert h(B/'terminal.json')==J(V/'registered.json')['old_terminal'];rows=[]
for path in sorted((B/'cases').glob('*.json'),key=lambda x:(0 if 'identity' in x.name else 1,x.name)):
 prev=J(path);p=V/'cases'/path.name
 if not p.exists():
  rc=run([V/'case2.py',prev['unit'],prev['case']],380_000_000)
  if rc:raise SystemExit(rc)
 r=J(p);assert r['previous_case']==h(path)and r['status']!='MISMATCH';rows.append(r)
assert len(rows)==36;from collections import Counter
completed=[r for r in rows if r['status']=='complete'];counts=Counter(r['events'][x]['status']for r in completed for x in('forward','reverse'));changes=Counter((r['c1_decisions'][x],r['events'][x]['status'])for r in completed for x in('forward','reverse'));assert all(r['events']['old_identity']['status']=='byte exact'for r in completed);record=dict(registration=h(V/'registered.json'),source_controls=len(rows),missing=36-len(completed),same_native_old_and_current_as_c1=len(completed),direction_counts=dict(counts),c1_to_c2_directions={a+' -> '+b_:n for (a,b_),n in changes.items()},key_membership_swaps=sum(r['c1_keys_equal']!=r['c2_keys_equal']for r in completed),native_eligible_changed_pairs=sum(r['events']['forward']['status']=='byte exact'and r['old_elf']!=r['new_elf']for r in completed),nondebug_change_pairs=sum(not r['nondebug_same']for r in completed),receipts={p.name:h(p)for p in sorted((V/'cases').glob('*.json'))});f=V/'terminal.json';f.write_text(json.dumps(record,sort_keys=True,indent=1)+'\n');print('C2 TERMINAL',h(f),{k:x for k,x in record.items()if k!='receipts'},flush=True)
