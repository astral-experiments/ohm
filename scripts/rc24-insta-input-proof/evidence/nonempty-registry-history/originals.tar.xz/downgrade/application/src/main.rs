fn main(){let (a,b,c)=v5consumer::result();println!("{a} {b} {c}");}
