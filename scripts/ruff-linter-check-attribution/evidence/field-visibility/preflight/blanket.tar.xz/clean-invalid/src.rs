pub struct External;
pub trait Candidate { fn selected(&self) -> u8 { 19 } }
impl<T> Candidate for T {}
