fn main() { println!("{}", consumer::result()); }
