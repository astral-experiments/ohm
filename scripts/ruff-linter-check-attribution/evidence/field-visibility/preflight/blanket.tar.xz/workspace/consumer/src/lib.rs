#[allow(unused_imports)] use facade::{Candidate, External};
trait Local { fn selected(&self) -> u8; }
impl Local for External { fn selected(&self) -> u8 { 17 } }
pub fn result() -> u8 { External.selected() }
