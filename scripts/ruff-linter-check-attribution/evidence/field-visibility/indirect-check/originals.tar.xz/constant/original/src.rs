#[macro_export]
macro_rules! selected { () => { $crate::VALUE }; }
pub const VALUE: u8 = 17;
