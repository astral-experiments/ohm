pub mod first { pub const VALUE: u8 = 17; }
pub mod second { pub const OTHER: u8 = 11; pub const VALUE: u8 = 19; }
#[macro_export]
macro_rules! selected { () => {{ use $crate::first::*; use $crate::second::*; VALUE }}; }
