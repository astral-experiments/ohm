
warning: .debug_names not created by gdb; ignoring
Breakpoint 1 at 0x401254: file /ohm/full.c, line 34.
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".

Breakpoint 1, 0x0000000000401254 in full_inlined () at /ohm/full.c:34
warning: 34	/ohm/full.c: No such file or directory
inline_witness = 22
$1 = 22
