; ModuleID = 'portable_atomic.ef8bb306c3dda87a-cgu.0'
source_filename = "portable_atomic.ef8bb306c3dda87a-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

@alloc_8340eaecd7a737fcfcdd0073e8956f2c = private unnamed_addr constant [41 x i8] c"assertion failed: detect::detect().lse2()", align 1, !guid !0
@alloc_a58296eaaaac2f2d9ac3b77633cdf456 = private unnamed_addr constant [154 x i8] c"/home/runner/work/_temp/gnu-ty-marker-census/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.13.1/src/imp/atomic128/aarch64.rs\00", align 1, !guid !1
@alloc_12412b956e66c04e12503c9367de68ad = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00w\02\00\00\05\00\00\00" }>, align 8, !guid !2
@alloc_bbf83a9036b634a7c8a3080dbbfef5b6 = private unnamed_addr constant [40 x i8] c"assertion failed: src as usize % 16 == 0", align 1, !guid !3
@alloc_01ae46f43b0b403ea43821c8570eb0e0 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00v\02\00\00\05\00\00\00" }>, align 8, !guid !4
@alloc_a4970165f4422c6d133b8ae28d684954 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\14\04\00\00\05\00\00\00" }>, align 8, !guid !5
@alloc_6c27a2b2ff3421ba7cd30da1ef1877fa = private unnamed_addr constant [40 x i8] c"assertion failed: dst as usize % 16 == 0", align 1, !guid !6
@alloc_9e98eff3184063ea6ad811293b560184 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\13\04\00\00\05\00\00\00" }>, align 8, !guid !7
@alloc_3dc46b42d6bdb2daf64cb0a467a82b62 = private unnamed_addr constant [43 x i8] c"assertion failed: detect::detect().lse128()", align 1, !guid !8
@alloc_61e22541e076e5d89db40f3c8d30d89a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00#\06\00\00\05\00\00\00" }>, align 8, !guid !9
@alloc_a463044e5da2c4c5c76c7b67250e5a64 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\22\06\00\00\05\00\00\00" }>, align 8, !guid !10
@alloc_d43cf41787e6ab3139468bf953d7c3ef = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\BA\02\00\00\05\00\00\00" }>, align 8, !guid !11
@alloc_b00d604102ee496c8753f807e35d5ef5 = private unnamed_addr constant [42 x i8] c"assertion failed: detect::detect().rcpc3()", align 1, !guid !12
@alloc_81102cd96afff72937c2beac9b95ce9a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\BB\02\00\00\05\00\00\00" }>, align 8, !guid !13
@alloc_bb7dfdea11a66e3386b2a546d12dbd10 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\B9\02\00\00\05\00\00\00" }>, align 8, !guid !14
@alloc_4698564d0679a083e3d70623192bc582 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00_\04\00\00\05\00\00\00" }>, align 8, !guid !15
@alloc_04b8e0899c86a564c6777f3d17a7854a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00`\04\00\00\05\00\00\00" }>, align 8, !guid !16
@alloc_63df8b5fe7be207dd35364f9603b6e7f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00^\04\00\00\05\00\00\00" }>, align 8, !guid !17
@alloc_0f506e367be60f045daaada6fe5b941c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00(\03\00\00\05\00\00\00" }>, align 8, !guid !18
@alloc_26281b586fc59a1b79384da8e2598487 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\98\04\00\00\05\00\00\00" }>, align 8, !guid !19
@alloc_6837de6f0f246ddf523dcfbb31c4fdb7 = private unnamed_addr constant [40 x i8] c"assertion failed: detect::detect().lse()", align 1, !guid !20
@alloc_f0a7c1e1a08c527f182e617e4babd556 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\86\05\00\00\05\00\00\00" }>, align 8, !guid !21
@alloc_017e25b07b4da233217b000fa2c86620 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\85\05\00\00\05\00\00\00" }>, align 8, !guid !22
@alloc_b38806655b417e8425a659de094e8348 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58296eaaaac2f2d9ac3b77633cdf456, [16 x i8] c"\99\00\00\00\00\00\00\00\B0\05\00\00\05\00\00\00" }>, align 8, !guid !23
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load4init, align 8, !guid !24
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads0_4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads0_4init, align 8, !guid !25
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads_4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads_4init, align 8, !guid !26
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store4init, align 8, !guid !27
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores0_4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores0_4init, align 8, !guid !28
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores_4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores_4init, align 8, !guid !29
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange4init, align 8, !guid !30
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges0_4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges0_4init, align 8, !guid !31
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges1_4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges1_4init, align 8, !guid !32
@_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges_4FUNC = local_unnamed_addr global ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges_4init, align 8, !guid !33
@_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 = internal unnamed_addr global i32 0, align 4, !guid !34

; portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
; Function Attrs: cold nounwind uwtable
define internal fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef nonnull align 4 captures(none) dereferenceable(4) %info) unnamed_addr #0 !dbg !43 !guid !53 {
start:
  %_0.i = tail call noundef i64 @getauxval(i64 noundef 16) #7, !dbg !54
  %_3 = and i64 %_0.i, 256, !dbg !59
  %0 = icmp eq i64 %_3, 0, !dbg !61
  br i1 %0, label %bb4, label %bb2, !dbg !61

bb2:                                              ; preds = %start
  %_4.i = load i32, ptr %info, align 4, !dbg !62, !alias.scope !67, !noundef !52
  %_0.i.i = or i32 %_4.i, 2, !dbg !70
  store i32 %_0.i.i, ptr %info, align 4, !dbg !73, !alias.scope !67
  br label %bb4, !dbg !74

bb4:                                              ; preds = %start, %bb2
  %_5 = and i64 %_0.i, 33554432, !dbg !59
  %1 = icmp eq i64 %_5, 0, !dbg !61
  br i1 %1, label %bb7, label %bb5, !dbg !61

bb5:                                              ; preds = %bb4
  %_4.i1 = load i32, ptr %info, align 4, !dbg !75, !alias.scope !77, !noundef !52
  %_0.i.i2 = or i32 %_4.i1, 8, !dbg !80
  store i32 %_0.i.i2, ptr %info, align 4, !dbg !82, !alias.scope !77
  br label %bb7, !dbg !74

bb7:                                              ; preds = %bb4, %bb5
  %_0.i3 = tail call noundef i64 @getauxval(i64 noundef 26) #7, !dbg !83
  %_8 = and i64 %_0.i3, 70368744177664, !dbg !85
  %2 = icmp eq i64 %_8, 0, !dbg !87
  br i1 %2, label %bb11, label %bb9, !dbg !87

bb9:                                              ; preds = %bb7
  %_4.i4 = load i32, ptr %info, align 4, !dbg !88, !alias.scope !90, !noundef !52
  %_0.i.i5 = or i32 %_4.i4, 32, !dbg !93
  store i32 %_0.i.i5, ptr %info, align 4, !dbg !95, !alias.scope !90
  br label %bb11, !dbg !96

bb11:                                             ; preds = %bb7, %bb9
  %_10 = and i64 %_0.i3, 140737488355328, !dbg !85
  %3 = icmp eq i64 %_10, 0, !dbg !87
  br i1 %3, label %bb14, label %bb12, !dbg !87

bb12:                                             ; preds = %bb11
  %_4.i6 = load i32, ptr %info, align 4, !dbg !97, !alias.scope !99, !noundef !52
  %_0.i.i7 = or i32 %_4.i6, 64, !dbg !102
  store i32 %_0.i.i7, ptr %info, align 4, !dbg !104, !alias.scope !99
  br label %bb14, !dbg !96

bb14:                                             ; preds = %bb11, %bb12
  ret void, !dbg !105
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_lse2_seqcst
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load23atomic_load_lse2_seqcst(ptr noundef %src) unnamed_addr #1 !dbg !106 !guid !109 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_4.i = ptrtoint ptr %src to i64, !dbg !110
  %_3.i = and i64 %_4.i, 15, !dbg !110
  %0 = icmp eq i64 %_3.i, 0, !dbg !110
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !110, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !115
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !118
  store i32 %1, ptr %info.i.i, align 4, !dbg !128
  %2 = icmp eq i32 %1, 0, !dbg !129
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !129, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !132, !alias.scope !134
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !137
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !138, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !139
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !144

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !145
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !146
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !147
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !147
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6416__atomic_load_ldp.exit, !dbg !154, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_01ae46f43b0b403ea43821c8570eb0e0) #8, !dbg !155
  unreachable, !dbg !155

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_12412b956e66c04e12503c9367de68ad) #8, !dbg !156
  unreachable, !dbg !156

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6416__atomic_load_ldp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %3 = tail call { i64, i64, i32 } asm sideeffect "ldar ${2}, [${3}]\0Aldp ${1}, ${0}, [${3}]\0Admb ishld", "=r,=r,=&r,r,~{memory}"(ptr %src) #7, !dbg !157, !srcloc !159
  %4 = extractvalue { i64, i64, i32 } %3, 0, !dbg !157
  %5 = extractvalue { i64, i64, i32 } %3, 1, !dbg !157
  %_16.sroa.4.0.insert.ext.i = zext i64 %4 to i128, !dbg !160
  %_16.sroa.4.0.insert.shift.i = shl nuw i128 %_16.sroa.4.0.insert.ext.i, 64, !dbg !160
  %_16.sroa.0.0.insert.ext.i = zext i64 %5 to i128, !dbg !160
  %_16.sroa.0.0.insert.insert.i = or disjoint i128 %_16.sroa.4.0.insert.shift.i, %_16.sroa.0.0.insert.ext.i, !dbg !160
  ret i128 %_16.sroa.0.0.insert.insert.i, !dbg !161
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_lse2_acquire
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_acquire(ptr noundef %src) unnamed_addr #1 !dbg !162 !guid !163 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_4.i = ptrtoint ptr %src to i64, !dbg !164
  %_3.i = and i64 %_4.i, 15, !dbg !164
  %0 = icmp eq i64 %_3.i, 0, !dbg !164
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !164, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !166
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !168
  store i32 %1, ptr %info.i.i, align 4, !dbg !171
  %2 = icmp eq i32 %1, 0, !dbg !172
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !172, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !173, !alias.scope !175
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !178
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !179, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !180
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !183

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !184
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !185
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !186
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !186
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6416__atomic_load_ldp.exit, !dbg !190, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_01ae46f43b0b403ea43821c8570eb0e0) #8, !dbg !191
  unreachable, !dbg !191

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_12412b956e66c04e12503c9367de68ad) #8, !dbg !192
  unreachable, !dbg !192

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6416__atomic_load_ldp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %3 = tail call { i64, i64 } asm sideeffect "ldp ${1}, ${0}, [${2}]\0Admb ishld", "=r,=r,r,~{memory}"(ptr %src) #7, !dbg !193, !srcloc !194
  %4 = extractvalue { i64, i64 } %3, 0, !dbg !193
  %5 = extractvalue { i64, i64 } %3, 1, !dbg !193
  %_14.sroa.4.0.insert.ext.i = zext i64 %4 to i128, !dbg !195
  %_14.sroa.4.0.insert.shift.i = shl nuw i128 %_14.sroa.4.0.insert.ext.i, 64, !dbg !195
  %_14.sroa.0.0.insert.ext.i = zext i64 %5 to i128, !dbg !195
  %_14.sroa.0.0.insert.insert.i = or disjoint i128 %_14.sroa.4.0.insert.shift.i, %_14.sroa.0.0.insert.ext.i, !dbg !195
  ret i128 %_14.sroa.0.0.insert.insert.i, !dbg !196
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_lse2_relaxed
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_relaxed(ptr noundef %src) unnamed_addr #1 !dbg !197 !guid !198 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_4.i = ptrtoint ptr %src to i64, !dbg !199
  %_3.i = and i64 %_4.i, 15, !dbg !199
  %0 = icmp eq i64 %_3.i, 0, !dbg !199
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !199, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !201
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !203
  store i32 %1, ptr %info.i.i, align 4, !dbg !206
  %2 = icmp eq i32 %1, 0, !dbg !207
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !207, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !208, !alias.scope !210
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !213
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !214, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !215
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !218

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !219
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !220
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !221
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !221
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6416__atomic_load_ldp.exit, !dbg !225, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_01ae46f43b0b403ea43821c8570eb0e0) #8, !dbg !226
  unreachable, !dbg !226

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_12412b956e66c04e12503c9367de68ad) #8, !dbg !227
  unreachable, !dbg !227

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6416__atomic_load_ldp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %3 = tail call { i64, i64 } asm sideeffect "ldp ${1}, ${0}, [${2}]\0A", "=r,=r,r,~{memory}"(ptr %src) #7, !dbg !228, !srcloc !229
  %4 = extractvalue { i64, i64 } %3, 0, !dbg !228
  %5 = extractvalue { i64, i64 } %3, 1, !dbg !228
  %_12.sroa.4.0.insert.ext.i = zext i64 %4 to i128, !dbg !230
  %_12.sroa.4.0.insert.shift.i = shl nuw i128 %_12.sroa.4.0.insert.ext.i, 64, !dbg !230
  %_12.sroa.0.0.insert.ext.i = zext i64 %5 to i128, !dbg !230
  %_12.sroa.0.0.insert.insert.i = or disjoint i128 %_12.sroa.4.0.insert.shift.i, %_12.sroa.0.0.insert.ext.i, !dbg !230
  ret i128 %_12.sroa.0.0.insert.insert.i, !dbg !231
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_no_lse2_seqcst
; Function Attrs: uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load26atomic_load_no_lse2_seqcst(ptr noundef %src) unnamed_addr #2 !dbg !232 !guid !233 {
start:
  %_4.i = ptrtoint ptr %src to i64, !dbg !234
  %_3.i = and i64 %_4.i, 15, !dbg !234
  %0 = icmp eq i64 %_3.i, 0, !dbg !234
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6422__atomic_load_ldxp_stxp.exit, label %bb2.i, !dbg !234, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0f506e367be60f045daaada6fe5b941c) #8, !dbg !237
  unreachable, !dbg !237

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6422__atomic_load_ldxp_stxp.exit: ; preds = %start
  %1 = tail call { i64, i64, i32 } asm sideeffect "2:\0Aldaxp ${0}, ${1}, [${3}]\0Astlxp ${2:w}, ${0}, ${1}, [${3}]\0Acbnz ${2:w}, 2b", "=&r,=&r,=&r,r,~{memory}"(ptr %src) #7, !dbg !238, !srcloc !240
  %out_lo.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 0, !dbg !238
  %out_hi.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 1, !dbg !238
  %_10.sroa.4.0.insert.ext.i = zext i64 %out_hi.sroa.0.0.i to i128, !dbg !241
  %_10.sroa.4.0.insert.shift.i = shl nuw i128 %_10.sroa.4.0.insert.ext.i, 64, !dbg !241
  %_10.sroa.0.0.insert.ext.i = zext i64 %out_lo.sroa.0.0.i to i128, !dbg !241
  %_10.sroa.0.0.insert.insert.i = or disjoint i128 %_10.sroa.4.0.insert.shift.i, %_10.sroa.0.0.insert.ext.i, !dbg !241
  ret i128 %_10.sroa.0.0.insert.insert.i, !dbg !242
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_no_lse2_acquire
; Function Attrs: uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_acquire(ptr noundef %src) unnamed_addr #2 !dbg !243 !guid !244 {
start:
  %_4.i = ptrtoint ptr %src to i64, !dbg !245
  %_3.i = and i64 %_4.i, 15, !dbg !245
  %0 = icmp eq i64 %_3.i, 0, !dbg !245
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6422__atomic_load_ldxp_stxp.exit, label %bb2.i, !dbg !245, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0f506e367be60f045daaada6fe5b941c) #8, !dbg !247
  unreachable, !dbg !247

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6422__atomic_load_ldxp_stxp.exit: ; preds = %start
  %1 = tail call { i64, i64, i32 } asm sideeffect "2:\0Aldaxp ${0}, ${1}, [${3}]\0Astxp ${2:w}, ${0}, ${1}, [${3}]\0Acbnz ${2:w}, 2b", "=&r,=&r,=&r,r,~{memory}"(ptr %src) #7, !dbg !248, !srcloc !240
  %out_lo.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 0, !dbg !248
  %out_hi.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 1, !dbg !248
  %_10.sroa.4.0.insert.ext.i = zext i64 %out_hi.sroa.0.0.i to i128, !dbg !249
  %_10.sroa.4.0.insert.shift.i = shl nuw i128 %_10.sroa.4.0.insert.ext.i, 64, !dbg !249
  %_10.sroa.0.0.insert.ext.i = zext i64 %out_lo.sroa.0.0.i to i128, !dbg !249
  %_10.sroa.0.0.insert.insert.i = or disjoint i128 %_10.sroa.4.0.insert.shift.i, %_10.sroa.0.0.insert.ext.i, !dbg !249
  ret i128 %_10.sroa.0.0.insert.insert.i, !dbg !250
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_no_lse2_relaxed
; Function Attrs: uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed(ptr noundef %src) unnamed_addr #2 !dbg !251 !guid !252 {
start:
  %_4.i = ptrtoint ptr %src to i64, !dbg !253
  %_3.i = and i64 %_4.i, 15, !dbg !253
  %0 = icmp eq i64 %_3.i, 0, !dbg !253
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6422__atomic_load_ldxp_stxp.exit, label %bb2.i, !dbg !253, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0f506e367be60f045daaada6fe5b941c) #8, !dbg !255
  unreachable, !dbg !255

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6422__atomic_load_ldxp_stxp.exit: ; preds = %start
  %1 = tail call { i64, i64, i32 } asm sideeffect "2:\0Aldxp ${0}, ${1}, [${3}]\0Astxp ${2:w}, ${0}, ${1}, [${3}]\0Acbnz ${2:w}, 2b", "=&r,=&r,=&r,r,~{memory}"(ptr %src) #7, !dbg !256, !srcloc !240
  %out_lo.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 0, !dbg !256
  %out_hi.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 1, !dbg !256
  %_10.sroa.4.0.insert.ext.i = zext i64 %out_hi.sroa.0.0.i to i128, !dbg !257
  %_10.sroa.4.0.insert.shift.i = shl nuw i128 %_10.sroa.4.0.insert.ext.i, 64, !dbg !257
  %_10.sroa.0.0.insert.ext.i = zext i64 %out_lo.sroa.0.0.i to i128, !dbg !257
  %_10.sroa.0.0.insert.insert.i = or disjoint i128 %_10.sroa.4.0.insert.shift.i, %_10.sroa.0.0.insert.ext.i, !dbg !257
  ret i128 %_10.sroa.0.0.insert.insert.i, !dbg !258
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_lse2_rcpc3_seqcst
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load29atomic_load_lse2_rcpc3_seqcst(ptr noundef %src) unnamed_addr #1 !dbg !259 !guid !260 {
start:
  %info.i1.i = alloca [4 x i8], align 4
  %info.i.i = alloca [4 x i8], align 4
  %_4.i = ptrtoint ptr %src to i64, !dbg !261
  %_3.i = and i64 %_4.i, 15, !dbg !261
  %0 = icmp eq i64 %_3.i, 0, !dbg !261
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !261, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !264
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !266
  store i32 %1, ptr %info.i.i, align 4, !dbg !269
  %2 = icmp eq i32 %1, 0, !dbg !270
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !270, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !271, !alias.scope !273
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !276
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !277, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !278
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !281

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !282
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !283
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !284
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !284
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %bb5.i, !dbg !288, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_bb7dfdea11a66e3386b2a546d12dbd10) #8, !dbg !289
  unreachable, !dbg !289

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d43cf41787e6ab3139468bf953d7c3ef) #8, !dbg !290
  unreachable, !dbg !290

bb5.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i1.i), !dbg !291
  %3 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !293
  store i32 %3, ptr %info.i1.i, align 4, !dbg !296
  %4 = icmp eq i32 %3, 0, !dbg !297
  br i1 %4, label %bb3.i4.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i, !dbg !297, !prof !131

bb3.i4.i:                                         ; preds = %bb5.i
  store i32 1, ptr %info.i1.i, align 4, !dbg !298, !alias.scope !300
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i1.i), !dbg !303
  %_9.i5.i = load i32, ptr %info.i1.i, align 4, !dbg !304, !noundef !52
  store atomic i32 %_9.i5.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !305
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i, !dbg !308

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i: ; preds = %bb5.i, %bb3.i4.i
  %_0.sroa.0.0.i3.i = phi i32 [ %_9.i5.i, %bb3.i4.i ], [ %3, %bb5.i ], !dbg !309
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i1.i), !dbg !310
  %_3.i.i.i7.i = and i32 %_0.sroa.0.0.i3.i, 32, !dbg !311
  %_0.i.i.i8.not.i = icmp eq i32 %_3.i.i.i7.i, 0, !dbg !311
  br i1 %_0.i.i.i8.not.i, label %bb10.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_load_ldiapp.exit, !dbg !316, !prof !131

bb10.i:                                           ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_b00d604102ee496c8753f807e35d5ef5, i64 noundef 42, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_81102cd96afff72937c2beac9b95ce9a) #8, !dbg !317
  unreachable, !dbg !317

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_load_ldiapp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i
  %5 = tail call { i64, i64, i32 } asm sideeffect ".arch_extension rcpc3\0Aldar ${2}, [${3}]\0Aldiapp ${1}, ${0}, [${3}]", "=r,=r,=&r,r,~{memory}"(ptr %src) #7, !dbg !318, !srcloc !320
  %6 = extractvalue { i64, i64, i32 } %5, 0, !dbg !318
  %7 = extractvalue { i64, i64, i32 } %5, 1, !dbg !318
  %_16.sroa.4.0.insert.ext.i = zext i64 %6 to i128, !dbg !321
  %_16.sroa.4.0.insert.shift.i = shl nuw i128 %_16.sroa.4.0.insert.ext.i, 64, !dbg !321
  %_16.sroa.0.0.insert.ext.i = zext i64 %7 to i128, !dbg !321
  %_16.sroa.0.0.insert.insert.i = or disjoint i128 %_16.sroa.4.0.insert.shift.i, %_16.sroa.0.0.insert.ext.i, !dbg !321
  ret i128 %_16.sroa.0.0.insert.insert.i, !dbg !322
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_lse2_rcpc3_acquire
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load30atomic_load_lse2_rcpc3_acquire(ptr noundef %src) unnamed_addr #1 !dbg !323 !guid !324 {
start:
  %info.i1.i = alloca [4 x i8], align 4
  %info.i.i = alloca [4 x i8], align 4
  %_4.i = ptrtoint ptr %src to i64, !dbg !325
  %_3.i = and i64 %_4.i, 15, !dbg !325
  %0 = icmp eq i64 %_3.i, 0, !dbg !325
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !325, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !327
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !329
  store i32 %1, ptr %info.i.i, align 4, !dbg !332
  %2 = icmp eq i32 %1, 0, !dbg !333
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !333, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !334, !alias.scope !336
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !339
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !340, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !341
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !344

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !345
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !346
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !347
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !347
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %bb5.i, !dbg !351, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_bbf83a9036b634a7c8a3080dbbfef5b6, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_bb7dfdea11a66e3386b2a546d12dbd10) #8, !dbg !352
  unreachable, !dbg !352

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d43cf41787e6ab3139468bf953d7c3ef) #8, !dbg !353
  unreachable, !dbg !353

bb5.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i1.i), !dbg !354
  %3 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !356
  store i32 %3, ptr %info.i1.i, align 4, !dbg !359
  %4 = icmp eq i32 %3, 0, !dbg !360
  br i1 %4, label %bb3.i4.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i, !dbg !360, !prof !131

bb3.i4.i:                                         ; preds = %bb5.i
  store i32 1, ptr %info.i1.i, align 4, !dbg !361, !alias.scope !363
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i1.i), !dbg !366
  %_9.i5.i = load i32, ptr %info.i1.i, align 4, !dbg !367, !noundef !52
  store atomic i32 %_9.i5.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !368
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i, !dbg !371

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i: ; preds = %bb5.i, %bb3.i4.i
  %_0.sroa.0.0.i3.i = phi i32 [ %_9.i5.i, %bb3.i4.i ], [ %3, %bb5.i ], !dbg !372
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i1.i), !dbg !373
  %_3.i.i.i7.i = and i32 %_0.sroa.0.0.i3.i, 32, !dbg !374
  %_0.i.i.i8.not.i = icmp eq i32 %_3.i.i.i7.i, 0, !dbg !374
  br i1 %_0.i.i.i8.not.i, label %bb10.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_load_ldiapp.exit, !dbg !378, !prof !131

bb10.i:                                           ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_b00d604102ee496c8753f807e35d5ef5, i64 noundef 42, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_81102cd96afff72937c2beac9b95ce9a) #8, !dbg !379
  unreachable, !dbg !379

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_load_ldiapp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit6.i
  %5 = tail call { i64, i64 } asm sideeffect ".arch_extension rcpc3\0Aldiapp ${1}, ${0}, [${2}]", "=r,=r,r,~{memory}"(ptr %src) #7, !dbg !380, !srcloc !381
  %6 = extractvalue { i64, i64 } %5, 0, !dbg !380
  %7 = extractvalue { i64, i64 } %5, 1, !dbg !380
  %_16.sroa.4.0.insert.ext.i = zext i64 %6 to i128, !dbg !382
  %_16.sroa.4.0.insert.shift.i = shl nuw i128 %_16.sroa.4.0.insert.ext.i, 64, !dbg !382
  %_16.sroa.0.0.insert.ext.i = zext i64 %7 to i128, !dbg !382
  %_16.sroa.0.0.insert.insert.i = or disjoint i128 %_16.sroa.4.0.insert.shift.i, %_16.sroa.0.0.insert.ext.i, !dbg !382
  ret i128 %_16.sroa.0.0.insert.insert.i, !dbg !383
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::init
; Function Attrs: cold uwtable
define noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load4init(ptr noundef %src) unnamed_addr #3 !dbg !384 !guid !385 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !386
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !389
  store i32 %0, ptr %info.i, align 4, !dbg !392
  %1 = icmp eq i32 %0, 0, !dbg !393
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !393, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !394, !alias.scope !396
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !399
  %_9.i = load i32, ptr %info.i, align 4, !dbg !400, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !401
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !404

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !405
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !406
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 8, !dbg !407
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !407
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_relaxed, !dbg !413
  store atomic ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load4FUNC monotonic, align 8, !dbg !414
; call portable_atomic::imp::atomic128::aarch64::atomic_load::atomic_load_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed
  %_0 = tail call noundef i128 %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed(ptr noundef %src), !dbg !420, !callees !421
  ret i128 %_0, !dbg !422
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::init
; Function Attrs: cold uwtable
define noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads0_4init(ptr noundef %src) unnamed_addr #3 !dbg !423 !guid !424 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !425
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !428
  store i32 %0, ptr %info.i, align 4, !dbg !431
  %1 = icmp eq i32 %0, 0, !dbg !432
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !432, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !433, !alias.scope !435
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !438
  %_9.i = load i32, ptr %info.i, align 4, !dbg !439, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !440
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !443

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !444
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !445
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 8, !dbg !446
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !446
  %_3.i.i.i1 = and i32 %_0.sroa.0.0.i, 32, !dbg !452
  %_0.i.i.i2.not = icmp eq i32 %_3.i.i.i1, 0, !dbg !452
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load29atomic_load_lse2_rcpc3_seqcst._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load23atomic_load_lse2_seqcst = select i1 %_0.i.i.i2.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load23atomic_load_lse2_seqcst, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load29atomic_load_lse2_rcpc3_seqcst, !dbg !452
  %func.sroa.0.0 = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load26atomic_load_no_lse2_seqcst, ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load29atomic_load_lse2_rcpc3_seqcst._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load23atomic_load_lse2_seqcst, !dbg !452
  store atomic ptr %func.sroa.0.0, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads0_4FUNC monotonic, align 8, !dbg !453
  %_0 = tail call noundef i128 %func.sroa.0.0(ptr noundef %src), !dbg !457, !callees !458
  ret i128 %_0, !dbg !459
}

; portable_atomic::imp::atomic128::aarch64::atomic_load::init
; Function Attrs: cold uwtable
define noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads_4init(ptr noundef %src) unnamed_addr #3 !dbg !460 !guid !461 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !462
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !465
  store i32 %0, ptr %info.i, align 4, !dbg !468
  %1 = icmp eq i32 %0, 0, !dbg !469
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !469, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !470, !alias.scope !472
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !475
  %_9.i = load i32, ptr %info.i, align 4, !dbg !476, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !477
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !480

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !481
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !482
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 8, !dbg !483
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !483
  %_3.i.i.i1 = and i32 %_0.sroa.0.0.i, 32, !dbg !489
  %_0.i.i.i2.not = icmp eq i32 %_3.i.i.i1, 0, !dbg !489
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load30atomic_load_lse2_rcpc3_acquire._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_acquire = select i1 %_0.i.i.i2.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_acquire, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load30atomic_load_lse2_rcpc3_acquire, !dbg !489
  %func.sroa.0.0 = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_acquire, ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load30atomic_load_lse2_rcpc3_acquire._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_acquire, !dbg !489
  store atomic ptr %func.sroa.0.0, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads_4FUNC monotonic, align 8, !dbg !490
  %_0 = tail call noundef i128 %func.sroa.0.0(ptr noundef %src), !dbg !494, !callees !495
  ret i128 %_0, !dbg !496
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse2_seqcst
; Function Attrs: noinline uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store24atomic_store_lse2_seqcst(ptr noundef %dst, i128 noundef %val) unnamed_addr #1 !dbg !497 !guid !499 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_5.i = ptrtoint ptr %dst to i64, !dbg !500
  %_4.i = and i64 %_5.i, 15, !dbg !500
  %0 = icmp eq i64 %_4.i, 0, !dbg !500
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !500, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !503
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !505
  store i32 %1, ptr %info.i.i, align 4, !dbg !508
  %2 = icmp eq i32 %1, 0, !dbg !509
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !509, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !510, !alias.scope !512
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !515
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !516, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !517
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !520

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !521
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !522
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !523
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !523
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_store_stp.exit, !dbg !527, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9e98eff3184063ea6ad811293b560184) #8, !dbg !528
  unreachable, !dbg !528

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a4970165f4422c6d133b8ae28d684954) #8, !dbg !529
  unreachable, !dbg !529

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_store_stp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %val3.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !530
  %val3.sroa.4.0.extract.shift.i = lshr i128 %val, 64, !dbg !530
  %val3.sroa.4.0.extract.trunc.i = trunc nuw i128 %val3.sroa.4.0.extract.shift.i to i64, !dbg !530
  tail call void asm sideeffect "dmb ish\0Astp ${1}, ${2}, [${0}]\0Admb ish", "r,r,r,~{memory}"(ptr %dst, i64 %val3.sroa.0.0.extract.trunc.i, i64 %val3.sroa.4.0.extract.trunc.i) #7, !dbg !531, !srcloc !533
  ret void, !dbg !534
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse2_relaxed
; Function Attrs: noinline uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_relaxed(ptr noundef %dst, i128 noundef %val) unnamed_addr #1 !dbg !535 !guid !536 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_5.i = ptrtoint ptr %dst to i64, !dbg !537
  %_4.i = and i64 %_5.i, 15, !dbg !537
  %0 = icmp eq i64 %_4.i, 0, !dbg !537
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !537, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !539
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !541
  store i32 %1, ptr %info.i.i, align 4, !dbg !544
  %2 = icmp eq i32 %1, 0, !dbg !545
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !545, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !546, !alias.scope !548
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !551
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !552, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !553
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !556

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !557
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !558
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !559
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !559
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_store_stp.exit, !dbg !563, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9e98eff3184063ea6ad811293b560184) #8, !dbg !564
  unreachable, !dbg !564

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a4970165f4422c6d133b8ae28d684954) #8, !dbg !565
  unreachable, !dbg !565

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_store_stp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %val1.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !566
  %val1.sroa.4.0.extract.shift.i = lshr i128 %val, 64, !dbg !566
  %val1.sroa.4.0.extract.trunc.i = trunc nuw i128 %val1.sroa.4.0.extract.shift.i to i64, !dbg !566
  tail call void asm sideeffect "\0Astp ${1}, ${2}, [${0}]\0A", "r,r,r,~{memory}"(ptr %dst, i64 %val1.sroa.0.0.extract.trunc.i, i64 %val1.sroa.4.0.extract.trunc.i) #7, !dbg !567, !srcloc !569
  ret void, !dbg !570
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse2_release
; Function Attrs: noinline uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_release(ptr noundef %dst, i128 noundef %val) unnamed_addr #1 !dbg !571 !guid !572 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_5.i = ptrtoint ptr %dst to i64, !dbg !573
  %_4.i = and i64 %_5.i, 15, !dbg !573
  %0 = icmp eq i64 %_4.i, 0, !dbg !573
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !573, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !575
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !577
  store i32 %1, ptr %info.i.i, align 4, !dbg !580
  %2 = icmp eq i32 %1, 0, !dbg !581
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !581, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !582, !alias.scope !584
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !587
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !588, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !589
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !592

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !593
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !594
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !595
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !595
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_store_stp.exit, !dbg !599, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9e98eff3184063ea6ad811293b560184) #8, !dbg !600
  unreachable, !dbg !600

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a4970165f4422c6d133b8ae28d684954) #8, !dbg !601
  unreachable, !dbg !601

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_store_stp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %val2.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !602
  %val2.sroa.4.0.extract.shift.i = lshr i128 %val, 64, !dbg !602
  %val2.sroa.4.0.extract.trunc.i = trunc nuw i128 %val2.sroa.4.0.extract.shift.i to i64, !dbg !602
  tail call void asm sideeffect "dmb ish\0Astp ${1}, ${2}, [${0}]\0A", "r,r,r,~{memory}"(ptr %dst, i64 %val2.sroa.0.0.extract.trunc.i, i64 %val2.sroa.4.0.extract.trunc.i) #7, !dbg !603, !srcloc !605
  ret void, !dbg !606
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse128_seqcst
; Function Attrs: noinline uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store26atomic_store_lse128_seqcst(ptr noundef %dst, i128 noundef %val) unnamed_addr #1 !dbg !607 !guid !608 {
start:
  %info.i.i.i = alloca [4 x i8], align 4
  %_5.i.i = ptrtoint ptr %dst to i64, !dbg !609
  %_4.i.i = and i64 %_5.i.i, 15, !dbg !609
  %0 = icmp eq i64 %_4.i.i, 0, !dbg !609
  br i1 %0, label %bb1.i.i, label %bb2.i.i, !dbg !609, !prof !114

bb1.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i.i), !dbg !614
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !616
  store i32 %1, ptr %info.i.i.i, align 4, !dbg !619
  %2 = icmp eq i32 %1, 0, !dbg !620
  br i1 %2, label %bb3.i.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i, !dbg !620, !prof !131

bb3.i.i.i:                                        ; preds = %bb1.i.i
  store i32 1, ptr %info.i.i.i, align 4, !dbg !621, !alias.scope !623
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i.i), !dbg !626
  %_9.i.i.i = load i32, ptr %info.i.i.i, align 4, !dbg !627, !noundef !52
  store atomic i32 %_9.i.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !628
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i, !dbg !631

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i: ; preds = %bb1.i.i, %bb3.i.i.i
  %_0.sroa.0.0.i.i.i = phi i32 [ %_9.i.i.i, %bb3.i.i.i ], [ %1, %bb1.i.i ], !dbg !632
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i.i), !dbg !633
  %_3.i.i.i.i.i = and i32 %_0.sroa.0.0.i.i.i, 64, !dbg !634
  %_0.i.i.i.not.i.i = icmp eq i32 %_3.i.i.i.i.i, 0, !dbg !634
  br i1 %_0.i.i.i.not.i.i, label %bb6.i.i, label %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store18__atomic_store_swpp.exit, !dbg !639, !prof !131

bb2.i.i:                                          ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a463044e5da2c4c5c76c7b67250e5a64) #8, !dbg !640
  unreachable, !dbg !640

bb6.i.i:                                          ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_3dc46b42d6bdb2daf64cb0a467a82b62, i64 noundef 43, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_61e22541e076e5d89db40f3c8d30d89a) #8, !dbg !641
  unreachable, !dbg !641

_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store18__atomic_store_swpp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i
  %val1.sroa.0.0.extract.trunc.i.i = trunc i128 %val to i64, !dbg !642
  %val1.sroa.8.0.extract.shift.i.i = lshr i128 %val, 64, !dbg !642
  %val1.sroa.8.0.extract.trunc.i.i = trunc nuw i128 %val1.sroa.8.0.extract.shift.i.i to i64, !dbg !642
  %3 = tail call { i64, i64 } asm sideeffect ".arch_extension lse128\0Aswppal ${0}, ${1}, [${2}]\0A", "=&r,=&r,r,0,1,~{memory}"(ptr %dst, i64 %val1.sroa.0.0.extract.trunc.i.i, i64 %val1.sroa.8.0.extract.trunc.i.i) #7, !dbg !643, !srcloc !646
  ret void, !dbg !647
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse128_release
; Function Attrs: noinline uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_lse128_release(ptr noundef %dst, i128 noundef %val) unnamed_addr #1 !dbg !648 !guid !649 {
start:
  %info.i.i.i = alloca [4 x i8], align 4
  %_5.i.i = ptrtoint ptr %dst to i64, !dbg !650
  %_4.i.i = and i64 %_5.i.i, 15, !dbg !650
  %0 = icmp eq i64 %_4.i.i, 0, !dbg !650
  br i1 %0, label %bb1.i.i, label %bb2.i.i, !dbg !650, !prof !114

bb1.i.i:                                          ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i.i), !dbg !653
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !655
  store i32 %1, ptr %info.i.i.i, align 4, !dbg !658
  %2 = icmp eq i32 %1, 0, !dbg !659
  br i1 %2, label %bb3.i.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i, !dbg !659, !prof !131

bb3.i.i.i:                                        ; preds = %bb1.i.i
  store i32 1, ptr %info.i.i.i, align 4, !dbg !660, !alias.scope !662
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i.i), !dbg !665
  %_9.i.i.i = load i32, ptr %info.i.i.i, align 4, !dbg !666, !noundef !52
  store atomic i32 %_9.i.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !667
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i, !dbg !670

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i: ; preds = %bb1.i.i, %bb3.i.i.i
  %_0.sroa.0.0.i.i.i = phi i32 [ %_9.i.i.i, %bb3.i.i.i ], [ %1, %bb1.i.i ], !dbg !671
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i.i), !dbg !672
  %_3.i.i.i.i.i = and i32 %_0.sroa.0.0.i.i.i, 64, !dbg !673
  %_0.i.i.i.not.i.i = icmp eq i32 %_3.i.i.i.i.i, 0, !dbg !673
  br i1 %_0.i.i.i.not.i.i, label %bb6.i.i, label %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store18__atomic_store_swpp.exit, !dbg !677, !prof !131

bb2.i.i:                                          ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a463044e5da2c4c5c76c7b67250e5a64) #8, !dbg !678
  unreachable, !dbg !678

bb6.i.i:                                          ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_3dc46b42d6bdb2daf64cb0a467a82b62, i64 noundef 43, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_61e22541e076e5d89db40f3c8d30d89a) #8, !dbg !679
  unreachable, !dbg !679

_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store18__atomic_store_swpp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i.i
  %val1.sroa.0.0.extract.trunc.i.i = trunc i128 %val to i64, !dbg !680
  %val1.sroa.8.0.extract.shift.i.i = lshr i128 %val, 64, !dbg !680
  %val1.sroa.8.0.extract.trunc.i.i = trunc nuw i128 %val1.sroa.8.0.extract.shift.i.i to i64, !dbg !680
  %3 = tail call { i64, i64 } asm sideeffect ".arch_extension lse128\0Aswppl ${0}, ${1}, [${2}]\0A", "=&r,=&r,r,0,1,~{memory}"(ptr %dst, i64 %val1.sroa.0.0.extract.trunc.i.i, i64 %val1.sroa.8.0.extract.trunc.i.i) #7, !dbg !681, !srcloc !682
  ret void, !dbg !683
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_no_lse2_seqcst
; Function Attrs: uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_no_lse2_seqcst(ptr noundef %dst, i128 noundef %val) unnamed_addr #2 !dbg !684 !guid !685 {
start:
  %_5.i = ptrtoint ptr %dst to i64, !dbg !686
  %_4.i = and i64 %_5.i, 15, !dbg !686
  %0 = icmp eq i64 %_4.i, 0, !dbg !686
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423__atomic_store_ldxp_stxp.exit, label %bb2.i, !dbg !686, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_26281b586fc59a1b79384da8e2598487) #8, !dbg !689
  unreachable, !dbg !689

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423__atomic_store_ldxp_stxp.exit: ; preds = %start
  %val1.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !690
  %val1.sroa.8.0.extract.shift.i = lshr i128 %val, 64, !dbg !690
  %val1.sroa.8.0.extract.trunc.i = trunc nuw i128 %val1.sroa.8.0.extract.shift.i to i64, !dbg !690
  %1 = tail call i32 asm sideeffect "2:\0Aldaxp xzr, ${0}, [${1}]\0Astlxp ${0:w}, ${2}, ${3}, [${1}]\0Acbnz ${0:w}, 2b\0A", "=&r,r,r,r,~{memory}"(ptr %dst, i64 %val1.sroa.0.0.extract.trunc.i, i64 %val1.sroa.8.0.extract.trunc.i) #7, !dbg !691, !srcloc !693
  ret void, !dbg !694
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_no_lse2_relaxed
; Function Attrs: uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed(ptr noundef %dst, i128 noundef %val) unnamed_addr #2 !dbg !695 !guid !696 {
start:
  %_5.i = ptrtoint ptr %dst to i64, !dbg !697
  %_4.i = and i64 %_5.i, 15, !dbg !697
  %0 = icmp eq i64 %_4.i, 0, !dbg !697
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423__atomic_store_ldxp_stxp.exit, label %bb2.i, !dbg !697, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_26281b586fc59a1b79384da8e2598487) #8, !dbg !699
  unreachable, !dbg !699

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423__atomic_store_ldxp_stxp.exit: ; preds = %start
  %val1.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !700
  %val1.sroa.8.0.extract.shift.i = lshr i128 %val, 64, !dbg !700
  %val1.sroa.8.0.extract.trunc.i = trunc nuw i128 %val1.sroa.8.0.extract.shift.i to i64, !dbg !700
  %1 = tail call i32 asm sideeffect "2:\0Aldxp xzr, ${0}, [${1}]\0Astxp ${0:w}, ${2}, ${3}, [${1}]\0Acbnz ${0:w}, 2b\0A", "=&r,r,r,r,~{memory}"(ptr %dst, i64 %val1.sroa.0.0.extract.trunc.i, i64 %val1.sroa.8.0.extract.trunc.i) #7, !dbg !701, !srcloc !702
  ret void, !dbg !703
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_no_lse2_release
; Function Attrs: uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_release(ptr noundef %dst, i128 noundef %val) unnamed_addr #2 !dbg !704 !guid !705 {
start:
  %_5.i = ptrtoint ptr %dst to i64, !dbg !706
  %_4.i = and i64 %_5.i, 15, !dbg !706
  %0 = icmp eq i64 %_4.i, 0, !dbg !706
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423__atomic_store_ldxp_stxp.exit, label %bb2.i, !dbg !706, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_26281b586fc59a1b79384da8e2598487) #8, !dbg !708
  unreachable, !dbg !708

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423__atomic_store_ldxp_stxp.exit: ; preds = %start
  %val1.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !709
  %val1.sroa.8.0.extract.shift.i = lshr i128 %val, 64, !dbg !709
  %val1.sroa.8.0.extract.trunc.i = trunc nuw i128 %val1.sroa.8.0.extract.shift.i to i64, !dbg !709
  %1 = tail call i32 asm sideeffect "2:\0Aldxp xzr, ${0}, [${1}]\0Astlxp ${0:w}, ${2}, ${3}, [${1}]\0Acbnz ${0:w}, 2b\0A", "=&r,r,r,r,~{memory}"(ptr %dst, i64 %val1.sroa.0.0.extract.trunc.i, i64 %val1.sroa.8.0.extract.trunc.i) #7, !dbg !710, !srcloc !711
  ret void, !dbg !712
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse2_rcpc3_seqcst
; Function Attrs: noinline uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store30atomic_store_lse2_rcpc3_seqcst(ptr noundef %dst, i128 noundef %val) unnamed_addr #1 !dbg !713 !guid !714 {
start:
  %info.i3.i = alloca [4 x i8], align 4
  %info.i.i = alloca [4 x i8], align 4
  %_5.i = ptrtoint ptr %dst to i64, !dbg !715
  %_4.i = and i64 %_5.i, 15, !dbg !715
  %0 = icmp eq i64 %_4.i, 0, !dbg !715
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !715, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !718
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !720
  store i32 %1, ptr %info.i.i, align 4, !dbg !723
  %2 = icmp eq i32 %1, 0, !dbg !724
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !724, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !725, !alias.scope !727
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !730
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !731, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !732
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !735

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !736
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !737
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !738
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !738
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %bb5.i, !dbg !742, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_63df8b5fe7be207dd35364f9603b6e7f) #8, !dbg !743
  unreachable, !dbg !743

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4698564d0679a083e3d70623192bc582) #8, !dbg !744
  unreachable, !dbg !744

bb5.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i3.i), !dbg !745
  %3 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !747
  store i32 %3, ptr %info.i3.i, align 4, !dbg !750
  %4 = icmp eq i32 %3, 0, !dbg !751
  br i1 %4, label %bb3.i6.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i, !dbg !751, !prof !131

bb3.i6.i:                                         ; preds = %bb5.i
  store i32 1, ptr %info.i3.i, align 4, !dbg !752, !alias.scope !754
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i3.i), !dbg !757
  %_9.i7.i = load i32, ptr %info.i3.i, align 4, !dbg !758, !noundef !52
  store atomic i32 %_9.i7.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !759
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i, !dbg !762

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i: ; preds = %bb5.i, %bb3.i6.i
  %_0.sroa.0.0.i5.i = phi i32 [ %_9.i7.i, %bb3.i6.i ], [ %3, %bb5.i ], !dbg !763
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i3.i), !dbg !764
  %_3.i.i.i9.i = and i32 %_0.sroa.0.0.i5.i, 32, !dbg !765
  %_0.i.i.i10.not.i = icmp eq i32 %_3.i.i.i9.i, 0, !dbg !765
  br i1 %_0.i.i.i10.not.i, label %bb10.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_store_stilp.exit, !dbg !769, !prof !131

bb10.i:                                           ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_b00d604102ee496c8753f807e35d5ef5, i64 noundef 42, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_04b8e0899c86a564c6777f3d17a7854a) #8, !dbg !770
  unreachable, !dbg !770

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_store_stilp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i
  %val2.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !771
  %val2.sroa.4.0.extract.shift.i = lshr i128 %val, 64, !dbg !771
  %val2.sroa.4.0.extract.trunc.i = trunc nuw i128 %val2.sroa.4.0.extract.shift.i to i64, !dbg !771
  tail call void asm sideeffect ".arch_extension rcpc3\0Astilp ${1}, ${2}, [${0}]\0Admb ish", "r,r,r,~{memory}"(ptr %dst, i64 %val2.sroa.0.0.extract.trunc.i, i64 %val2.sroa.4.0.extract.trunc.i) #7, !dbg !772, !srcloc !774
  ret void, !dbg !775
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse2_rcpc3_release
; Function Attrs: noinline uwtable
define internal void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store31atomic_store_lse2_rcpc3_release(ptr noundef %dst, i128 noundef %val) unnamed_addr #1 !dbg !776 !guid !777 {
start:
  %info.i3.i = alloca [4 x i8], align 4
  %info.i.i = alloca [4 x i8], align 4
  %_5.i = ptrtoint ptr %dst to i64, !dbg !778
  %_4.i = and i64 %_5.i, 15, !dbg !778
  %0 = icmp eq i64 %_4.i, 0, !dbg !778
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !778, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !780
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !782
  store i32 %1, ptr %info.i.i, align 4, !dbg !785
  %2 = icmp eq i32 %1, 0, !dbg !786
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !786, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !787, !alias.scope !789
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !792
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !793, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !794
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !797

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !798
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !799
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 8, !dbg !800
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !800
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %bb5.i, !dbg !804, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_63df8b5fe7be207dd35364f9603b6e7f) #8, !dbg !805
  unreachable, !dbg !805

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_8340eaecd7a737fcfcdd0073e8956f2c, i64 noundef 41, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4698564d0679a083e3d70623192bc582) #8, !dbg !806
  unreachable, !dbg !806

bb5.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i3.i), !dbg !807
  %3 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !809
  store i32 %3, ptr %info.i3.i, align 4, !dbg !812
  %4 = icmp eq i32 %3, 0, !dbg !813
  br i1 %4, label %bb3.i6.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i, !dbg !813, !prof !131

bb3.i6.i:                                         ; preds = %bb5.i
  store i32 1, ptr %info.i3.i, align 4, !dbg !814, !alias.scope !816
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i3.i), !dbg !819
  %_9.i7.i = load i32, ptr %info.i3.i, align 4, !dbg !820, !noundef !52
  store atomic i32 %_9.i7.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !821
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i, !dbg !824

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i: ; preds = %bb5.i, %bb3.i6.i
  %_0.sroa.0.0.i5.i = phi i32 [ %_9.i7.i, %bb3.i6.i ], [ %3, %bb5.i ], !dbg !825
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i3.i), !dbg !826
  %_3.i.i.i9.i = and i32 %_0.sroa.0.0.i5.i, 32, !dbg !827
  %_0.i.i.i10.not.i = icmp eq i32 %_3.i.i.i9.i, 0, !dbg !827
  br i1 %_0.i.i.i10.not.i, label %bb10.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_store_stilp.exit, !dbg !831, !prof !131

bb10.i:                                           ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_b00d604102ee496c8753f807e35d5ef5, i64 noundef 42, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_04b8e0899c86a564c6777f3d17a7854a) #8, !dbg !832
  unreachable, !dbg !832

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_store_stilp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit8.i
  %val1.sroa.0.0.extract.trunc.i = trunc i128 %val to i64, !dbg !833
  %val1.sroa.4.0.extract.shift.i = lshr i128 %val, 64, !dbg !833
  %val1.sroa.4.0.extract.trunc.i = trunc nuw i128 %val1.sroa.4.0.extract.shift.i to i64, !dbg !833
  tail call void asm sideeffect ".arch_extension rcpc3\0Astilp ${1}, ${2}, [${0}]\0A", "r,r,r,~{memory}"(ptr %dst, i64 %val1.sroa.0.0.extract.trunc.i, i64 %val1.sroa.4.0.extract.trunc.i) #7, !dbg !834, !srcloc !836
  ret void, !dbg !837
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::init
; Function Attrs: cold uwtable
define void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store4init(ptr noundef %dst, i128 noundef %val) unnamed_addr #3 !dbg !838 !guid !839 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !840
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !843
  store i32 %0, ptr %info.i, align 4, !dbg !846
  %1 = icmp eq i32 %0, 0, !dbg !847
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !847, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !848, !alias.scope !850
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !853
  %_9.i = load i32, ptr %info.i, align 4, !dbg !854, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !855
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !858

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !859
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !860
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 8, !dbg !861
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !861
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_relaxed, !dbg !867
  store atomic ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store4FUNC monotonic, align 8, !dbg !868
; call portable_atomic::imp::atomic128::aarch64::atomic_store::atomic_store_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed
  tail call void %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed(ptr noundef %dst, i128 noundef %val), !dbg !872, !callees !873
  ret void, !dbg !874
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::init
; Function Attrs: cold uwtable
define void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores0_4init(ptr noundef %dst, i128 noundef %val) unnamed_addr #3 !dbg !875 !guid !876 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !877
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !880
  store i32 %0, ptr %info.i, align 4, !dbg !883
  %1 = icmp eq i32 %0, 0, !dbg !884
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !884, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !885, !alias.scope !887
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !890
  %_9.i = load i32, ptr %info.i, align 4, !dbg !891, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !892
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !895

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !896
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !897
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 8, !dbg !898
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !898
  br i1 %_0.i.i.i.not, label %bb13, label %bb3, !dbg !904

bb3:                                              ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit
  %_3.i.i.i1 = and i32 %_0.sroa.0.0.i, 64, !dbg !905
  %_0.i.i.i2.not = icmp eq i32 %_3.i.i.i1, 0, !dbg !905
  br i1 %_0.i.i.i2.not, label %bb6, label %bb13, !dbg !909

bb13:                                             ; preds = %bb3, %bb6, %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit
  %func.sroa.0.0 = phi ptr [ %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store30atomic_store_lse2_rcpc3_seqcst._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store24atomic_store_lse2_seqcst, %bb6 ], [ @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_no_lse2_seqcst, %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit ], [ @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store26atomic_store_lse128_seqcst, %bb3 ], !dbg !910
  store atomic ptr %func.sroa.0.0, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores0_4FUNC monotonic, align 8, !dbg !911
  tail call void %func.sroa.0.0(ptr noundef %dst, i128 noundef %val), !dbg !915, !callees !916
  ret void, !dbg !917

bb6:                                              ; preds = %bb3
  %_3.i.i.i3 = and i32 %_0.sroa.0.0.i, 32, !dbg !918
  %_0.i.i.i4.not = icmp eq i32 %_3.i.i.i3, 0, !dbg !918
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store30atomic_store_lse2_rcpc3_seqcst._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store24atomic_store_lse2_seqcst = select i1 %_0.i.i.i4.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store24atomic_store_lse2_seqcst, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store30atomic_store_lse2_rcpc3_seqcst, !dbg !922
  br label %bb13, !dbg !922
}

; portable_atomic::imp::atomic128::aarch64::atomic_store::init
; Function Attrs: cold uwtable
define void @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores_4init(ptr noundef %dst, i128 noundef %val) unnamed_addr #3 !dbg !923 !guid !924 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !925
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !928
  store i32 %0, ptr %info.i, align 4, !dbg !931
  %1 = icmp eq i32 %0, 0, !dbg !932
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !932, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !933, !alias.scope !935
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !938
  %_9.i = load i32, ptr %info.i, align 4, !dbg !939, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !940
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !943

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !944
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !945
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 8, !dbg !946
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !946
  br i1 %_0.i.i.i.not, label %bb13, label %bb3, !dbg !952

bb3:                                              ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit
  %_3.i.i.i1 = and i32 %_0.sroa.0.0.i, 32, !dbg !953
  %_0.i.i.i2.not = icmp eq i32 %_3.i.i.i1, 0, !dbg !953
  br i1 %_0.i.i.i2.not, label %bb6, label %bb13, !dbg !957

bb13:                                             ; preds = %bb3, %bb6, %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit
  %func.sroa.0.0 = phi ptr [ %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_lse128_release._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_release, %bb6 ], [ @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_release, %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit ], [ @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store31atomic_store_lse2_rcpc3_release, %bb3 ], !dbg !958
  store atomic ptr %func.sroa.0.0, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores_4FUNC monotonic, align 8, !dbg !959
  tail call void %func.sroa.0.0(ptr noundef %dst, i128 noundef %val), !dbg !963, !callees !964
  ret void, !dbg !965

bb6:                                              ; preds = %bb3
  %_3.i.i.i3 = and i32 %_0.sroa.0.0.i, 64, !dbg !966
  %_0.i.i.i4.not = icmp eq i32 %_3.i.i.i3, 0, !dbg !966
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_lse128_release._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_release = select i1 %_0.i.i.i4.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_release, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_lse128_release, !dbg !970
  br label %bb13, !dbg !970
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_acqrel
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange35atomic_compare_exchange_casp_acqrel(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #1 !dbg !971 !guid !973 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_7.i = ptrtoint ptr %dst to i64, !dbg !974
  %_6.i = and i64 %_7.i, 15, !dbg !974
  %0 = icmp eq i64 %_6.i, 0, !dbg !974
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !974, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !977
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !979
  store i32 %1, ptr %info.i.i, align 4, !dbg !982
  %2 = icmp eq i32 %1, 0, !dbg !983
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !983, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !984, !alias.scope !986
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !989
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !990, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !991
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !994

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !995
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !996
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 2, !dbg !997
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !997
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit, !dbg !1002, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_017e25b07b4da233217b000fa2c86620) #8, !dbg !1003
  unreachable, !dbg !1003

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6837de6f0f246ddf523dcfbb31c4fdb7, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f0a7c1e1a08c527f182e617e4babd556) #8, !dbg !1004
  unreachable, !dbg !1004

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1005
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1005
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1005
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1007
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1007
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1007
  %3 = tail call { i64, i64 } asm sideeffect ".arch_extension lse\0Acaspal x6, x7, x4, x5, [${2}]\0A", "=&{x6},=&{x7},r,0,1,{x4},{x5},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1009, !srcloc !1012
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64 } %3, 1, !dbg !1009
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64 } %3, 0, !dbg !1009
  %_38.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1013
  %_38.sroa.4.0.insert.shift.i = shl nuw i128 %_38.sroa.4.0.insert.ext.i, 64, !dbg !1013
  %_38.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1013
  %_38.sroa.0.0.insert.insert.i = or disjoint i128 %_38.sroa.4.0.insert.shift.i, %_38.sroa.0.0.insert.ext.i, !dbg !1013
  ret i128 %_38.sroa.0.0.insert.insert.i, !dbg !1014
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_acquire
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_acquire(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #1 !dbg !1015 !guid !1016 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_7.i = ptrtoint ptr %dst to i64, !dbg !1017
  %_6.i = and i64 %_7.i, 15, !dbg !1017
  %0 = icmp eq i64 %_6.i, 0, !dbg !1017
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !1017, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !1019
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1021
  store i32 %1, ptr %info.i.i, align 4, !dbg !1024
  %2 = icmp eq i32 %1, 0, !dbg !1025
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !1025, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !1026, !alias.scope !1028
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !1031
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !1032, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1033
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !1036

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !1037
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !1038
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 2, !dbg !1039
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !1039
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit, !dbg !1043, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_017e25b07b4da233217b000fa2c86620) #8, !dbg !1044
  unreachable, !dbg !1044

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6837de6f0f246ddf523dcfbb31c4fdb7, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f0a7c1e1a08c527f182e617e4babd556) #8, !dbg !1045
  unreachable, !dbg !1045

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1046
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1046
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1046
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1047
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1047
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1047
  %3 = tail call { i64, i64 } asm sideeffect ".arch_extension lse\0Acaspa x6, x7, x4, x5, [${2}]\0A", "=&{x6},=&{x7},r,0,1,{x4},{x5},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1048, !srcloc !1049
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64 } %3, 1, !dbg !1048
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64 } %3, 0, !dbg !1048
  %_38.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1050
  %_38.sroa.4.0.insert.shift.i = shl nuw i128 %_38.sroa.4.0.insert.ext.i, 64, !dbg !1050
  %_38.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1050
  %_38.sroa.0.0.insert.insert.i = or disjoint i128 %_38.sroa.4.0.insert.shift.i, %_38.sroa.0.0.insert.ext.i, !dbg !1050
  ret i128 %_38.sroa.0.0.insert.insert.i, !dbg !1051
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_relaxed
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_relaxed(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #1 !dbg !1052 !guid !1053 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_7.i = ptrtoint ptr %dst to i64, !dbg !1054
  %_6.i = and i64 %_7.i, 15, !dbg !1054
  %0 = icmp eq i64 %_6.i, 0, !dbg !1054
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !1054, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !1056
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1058
  store i32 %1, ptr %info.i.i, align 4, !dbg !1061
  %2 = icmp eq i32 %1, 0, !dbg !1062
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !1062, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !1063, !alias.scope !1065
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !1068
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !1069, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1070
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !1073

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !1074
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !1075
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 2, !dbg !1076
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !1076
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit, !dbg !1080, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_017e25b07b4da233217b000fa2c86620) #8, !dbg !1081
  unreachable, !dbg !1081

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6837de6f0f246ddf523dcfbb31c4fdb7, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f0a7c1e1a08c527f182e617e4babd556) #8, !dbg !1082
  unreachable, !dbg !1082

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1083
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1083
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1083
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1084
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1084
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1084
  %3 = tail call { i64, i64 } asm sideeffect ".arch_extension lse\0Acasp x6, x7, x4, x5, [${2}]\0A", "=&{x6},=&{x7},r,0,1,{x4},{x5},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1085, !srcloc !1086
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64 } %3, 1, !dbg !1085
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64 } %3, 0, !dbg !1085
  %_38.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1087
  %_38.sroa.4.0.insert.shift.i = shl nuw i128 %_38.sroa.4.0.insert.ext.i, 64, !dbg !1087
  %_38.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1087
  %_38.sroa.0.0.insert.insert.i = or disjoint i128 %_38.sroa.4.0.insert.shift.i, %_38.sroa.0.0.insert.ext.i, !dbg !1087
  ret i128 %_38.sroa.0.0.insert.insert.i, !dbg !1088
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_release
; Function Attrs: noinline uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_release(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #1 !dbg !1089 !guid !1090 {
start:
  %info.i.i = alloca [4 x i8], align 4
  %_7.i = ptrtoint ptr %dst to i64, !dbg !1091
  %_6.i = and i64 %_7.i, 15, !dbg !1091
  %0 = icmp eq i64 %_6.i, 0, !dbg !1091
  br i1 %0, label %bb1.i, label %bb2.i, !dbg !1091, !prof !114

bb1.i:                                            ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i.i), !dbg !1093
  %1 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1095
  store i32 %1, ptr %info.i.i, align 4, !dbg !1098
  %2 = icmp eq i32 %1, 0, !dbg !1099
  br i1 %2, label %bb3.i.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !1099, !prof !131

bb3.i.i:                                          ; preds = %bb1.i
  store i32 1, ptr %info.i.i, align 4, !dbg !1100, !alias.scope !1102
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i.i), !dbg !1105
  %_9.i.i = load i32, ptr %info.i.i, align 4, !dbg !1106, !noundef !52
  store atomic i32 %_9.i.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1107
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i, !dbg !1110

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i: ; preds = %bb1.i, %bb3.i.i
  %_0.sroa.0.0.i.i = phi i32 [ %_9.i.i, %bb3.i.i ], [ %1, %bb1.i ], !dbg !1111
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i.i), !dbg !1112
  %_3.i.i.i.i = and i32 %_0.sroa.0.0.i.i, 2, !dbg !1113
  %_0.i.i.i.not.i = icmp eq i32 %_3.i.i.i.i, 0, !dbg !1113
  br i1 %_0.i.i.i.not.i, label %bb6.i, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit, !dbg !1117, !prof !131

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_017e25b07b4da233217b000fa2c86620) #8, !dbg !1118
  unreachable, !dbg !1118

bb6.i:                                            ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6837de6f0f246ddf523dcfbb31c4fdb7, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f0a7c1e1a08c527f182e617e4babd556) #8, !dbg !1119
  unreachable, !dbg !1119

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp.exit: ; preds = %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit.i
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1120
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1120
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1120
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1121
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1121
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1121
  %3 = tail call { i64, i64 } asm sideeffect ".arch_extension lse\0Acaspl x6, x7, x4, x5, [${2}]\0A", "=&{x6},=&{x7},r,0,1,{x4},{x5},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1122, !srcloc !1123
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64 } %3, 1, !dbg !1122
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64 } %3, 0, !dbg !1122
  %_38.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1124
  %_38.sroa.4.0.insert.shift.i = shl nuw i128 %_38.sroa.4.0.insert.ext.i, 64, !dbg !1124
  %_38.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1124
  %_38.sroa.0.0.insert.insert.i = or disjoint i128 %_38.sroa.4.0.insert.shift.i, %_38.sroa.0.0.insert.ext.i, !dbg !1124
  ret i128 %_38.sroa.0.0.insert.insert.i, !dbg !1125
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_ldxp_stxp_acqrel
; Function Attrs: uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #2 !dbg !1126 !guid !1127 {
start:
  %_7.i = ptrtoint ptr %dst to i64, !dbg !1128
  %_6.i = and i64 %_7.i, 15, !dbg !1128
  %0 = icmp eq i64 %_6.i, 0, !dbg !1128
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit, label %bb2.i, !dbg !1128, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b38806655b417e8425a659de094e8348) #8, !dbg !1131
  unreachable, !dbg !1131

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit: ; preds = %start
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1132
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1132
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1132
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1134
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1134
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1134
  %1 = tail call { i64, i64, i32 } asm sideeffect "2:\0Aldaxp ${0}, ${1}, [${3}]\0Acmp ${0}, ${4}\0Acset ${2:w}, ne\0Acmp ${1}, ${5}\0Acinc ${2:w}, ${2:w}, ne\0Acbz ${2:w}, 3f\0Astlxp ${2:w}, ${0}, ${1}, [${3}]\0Acbnz ${2:w}, 2b\0Ab 4f\0A3:\0Astlxp ${2:w}, ${6}, ${7}, [${3}]\0Acbnz ${2:w}, 2b\0A4:\0A", "=&r,=&r,=&r,r,r,r,r,r,~{cc},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1136, !srcloc !1139
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 1, !dbg !1136
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 0, !dbg !1136
  %_35.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1140
  %_35.sroa.4.0.insert.shift.i = shl nuw i128 %_35.sroa.4.0.insert.ext.i, 64, !dbg !1140
  %_35.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1140
  %_35.sroa.0.0.insert.insert.i = or disjoint i128 %_35.sroa.4.0.insert.shift.i, %_35.sroa.0.0.insert.ext.i, !dbg !1140
  ret i128 %_35.sroa.0.0.insert.insert.i, !dbg !1141
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_ldxp_stxp_acquire
; Function Attrs: uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #2 !dbg !1142 !guid !1143 {
start:
  %_7.i = ptrtoint ptr %dst to i64, !dbg !1144
  %_6.i = and i64 %_7.i, 15, !dbg !1144
  %0 = icmp eq i64 %_6.i, 0, !dbg !1144
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit, label %bb2.i, !dbg !1144, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b38806655b417e8425a659de094e8348) #8, !dbg !1146
  unreachable, !dbg !1146

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit: ; preds = %start
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1147
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1147
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1147
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1148
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1148
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1148
  %1 = tail call { i64, i64, i32 } asm sideeffect "2:\0Aldaxp ${0}, ${1}, [${3}]\0Acmp ${0}, ${4}\0Acset ${2:w}, ne\0Acmp ${1}, ${5}\0Acinc ${2:w}, ${2:w}, ne\0Acbz ${2:w}, 3f\0Astxp ${2:w}, ${0}, ${1}, [${3}]\0Acbnz ${2:w}, 2b\0Ab 4f\0A3:\0Astxp ${2:w}, ${6}, ${7}, [${3}]\0Acbnz ${2:w}, 2b\0A4:\0A", "=&r,=&r,=&r,r,r,r,r,r,~{cc},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1149, !srcloc !1150
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 1, !dbg !1149
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 0, !dbg !1149
  %_35.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1151
  %_35.sroa.4.0.insert.shift.i = shl nuw i128 %_35.sroa.4.0.insert.ext.i, 64, !dbg !1151
  %_35.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1151
  %_35.sroa.0.0.insert.insert.i = or disjoint i128 %_35.sroa.4.0.insert.shift.i, %_35.sroa.0.0.insert.ext.i, !dbg !1151
  ret i128 %_35.sroa.0.0.insert.insert.i, !dbg !1152
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_ldxp_stxp_relaxed
; Function Attrs: uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #2 !dbg !1153 !guid !1154 {
start:
  %_7.i = ptrtoint ptr %dst to i64, !dbg !1155
  %_6.i = and i64 %_7.i, 15, !dbg !1155
  %0 = icmp eq i64 %_6.i, 0, !dbg !1155
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit, label %bb2.i, !dbg !1155, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b38806655b417e8425a659de094e8348) #8, !dbg !1157
  unreachable, !dbg !1157

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit: ; preds = %start
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1158
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1158
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1158
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1159
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1159
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1159
  %1 = tail call { i64, i64, i32 } asm sideeffect "2:\0Aldxp ${0}, ${1}, [${3}]\0Acmp ${0}, ${4}\0Acset ${2:w}, ne\0Acmp ${1}, ${5}\0Acinc ${2:w}, ${2:w}, ne\0Acbz ${2:w}, 3f\0Astxp ${2:w}, ${0}, ${1}, [${3}]\0Acbnz ${2:w}, 2b\0Ab 4f\0A3:\0Astxp ${2:w}, ${6}, ${7}, [${3}]\0Acbnz ${2:w}, 2b\0A4:\0A", "=&r,=&r,=&r,r,r,r,r,r,~{cc},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1160, !srcloc !1161
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 1, !dbg !1160
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 0, !dbg !1160
  %_35.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1162
  %_35.sroa.4.0.insert.shift.i = shl nuw i128 %_35.sroa.4.0.insert.ext.i, 64, !dbg !1162
  %_35.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1162
  %_35.sroa.0.0.insert.insert.i = or disjoint i128 %_35.sroa.4.0.insert.shift.i, %_35.sroa.0.0.insert.ext.i, !dbg !1162
  ret i128 %_35.sroa.0.0.insert.insert.i, !dbg !1163
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_ldxp_stxp_release
; Function Attrs: uwtable
define internal noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #2 !dbg !1164 !guid !1165 {
start:
  %_7.i = ptrtoint ptr %dst to i64, !dbg !1166
  %_6.i = and i64 %_7.i, 15, !dbg !1166
  %0 = icmp eq i64 %_6.i, 0, !dbg !1166
  br i1 %0, label %_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit, label %bb2.i, !dbg !1166, !prof !114

bb2.i:                                            ; preds = %start
; call core::panicking::panic
  tail call void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_6c27a2b2ff3421ba7cd30da1ef1877fa, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b38806655b417e8425a659de094e8348) #8, !dbg !1168
  unreachable, !dbg !1168

_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp.exit: ; preds = %start
  %old1.sroa.0.0.extract.trunc.i = trunc i128 %old to i64, !dbg !1169
  %old1.sroa.8.0.extract.shift.i = lshr i128 %old, 64, !dbg !1169
  %old1.sroa.8.0.extract.trunc.i = trunc nuw i128 %old1.sroa.8.0.extract.shift.i to i64, !dbg !1169
  %new2.sroa.0.0.extract.trunc.i = trunc i128 %new to i64, !dbg !1170
  %new2.sroa.8.0.extract.shift.i = lshr i128 %new, 64, !dbg !1170
  %new2.sroa.8.0.extract.trunc.i = trunc nuw i128 %new2.sroa.8.0.extract.shift.i to i64, !dbg !1170
  %1 = tail call { i64, i64, i32 } asm sideeffect "2:\0Aldxp ${0}, ${1}, [${3}]\0Acmp ${0}, ${4}\0Acset ${2:w}, ne\0Acmp ${1}, ${5}\0Acinc ${2:w}, ${2:w}, ne\0Acbz ${2:w}, 3f\0Astlxp ${2:w}, ${0}, ${1}, [${3}]\0Acbnz ${2:w}, 2b\0Ab 4f\0A3:\0Astlxp ${2:w}, ${6}, ${7}, [${3}]\0Acbnz ${2:w}, 2b\0A4:\0A", "=&r,=&r,=&r,r,r,r,r,r,~{cc},~{memory}"(ptr %dst, i64 %old1.sroa.0.0.extract.trunc.i, i64 %old1.sroa.8.0.extract.trunc.i, i64 %new2.sroa.0.0.extract.trunc.i, i64 %new2.sroa.8.0.extract.trunc.i) #7, !dbg !1171, !srcloc !1172
  %prev_hi.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 1, !dbg !1171
  %prev_lo.sroa.0.0.i = extractvalue { i64, i64, i32 } %1, 0, !dbg !1171
  %_35.sroa.4.0.insert.ext.i = zext i64 %prev_hi.sroa.0.0.i to i128, !dbg !1173
  %_35.sroa.4.0.insert.shift.i = shl nuw i128 %_35.sroa.4.0.insert.ext.i, 64, !dbg !1173
  %_35.sroa.0.0.insert.ext.i = zext i64 %prev_lo.sroa.0.0.i to i128, !dbg !1173
  %_35.sroa.0.0.insert.insert.i = or disjoint i128 %_35.sroa.4.0.insert.shift.i, %_35.sroa.0.0.insert.ext.i, !dbg !1173
  ret i128 %_35.sroa.0.0.insert.insert.i, !dbg !1174
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::init
; Function Attrs: cold uwtable
define noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange4init(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #3 !dbg !1175 !guid !1176 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !1177
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1180
  store i32 %0, ptr %info.i, align 4, !dbg !1183
  %1 = icmp eq i32 %0, 0, !dbg !1184
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1184, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !1185, !alias.scope !1187
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !1190
  %_9.i = load i32, ptr %info.i, align 4, !dbg !1191, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1192
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1195

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !1196
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !1197
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 2, !dbg !1198
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !1198
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_relaxed, !dbg !1202
  store atomic ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange4FUNC monotonic, align 8, !dbg !1203
; call portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed
  %_0 = tail call noundef i128 %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_relaxed._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed(ptr noundef %dst, i128 noundef %old, i128 noundef %new), !dbg !1207, !callees !1208
  ret i128 %_0, !dbg !1209
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::init
; Function Attrs: cold uwtable
define noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges0_4init(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #3 !dbg !1210 !guid !1211 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !1212
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1215
  store i32 %0, ptr %info.i, align 4, !dbg !1218
  %1 = icmp eq i32 %0, 0, !dbg !1219
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1219, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !1220, !alias.scope !1222
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !1225
  %_9.i = load i32, ptr %info.i, align 4, !dbg !1226, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1227
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1230

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !1231
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !1232
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 2, !dbg !1233
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !1233
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_release._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_release, !dbg !1237
  store atomic ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_release._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges0_4FUNC monotonic, align 8, !dbg !1238
; call portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_release._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release
  %_0 = tail call noundef i128 %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_release._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release(ptr noundef %dst, i128 noundef %old, i128 noundef %new), !dbg !1242, !callees !1243
  ret i128 %_0, !dbg !1244
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::init
; Function Attrs: cold uwtable
define noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges1_4init(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #3 !dbg !1245 !guid !1246 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !1247
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1250
  store i32 %0, ptr %info.i, align 4, !dbg !1253
  %1 = icmp eq i32 %0, 0, !dbg !1254
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1254, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !1255, !alias.scope !1257
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !1260
  %_9.i = load i32, ptr %info.i, align 4, !dbg !1261, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1262
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1265

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !1266
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !1267
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 2, !dbg !1268
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !1268
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange35atomic_compare_exchange_casp_acqrel._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange35atomic_compare_exchange_casp_acqrel, !dbg !1272
  store atomic ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange35atomic_compare_exchange_casp_acqrel._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges1_4FUNC monotonic, align 8, !dbg !1273
; call portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_acqrel._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel
  %_0 = tail call noundef i128 %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange35atomic_compare_exchange_casp_acqrel._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel(ptr noundef %dst, i128 noundef %old, i128 noundef %new), !dbg !1277, !callees !1278
  ret i128 %_0, !dbg !1279
}

; portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::init
; Function Attrs: cold uwtable
define noundef i128 @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges_4init(ptr noundef %dst, i128 noundef %old, i128 noundef %new) unnamed_addr #3 !dbg !1280 !guid !1281 {
start:
  %info.i = alloca [4 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %info.i), !dbg !1282
  %0 = load atomic i32, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1285
  store i32 %0, ptr %info.i, align 4, !dbg !1288
  %1 = icmp eq i32 %0, 0, !dbg !1289
  br i1 %1, label %bb3.i, label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1289, !prof !131

bb3.i:                                            ; preds = %start
  store i32 1, ptr %info.i, align 4, !dbg !1290, !alias.scope !1292
; call portable_atomic::imp::atomic128::aarch64::detect::arch::_detect
  call fastcc void @_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect(ptr noalias nofree noundef align 4 dereferenceable(4) %info.i), !dbg !1295
  %_9.i = load i32, ptr %info.i, align 4, !dbg !1296, !noundef !52
  store atomic i32 %_9.i, ptr @_RNvNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect5CACHE.0 monotonic, align 4, !dbg !1297
  br label %_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit, !dbg !1300

_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect.exit: ; preds = %start, %bb3.i
  %_0.sroa.0.0.i = phi i32 [ %_9.i, %bb3.i ], [ %0, %start ], !dbg !1301
  call void @llvm.lifetime.end.p0(ptr nonnull %info.i), !dbg !1302
  %_3.i.i.i = and i32 %_0.sroa.0.0.i, 2, !dbg !1303
  %_0.i.i.i.not = icmp eq i32 %_3.i.i.i, 0, !dbg !1303
  %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_acquire._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire = select i1 %_0.i.i.i.not, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_acquire, !dbg !1307
  store atomic ptr %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_acquire._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges_4FUNC monotonic, align 8, !dbg !1308
; call portable_atomic::imp::atomic128::aarch64::atomic_compare_exchange::atomic_compare_exchange_casp_acquire._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire
  %_0 = tail call noundef i128 %_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_acquire._RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire(ptr noundef %dst, i128 noundef %old, i128 noundef %new), !dbg !1312, !callees !1313
  ret i128 %_0, !dbg !1314
}

; core::panicking::panic
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCs3gpSGQR8D0n_4core9panicking5panic(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #5

; Function Attrs: nounwind uwtable
declare noundef i64 @getauxval(i64 noundef) unnamed_addr #6

attributes #0 = { cold nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+outline-atomics" }
attributes #1 = { noinline uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+outline-atomics" }
attributes #2 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+outline-atomics" }
attributes #3 = { cold uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+outline-atomics" }
attributes #4 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+outline-atomics" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+outline-atomics" }
attributes #7 = { nounwind }
attributes #8 = { noinline noreturn }

!llvm.module.flags = !{!35, !36, !37, !38, !39}
!llvm.ident = !{!40}
!llvm.dbg.cu = !{!41}

!0 = !{i64 2132556820098530948}
!1 = !{i64 1480084104494128601}
!2 = !{i64 -2206213477496061499}
!3 = !{i64 -7810035103996988374}
!4 = !{i64 1593553139445274914}
!5 = !{i64 -5059853052556460211}
!6 = !{i64 2771010050811151043}
!7 = !{i64 -4460208654268425156}
!8 = !{i64 -4162506028266721391}
!9 = !{i64 -2289162336140596196}
!10 = !{i64 1527806331619623924}
!11 = !{i64 -575156290968473616}
!12 = !{i64 2141308398331439191}
!13 = !{i64 -3345721622703871459}
!14 = !{i64 4948836197871557297}
!15 = !{i64 4142191349026265848}
!16 = !{i64 8301641791698525860}
!17 = !{i64 -1958973346243755981}
!18 = !{i64 6182738853987810224}
!19 = !{i64 6898235193106848974}
!20 = !{i64 -6726316443405260027}
!21 = !{i64 -192532618943283959}
!22 = !{i64 -1392566202078962823}
!23 = !{i64 -6213245441175554089}
!24 = !{i64 -848166997012774249}
!25 = !{i64 -1823296821117791149}
!26 = !{i64 3556418614633865173}
!27 = !{i64 6871684466534341051}
!28 = !{i64 5186443760886301048}
!29 = !{i64 4704557526354149073}
!30 = !{i64 -3898706648866272882}
!31 = !{i64 -2237779698301172648}
!32 = !{i64 1768812174393000881}
!33 = !{i64 6397864587050123224}
!34 = !{i64 5706008209008586331}
!35 = !{i32 8, !"PIC Level", i32 2}
!36 = !{i32 7, !"uwtable", i32 2}
!37 = !{i32 7, !"frame-pointer", i32 1}
!38 = !{i32 7, !"Dwarf Version", i32 4}
!39 = !{i32 2, !"Debug Info Version", i32 3}
!40 = !{!"rustc version 1.99.0-dev"}
!41 = distinct !DICompileUnit(language: DW_LANG_Rust, file: !42, producer: "clang LLVM (rustc version 1.99.0-dev)", isOptimized: true, runtimeVersion: 0, emissionKind: LineTablesOnly, splitDebugInlining: false, nameTableKind: None)
!42 = !DIFile(filename: "/home/runner/work/_temp/gnu-ty-marker-census/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.13.1/src/lib.rs/@/portable_atomic.ef8bb306c3dda87a-cgu.0", directory: "/home/runner/work/_temp/gnu-ty-marker-census/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.13.1")
!43 = distinct !DISubprogram(name: "_detect", linkageName: "_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4arch7__detect", scope: !45, file: !44, line: 561, type: !51, scopeLine: 561, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!44 = !DIFile(filename: "src/imp/atomic128/../detect/auxv.rs", directory: "/home/runner/work/_temp/gnu-ty-marker-census/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.13.1", checksumkind: CSK_MD5, checksum: "04c35fb909d1ea9fe466040531aa30c3")
!45 = !DINamespace(name: "arch", scope: !46)
!46 = !DINamespace(name: "detect", scope: !47)
!47 = !DINamespace(name: "aarch64", scope: !48)
!48 = !DINamespace(name: "atomic128", scope: !49)
!49 = !DINamespace(name: "imp", scope: !50)
!50 = !DINamespace(name: "portable_atomic", scope: null)
!51 = !DISubroutineType(types: !52)
!52 = !{}
!53 = !{i64 -4781624231765991342}
!54 = !DILocation(line: 324, column: 18, scope: !55, inlinedAt: !58)
!55 = distinct !DILexicalBlock(scope: !56, file: !44, line: 307, column: 17)
!56 = distinct !DISubprogram(name: "getauxval", linkageName: "_RNvNtNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect2os9getauxval", scope: !57, file: !44, line: 286, type: !51, scopeLine: 286, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!57 = !DINamespace(name: "os", scope: !46)
!58 = distinct !DILocation(line: 590, column: 21, scope: !43)
!59 = !DILocation(line: 585, column: 20, scope: !60)
!60 = distinct !DILexicalBlock(scope: !43, file: !44, line: 590, column: 9)
!61 = !DILocation(line: 585, column: 25, scope: !60)
!62 = !DILocation(line: 10, column: 22, scope: !63, inlinedAt: !66)
!63 = distinct !DISubprogram(name: "set", linkageName: "_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set", scope: !65, file: !64, line: 9, type: !51, scopeLine: 9, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!64 = !DIFile(filename: "src/imp/atomic128/../detect/common.rs", directory: "/home/runner/work/_temp/gnu-ty-marker-census/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.13.1", checksumkind: CSK_MD5, checksum: "67c2b6a94e33e3cd5aef06e20f804d2f")
!65 = !DINamespace(name: "CpuInfo", scope: !46)
!66 = distinct !DILocation(line: 586, column: 26, scope: !60)
!67 = !{!68}
!68 = distinct !{!68, !69, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!69 = distinct !{!69, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!70 = !DILocation(line: 22, column: 5, scope: !71, inlinedAt: !72)
!71 = distinct !DISubprogram(name: "set", linkageName: "_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect3set", scope: !46, file: !64, line: 21, type: !51, scopeLine: 21, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!72 = distinct !DILocation(line: 10, column: 18, scope: !63, inlinedAt: !66)
!73 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !66)
!74 = !DILocation(line: 586, column: 26, scope: !60)
!75 = !DILocation(line: 10, column: 22, scope: !63, inlinedAt: !76)
!76 = distinct !DILocation(line: 586, column: 26, scope: !60)
!77 = !{!78}
!78 = distinct !{!78, !79, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!79 = distinct !{!79, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!80 = !DILocation(line: 22, column: 5, scope: !71, inlinedAt: !81)
!81 = distinct !DILocation(line: 10, column: 18, scope: !63, inlinedAt: !76)
!82 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !76)
!83 = !DILocation(line: 324, column: 18, scope: !55, inlinedAt: !84)
!84 = distinct !DILocation(line: 603, column: 26, scope: !60)
!85 = !DILocation(line: 585, column: 20, scope: !86)
!86 = distinct !DILexicalBlock(scope: !60, file: !44, line: 603, column: 13)
!87 = !DILocation(line: 585, column: 25, scope: !86)
!88 = !DILocation(line: 10, column: 22, scope: !63, inlinedAt: !89)
!89 = distinct !DILocation(line: 586, column: 26, scope: !86)
!90 = !{!91}
!91 = distinct !{!91, !92, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!92 = distinct !{!92, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!93 = !DILocation(line: 22, column: 5, scope: !71, inlinedAt: !94)
!94 = distinct !DILocation(line: 10, column: 18, scope: !63, inlinedAt: !89)
!95 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !89)
!96 = !DILocation(line: 586, column: 26, scope: !86)
!97 = !DILocation(line: 10, column: 22, scope: !63, inlinedAt: !98)
!98 = distinct !DILocation(line: 586, column: 26, scope: !86)
!99 = !{!100}
!100 = distinct !{!100, !101, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!101 = distinct !{!101, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!102 = !DILocation(line: 22, column: 5, scope: !71, inlinedAt: !103)
!103 = distinct !DILocation(line: 10, column: 18, scope: !63, inlinedAt: !98)
!104 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !98)
!105 = !DILocation(line: 613, column: 6, scope: !43)
!106 = distinct !DISubprogram(name: "atomic_load_lse2_seqcst", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load23atomic_load_lse2_seqcst", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!107 = !DIFile(filename: "src/utils.rs", directory: "/home/runner/work/_temp/gnu-ty-marker-census/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.13.1", checksumkind: CSK_MD5, checksum: "06253d496a33e085c4487ceac4de82f1")
!108 = !DINamespace(name: "atomic_load", scope: !47)
!109 = !{i64 -115803196020275535}
!110 = !DILocation(line: 630, column: 19, scope: !111, inlinedAt: !113)
!111 = distinct !DISubprogram(name: "_atomic_load_ldp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6416__atomic_load_ldp", scope: !47, file: !112, line: 629, type: !51, scopeLine: 629, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!112 = !DIFile(filename: "src/imp/atomic128/aarch64.rs", directory: "/home/runner/work/_temp/gnu-ty-marker-census/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/portable-atomic-1.13.1", checksumkind: CSK_MD5, checksum: "2f0da41e8cc62f740b4601bb3e492e0e")
!113 = distinct !DILocation(line: 103, column: 22, scope: !106)
!114 = !{!"branch_weights", !"expected", i32 2000, i32 1}
!115 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !117)
!116 = distinct !DISubprogram(name: "detect", linkageName: "_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect6detect", scope: !46, file: !64, line: 31, type: !51, scopeLine: 31, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!117 = distinct !DILocation(line: 240, column: 27, scope: !111, inlinedAt: !113)
!118 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !124)
!119 = distinct !DISubprogram(name: "atomic_load<u32>", linkageName: "_RINvNtNtCs3gpSGQR8D0n_4core4sync6atomic11atomic_loadmECskz5XzuL9Z1u_15portable_atomic", scope: !121, file: !120, line: 3990, type: !51, scopeLine: 3990, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!120 = !DIFile(filename: "library/core/src/sync/atomic.rs", directory: "/home/runner/work/_temp/ohm-aarch64-linux-zmij/rust", checksumkind: CSK_MD5, checksum: "51c6a96ef01c6a3d76d0125641245f4c")
!121 = !DINamespace(name: "atomic", scope: !122)
!122 = !DINamespace(name: "sync", scope: !123)
!123 = !DINamespace(name: "core", scope: null)
!124 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !127)
!125 = distinct !DISubprogram(name: "load", linkageName: "_RNvMsS_NtNtCs3gpSGQR8D0n_4core4sync6atomicINtB5_6AtomicmE4load", scope: !126, file: !120, line: 2914, type: !51, scopeLine: 2914, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!126 = !DINamespace(name: "Atomic", scope: !121)
!127 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !117)
!128 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !117)
!129 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !117)
!130 = distinct !DILexicalBlock(scope: !116, file: !64, line: 35, column: 5)
!131 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!132 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !133)
!133 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !117)
!134 = !{!135}
!135 = distinct !{!135, !136, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!136 = distinct !{!136, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!137 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !117)
!138 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !117)
!139 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !141)
!140 = distinct !DISubprogram(name: "atomic_store<u32>", linkageName: "_RINvNtNtCs3gpSGQR8D0n_4core4sync6atomic12atomic_storemECskz5XzuL9Z1u_15portable_atomic", scope: !121, file: !120, line: 3974, type: !51, scopeLine: 3974, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!141 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !143)
!142 = distinct !DISubprogram(name: "store", linkageName: "_RNvMsS_NtNtCs3gpSGQR8D0n_4core4sync6atomicINtB5_6AtomicmE5store", scope: !126, file: !120, line: 2944, type: !51, scopeLine: 2944, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!143 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !117)
!144 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !117)
!145 = !DILocation(line: 0, scope: !130, inlinedAt: !117)
!146 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !117)
!147 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !149)
!148 = distinct !DISubprogram(name: "test", linkageName: "_RNvNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detect4test", scope: !46, file: !64, line: 26, type: !51, scopeLine: 26, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!149 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !151)
!150 = distinct !DISubprogram(name: "test", linkageName: "_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo4test", scope: !65, file: !64, line: 14, type: !51, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!151 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !153)
!152 = distinct !DISubprogram(name: "lse2", linkageName: "_RNvMs2_NtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB5_7CpuInfo4lse2", scope: !65, file: !64, line: 68, type: !51, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!153 = distinct !DILocation(line: 240, column: 44, scope: !111, inlinedAt: !113)
!154 = !DILocation(line: 240, column: 27, scope: !111, inlinedAt: !113)
!155 = !DILocation(line: 630, column: 5, scope: !111, inlinedAt: !113)
!156 = !DILocation(line: 240, column: 13, scope: !111, inlinedAt: !113)
!157 = !DILocation(line: 664, column: 17, scope: !158, inlinedAt: !113)
!158 = distinct !DILexicalBlock(scope: !111, file: !112, line: 638, column: 9)
!159 = !{i64 1518760565761339, i64 1518996788962662, i64 1519138522883485}
!160 = !DILocation(line: 676, column: 17, scope: !158, inlinedAt: !113)
!161 = !DILocation(line: 104, column: 10, scope: !106)
!162 = distinct !DISubprogram(name: "atomic_load_lse2_acquire", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_acquire", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!163 = !{i64 -5544541150338603483}
!164 = !DILocation(line: 630, column: 19, scope: !111, inlinedAt: !165)
!165 = distinct !DILocation(line: 103, column: 22, scope: !162)
!166 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !167)
!167 = distinct !DILocation(line: 240, column: 27, scope: !111, inlinedAt: !165)
!168 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !169)
!169 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !170)
!170 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !167)
!171 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !167)
!172 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !167)
!173 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !174)
!174 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !167)
!175 = !{!176}
!176 = distinct !{!176, !177, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!177 = distinct !{!177, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!178 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !167)
!179 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !167)
!180 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !181)
!181 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !182)
!182 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !167)
!183 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !167)
!184 = !DILocation(line: 0, scope: !130, inlinedAt: !167)
!185 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !167)
!186 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !187)
!187 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !188)
!188 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !189)
!189 = distinct !DILocation(line: 240, column: 44, scope: !111, inlinedAt: !165)
!190 = !DILocation(line: 240, column: 27, scope: !111, inlinedAt: !165)
!191 = !DILocation(line: 630, column: 5, scope: !111, inlinedAt: !165)
!192 = !DILocation(line: 240, column: 13, scope: !111, inlinedAt: !165)
!193 = !DILocation(line: 641, column: 17, scope: !158, inlinedAt: !165)
!194 = !{i64 1513039669321723, i64 1517094118450113}
!195 = !DILocation(line: 649, column: 17, scope: !158, inlinedAt: !165)
!196 = !DILocation(line: 104, column: 10, scope: !162)
!197 = distinct !DISubprogram(name: "atomic_load_lse2_relaxed", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_relaxed", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!198 = !{i64 -8067217761105799713}
!199 = !DILocation(line: 630, column: 19, scope: !111, inlinedAt: !200)
!200 = distinct !DILocation(line: 103, column: 22, scope: !197)
!201 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !202)
!202 = distinct !DILocation(line: 240, column: 27, scope: !111, inlinedAt: !200)
!203 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !204)
!204 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !205)
!205 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !202)
!206 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !202)
!207 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !202)
!208 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !209)
!209 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !202)
!210 = !{!211}
!211 = distinct !{!211, !212, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!212 = distinct !{!212, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!213 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !202)
!214 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !202)
!215 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !216)
!216 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !217)
!217 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !202)
!218 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !202)
!219 = !DILocation(line: 0, scope: !130, inlinedAt: !202)
!220 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !202)
!221 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !222)
!222 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !223)
!223 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !224)
!224 = distinct !DILocation(line: 240, column: 44, scope: !111, inlinedAt: !200)
!225 = !DILocation(line: 240, column: 27, scope: !111, inlinedAt: !200)
!226 = !DILocation(line: 630, column: 5, scope: !111, inlinedAt: !200)
!227 = !DILocation(line: 240, column: 13, scope: !111, inlinedAt: !200)
!228 = !DILocation(line: 641, column: 17, scope: !158, inlinedAt: !200)
!229 = !{i64 1513039669321723, i64 1516385448846117}
!230 = !DILocation(line: 649, column: 17, scope: !158, inlinedAt: !200)
!231 = !DILocation(line: 104, column: 10, scope: !197)
!232 = distinct !DISubprogram(name: "atomic_load_no_lse2_seqcst", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load26atomic_load_no_lse2_seqcst", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!233 = !{i64 -8620397738054231290}
!234 = !DILocation(line: 808, column: 19, scope: !235, inlinedAt: !236)
!235 = distinct !DISubprogram(name: "_atomic_load_ldxp_stxp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6422__atomic_load_ldxp_stxp", scope: !47, file: !112, line: 807, type: !51, scopeLine: 807, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!236 = distinct !DILocation(line: 103, column: 22, scope: !232)
!237 = !DILocation(line: 808, column: 5, scope: !235, inlinedAt: !236)
!238 = !DILocation(line: 815, column: 17, scope: !239, inlinedAt: !236)
!239 = distinct !DILexicalBlock(scope: !235, file: !112, line: 812, column: 9)
!240 = !{i64 1544749412875503, i64 1545110190128396, i64 1545496737185119, i64 1546042198031888}
!241 = !DILocation(line: 837, column: 1, scope: !235, inlinedAt: !236)
!242 = !DILocation(line: 104, column: 10, scope: !232)
!243 = distinct !DISubprogram(name: "atomic_load_no_lse2_acquire", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_acquire", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!244 = !{i64 5849873689894153726}
!245 = !DILocation(line: 808, column: 19, scope: !235, inlinedAt: !246)
!246 = distinct !DILocation(line: 103, column: 22, scope: !243)
!247 = !DILocation(line: 808, column: 5, scope: !235, inlinedAt: !246)
!248 = !DILocation(line: 815, column: 17, scope: !239, inlinedAt: !246)
!249 = !DILocation(line: 837, column: 1, scope: !235, inlinedAt: !246)
!250 = !DILocation(line: 104, column: 10, scope: !243)
!251 = distinct !DISubprogram(name: "atomic_load_no_lse2_relaxed", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!252 = !{i64 -7925143952819027244}
!253 = !DILocation(line: 808, column: 19, scope: !235, inlinedAt: !254)
!254 = distinct !DILocation(line: 103, column: 22, scope: !251)
!255 = !DILocation(line: 808, column: 5, scope: !235, inlinedAt: !254)
!256 = !DILocation(line: 815, column: 17, scope: !239, inlinedAt: !254)
!257 = !DILocation(line: 837, column: 1, scope: !235, inlinedAt: !254)
!258 = !DILocation(line: 104, column: 10, scope: !251)
!259 = distinct !DISubprogram(name: "atomic_load_lse2_rcpc3_seqcst", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load29atomic_load_lse2_rcpc3_seqcst", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!260 = !{i64 -4017136212601361172}
!261 = !DILocation(line: 697, column: 19, scope: !262, inlinedAt: !263)
!262 = distinct !DISubprogram(name: "_atomic_load_ldiapp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_load_ldiapp", scope: !47, file: !112, line: 696, type: !51, scopeLine: 696, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!263 = distinct !DILocation(line: 103, column: 22, scope: !259)
!264 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !265)
!265 = distinct !DILocation(line: 240, column: 27, scope: !262, inlinedAt: !263)
!266 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !267)
!267 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !268)
!268 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !265)
!269 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !265)
!270 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !265)
!271 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !272)
!272 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !265)
!273 = !{!274}
!274 = distinct !{!274, !275, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!275 = distinct !{!275, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!276 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !265)
!277 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !265)
!278 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !279)
!279 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !280)
!280 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !265)
!281 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !265)
!282 = !DILocation(line: 0, scope: !130, inlinedAt: !265)
!283 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !265)
!284 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !285)
!285 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !286)
!286 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !287)
!287 = distinct !DILocation(line: 240, column: 44, scope: !262, inlinedAt: !263)
!288 = !DILocation(line: 240, column: 27, scope: !262, inlinedAt: !263)
!289 = !DILocation(line: 697, column: 5, scope: !262, inlinedAt: !263)
!290 = !DILocation(line: 240, column: 13, scope: !262, inlinedAt: !263)
!291 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !292)
!292 = distinct !DILocation(line: 326, column: 27, scope: !262, inlinedAt: !263)
!293 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !294)
!294 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !295)
!295 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !292)
!296 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !292)
!297 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !292)
!298 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !299)
!299 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !292)
!300 = !{!301}
!301 = distinct !{!301, !302, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!302 = distinct !{!302, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!303 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !292)
!304 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !292)
!305 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !306)
!306 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !307)
!307 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !292)
!308 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !292)
!309 = !DILocation(line: 0, scope: !130, inlinedAt: !292)
!310 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !292)
!311 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !312)
!312 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !313)
!313 = distinct !DILocation(line: 69, column: 26, scope: !314, inlinedAt: !315)
!314 = distinct !DISubprogram(name: "rcpc3", linkageName: "_RNvMs2_NtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB5_7CpuInfo5rcpc3", scope: !65, file: !64, line: 68, type: !51, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!315 = distinct !DILocation(line: 326, column: 44, scope: !262, inlinedAt: !263)
!316 = !DILocation(line: 326, column: 27, scope: !262, inlinedAt: !263)
!317 = !DILocation(line: 326, column: 13, scope: !262, inlinedAt: !263)
!318 = !DILocation(line: 732, column: 17, scope: !319, inlinedAt: !263)
!319 = distinct !DILexicalBlock(scope: !262, file: !112, line: 706, column: 9)
!320 = !{i64 1529764271976258, i64 1530764999356454, i64 1531014107459665}
!321 = !DILocation(line: 764, column: 1, scope: !262, inlinedAt: !263)
!322 = !DILocation(line: 104, column: 10, scope: !259)
!323 = distinct !DISubprogram(name: "atomic_load_lse2_rcpc3_acquire", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load30atomic_load_lse2_rcpc3_acquire", scope: !108, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!324 = !{i64 4670804623515020969}
!325 = !DILocation(line: 697, column: 19, scope: !262, inlinedAt: !326)
!326 = distinct !DILocation(line: 103, column: 22, scope: !323)
!327 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !328)
!328 = distinct !DILocation(line: 240, column: 27, scope: !262, inlinedAt: !326)
!329 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !330)
!330 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !331)
!331 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !328)
!332 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !328)
!333 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !328)
!334 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !335)
!335 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !328)
!336 = !{!337}
!337 = distinct !{!337, !338, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!338 = distinct !{!338, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!339 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !328)
!340 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !328)
!341 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !342)
!342 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !343)
!343 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !328)
!344 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !328)
!345 = !DILocation(line: 0, scope: !130, inlinedAt: !328)
!346 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !328)
!347 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !348)
!348 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !349)
!349 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !350)
!350 = distinct !DILocation(line: 240, column: 44, scope: !262, inlinedAt: !326)
!351 = !DILocation(line: 240, column: 27, scope: !262, inlinedAt: !326)
!352 = !DILocation(line: 697, column: 5, scope: !262, inlinedAt: !326)
!353 = !DILocation(line: 240, column: 13, scope: !262, inlinedAt: !326)
!354 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !355)
!355 = distinct !DILocation(line: 326, column: 27, scope: !262, inlinedAt: !326)
!356 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !357)
!357 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !358)
!358 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !355)
!359 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !355)
!360 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !355)
!361 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !362)
!362 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !355)
!363 = !{!364}
!364 = distinct !{!364, !365, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!365 = distinct !{!365, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!366 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !355)
!367 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !355)
!368 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !369)
!369 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !370)
!370 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !355)
!371 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !355)
!372 = !DILocation(line: 0, scope: !130, inlinedAt: !355)
!373 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !355)
!374 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !375)
!375 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !376)
!376 = distinct !DILocation(line: 69, column: 26, scope: !314, inlinedAt: !377)
!377 = distinct !DILocation(line: 326, column: 44, scope: !262, inlinedAt: !326)
!378 = !DILocation(line: 326, column: 27, scope: !262, inlinedAt: !326)
!379 = !DILocation(line: 326, column: 13, scope: !262, inlinedAt: !326)
!380 = !DILocation(line: 710, column: 17, scope: !319, inlinedAt: !326)
!381 = !{i64 1525409175137100, i64 1525653988273009}
!382 = !DILocation(line: 764, column: 1, scope: !262, inlinedAt: !326)
!383 = !DILocation(line: 104, column: 10, scope: !323)
!384 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load4init", scope: !108, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!385 = !{i64 7806401800900586408}
!386 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !387)
!387 = distinct !DILocation(line: 551, column: 43, scope: !388)
!388 = !DILexicalBlockFile(scope: !384, file: !112, discriminator: 0)
!389 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !390)
!390 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !391)
!391 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !387)
!392 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !387)
!393 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !387)
!394 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !395)
!395 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !387)
!396 = !{!397}
!397 = distinct !{!397, !398, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!398 = distinct !{!398, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!399 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !387)
!400 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !387)
!401 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !402)
!402 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !403)
!403 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !387)
!404 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !387)
!405 = !DILocation(line: 0, scope: !130, inlinedAt: !387)
!406 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !387)
!407 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !408)
!408 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !409)
!409 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !410)
!410 = distinct !DILocation(line: 552, column: 40, scope: !411)
!411 = !DILexicalBlockFile(scope: !412, file: !112, discriminator: 0)
!412 = distinct !DILexicalBlock(scope: !384, file: !107, line: 62, column: 30)
!413 = !DILocation(line: 552, column: 29, scope: !411)
!414 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !416)
!415 = distinct !DISubprogram(name: "atomic_store<*mut ()>", linkageName: "_RINvNtNtCs3gpSGQR8D0n_4core4sync6atomic12atomic_storeOuECskz5XzuL9Z1u_15portable_atomic", scope: !121, file: !120, line: 3974, type: !51, scopeLine: 3974, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!416 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !418)
!417 = distinct !DISubprogram(name: "store<()>", linkageName: "_RNvMs3_NtNtCs3gpSGQR8D0n_4core4sync6atomicINtB5_6AtomicOuE5storeCskz5XzuL9Z1u_15portable_atomic", scope: !126, file: !120, line: 1794, type: !51, scopeLine: 1794, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!418 = distinct !DILocation(line: 63, column: 18, scope: !419)
!419 = distinct !DILexicalBlock(scope: !384, file: !107, line: 62, column: 13)
!420 = !DILocation(line: 65, column: 22, scope: !419)
!421 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_relaxed}
!422 = !DILocation(line: 66, column: 10, scope: !384)
!423 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads0_4init", scope: !108, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!424 = !{i64 8775810602120231626}
!425 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !426)
!426 = distinct !DILocation(line: 580, column: 43, scope: !427)
!427 = !DILexicalBlockFile(scope: !423, file: !112, discriminator: 0)
!428 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !429)
!429 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !430)
!430 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !426)
!431 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !426)
!432 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !426)
!433 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !434)
!434 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !426)
!435 = !{!436}
!436 = distinct !{!436, !437, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!437 = distinct !{!437, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!438 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !426)
!439 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !426)
!440 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !441)
!441 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !442)
!442 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !426)
!443 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !426)
!444 = !DILocation(line: 0, scope: !130, inlinedAt: !426)
!445 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !426)
!446 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !447)
!447 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !448)
!448 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !449)
!449 = distinct !DILocation(line: 581, column: 40, scope: !450)
!450 = !DILexicalBlockFile(scope: !451, file: !112, discriminator: 0)
!451 = distinct !DILexicalBlock(scope: !423, file: !107, line: 62, column: 30)
!452 = !DILocation(line: 581, column: 32, scope: !450)
!453 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !454)
!454 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !455)
!455 = distinct !DILocation(line: 63, column: 18, scope: !456)
!456 = distinct !DILexicalBlock(scope: !423, file: !107, line: 62, column: 13)
!457 = !DILocation(line: 65, column: 22, scope: !456)
!458 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load23atomic_load_lse2_seqcst, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load26atomic_load_no_lse2_seqcst, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load29atomic_load_lse2_rcpc3_seqcst}
!459 = !DILocation(line: 66, column: 10, scope: !423)
!460 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_loads_4init", scope: !108, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!461 = !{i64 -900432717922949583}
!462 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !463)
!463 = distinct !DILocation(line: 563, column: 43, scope: !464)
!464 = !DILexicalBlockFile(scope: !460, file: !112, discriminator: 0)
!465 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !466)
!466 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !467)
!467 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !463)
!468 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !463)
!469 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !463)
!470 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !471)
!471 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !463)
!472 = !{!473}
!473 = distinct !{!473, !474, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!474 = distinct !{!474, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!475 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !463)
!476 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !463)
!477 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !478)
!478 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !479)
!479 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !463)
!480 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !463)
!481 = !DILocation(line: 0, scope: !130, inlinedAt: !463)
!482 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !463)
!483 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !484)
!484 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !485)
!485 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !486)
!486 = distinct !DILocation(line: 564, column: 40, scope: !487)
!487 = !DILexicalBlockFile(scope: !488, file: !112, discriminator: 0)
!488 = distinct !DILexicalBlock(scope: !460, file: !107, line: 62, column: 30)
!489 = !DILocation(line: 564, column: 32, scope: !487)
!490 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !491)
!491 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !492)
!492 = distinct !DILocation(line: 63, column: 18, scope: !493)
!493 = distinct !DILexicalBlock(scope: !460, file: !107, line: 62, column: 13)
!494 = !DILocation(line: 65, column: 22, scope: !493)
!495 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load24atomic_load_lse2_acquire, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load27atomic_load_no_lse2_acquire, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6411atomic_load30atomic_load_lse2_rcpc3_acquire}
!496 = !DILocation(line: 66, column: 10, scope: !460)
!497 = distinct !DISubprogram(name: "atomic_store_lse2_seqcst", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store24atomic_store_lse2_seqcst", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!498 = !DINamespace(name: "atomic_store", scope: !47)
!499 = !{i64 4484074050844615556}
!500 = !DILocation(line: 1043, column: 19, scope: !501, inlinedAt: !502)
!501 = distinct !DISubprogram(name: "_atomic_store_stp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_store_stp", scope: !47, file: !112, line: 1042, type: !51, scopeLine: 1042, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!502 = distinct !DILocation(line: 103, column: 22, scope: !497)
!503 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !504)
!504 = distinct !DILocation(line: 240, column: 27, scope: !501, inlinedAt: !502)
!505 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !506)
!506 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !507)
!507 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !504)
!508 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !504)
!509 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !504)
!510 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !511)
!511 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !504)
!512 = !{!513}
!513 = distinct !{!513, !514, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!514 = distinct !{!514, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!515 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !504)
!516 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !504)
!517 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !518)
!518 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !519)
!519 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !504)
!520 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !504)
!521 = !DILocation(line: 0, scope: !130, inlinedAt: !504)
!522 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !504)
!523 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !524)
!524 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !525)
!525 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !526)
!526 = distinct !DILocation(line: 240, column: 44, scope: !501, inlinedAt: !502)
!527 = !DILocation(line: 240, column: 27, scope: !501, inlinedAt: !502)
!528 = !DILocation(line: 1043, column: 5, scope: !501, inlinedAt: !502)
!529 = !DILocation(line: 240, column: 13, scope: !501, inlinedAt: !502)
!530 = !DILocation(line: 1053, column: 27, scope: !501, inlinedAt: !502)
!531 = !DILocation(line: 1054, column: 17, scope: !532, inlinedAt: !502)
!532 = distinct !DILexicalBlock(scope: !501, file: !112, line: 1053, column: 17)
!533 = !{i64 1601009189498901, i64 1590615368640137, i64 1600961944858634}
!534 = !DILocation(line: 104, column: 10, scope: !497)
!535 = distinct !DISubprogram(name: "atomic_store_lse2_relaxed", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_relaxed", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!536 = !{i64 2622664877976406750}
!537 = !DILocation(line: 1043, column: 19, scope: !501, inlinedAt: !538)
!538 = distinct !DILocation(line: 103, column: 22, scope: !535)
!539 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !540)
!540 = distinct !DILocation(line: 240, column: 27, scope: !501, inlinedAt: !538)
!541 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !542)
!542 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !543)
!543 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !540)
!544 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !540)
!545 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !540)
!546 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !547)
!547 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !540)
!548 = !{!549}
!549 = distinct !{!549, !550, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!550 = distinct !{!550, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!551 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !540)
!552 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !540)
!553 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !554)
!554 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !555)
!555 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !540)
!556 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !540)
!557 = !DILocation(line: 0, scope: !130, inlinedAt: !540)
!558 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !540)
!559 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !560)
!560 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !561)
!561 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !562)
!562 = distinct !DILocation(line: 240, column: 44, scope: !501, inlinedAt: !538)
!563 = !DILocation(line: 240, column: 27, scope: !501, inlinedAt: !538)
!564 = !DILocation(line: 1043, column: 5, scope: !501, inlinedAt: !538)
!565 = !DILocation(line: 240, column: 13, scope: !501, inlinedAt: !538)
!566 = !DILocation(line: 1053, column: 27, scope: !501, inlinedAt: !538)
!567 = !DILocation(line: 1054, column: 17, scope: !568, inlinedAt: !538)
!568 = distinct !DILexicalBlock(scope: !501, file: !112, line: 1053, column: 17)
!569 = !{i64 1598758626635280, i64 1590615368640137, i64 1598741446766092}
!570 = !DILocation(line: 104, column: 10, scope: !535)
!571 = distinct !DISubprogram(name: "atomic_store_lse2_release", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_release", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!572 = !{i64 -8617011412334727950}
!573 = !DILocation(line: 1043, column: 19, scope: !501, inlinedAt: !574)
!574 = distinct !DILocation(line: 103, column: 22, scope: !571)
!575 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !576)
!576 = distinct !DILocation(line: 240, column: 27, scope: !501, inlinedAt: !574)
!577 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !578)
!578 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !579)
!579 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !576)
!580 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !576)
!581 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !576)
!582 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !583)
!583 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !576)
!584 = !{!585}
!585 = distinct !{!585, !586, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!586 = distinct !{!586, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!587 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !576)
!588 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !576)
!589 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !590)
!590 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !591)
!591 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !576)
!592 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !576)
!593 = !DILocation(line: 0, scope: !130, inlinedAt: !576)
!594 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !576)
!595 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !596)
!596 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !597)
!597 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !598)
!598 = distinct !DILocation(line: 240, column: 44, scope: !501, inlinedAt: !574)
!599 = !DILocation(line: 240, column: 27, scope: !501, inlinedAt: !574)
!600 = !DILocation(line: 1043, column: 5, scope: !501, inlinedAt: !574)
!601 = !DILocation(line: 240, column: 13, scope: !501, inlinedAt: !574)
!602 = !DILocation(line: 1053, column: 27, scope: !501, inlinedAt: !574)
!603 = !DILocation(line: 1054, column: 17, scope: !604, inlinedAt: !574)
!604 = distinct !DILexicalBlock(scope: !501, file: !112, line: 1053, column: 17)
!605 = !{i64 1599871023165196, i64 1590615368640137, i64 1599823778524936}
!606 = !DILocation(line: 104, column: 10, scope: !571)
!607 = distinct !DISubprogram(name: "atomic_store_lse128_seqcst", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store26atomic_store_lse128_seqcst", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!608 = !{i64 -3434597584493783106}
!609 = !DILocation(line: 1570, column: 19, scope: !610, inlinedAt: !611)
!610 = distinct !DISubprogram(name: "_atomic_swap_swpp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6417__atomic_swap_swpp", scope: !47, file: !112, line: 1569, type: !51, scopeLine: 1569, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!611 = distinct !DILocation(line: 919, column: 21, scope: !612, inlinedAt: !613)
!612 = distinct !DISubprogram(name: "_atomic_store_swpp", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store18__atomic_store_swpp", scope: !498, file: !112, line: 916, type: !51, scopeLine: 916, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!613 = distinct !DILocation(line: 103, column: 22, scope: !607)
!614 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !615)
!615 = distinct !DILocation(line: 283, column: 27, scope: !610, inlinedAt: !611)
!616 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !617)
!617 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !618)
!618 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !615)
!619 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !615)
!620 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !615)
!621 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !622)
!622 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !615)
!623 = !{!624}
!624 = distinct !{!624, !625, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!625 = distinct !{!625, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!626 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !615)
!627 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !615)
!628 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !629)
!629 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !630)
!630 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !615)
!631 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !615)
!632 = !DILocation(line: 0, scope: !130, inlinedAt: !615)
!633 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !615)
!634 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !635)
!635 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !636)
!636 = distinct !DILocation(line: 69, column: 26, scope: !637, inlinedAt: !638)
!637 = distinct !DISubprogram(name: "lse128", linkageName: "_RNvMs2_NtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB5_7CpuInfo6lse128", scope: !65, file: !64, line: 68, type: !51, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!638 = distinct !DILocation(line: 283, column: 44, scope: !610, inlinedAt: !611)
!639 = !DILocation(line: 283, column: 27, scope: !610, inlinedAt: !611)
!640 = !DILocation(line: 1570, column: 5, scope: !610, inlinedAt: !611)
!641 = !DILocation(line: 283, column: 13, scope: !610, inlinedAt: !611)
!642 = !DILocation(line: 1579, column: 19, scope: !610, inlinedAt: !611)
!643 = !DILocation(line: 1584, column: 17, scope: !644, inlinedAt: !611)
!644 = distinct !DILexicalBlock(scope: !645, file: !112, line: 1580, column: 9)
!645 = distinct !DILexicalBlock(scope: !610, file: !112, line: 1579, column: 9)
!646 = !{i64 1688557802880941, i64 1688940054970322, i64 1474780100640078}
!647 = !DILocation(line: 104, column: 10, scope: !607)
!648 = distinct !DISubprogram(name: "atomic_store_lse128_release", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_lse128_release", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!649 = !{i64 5404911928255126697}
!650 = !DILocation(line: 1570, column: 19, scope: !610, inlinedAt: !651)
!651 = distinct !DILocation(line: 919, column: 21, scope: !612, inlinedAt: !652)
!652 = distinct !DILocation(line: 103, column: 22, scope: !648)
!653 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !654)
!654 = distinct !DILocation(line: 283, column: 27, scope: !610, inlinedAt: !651)
!655 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !656)
!656 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !657)
!657 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !654)
!658 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !654)
!659 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !654)
!660 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !661)
!661 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !654)
!662 = !{!663}
!663 = distinct !{!663, !664, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!664 = distinct !{!664, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!665 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !654)
!666 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !654)
!667 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !668)
!668 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !669)
!669 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !654)
!670 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !654)
!671 = !DILocation(line: 0, scope: !130, inlinedAt: !654)
!672 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !654)
!673 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !674)
!674 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !675)
!675 = distinct !DILocation(line: 69, column: 26, scope: !637, inlinedAt: !676)
!676 = distinct !DILocation(line: 283, column: 44, scope: !610, inlinedAt: !651)
!677 = !DILocation(line: 283, column: 27, scope: !610, inlinedAt: !651)
!678 = !DILocation(line: 1570, column: 5, scope: !610, inlinedAt: !651)
!679 = !DILocation(line: 283, column: 13, scope: !610, inlinedAt: !651)
!680 = !DILocation(line: 1579, column: 19, scope: !610, inlinedAt: !651)
!681 = !DILocation(line: 1584, column: 17, scope: !644, inlinedAt: !651)
!682 = !{i64 1688557802880941, i64 1688940054970322, i64 1472868840192913}
!683 = !DILocation(line: 104, column: 10, scope: !648)
!684 = distinct !DISubprogram(name: "atomic_store_no_lse2_seqcst", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_no_lse2_seqcst", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!685 = !{i64 2164832635645357858}
!686 = !DILocation(line: 1176, column: 19, scope: !687, inlinedAt: !688)
!687 = distinct !DISubprogram(name: "_atomic_store_ldxp_stxp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423__atomic_store_ldxp_stxp", scope: !47, file: !112, line: 1175, type: !51, scopeLine: 1175, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!688 = distinct !DILocation(line: 103, column: 22, scope: !684)
!689 = !DILocation(line: 1176, column: 5, scope: !687, inlinedAt: !688)
!690 = !DILocation(line: 1180, column: 19, scope: !687, inlinedAt: !688)
!691 = !DILocation(line: 1183, column: 17, scope: !692, inlinedAt: !688)
!692 = distinct !DILexicalBlock(scope: !687, file: !112, line: 1180, column: 9)
!693 = !{i64 1615431689682232, i64 1615758107196757, i64 1616153244188064, i64 1616707294969427, i64 1474780100640078}
!694 = !DILocation(line: 104, column: 10, scope: !684)
!695 = distinct !DISubprogram(name: "atomic_store_no_lse2_relaxed", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!696 = !{i64 -1057234778440169012}
!697 = !DILocation(line: 1176, column: 19, scope: !687, inlinedAt: !698)
!698 = distinct !DILocation(line: 103, column: 22, scope: !695)
!699 = !DILocation(line: 1176, column: 5, scope: !687, inlinedAt: !698)
!700 = !DILocation(line: 1180, column: 19, scope: !687, inlinedAt: !698)
!701 = !DILocation(line: 1183, column: 17, scope: !692, inlinedAt: !698)
!702 = !{i64 1615431689682232, i64 1615758107196757, i64 1616153244188064, i64 1616707294969427, i64 1472422163594025}
!703 = !DILocation(line: 104, column: 10, scope: !695)
!704 = distinct !DISubprogram(name: "atomic_store_no_lse2_release", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_release", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!705 = !{i64 -8709220060426235475}
!706 = !DILocation(line: 1176, column: 19, scope: !687, inlinedAt: !707)
!707 = distinct !DILocation(line: 103, column: 22, scope: !704)
!708 = !DILocation(line: 1176, column: 5, scope: !687, inlinedAt: !707)
!709 = !DILocation(line: 1180, column: 19, scope: !687, inlinedAt: !707)
!710 = !DILocation(line: 1183, column: 17, scope: !692, inlinedAt: !707)
!711 = !{i64 1615431689682232, i64 1615758107196757, i64 1616153244188064, i64 1616707294969427, i64 1472868840192913}
!712 = !DILocation(line: 104, column: 10, scope: !704)
!713 = distinct !DISubprogram(name: "atomic_store_lse2_rcpc3_seqcst", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store30atomic_store_lse2_rcpc3_seqcst", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!714 = !{i64 -5529701942836246078}
!715 = !DILocation(line: 1118, column: 19, scope: !716, inlinedAt: !717)
!716 = distinct !DISubprogram(name: "_atomic_store_stilp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6419__atomic_store_stilp", scope: !47, file: !112, line: 1117, type: !51, scopeLine: 1117, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!717 = distinct !DILocation(line: 103, column: 22, scope: !713)
!718 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !719)
!719 = distinct !DILocation(line: 240, column: 27, scope: !716, inlinedAt: !717)
!720 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !721)
!721 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !722)
!722 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !719)
!723 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !719)
!724 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !719)
!725 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !726)
!726 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !719)
!727 = !{!728}
!728 = distinct !{!728, !729, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!729 = distinct !{!729, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!730 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !719)
!731 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !719)
!732 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !733)
!733 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !734)
!734 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !719)
!735 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !719)
!736 = !DILocation(line: 0, scope: !130, inlinedAt: !719)
!737 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !719)
!738 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !739)
!739 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !740)
!740 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !741)
!741 = distinct !DILocation(line: 240, column: 44, scope: !716, inlinedAt: !717)
!742 = !DILocation(line: 240, column: 27, scope: !716, inlinedAt: !717)
!743 = !DILocation(line: 1118, column: 5, scope: !716, inlinedAt: !717)
!744 = !DILocation(line: 240, column: 13, scope: !716, inlinedAt: !717)
!745 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !746)
!746 = distinct !DILocation(line: 326, column: 27, scope: !716, inlinedAt: !717)
!747 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !748)
!748 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !749)
!749 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !746)
!750 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !746)
!751 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !746)
!752 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !753)
!753 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !746)
!754 = !{!755}
!755 = distinct !{!755, !756, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!756 = distinct !{!756, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!757 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !746)
!758 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !746)
!759 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !760)
!760 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !761)
!761 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !746)
!762 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !746)
!763 = !DILocation(line: 0, scope: !130, inlinedAt: !746)
!764 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !746)
!765 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !766)
!766 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !767)
!767 = distinct !DILocation(line: 69, column: 26, scope: !314, inlinedAt: !768)
!768 = distinct !DILocation(line: 326, column: 44, scope: !716, inlinedAt: !717)
!769 = !DILocation(line: 326, column: 27, scope: !716, inlinedAt: !717)
!770 = !DILocation(line: 326, column: 13, scope: !716, inlinedAt: !717)
!771 = !DILocation(line: 1129, column: 27, scope: !716, inlinedAt: !717)
!772 = !DILocation(line: 1131, column: 17, scope: !773, inlinedAt: !717)
!773 = distinct !DILexicalBlock(scope: !716, file: !112, line: 1129, column: 17)
!774 = !{i64 1605922632086662, i64 1606163150255275, i64 1612506816952970}
!775 = !DILocation(line: 104, column: 10, scope: !713)
!776 = distinct !DISubprogram(name: "atomic_store_lse2_rcpc3_release", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store31atomic_store_lse2_rcpc3_release", scope: !498, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!777 = !{i64 5652770491434934211}
!778 = !DILocation(line: 1118, column: 19, scope: !716, inlinedAt: !779)
!779 = distinct !DILocation(line: 103, column: 22, scope: !776)
!780 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !781)
!781 = distinct !DILocation(line: 240, column: 27, scope: !716, inlinedAt: !779)
!782 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !783)
!783 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !784)
!784 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !781)
!785 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !781)
!786 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !781)
!787 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !788)
!788 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !781)
!789 = !{!790}
!790 = distinct !{!790, !791, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!791 = distinct !{!791, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!792 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !781)
!793 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !781)
!794 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !795)
!795 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !796)
!796 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !781)
!797 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !781)
!798 = !DILocation(line: 0, scope: !130, inlinedAt: !781)
!799 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !781)
!800 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !801)
!801 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !802)
!802 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !803)
!803 = distinct !DILocation(line: 240, column: 44, scope: !716, inlinedAt: !779)
!804 = !DILocation(line: 240, column: 27, scope: !716, inlinedAt: !779)
!805 = !DILocation(line: 1118, column: 5, scope: !716, inlinedAt: !779)
!806 = !DILocation(line: 240, column: 13, scope: !716, inlinedAt: !779)
!807 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !808)
!808 = distinct !DILocation(line: 326, column: 27, scope: !716, inlinedAt: !779)
!809 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !810)
!810 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !811)
!811 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !808)
!812 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !808)
!813 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !808)
!814 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !815)
!815 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !808)
!816 = !{!817}
!817 = distinct !{!817, !818, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!818 = distinct !{!818, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!819 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !808)
!820 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !808)
!821 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !822)
!822 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !823)
!823 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !808)
!824 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !808)
!825 = !DILocation(line: 0, scope: !130, inlinedAt: !808)
!826 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !808)
!827 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !828)
!828 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !829)
!829 = distinct !DILocation(line: 69, column: 26, scope: !314, inlinedAt: !830)
!830 = distinct !DILocation(line: 326, column: 44, scope: !716, inlinedAt: !779)
!831 = !DILocation(line: 326, column: 27, scope: !716, inlinedAt: !779)
!832 = !DILocation(line: 326, column: 13, scope: !716, inlinedAt: !779)
!833 = !DILocation(line: 1129, column: 27, scope: !716, inlinedAt: !779)
!834 = !DILocation(line: 1131, column: 17, scope: !835, inlinedAt: !779)
!835 = distinct !DILexicalBlock(scope: !716, file: !112, line: 1129, column: 17)
!836 = !{i64 1605922632086662, i64 1606163150255275, i64 1610247664154755}
!837 = !DILocation(line: 104, column: 10, scope: !776)
!838 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store4init", scope: !498, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!839 = !{i64 6617932155820378965}
!840 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !841)
!841 = distinct !DILocation(line: 947, column: 43, scope: !842)
!842 = !DILexicalBlockFile(scope: !838, file: !112, discriminator: 0)
!843 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !844)
!844 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !845)
!845 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !841)
!846 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !841)
!847 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !841)
!848 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !849)
!849 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !841)
!850 = !{!851}
!851 = distinct !{!851, !852, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!852 = distinct !{!852, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!853 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !841)
!854 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !841)
!855 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !856)
!856 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !857)
!857 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !841)
!858 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !841)
!859 = !DILocation(line: 0, scope: !130, inlinedAt: !841)
!860 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !841)
!861 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !862)
!862 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !863)
!863 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !864)
!864 = distinct !DILocation(line: 948, column: 40, scope: !865)
!865 = !DILexicalBlockFile(scope: !866, file: !112, discriminator: 0)
!866 = distinct !DILexicalBlock(scope: !838, file: !107, line: 62, column: 30)
!867 = !DILocation(line: 948, column: 29, scope: !865)
!868 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !869)
!869 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !870)
!870 = distinct !DILocation(line: 63, column: 18, scope: !871)
!871 = distinct !DILexicalBlock(scope: !838, file: !107, line: 62, column: 13)
!872 = !DILocation(line: 65, column: 22, scope: !871)
!873 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_relaxed}
!874 = !DILocation(line: 66, column: 10, scope: !838)
!875 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores0_4init", scope: !498, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!876 = !{i64 2329311921759137944}
!877 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !878)
!878 = distinct !DILocation(line: 979, column: 43, scope: !879)
!879 = !DILexicalBlockFile(scope: !875, file: !112, discriminator: 0)
!880 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !881)
!881 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !882)
!882 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !878)
!883 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !878)
!884 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !878)
!885 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !886)
!886 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !878)
!887 = !{!888}
!888 = distinct !{!888, !889, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!889 = distinct !{!889, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!890 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !878)
!891 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !878)
!892 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !893)
!893 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !894)
!894 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !878)
!895 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !878)
!896 = !DILocation(line: 0, scope: !130, inlinedAt: !878)
!897 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !878)
!898 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !899)
!899 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !900)
!900 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !901)
!901 = distinct !DILocation(line: 980, column: 40, scope: !902)
!902 = !DILexicalBlockFile(scope: !903, file: !112, discriminator: 0)
!903 = distinct !DILexicalBlock(scope: !875, file: !107, line: 62, column: 30)
!904 = !DILocation(line: 980, column: 32, scope: !902)
!905 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !906)
!906 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !907)
!907 = distinct !DILocation(line: 69, column: 26, scope: !637, inlinedAt: !908)
!908 = distinct !DILocation(line: 981, column: 44, scope: !902)
!909 = !DILocation(line: 981, column: 36, scope: !902)
!910 = !DILocation(line: 0, scope: !902)
!911 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !912)
!912 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !913)
!913 = distinct !DILocation(line: 63, column: 18, scope: !914)
!914 = distinct !DILexicalBlock(scope: !875, file: !107, line: 62, column: 13)
!915 = !DILocation(line: 65, column: 22, scope: !914)
!916 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store24atomic_store_lse2_seqcst, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store26atomic_store_lse128_seqcst, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_no_lse2_seqcst, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store30atomic_store_lse2_rcpc3_seqcst}
!917 = !DILocation(line: 66, column: 10, scope: !875)
!918 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !919)
!919 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !920)
!920 = distinct !DILocation(line: 69, column: 26, scope: !314, inlinedAt: !921)
!921 = distinct !DILocation(line: 984, column: 51, scope: !902)
!922 = !DILocation(line: 984, column: 40, scope: !902)
!923 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_stores_4init", scope: !498, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!924 = !{i64 9086266175769525161}
!925 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !926)
!926 = distinct !DILocation(line: 959, column: 43, scope: !927)
!927 = !DILexicalBlockFile(scope: !923, file: !112, discriminator: 0)
!928 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !929)
!929 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !930)
!930 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !926)
!931 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !926)
!932 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !926)
!933 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !934)
!934 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !926)
!935 = !{!936}
!936 = distinct !{!936, !937, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!937 = distinct !{!937, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!938 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !926)
!939 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !926)
!940 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !941)
!941 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !942)
!942 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !926)
!943 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !926)
!944 = !DILocation(line: 0, scope: !130, inlinedAt: !926)
!945 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !926)
!946 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !947)
!947 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !948)
!948 = distinct !DILocation(line: 69, column: 26, scope: !152, inlinedAt: !949)
!949 = distinct !DILocation(line: 960, column: 40, scope: !950)
!950 = !DILexicalBlockFile(scope: !951, file: !112, discriminator: 0)
!951 = distinct !DILexicalBlock(scope: !923, file: !107, line: 62, column: 30)
!952 = !DILocation(line: 960, column: 32, scope: !950)
!953 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !954)
!954 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !955)
!955 = distinct !DILocation(line: 69, column: 26, scope: !314, inlinedAt: !956)
!956 = distinct !DILocation(line: 961, column: 44, scope: !950)
!957 = !DILocation(line: 961, column: 36, scope: !950)
!958 = !DILocation(line: 0, scope: !950)
!959 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !960)
!960 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !961)
!961 = distinct !DILocation(line: 63, column: 18, scope: !962)
!962 = distinct !DILexicalBlock(scope: !923, file: !107, line: 62, column: 13)
!963 = !DILocation(line: 65, column: 22, scope: !962)
!964 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store25atomic_store_lse2_release, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store27atomic_store_lse128_release, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store28atomic_store_no_lse2_release, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6412atomic_store31atomic_store_lse2_rcpc3_release}
!965 = !DILocation(line: 66, column: 10, scope: !923)
!966 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !967)
!967 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !968)
!968 = distinct !DILocation(line: 69, column: 26, scope: !637, inlinedAt: !969)
!969 = distinct !DILocation(line: 964, column: 51, scope: !950)
!970 = !DILocation(line: 964, column: 40, scope: !950)
!971 = distinct !DISubprogram(name: "atomic_compare_exchange_casp_acqrel", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange35atomic_compare_exchange_casp_acqrel", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!972 = !DINamespace(name: "atomic_compare_exchange", scope: !47)
!973 = !{i64 -2815899572287801971}
!974 = !DILocation(line: 1413, column: 19, scope: !975, inlinedAt: !976)
!975 = distinct !DISubprogram(name: "_atomic_compare_exchange_casp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6429__atomic_compare_exchange_casp", scope: !47, file: !112, line: 1406, type: !51, scopeLine: 1406, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!976 = distinct !DILocation(line: 103, column: 22, scope: !971)
!977 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !978)
!978 = distinct !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !976)
!979 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !980)
!980 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !981)
!981 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !978)
!982 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !978)
!983 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !978)
!984 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !985)
!985 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !978)
!986 = !{!987}
!987 = distinct !{!987, !988, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!988 = distinct !{!988, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!989 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !978)
!990 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !978)
!991 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !992)
!992 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !993)
!993 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !978)
!994 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !978)
!995 = !DILocation(line: 0, scope: !130, inlinedAt: !978)
!996 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !978)
!997 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !998)
!998 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !999)
!999 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1001)
!1000 = distinct !DISubprogram(name: "lse", linkageName: "_RNvMs2_NtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB5_7CpuInfo3lse", scope: !65, file: !64, line: 68, type: !51, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1001 = distinct !DILocation(line: 200, column: 44, scope: !975, inlinedAt: !976)
!1002 = !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !976)
!1003 = !DILocation(line: 1413, column: 5, scope: !975, inlinedAt: !976)
!1004 = !DILocation(line: 200, column: 13, scope: !975, inlinedAt: !976)
!1005 = !DILocation(line: 1423, column: 19, scope: !1006, inlinedAt: !976)
!1006 = distinct !DILexicalBlock(scope: !975, file: !112, line: 1415, column: 5)
!1007 = !DILocation(line: 1424, column: 19, scope: !1008, inlinedAt: !976)
!1008 = distinct !DILexicalBlock(scope: !1006, file: !112, line: 1423, column: 9)
!1009 = !DILocation(line: 1428, column: 17, scope: !1010, inlinedAt: !976)
!1010 = distinct !DILexicalBlock(scope: !1011, file: !112, line: 1425, column: 9)
!1011 = distinct !DILexicalBlock(scope: !1008, file: !112, line: 1424, column: 9)
!1012 = !{i64 1660670580221523, i64 1661035652441717, i64 1473092178492357}
!1013 = !DILocation(line: 1445, column: 5, scope: !1008, inlinedAt: !976)
!1014 = !DILocation(line: 104, column: 10, scope: !971)
!1015 = distinct !DISubprogram(name: "atomic_compare_exchange_casp_acquire", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_acquire", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1016 = !{i64 250185580390976681}
!1017 = !DILocation(line: 1413, column: 19, scope: !975, inlinedAt: !1018)
!1018 = distinct !DILocation(line: 103, column: 22, scope: !1015)
!1019 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !1020)
!1020 = distinct !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !1018)
!1021 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !1022)
!1022 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !1023)
!1023 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !1020)
!1024 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !1020)
!1025 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !1020)
!1026 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !1027)
!1027 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !1020)
!1028 = !{!1029}
!1029 = distinct !{!1029, !1030, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!1030 = distinct !{!1030, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!1031 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !1020)
!1032 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !1020)
!1033 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !1034)
!1034 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !1035)
!1035 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !1020)
!1036 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !1020)
!1037 = !DILocation(line: 0, scope: !130, inlinedAt: !1020)
!1038 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !1020)
!1039 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !1040)
!1040 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !1041)
!1041 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1042)
!1042 = distinct !DILocation(line: 200, column: 44, scope: !975, inlinedAt: !1018)
!1043 = !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !1018)
!1044 = !DILocation(line: 1413, column: 5, scope: !975, inlinedAt: !1018)
!1045 = !DILocation(line: 200, column: 13, scope: !975, inlinedAt: !1018)
!1046 = !DILocation(line: 1423, column: 19, scope: !1006, inlinedAt: !1018)
!1047 = !DILocation(line: 1424, column: 19, scope: !1008, inlinedAt: !1018)
!1048 = !DILocation(line: 1428, column: 17, scope: !1010, inlinedAt: !1018)
!1049 = !{i64 1660670580221523, i64 1661035652441717, i64 1472645501893469}
!1050 = !DILocation(line: 1445, column: 5, scope: !1008, inlinedAt: !1018)
!1051 = !DILocation(line: 104, column: 10, scope: !1015)
!1052 = distinct !DISubprogram(name: "atomic_compare_exchange_casp_relaxed", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_relaxed", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1053 = !{i64 -8366550200231316689}
!1054 = !DILocation(line: 1413, column: 19, scope: !975, inlinedAt: !1055)
!1055 = distinct !DILocation(line: 103, column: 22, scope: !1052)
!1056 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !1057)
!1057 = distinct !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !1055)
!1058 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !1059)
!1059 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !1060)
!1060 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !1057)
!1061 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !1057)
!1062 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !1057)
!1063 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !1064)
!1064 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !1057)
!1065 = !{!1066}
!1066 = distinct !{!1066, !1067, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!1067 = distinct !{!1067, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!1068 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !1057)
!1069 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !1057)
!1070 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !1071)
!1071 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !1072)
!1072 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !1057)
!1073 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !1057)
!1074 = !DILocation(line: 0, scope: !130, inlinedAt: !1057)
!1075 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !1057)
!1076 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !1077)
!1077 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !1078)
!1078 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1079)
!1079 = distinct !DILocation(line: 200, column: 44, scope: !975, inlinedAt: !1055)
!1080 = !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !1055)
!1081 = !DILocation(line: 1413, column: 5, scope: !975, inlinedAt: !1055)
!1082 = !DILocation(line: 200, column: 13, scope: !975, inlinedAt: !1055)
!1083 = !DILocation(line: 1423, column: 19, scope: !1006, inlinedAt: !1055)
!1084 = !DILocation(line: 1424, column: 19, scope: !1008, inlinedAt: !1055)
!1085 = !DILocation(line: 1428, column: 17, scope: !1010, inlinedAt: !1055)
!1086 = !{i64 1660670580221523, i64 1661035652441717, i64 1472422163594025}
!1087 = !DILocation(line: 1445, column: 5, scope: !1008, inlinedAt: !1055)
!1088 = !DILocation(line: 104, column: 10, scope: !1052)
!1089 = distinct !DISubprogram(name: "atomic_compare_exchange_casp_release", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_release", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1090 = !{i64 -3370199611531864070}
!1091 = !DILocation(line: 1413, column: 19, scope: !975, inlinedAt: !1092)
!1092 = distinct !DILocation(line: 103, column: 22, scope: !1089)
!1093 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !1094)
!1094 = distinct !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !1092)
!1095 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !1096)
!1096 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !1097)
!1097 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !1094)
!1098 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !1094)
!1099 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !1094)
!1100 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !1101)
!1101 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !1094)
!1102 = !{!1103}
!1103 = distinct !{!1103, !1104, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!1104 = distinct !{!1104, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!1105 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !1094)
!1106 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !1094)
!1107 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !1108)
!1108 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !1109)
!1109 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !1094)
!1110 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !1094)
!1111 = !DILocation(line: 0, scope: !130, inlinedAt: !1094)
!1112 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !1094)
!1113 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !1114)
!1114 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !1115)
!1115 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1116)
!1116 = distinct !DILocation(line: 200, column: 44, scope: !975, inlinedAt: !1092)
!1117 = !DILocation(line: 200, column: 27, scope: !975, inlinedAt: !1092)
!1118 = !DILocation(line: 1413, column: 5, scope: !975, inlinedAt: !1092)
!1119 = !DILocation(line: 200, column: 13, scope: !975, inlinedAt: !1092)
!1120 = !DILocation(line: 1423, column: 19, scope: !1006, inlinedAt: !1092)
!1121 = !DILocation(line: 1424, column: 19, scope: !1008, inlinedAt: !1092)
!1122 = !DILocation(line: 1428, column: 17, scope: !1010, inlinedAt: !1092)
!1123 = !{i64 1660670580221523, i64 1661035652441717, i64 1472868840192913}
!1124 = !DILocation(line: 1445, column: 5, scope: !1008, inlinedAt: !1092)
!1125 = !DILocation(line: 104, column: 10, scope: !1089)
!1126 = distinct !DISubprogram(name: "atomic_compare_exchange_ldxp_stxp_acqrel", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1127 = !{i64 6923447677235561856}
!1128 = !DILocation(line: 1456, column: 19, scope: !1129, inlinedAt: !1130)
!1129 = distinct !DISubprogram(name: "_atomic_compare_exchange_ldxp_stxp", linkageName: "_RNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6434__atomic_compare_exchange_ldxp_stxp", scope: !47, file: !112, line: 1449, type: !51, scopeLine: 1449, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1130 = distinct !DILocation(line: 103, column: 22, scope: !1126)
!1131 = !DILocation(line: 1456, column: 5, scope: !1129, inlinedAt: !1130)
!1132 = !DILocation(line: 1474, column: 19, scope: !1133, inlinedAt: !1130)
!1133 = distinct !DILexicalBlock(scope: !1129, file: !112, line: 1457, column: 5)
!1134 = !DILocation(line: 1475, column: 19, scope: !1135, inlinedAt: !1130)
!1135 = distinct !DILexicalBlock(scope: !1133, file: !112, line: 1474, column: 9)
!1136 = !DILocation(line: 1479, column: 17, scope: !1137, inlinedAt: !1130)
!1137 = distinct !DILexicalBlock(scope: !1138, file: !112, line: 1476, column: 9)
!1138 = distinct !DILexicalBlock(scope: !1135, file: !112, line: 1475, column: 9)
!1139 = !{i64 1671292034347014, i64 1671661401534499, i64 1671876149899385, i64 1672056538525868, i64 1672275581858006, i64 1672486035255561, i64 1672662128914746, i64 1673061560873314, i64 1673607021720085, i64 1673744460673599, i64 1673856129823323, i64 1674246971847288, i64 1674792432694057, i64 1674904101843791, i64 1473092178492357}
!1140 = !DILocation(line: 1512, column: 5, scope: !1135, inlinedAt: !1130)
!1141 = !DILocation(line: 104, column: 10, scope: !1126)
!1142 = distinct !DISubprogram(name: "atomic_compare_exchange_ldxp_stxp_acquire", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1143 = !{i64 3110189154876413730}
!1144 = !DILocation(line: 1456, column: 19, scope: !1129, inlinedAt: !1145)
!1145 = distinct !DILocation(line: 103, column: 22, scope: !1142)
!1146 = !DILocation(line: 1456, column: 5, scope: !1129, inlinedAt: !1145)
!1147 = !DILocation(line: 1474, column: 19, scope: !1133, inlinedAt: !1145)
!1148 = !DILocation(line: 1475, column: 19, scope: !1135, inlinedAt: !1145)
!1149 = !DILocation(line: 1479, column: 17, scope: !1137, inlinedAt: !1145)
!1150 = !{i64 1671292034347014, i64 1671661401534499, i64 1671876149899385, i64 1672056538525868, i64 1672275581858006, i64 1672486035255561, i64 1672662128914746, i64 1673061560873314, i64 1673607021720085, i64 1673744460673599, i64 1673856129823323, i64 1674246971847288, i64 1674792432694057, i64 1674904101843791, i64 1472645501893469}
!1151 = !DILocation(line: 1512, column: 5, scope: !1135, inlinedAt: !1145)
!1152 = !DILocation(line: 104, column: 10, scope: !1142)
!1153 = distinct !DISubprogram(name: "atomic_compare_exchange_ldxp_stxp_relaxed", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1154 = !{i64 3900990044101495835}
!1155 = !DILocation(line: 1456, column: 19, scope: !1129, inlinedAt: !1156)
!1156 = distinct !DILocation(line: 103, column: 22, scope: !1153)
!1157 = !DILocation(line: 1456, column: 5, scope: !1129, inlinedAt: !1156)
!1158 = !DILocation(line: 1474, column: 19, scope: !1133, inlinedAt: !1156)
!1159 = !DILocation(line: 1475, column: 19, scope: !1135, inlinedAt: !1156)
!1160 = !DILocation(line: 1479, column: 17, scope: !1137, inlinedAt: !1156)
!1161 = !{i64 1671292034347014, i64 1671661401534499, i64 1671876149899385, i64 1672056538525868, i64 1672275581858006, i64 1672486035255561, i64 1672662128914746, i64 1673061560873314, i64 1673607021720085, i64 1673744460673599, i64 1673856129823323, i64 1674246971847288, i64 1674792432694057, i64 1674904101843791, i64 1472422163594025}
!1162 = !DILocation(line: 1512, column: 5, scope: !1135, inlinedAt: !1156)
!1163 = !DILocation(line: 104, column: 10, scope: !1153)
!1164 = distinct !DISubprogram(name: "atomic_compare_exchange_ldxp_stxp_release", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release", scope: !972, file: !107, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1165 = !{i64 6254373072239342057}
!1166 = !DILocation(line: 1456, column: 19, scope: !1129, inlinedAt: !1167)
!1167 = distinct !DILocation(line: 103, column: 22, scope: !1164)
!1168 = !DILocation(line: 1456, column: 5, scope: !1129, inlinedAt: !1167)
!1169 = !DILocation(line: 1474, column: 19, scope: !1133, inlinedAt: !1167)
!1170 = !DILocation(line: 1475, column: 19, scope: !1135, inlinedAt: !1167)
!1171 = !DILocation(line: 1479, column: 17, scope: !1137, inlinedAt: !1167)
!1172 = !{i64 1671292034347014, i64 1671661401534499, i64 1671876149899385, i64 1672056538525868, i64 1672275581858006, i64 1672486035255561, i64 1672662128914746, i64 1673061560873314, i64 1673607021720085, i64 1673744460673599, i64 1673856129823323, i64 1674246971847288, i64 1674792432694057, i64 1674904101843791, i64 1472868840192913}
!1173 = !DILocation(line: 1512, column: 5, scope: !1135, inlinedAt: !1167)
!1174 = !DILocation(line: 104, column: 10, scope: !1164)
!1175 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange4init", scope: !972, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1176 = !{i64 -3098268933238380036}
!1177 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !1178)
!1178 = distinct !DILocation(line: 1297, column: 28, scope: !1179)
!1179 = !DILexicalBlockFile(scope: !1175, file: !112, discriminator: 0)
!1180 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !1181)
!1181 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !1182)
!1182 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !1178)
!1183 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !1178)
!1184 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !1178)
!1185 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !1186)
!1186 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !1178)
!1187 = !{!1188}
!1188 = distinct !{!1188, !1189, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!1189 = distinct !{!1189, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!1190 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !1178)
!1191 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !1178)
!1192 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !1193)
!1193 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !1194)
!1194 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !1178)
!1195 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !1178)
!1196 = !DILocation(line: 0, scope: !130, inlinedAt: !1178)
!1197 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !1178)
!1198 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !1199)
!1199 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !1200)
!1200 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1201)
!1201 = distinct !DILocation(line: 1297, column: 45, scope: !1179)
!1202 = !DILocation(line: 1297, column: 25, scope: !1179)
!1203 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !1204)
!1204 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !1205)
!1205 = distinct !DILocation(line: 63, column: 18, scope: !1206)
!1206 = distinct !DILexicalBlock(scope: !1175, file: !107, line: 62, column: 13)
!1207 = !DILocation(line: 65, column: 22, scope: !1206)
!1208 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_relaxed, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_relaxed}
!1209 = !DILocation(line: 66, column: 10, scope: !1175)
!1210 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges0_4init", scope: !972, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1211 = !{i64 6137762754228629109}
!1212 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !1213)
!1213 = distinct !DILocation(line: 1319, column: 28, scope: !1214)
!1214 = !DILexicalBlockFile(scope: !1210, file: !112, discriminator: 0)
!1215 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !1216)
!1216 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !1217)
!1217 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !1213)
!1218 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !1213)
!1219 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !1213)
!1220 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !1221)
!1221 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !1213)
!1222 = !{!1223}
!1223 = distinct !{!1223, !1224, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!1224 = distinct !{!1224, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!1225 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !1213)
!1226 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !1213)
!1227 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !1228)
!1228 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !1229)
!1229 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !1213)
!1230 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !1213)
!1231 = !DILocation(line: 0, scope: !130, inlinedAt: !1213)
!1232 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !1213)
!1233 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !1234)
!1234 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !1235)
!1235 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1236)
!1236 = distinct !DILocation(line: 1319, column: 45, scope: !1214)
!1237 = !DILocation(line: 1319, column: 25, scope: !1214)
!1238 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !1239)
!1239 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !1240)
!1240 = distinct !DILocation(line: 63, column: 18, scope: !1241)
!1241 = distinct !DILexicalBlock(scope: !1210, file: !107, line: 62, column: 13)
!1242 = !DILocation(line: 65, column: 22, scope: !1241)
!1243 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_release, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_release}
!1244 = !DILocation(line: 66, column: 10, scope: !1210)
!1245 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges1_4init", scope: !972, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1246 = !{i64 -5404471344577238328}
!1247 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !1248)
!1248 = distinct !DILocation(line: 1332, column: 28, scope: !1249)
!1249 = !DILexicalBlockFile(scope: !1245, file: !112, discriminator: 0)
!1250 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !1251)
!1251 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !1252)
!1252 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !1248)
!1253 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !1248)
!1254 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !1248)
!1255 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !1256)
!1256 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !1248)
!1257 = !{!1258}
!1258 = distinct !{!1258, !1259, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!1259 = distinct !{!1259, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!1260 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !1248)
!1261 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !1248)
!1262 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !1263)
!1263 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !1264)
!1264 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !1248)
!1265 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !1248)
!1266 = !DILocation(line: 0, scope: !130, inlinedAt: !1248)
!1267 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !1248)
!1268 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !1269)
!1269 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !1270)
!1270 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1271)
!1271 = distinct !DILocation(line: 1332, column: 45, scope: !1249)
!1272 = !DILocation(line: 1332, column: 25, scope: !1249)
!1273 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !1274)
!1274 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !1275)
!1275 = distinct !DILocation(line: 63, column: 18, scope: !1276)
!1276 = distinct !DILexicalBlock(scope: !1245, file: !107, line: 62, column: 13)
!1277 = !DILocation(line: 65, column: 22, scope: !1276)
!1278 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange35atomic_compare_exchange_casp_acqrel, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange40atomic_compare_exchange_ldxp_stxp_acqrel}
!1279 = !DILocation(line: 66, column: 10, scope: !1245)
!1280 = distinct !DISubprogram(name: "init", linkageName: "_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchanges_4init", scope: !972, file: !107, line: 61, type: !51, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !41, templateParams: !52)
!1281 = !{i64 -8646760706404052899}
!1282 = !DILocation(line: 35, column: 9, scope: !116, inlinedAt: !1283)
!1283 = distinct !DILocation(line: 1308, column: 28, scope: !1284)
!1284 = !DILexicalBlockFile(scope: !1280, file: !112, discriminator: 0)
!1285 = !DILocation(line: 3994, column: 24, scope: !119, inlinedAt: !1286)
!1286 = distinct !DILocation(line: 2916, column: 26, scope: !125, inlinedAt: !1287)
!1287 = distinct !DILocation(line: 35, column: 34, scope: !116, inlinedAt: !1283)
!1288 = !DILocation(line: 35, column: 20, scope: !116, inlinedAt: !1283)
!1289 = !DILocation(line: 36, column: 8, scope: !130, inlinedAt: !1283)
!1290 = !DILocation(line: 10, column: 9, scope: !63, inlinedAt: !1291)
!1291 = distinct !DILocation(line: 39, column: 10, scope: !130, inlinedAt: !1283)
!1292 = !{!1293}
!1293 = distinct !{!1293, !1294, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set: %self"}
!1294 = distinct !{!1294, !"_RNvMNtNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch646detectNtB2_7CpuInfo3set"}
!1295 = !DILocation(line: 43, column: 9, scope: !130, inlinedAt: !1283)
!1296 = !DILocation(line: 45, column: 17, scope: !130, inlinedAt: !1283)
!1297 = !DILocation(line: 3978, column: 24, scope: !140, inlinedAt: !1298)
!1298 = distinct !DILocation(line: 2946, column: 26, scope: !142, inlinedAt: !1299)
!1299 = distinct !DILocation(line: 45, column: 11, scope: !130, inlinedAt: !1283)
!1300 = !DILocation(line: 47, column: 2, scope: !116, inlinedAt: !1283)
!1301 = !DILocation(line: 0, scope: !130, inlinedAt: !1283)
!1302 = !DILocation(line: 47, column: 1, scope: !116, inlinedAt: !1283)
!1303 = !DILocation(line: 27, column: 5, scope: !148, inlinedAt: !1304)
!1304 = distinct !DILocation(line: 15, column: 9, scope: !150, inlinedAt: !1305)
!1305 = distinct !DILocation(line: 69, column: 26, scope: !1000, inlinedAt: !1306)
!1306 = distinct !DILocation(line: 1308, column: 45, scope: !1284)
!1307 = !DILocation(line: 1308, column: 25, scope: !1284)
!1308 = !DILocation(line: 3978, column: 24, scope: !415, inlinedAt: !1309)
!1309 = distinct !DILocation(line: 1797, column: 13, scope: !417, inlinedAt: !1310)
!1310 = distinct !DILocation(line: 63, column: 18, scope: !1311)
!1311 = distinct !DILexicalBlock(scope: !1280, file: !107, line: 62, column: 13)
!1312 = !DILocation(line: 65, column: 22, scope: !1311)
!1313 = !{ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange36atomic_compare_exchange_casp_acquire, ptr @_RNvNvNtNtNtCskz5XzuL9Z1u_15portable_atomic3imp9atomic1287aarch6423atomic_compare_exchange41atomic_compare_exchange_ldxp_stxp_acquire}
!1314 = !DILocation(line: 66, column: 10, scope: !1280)
