"""Read terminal uv check metadata without running a toolchain or changing either product."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re
import runpy
import struct
import sys
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
SNAP = runpy.run_path(str(HERE.parents[1]/"uv-workflow-search/rdr_snapshot.py"))
SIG = SNAP["sig"]
LIMIT = 32*2**20
SHA = lambda d: hashlib.sha256(d).hexdigest()

def require(test, text):
    if not test:
        raise ValueError(text)

def blob(arg):
    file, token, sub = arg.partition("::")
    p = Path(file)
    if token:
        with ZipFile(p) as archive:
            info = archive.getinfo(sub)
            require(0<info.file_size<=LIMIT,"oversized ZIP entry")
            data=archive.read(info)
    else:
        require(0<p.stat().st_size<=LIMIT,"oversized product")
        data=p.read_bytes()
    if data[:2]==b"\x1f\x8b":
        from io import BytesIO
        with gzip.GzipFile(fileobj=BytesIO(data)) as f:
            data=f.read(LIMIT+1)
    require(0<len(data)<=LIMIT,"oversized uncompressed product")
    return data

def integer(value):
    out=bytearray()
    while value>=128:
        out.append((value&127)|128)
        value >>= 7
    out.append(value)
    return bytes(out)

def text_leaf(encoded):
    # Alloc tag 0, byte alignment, immutable, not all-zero. The original encoder then
    # emits byte length and bytes, an empty pointer map, lazy fully-initialized mask,
    # and the mask length. Check the whole record before interpreting any payload.
    if len(encoded)<7 or encoded[:2]!=b"\x00\x00":
        return None
    reader=SIG.Reader(encoded,2)
    size=reader.u()
    end=reader.p+size
    if not size or end>=len(encoded) or encoded[end:]!=b"\x00\x00\x01"+integer(size):
        return None
    data=encoded[reader.p:end]
    if len(data)>256:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None

def parse(arg):
    raw=blob(arg)
    data=SIG.ar.payload(raw) if raw.startswith(b"\x7fELF") else raw
    require(data[:8]==b"rust\0\0\0\n","unknown rust metadata magic")
    at=struct.unpack_from("<Q",data,8)[0]
    try:
        root=SIG.Reader(data,at).read()
    except (AssertionError,IndexError,struct.error):
        root=SNAP["Reader21"](data,at).read()
    require(root["target"]=="x86_64-unknown-linux-gnu" and root["crate_name"]=="uv","not terminal GNU uv")
    # rdr_snapshot already resolves stable DefPathHash and human paths from the release tables.
    class Input:
        def read_bytes(self):return data
    snap=SNAP["crate"](Input())
    require(root["public_svh"]==snap["public"] and root["global_public_hash"]==snap["global"],"inconsistent readers")
    tables=root["tables"]
    hash_table=SIG.di.rows(data,tables["expn_hashes"])
    raw_exps=SIG.di.rows(data,tables["rdr_hashes.expn"])
    exps={}
    for i,row in enumerate(raw_exps):
        if not any(row):
            continue
        require(row[0]==1 and len(row)<=17 and i<len(hash_table),"bad expansion hash")
        start=int.from_bytes(hash_table[i],"little")
        require(0<start<at and start+16<=len(data),"bad expansion identity")
        key=data[start:start+16]
        require((i==0 and not any(key)) or int.from_bytes(key[:8],"little")==int(root["stable_crate_id"],16),
                "foreign expansion identity")
        require(key.hex() not in exps,"duplicate expansion identity")
        exps[key.hex()]=row.ljust(17,b"\0")[1:].hex()
    # Source writes consecutive specialized_encode_alloc_id records, followed by their offset array.
    alloc=tables["interpret_alloc_index"]
    count,stop=alloc["length"],alloc["position"]
    recs=Counter()
    tags=Counter()
    seq=hashlib.sha256()
    hints={}
    if count:
        require(0<count<=2**20 and 0<stop<at,"bad allocation array")
        rd=SIG.Reader(data,stop)
        starts=[rd.u() for _ in range(count)]
        require(starts==sorted(set(starts)) and 0<starts[0] and starts[-1]<stop,"invalid allocation offsets")
        for begin,end in zip(starts,starts[1:]+[stop]):
            encoded=data[begin:end]
            require(encoded and encoded[0] in range(5),"unknown public allocation tag")
            key=SHA(encoded)
            recs[key]+=1
            tags[encoded[0]]+=1
            seq.update(bytes.fromhex(key))
            hints[key]={"tag":encoded[0],"bytes":len(encoded),"immutable_pointer_free_utf8":text_leaf(encoded),"ascii_fragments":[v.decode() for v in re.findall(rb"[A-Za-z_][A-Za-z_0-9-]{2,63}",encoded)[:4]]}
    header={k:root[k] for k in ("target","crate_name","private_svh","public_svh","stable_crate_id","global_public_hash")}
    header.update(raw_sha256=SHA(raw),bytes=len(raw),definition_count=len(snap["rows"]),reachable_expansions=len(exps),
                  allocation_records=count,distinct_allocation_records=len(recs),allocation_tags=dict(tags),allocation_order_sha256=seq.hexdigest())
    return header,snap["rows"],exps,recs,hints

def summary(warm,fresh, *, signed_edit_control=False):
    a,b=parse(warm),parse(fresh)
    w,defs1,exps1,one,_=a
    c,defs2,exps2,two,_=b
    require(w["stable_crate_id"]==c["stable_crate_id"],"stable crate identity differs")
    if signed_edit_control:
        old=json.loads((HERE.parent/"remainder/signed22-20988-definition-delta.json").read_bytes())["by_crate"]["uv"]
        require((w["raw_sha256"],c["raw_sha256"])==(old["A"]["sha256"],old["B"]["sha256"]),
                "positive control requires the two exact signed A/B fixtures")
    else:
        require(w["private_svh"]==c["private_svh"],"same-B control has different private hashes")
    interesting=lambda v: any(bytes.fromhex(v[0]))
    fingerprint=lambda row:bytes.fromhex(row[0]).ljust(17,b"\0")[1:].hex()
    d1={k:fingerprint(v) for k,v in defs1.items() if interesting(v)};d2={k:fingerprint(v) for k,v in defs2.items() if interesting(v)}
    def delta(x,y):
        return {"only_warm":len(x.keys()-y.keys()),"only_fresh":len(y.keys()-x.keys()),
                "same":sum(x[k]==y[k] for k in x.keys()&y.keys()),"changed":sum(x[k]!=y[k] for k in x.keys()&y.keys())}
    changed=[k for k in sorted(d1.keys()&d2.keys()) if d1[k]!=d2[k]]
    kdiff=sorted((k for k in one.keys()|two.keys() if one[k]!=two[k]),key=lambda k:(-abs(one[k]-two[k]),k))
    both=[k for k in kdiff if one[k] and two[k]]
    row=lambda k:{"sha256":k,"warm":one[k],"fresh":two[k],**(a[4].get(k) or b[4][k])}
    prior=json.loads((HERE.parent/"rc23-root-fingerprint-diff/report.json").read_bytes())["observations"]["signed_ohm22"]["terminal_root"]
    return {"comparison":"signed_A_to_incremental_B_positive_control" if signed_edit_control else "same_B_warm_to_fresh","warm":w,"fresh":c,"same_private":w["private_svh"]==c["private_svh"],"same_global":w["global_public_hash"]==c["global_public_hash"],"same_public":w["public_svh"]==c["public_svh"],
            "agrees_with_original_signed_surface":{"warm_raw":w["raw_sha256"]==prior["edited"]["sha256"],"fresh_raw":c["raw_sha256"]==prior["cold"]["sha256"],"warm_public":w["public_svh"]==prior["edited"]["public_hash"],"fresh_public":c["public_svh"]==prior["cold"]["public_hash"]},
            "stable_defs":delta(d1,d2),"stable_expansions":delta(exps1,exps2),"changed_kinds":dict(Counter(defs2[k][2] for k in changed)),
            "changed_def_examples":[SNAP["label"](defs2,k) for k in changed[:20]],"allocations":{"ordered_equal":w["allocation_order_sha256"]==c["allocation_order_sha256"],"multisets_equal":one==two,
            "warm_excess_records":sum((one-two).values()),"fresh_excess_records":sum((two-one).values()),"different_distinct_records":len(kdiff),
            "common_payloads_with_different_copy_counts":len(both),"common_immutable_utf8_with_different_copy_counts":sum(row(k)["immutable_pointer_free_utf8"] is not None for k in both),"common_payload_examples":[row(k) for k in both[:16]],"all_difference_examples":[row(k) for k in kdiff[:16]]},
            "interpretation":"These are serialized metadata allocation records. A byte-identical record with different multiplicity is evidence for an aliasing difference; reachable stable fingerprints and a matched compiler intervention are necessary to attribute the public hash to CTFE. Differing encoded references can also change record bytes."}

if __name__=="__main__":
    if len(sys.argv)==4 and sys.argv[1]=="--signed-edit-control":
        print(json.dumps(summary(*sys.argv[2:],signed_edit_control=True),indent=2))
        raise SystemExit
    if len(sys.argv)!=3:
        raise SystemExit("metadata.py WARM.rmeta[.gz] FRESH.rmeta[.gz]; ZIP::member also accepted")
    print(json.dumps(summary(*sys.argv[1:]),indent=2))
