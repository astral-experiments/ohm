"""Distinguish raw archive, native object, metadata, and signed-input semantic drift in the immutable run."""
from pathlib import Path
import collections,gzip,hashlib,json,os,re,runpy,struct,sys,zipfile
H=Path(__file__).resolve().parent;D=H.parents[4];SRC=D/'released-recent/22635-hosted/run-41380171343/metadata-forensic';Q=runpy.run_path(str(SRC/'compare.py'));M=runpy.run_path(str(SRC/'mechanism.py'))
C=Q['C'];S=Q['S'];sha=lambda b:hashlib.sha256(b).hexdigest()
A='437b609a5566247c84a23e148593cf48d3212c14464bdbe210fa8fbf2d0b13db'
def ar(b):
    assert b.startswith(b'!<arch>\n');p=8;rows=[];long=None
    while p<len(b):
        h=b[p:p+60];assert h[58:]==b'`\n';n=h[:16].rstrip().decode();size=int(h[48:58]);v=b[p+60:p+60+size];assert len(v)==size
        if n=='//':long=v
        if n.startswith('/')and n[1:].isdigit():
            ix=int(n[1:]);end=long.index(b'/\n',ix);n=long[ix:end].decode()
        elif n not in ('/','//','/SYM64/'):n=n.removesuffix('/')
        rows.append((n,h,v,p+60));p+=60+size+(size%2)
    assert p==len(b);return rows
def sec(b):
    assert b[:6]==b'\x7fELF\x02\x01';header=struct.unpack_from('<16sHHIQQQIHHHHHH',b);off=header[6];sz=header[11];n=header[12];names=header[13];assert sz==64 and 0<names<n
    all0=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*sz)for i in range(n)];txt=all0[names];strtab=b[txt[4]:txt[4]+txt[5]]
    name=lambda i:strtab[i:strtab.index(b'\0',i)].decode();return [(name(x[0]),x[1],x[2],int(x[4]),int(x[5]))for x in all0]
def elf(x,y):
    assert len(x)==len(y);a,b=sec(x),sec(y);assert a==b
    o=[i for i,(e,f)in enumerate(zip(x,y))if e!=f];rr=[]
    for n,typ,flags,lo,size in a:
        if typ==8:continue
        idx=[i for i in o if lo<=i<lo+size]
        if idx:
            slice=lambda raw,i:raw[raw.rfind(b'\0',lo,i)+1:mathend(raw,i,lo+size)].decode('utf8','backslashreplace')if n in('.strtab','.shstrtab')else None
            atoms=sorted(set((slice(x,i),slice(y,i))for i in idx))if n in('.strtab','.shstrtab')else []
            rr.append({'section':n,'type':typ,'flags':flags,'diff_bytes':len(idx),'old_new_strings':atoms})
    assert sum(z['diff_bytes']for z in rr)==len(o);return rr
def mathend(raw,i,stop):
    try:return raw.index(b'\0',i,stop)
    except ValueError:return stop
def native_archive(x,y):
    ax,ay=ar(x),ar(y);assert len(ax)==len(ay);mol=[];vary=[]
    for i,((nx,hx,bx,ox),(ny,hy,by,oy))in enumerate(zip(ax,ay)):
        assert hx==hy and ox==oy and len(bx)==len(by)
        if nx!=ny:
            a,b=nx.split('.'),ny.split('.');ij=[k for k,(p,q)in enumerate(zip(a,b))if p!=q];assert len(a)==len(b)and len(ij)==1 and nx.endswith('.rcgu.o')and ny.endswith('.rcgu.o');pos=ij[0];vary.append((a[pos],b[pos]))
        if bx==by and nx==ny:continue
        row={'index':i,'names':[nx,ny],'sizes':[len(bx),len(by)],'content_sha256':[sha(bx),sha(by)],'different_payload_bytes':sum(i!=j for i,j in zip(bx,by))}
        if bx.startswith(b'\x7fELF'):row['elf_sections']=elf(bx,by)
        if nx=='//':row['filename_table']=True
        mol.append(row)
    # Apply only the observed changed filename fragment on its exact byte spans, then require complete archive equality.
    changes=[];m=bytearray(x)
    for bef,aft in sorted(set(vary)):
        l,r=bef.encode(),aft.encode();p=0
        while (p:=x.find(l,p))>=0:
            if y[p:p+len(r)]==r:m[p:p+len(r)]=r;changes.append([p,bef,aft])
            p+=len(l)
    return {'members':len(ax),'total_different_bytes':sum(d!=e for d,e in zip(x,y)),'archive_headers_identities_offsets_sizes_equal':True,'changed_members':mol,'exact_filename_token_substitutions':changes,'complete_archive_after_atomic_token_substitution_equal':bytes(m)==y}
def diff_rmeta(x,y,name):
    q=Q['compare'](x,y,name);r1,r2=C['root'](x),C['root'](y);P=Q['P'];d=P(x,name)[1];i1=[k.hex()for k in S['sig'].di.keyed(x,r1)];i2=[k.hex()for k in S['sig'].di.keyed(y,r2)];rev={k:i for i,k in enumerate(i2)}
    q['physical_moved_classes']=dict(collections.Counter(d[k][2]for i,k in enumerate(i1)if k in rev and rev[k]!=i));q['ordered_bytes_equal']=x==y
    if len(x)==len(y):
        o=[i for i in range(len(x))if x[i]!=y[i]];q['point_changes_same_length']=len(o)
        if i1==i2:
            q['exact_mismatch_ranges']=runs(o);q['intersection_with_fixed_tables']={}
            for key,t in r1['tables'].items():
                if t['type']=='table':
                    c=sum(t['position']<=n<t['end']for n in o)
                    if c:q['intersection_with_fixed_tables'][key]=c
            q['root_table_layout_identical']=r1['tables']==r2['tables']
    return q
def runs(o):
    cur=[]
    for x in o:
        if not cur or cur[-1][1]!=x:cur.append([x,x+1])
        else:cur[-1][1]+=1
    return cur
def process():
    physical=H.parent/'original.zip';assert hashlib.file_digest(physical.open('rb'),'sha256').hexdigest()==A;z=zipfile.ZipFile(physical);j=lambda n:json.loads(z.read(n));out={}
    def raw(f):
        data=gzip.decompress(z.read('blobs/'+f[1]+'.gz'));assert [len(data),sha(data)]==f;return data
    for role in('stock_ctfe318','fa7a_stack_ctfe318'):
        root='hold1-'+role+'/qualification/';a=j(root+'first-B-ordinary/all-products.json');b=j(root+'independent-cold-B/all-products.json');initial=j(root+'parent-typed/all-products.json');assert set(a)==set(b)==set(initial)and len(a)==656
        assert all(j(root+x+'/all-products.json')==a for x in ('first-B-typed','first-B-vv','first-B-kernel'))
        d={'rlib':{},'rmeta':{},'unchanged_rustc':{},'same_source_selectors':{'public_sidecars':sum(k.endswith('.public-api-hash')for k in a)},'source_witness':[j(root+x+'-native-witness/stdout')for x in ('parent','edited','clean-child')]}
        for k in sorted(a):
            if a[k]==b[k]:continue
            x,y=raw(a[k]),raw(b[k]);stem=Path(k).name[3:].split('-')[0]
            if k.endswith('.rlib'):d['rlib'][stem]=native_archive(x,y);continue
            assert k.endswith('.rmeta');q=diff_rmeta(x,y,stem);d['rmeta'][stem]=q
            if stem=='uv_workspace':
                d['true_source_edit_provider']=Q['compare'](raw(initial[k]),x,stem)
                left,right=[M['alloc'](t,C['root'](t))for t in (x,y)]
                d['provider_allocation_provenance']={'counts':[len(k[0])for k in (left,right)],'all_memory_provenance_edges':[sum(map(len,k[2].values()))for k in (left,right)],'exact_all_encoded_records_in_order':left[0]==right[0],'exact_recursive_allocation_content_histogram':left[4]==right[4],'exact_memory_provenance_edges':left[2]==right[2],'exact_immutable_text_atoms':left[1]==right[1]}
        assert len(d['rmeta'])==16 and len(d['rlib'])==2
        for st in ('A','B'):
            n=root+st+'-unchanged-kernel-fingerprint/';v=j(n+'verified-kernel.json');tr=j(n+'link-origins.json');seen=[(argv[argv.index('--crate-name')+1],argv[argv.index('--crate-type')+1])for _,argv in v['compilers']];
            assert len(seen)==len(set(seen));d['unchanged_rustc'][st]={'names':sorted(seen),'physical_depfiles':len(tr['raw_dep_info']),'sole_phony_marker':tr['native_marker_inputs'],'source_and_generated':{k:{x:v[x]for x in ('bytes','sha256','mtime_ns')}for k,v in tr['script_source_executables_and_generated'].items()}}
        out[role]=d
    return {'sha256':A,'roles':out,'strict_eligibility':False}
if __name__=='__main__':print(json.dumps(process(),sort_keys=True,indent=2))
