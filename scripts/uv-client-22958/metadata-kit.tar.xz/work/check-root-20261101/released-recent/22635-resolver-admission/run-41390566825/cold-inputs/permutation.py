"""Replay a physical OpaqueLifetime DefIndex permutation through five true metadata representations."""
from pathlib import Path
from collections import Counter
import json,runpy,struct,zipfile
H=Path(__file__).resolve().parent
s=runpy.run_path(str(H/'points.py'));R=s['R'];C=s['C'];Q=s['Q'];di=R['sig'].di;keys=R['keys']
def need(ok,why):
    if not ok:raise ValueError(why)
def vi(data,p):
    n=0
    for i in range(10):
        q=data[p+i];n|=(q&127)<<(7*i)
        if q<128:return n,p+i+1
    raise ValueError('bad usize')
def cell(d,t,i):
    need(i<t['length'],'missing row')
    if t['sparse']:
        b,k=struct.unpack_from('<QI',d,t['position']+i//64*12);bit=i%64
        if not b>>bit&1:return None
        i=k+(b&((1<<bit)-1)).bit_count()
    return t['values_position']+i*t['width']
def span(d,p):
    tag=d[p];need(tag&3==3 and 0<tag>>3<=8,'not a backward span shorthand')
    n=tag>>3;val=int.from_bytes(d[p+1:p+1+n],'little')
    ptr=p-val if tag&4 else val
    need(0<ptr<p and d[ptr]&3!=3,'invalid span referent')
    return ptr,n+1
def encode_span(pos,target):
    offset=pos-target;need(offset>0,'invalid forward span');relative=offset<target
    val=offset if relative else target;n=max(1,(val.bit_length()+7)//8)
    return bytes([(n<<3)|(4 if relative else 0)|3])+val.to_bytes(n,'little')
def project(a,b,name,extra_corruption_check=False):
    h=C['root'](a);h2=C['root'](b);need(len(a)==len(b)and h['tables']==h2['tables'],'metadata layout differs')
    ow=di.keyed(a,h);new=di.keyed(b,h2)
    need(len(ow)==len(set(ow))and set(ow)==set(new),'identity set changed');nr={k:i for i,k in enumerate(new)};mv={i:nr[k]for i,k in enumerate(ow)if nr[k]!=i};need(mv and set(mv)==set(mv.values()),'not a pure DefIndex permutation')
    dst=bytearray(a);metric=Counter();ops=[]
    def patch(pos,data,why):
        need(pos>=0 and pos+len(data)<=len(dst),'impossible position')
        need(dst[pos:pos+len(data)]==a[pos:pos+len(data)],'overlapping edits')
        diffs=sum(x!=y for x,y in zip(a[pos:pos+len(data)],data));metric[why]+=diffs;dst[pos:pos+len(data)]=data;ops.append([pos,len(data),why,diffs])
    allptr={g:[int.from_bytes(x,'little')for x in di.rows(a,h['tables'][g])]for g in ('def_keys','def_span','def_ident_span')}
    # Map is length-prefixed by the exact Rust DefPathHashMapRef encoder. Establish
    # the unique little-endian Hash64/u32 pair of EVERY live local inside that native map.
    ln,fstart=vi(a,h['tables']['def_path_hash_map']['position']);region=a[fstart:fstart+ln]
    need(len(region)==ln and len(region)>len(ow)*12,'invalid ODHT blob')
    for oi,key in enumerate(ow):
        pair=key+oi.to_bytes(4,'little');local=region.find(pair);need(local>=0 and region.find(pair,local+1)<0,'ambiguous/nonexistent native ODHT key-value')
        if oi in mv:patch(fstart+local+8,mv[oi].to_bytes(4,'little'),'DefPathHashMap Hash64 -> DefIndex')
    for old,newidx in mv.items():
        for t in('def_path_hashes','rdr_hashes.local'):
            table=h['tables'][t];o=cell(a,table,old);n=cell(a,table,newidx)
            need((o is None)==(n is None),'sparse mask change unsupported')
            if o is not None:patch(n,a[o:o+table['width']],t)
        kp=allptr['def_keys'];dk,e=keys.key_at(a,kp[old],ow);_,ep=keys.key_at(a,kp[newidx],ow);n=kp[newidx]
        need(dk['kind']=='OpaqueLifetime'and (dk['parent']is None or bytes.fromhex(dk['parent'])not in {ow[j]for j in mv}),'non-lifetime or moved parent')
        need(e-kp[old]==ep-n,'variable size def key');patch(n,a[kp[old]:e],'DefKey, unchanged parent DefIndex')
        for k in('def_span','def_ident_span'):
            oldp,newp=allptr[k][old],allptr[k][newidx]
            need(bool(oldp)==bool(newp),'different optional span presence')
            if not oldp:continue
            target,n=span(a,oldp);_,room=span(a,newp)
            rec=encode_span(newp,target);need(len(rec)==room,'span width changes');patch(newp,rec,k+' native absolute referent')
    need(bytes(dst)==b,'additional differences beyond typed permutation')
    return {'bytes':len(a),'raw_SHA256':[Q['q']['sha'](v)for v in(a,b)],'physical_DefIndex_moves':[[o,n,ow[o].hex()]for o,n in mv.items()],'all_native_ODHT_keys_validated':len(ow),'exact_changes_by_role':dict(metric),'different_bytes':sum(metric.values()),'cold_raw_fully_reconstructed':True,'writes':ops}
def main():
    refs=[('stock_ctfe318','uv_python_interpreter'),('stock_ctfe318','uv_git'),('fa7a_stack_ctfe318','uv_python_interpreter'),('fa7a_stack_ctfe318','uv_resolver_types'),('fa7a_stack_ctfe318','uv_git')]
    ans={}
    with zipfile.ZipFile(H.parent/'original.zip')as z:
        for role,k in refs:
            a,b=s['opened'](z,role,k);v=project(a,b,k);cnt=0
            for p,_,_,n in [(128,1,'unrelated',1),*v['writes']]:
                if not n:continue
                mad=bytearray(b);mad[p]^=1
                try:project(a,bytes(mad),k)
                except (ValueError,AssertionError,KeyError,IndexError):cnt+=1
                else:raise ValueError('accepted '+str(p))
            v['corruption_controls']=cnt;ans[role+'/'+k]=v
    return ans
if __name__=='__main__':print(json.dumps(main(),sort_keys=True,indent=2))
