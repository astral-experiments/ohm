"""Locate all independently generated A input differences in the authentic resolver package archive."""
import collections,gzip,hashlib,json,runpy,sys,zipfile
from pathlib import Path
H=Path(__file__).resolve().parent;J=H.parent;R=J.parent;F=R.parent/'22635-production-discovery/actual-fingerprint-successor/run-41386773674/forensics'
q=runpy.run_path(str(F/'classify.py'));C=q['C'];S=q['S'];Q=q['Q'];A='7f0d130abaec9f2b4f5aa0e0683724887f0a9fb164d6327b3f305c1086e54ef3'
def run():
    z=zipfile.ZipFile(J/'original.zip');assert q['sha']((J/'original.zip').read_bytes())==A;rows={}
    jb=lambda n:json.loads(z.read(n))
    def read(t):v=gzip.decompress(z.read('blobs/'+t[1]+'.gz'));assert [len(v),q['sha'](v)]==t;return v
    for role in('stock_ctfe318','fa7a_stack_ctfe318'):
        ranges={}
        dirs=[role+'/'+k+'/'for k in('A-cold-typed','A-cold-ordinary')]
        wg=[jb(d+'workspace-products.json')for d in dirs];di=[jb(d+'terminal-extern-inputs.json')for d in dirs];reg=[jb(d+'registry-products.json')for d in dirs];checks={}
        for g in(wg,di,reg):
            for k,v in g[0].items():
                if k in checks or v==g[1][k]:continue
                if not all('blobs/'+z1[k][1]+'.gz'in z.namelist()for z1 in g):
                    checks[k]={'custody':False,'rows':[z1[k]for z1 in g]};continue
                x,y=[read(z1[k])for z1 in g];name=Path(k).name.removeprefix('lib').split('-')[0]
                if k.endswith('.rlib'):checks[k]={'custody':True,'ar_proof':q['native_archive'](x,y)};continue
                assert k.endswith('.rmeta')
                h,c=[C['root'](v)for v in(x,y)];m=q['diff_rmeta'](x,y,name)
                ix=[i for i in range(min(len(x),len(y)))if x[i]!=y[i]]
                sections={}
                for t,vv in h['tables'].items():
                    if vv['type']!='table':continue
                    a1,b1=vv['position'],vv['end'];a2,b2=c['tables'][t]['position'],c['tables'][t]['end']
                    if x[a1:b1]!=y[a2:b2]:sections[t]=[a1,b1,a2,b2,sum(v!=w for v,w in zip(x[a1:b1],y[a2:b2]))]
                checks[k]={'custody':True,'name':name,'is_resolver_extern':k in di[0],'raw_rows':[z1[k]for z1 in g],'byte_differences':len(ix),'runs':q['runs'](ix),'tables_with_changed_raw_rows':sections,'native':m}
        rows[role]=checks
    return {'original':A,'scope':'complete actual raw workspace and direct terminal inputs, no edit or timing sampled','roles':rows}
if __name__=='__main__':print(json.dumps(run(),indent=2,sort_keys=True))
