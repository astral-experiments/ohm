"""Resolve changed cold A bytes to original fixed metadata fields or actual nearby lazy object boundaries."""
from pathlib import Path
import bisect,collections,gzip,json,re,runpy,subprocess,zipfile
H=Path(__file__).resolve().parent
Q=runpy.run_path(str(H/'analyze.py'));q=Q['q'];C=Q['C'];R=q['S'];J=H.parent
def opened(z,role,name):
    vals=[]
    for visit in('A-cold-typed','A-cold-ordinary'):
        ns=json.loads(z.read(role+'/'+visit+'/workspace-products.json'));k,=[k for k in ns if k.endswith('.rmeta')and Path(k).name.startswith('lib'+name+'-')];data=gzip.decompress(z.read('blobs/'+ns[k][1]+'.gz'));assert q['sha'](data)==ns[k][1];vals.append(data)
    return vals
def lookup(x,name,src):
    h=C['root'](x);idx=[k.hex()for k in R['sig'].di.keyed(x,h)];defs=Q['Q']['P'](x,name)[1];bounds={}
    for n,t in h['tables'].items():
        if t['type']!='table':
            bounds.setdefault(t['position'],[]).append((n,'crate-root',str(t['type'])));continue
        if n not in src:continue
        tp=src[n]
        size=(16 if 'LazyArray<'in tp else 8)
        for i,cell in enumerate(R['sig'].di.rows(x,t)):
            if not any(cell):continue
            raw=cell.ljust(size,b'\0');pos=int.from_bytes(raw[::2]if 'LazyArray<'in tp else raw,'little')
            if not 0<pos<len(x):continue
            bounds.setdefault(pos,[]).append((n,i,(R['label'](defs,idx[i])if i<len(idx)else '?')))
    return h,idx,defs,bounds
def detail(role,name,z,src):
    x,y=opened(z,role,name);a,ix,defs,fields=lookup(x,name,src);b,iy,_,_=lookup(y,name,src)
    fixed={};octets=[]
    for n,t in a['tables'].items():
        if t['type']=='table':
            fixed.update({i:n for i in range(t['position'],t['end'])})
    starts=sorted(p for p in fields if isinstance(p,int));moved=[]
    for i,(l,r)in enumerate(zip(ix,iy)):
        if l!=r:
            moved.append([i,iy.index(l),R['label'](defs,l),l,defs[l][2]])
    for i,(l,r)in enumerate(zip(x,y)):
        if l==r:continue
        if i in fixed:continue
        p=bisect.bisect_right(starts,i);near=starts[p-1];octets.append({'offset':i,'old_new':[l,r],'old_around':x[i-3:i+4].hex(),'new_around':y[i-3:i+4].hex(),'distance':i-near,'table':fields[near][:8],'next_field':fields[starts[p]][:4]if p<len(starts)else None})
    return {'moved':moved,'unfixed':octets}
def main():
    D=H.parents[3];g=D/'released-source/stack.git';source=subprocess.check_output(['git','--git-dir='+str(g),'show','008a21ac:compiler/rustc_metadata/src/rmeta/mod.rs']).decode();mapping={n:t for n,t in re.findall(r'^    (\w+): Table<RDR\w+, \w+, (.+)>,',source,re.M)if 'LazyValue<'in t or 'LazyArray<'in t};assert 'def_keys'in mapping
    with zipfile.ZipFile(J/'original.zip')as z:
        return {role:{name:detail(role,name,z,mapping)for name in names}for role,names in [('stock_ctfe318',['uv_python_interpreter','uv_git']),('fa7a_stack_ctfe318',['uv_python_interpreter','uv_resolver_types','uv_types','uv_git'])]}
if __name__=='__main__':print(json.dumps(main(),sort_keys=True,indent=2))
