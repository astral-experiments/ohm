"""Audit candidate controls and counter eligibility before reading a single candidate guest count."""
from collections import Counter
from pathlib import Path
import gzip
import hashlib
import json
import re
import runpy

T=Path(__file__).resolve().parent;H=T.parent;D=H.parents[1]
C=runpy.run_path(str(T/"canonical.py"));Z=C["Z"];R=runpy.run_path(str(T/"role.py"));L=runpy.run_path(str(T/"lifetime_stream.py"))
GEN=runpy.run_path(str(T/"registry_schema.py"))
GEN["configure"](C,Z,L)
ODHT=runpy.run_path(str(T/"odht_wire.py"))
def read(p):return json.loads(p.read_bytes())
def sha(d):return hashlib.sha256(d).hexdigest()
def check_delta(pair1,pair2,name):
    a,b=C["raw"](pair1),C["raw"](pair2);v=Z["delta"](a,b,name);s=v["semantic"]
    headers=[Z["ROOT"](z)["actual_options"]for z in (a,b)]
    checks=dict(complete_identity_set=v["identical_stable_def_set"]and not any(s["missing_keys"]),
        exact_actual_header_options=headers[0]==headers[1],
        def_key_descriptors=not s["def_key_descriptor_differences"],all_keyed_rdr=s["changed_RDR_key_count"]==0,
        native_crate_root=all(len(set(h))==1 for h in s["header"].values()),deps=s["exact_all_dependencies"],
        source_expansions=s["exact_keyed_reachable_expansions"],ctfe=s["allocations"]["multisets_identical"],
        physical_kinds=set(s["physical_moved_classes"]).issubset({"OpaqueLifetime","SyntheticCoroutineBody","AnonAssocTy"}))
    exact=None;errors=[]
    for fn in (lambda:C["M"]["project"](a,b,name),lambda:L["project"](a,b),lambda:L["project"](a,b,rebuild_map=ODHT["def_path_hash_map"])):
        try:exact=fn();break
        except (AssertionError,ValueError,IndexError,KeyError)as err:errors.append([type(err).__name__,str(err)])
    return dict(warm=pair1,cold=pair2,checks=checks,physical_moved=s["physical_moved_classes"],definitions=s["defs"],
                dependencies=s["dependency_count"],expansions=s["keyed_reachable_expansion_counts"],
                literal_patterns=s["allocations"]["distinct"],actual_header_options=headers,exact_complete_bytes=exact is not None,
                exact_refusals=errors if exact is None else [],stable_descriptor_sha=sha(json.dumps(s["header"],sort_keys=True).encode()))
def graph_roster(src,crate,states):
    m,ks,_,_=runpy.run_path(str(D/"residual-mir/reduce.py"))["setup"]("306")
    s=("1.99.0-dev ("+src["commit"][:9]+" 2026-11-02)").encode()
    m.Graph.__init__.__globals__["HEADER"]=b"RSIC"+src["epoch"].to_bytes(2,"little")+bytes([len(s)])+s
    return [m.Graph(C["raw"](z["graphs"][crate][1]))for z in states],ks
def source_label(s):
    return re.sub(r"DefId\([0-9]+:[0-9]+ ~ ([a-zA-Z0-9_]+)\[[0-9a-f]{4}\]::",r"DefId(\1::",s)
def salted_argv(a,role):
    unit=str(H/"runtime/target/debug/build")+"/"
    actual=[]
    for arg in a:
        x=arg.replace(str(R["ROLES"][role][0]),"{verified_sdk}")
        x=re.sub(re.escape(unit)+r"([^/]+)/[0-9a-f]{16}/",r"{build}/\1/{Cargo-unit-salt}/",x)
        x=re.sub(r"(?<=/)(lib[a-zA-Z_0-9]+)-[0-9a-f]{16}(?=\.(?:rlib|rmeta|so))",r"\1-{Cargo-unit-salt}",x)
        x=re.sub(r"^(extra-filename=-|metadata=)[0-9a-f]{16}$",r"\1{Cargo-unit-salt}",x);actual.append(x)
    return actual
def route_delta(base,cand):
    ksreg=read(base/"typed.json")["owners"];cr=read(cand/"typed.json")["owners"];src=read(R["ROLES"]["callable"][0].parent/"installed.json")["source"]
    roles={};states=[read(cand/z/"products.json")for z in("A","first-B","keyed-B","fresh-B")]
    for n,known in ksreg.items():
        if n not in cr:continue
        gs,ks=graph_roster(src,n,states)
        marked={bytes.fromhex(k):w for k,w in known["stable_only_copy_named"].items()if w["local"]and w["shape"]in {"Closure","Coroutine","CoroutineWitness","CoroutineClosure","FnDef"}}
        old_labels={source_label(z["label"]):[k.hex(),z["answer"]]for k,z in marked.items()};assert len(old_labels)==len(marked)
        profile=read(cand/"keyed-B/keyed-processes.json")[n]
        pmod=runpy.run_path(str(D/"residual-mir/reduce.py"))["setup"]("306")[0]
        prof=pmod.edge.g.Profile(C["raw"](profile["self_profile"]));kg=gs[2];import struct
        observed=set();receivers={};provider_counter=Counter()
        for typ,i,*_ in struct.iter_unpack("<QQIIII",memoryview(prof.entries)[8:]):
            if prof.label(typ)=="Query"and i<kg.maximum and kg.offset(i):
                k=kg.get(i)[0]
                if ks[k[0]]in ("typeck_root","mir_borrowck","mir_built","check_well_formed","non_blanket_trait_impls"):
                    assert prof.label(i).partition("\x1e")[0]==ks[k[0]]
                    name=source_label(prof.label(i));observed.add(name);provider_counter[ks[k[0]]]+=1
                    if name in old_labels:
                        if name in receivers:assert k==receivers[name]
                        receivers[name]=k
        indexes=[g.scan(set(receivers.values()))for g in gs]if receivers else []
        actual={}
        for label,key in receivers.items():
            if not all(key in ix for ix in indexes):actual[label]=dict(status="missing native phase");continue
            values=[ix[key][1].hex()for ix in indexes];parents=[]
            for g,ix in zip(gs,indexes):
                _,_,lo,hi,width=g.get(ix[key][0])
                parents.append([ks[g.get(int.from_bytes(g.data[i:i+width],"little"))[0][0]]for i in range(lo,hi,width)])
            actual[label]=dict(candidate_key=key[1].hex(),mature_key=old_labels[label][0],candidate_native_results=values,dependencies=parents)
        both=[v["owner"]for v in known["owners"]if source_label(v["owner"])in observed]
        roles[n]=dict(prior_preselected_stable_local_keys=len(marked),candidate_provider_events=dict(provider_counter),
            old_source_keys_with_a_candidate_B_provider_event=len(receivers),
            old_source_keys_without_a_candidate_B_provider_event=len(marked)-len(receivers),edges=actual,
            known_prior_evaluated_scoped_owners=len(known["owners"]),same_in_new_observed_profile=both,first_veto_observed=False,
            comparison="full source labels; role-specific DefIds and authenticated Cargo crate salts differ; no candidate provider event does not identify the new graph node")
    return roles
def main():
    base=T/"mature-diagnostic-02";cand=T/"callable-native-01";closure=read(cand/"closed.json")
    assert closure["no_performance_observations"]and closure["dirty_kernel"]==["uv_client","uv_configuration"]
    assert sha((T/"guest-diagnostic-registration.json").read_bytes())=="a95d6f7cd08b3489698abb2ccf4ba3ab5805a2f6653619d8e012e3ee3fe465b0"
    assert [read(cand/("plan-"+st+".json"))["sha256"]for st in ("A","B")]==[read(H/"unit-plans-26210096.json")["states"]["A"]["raw_unit_graph"]]*2
    all_exact=all(not row for mode in ("bare","keyed")for row in closure["comparisons"][mode].values())
    w=read(cand/"first-B/products.json");b=read(cand/"fresh-B/products.json")
    changes={}
    for p,x in w["workspace"].items():
        y=b["workspace"][p]
        if x!=y:
            name=Path(p).name[3:].split("-")[0];changes[name]=check_delta(x,y,name)
    remaining={};foreign={}
    bypath={str(H/"runtime/target"/p):z for p,z in w["workspace"].items()}
    for n,inputs in w["externs"].items():
        remaining[n]=[]
        assert set(inputs)==set(b["externs"][n])
        for p,x in inputs.items():
            z=b["externs"][n][p]
            if x!=z:
                part=Path(p);assert part.is_absolute()and part.is_relative_to(H/"runtime/target")and part.suffix==".rmeta"and part.name.startswith("lib")
                name=part.name[3:].split("-")[0]
                if p in bypath:assert bypath[p]==x and name in changes and changes[name]["cold"]==z
                elif p in foreign:assert (foreign[p]["warm"],foreign[p]["cold"])==(x,z)
                else:foreign[p]=check_delta(x,z,name)
                remaining[n].append(p)
    previous=read(base/"first-B/selectors.json");current=read(cand/"first-B/selectors.json")
    comparable={}
    for n in sorted(previous):
        norm=lambda a,role:[x.replace(str(R["ROLES"][role][0]),"{verified_sdk}")for x in a]
        x,y=norm(previous[n],"mature"),norm(current[n],"callable")
        sx,sy=salted_argv(previous[n],"mature"),salted_argv(current[n],"callable")
        comparable[n]=dict(exact_after_sdk_root=x==y,exact_after_sdk_and_issued_unit_salts=sx==sy,argc=[len(x),len(y)],
            normalized=sx,differing_positions=[[i,u,v]for i,(u,v)in enumerate(zip(x,y))if u!=v])
    sf=read(cand/"first-B/linked-parser.json");assert sf==read(cand/"fresh-B/linked-parser.json")
    source_api=[read(cand/st/"actual-output-API.json")["schema"]for st in ("A","first-B","fresh-B")]
    assert source_api[0]["codes"]==["E0432"]and all(x["rc"]==0 and not x["codes"]for x in source_api[1:])
    pk=read(cand/"typed.json");mech=route_delta(base,cand)
    eligible=all_exact and all(z["exact_after_sdk_and_issued_unit_salts"]for z in comparable.values())and all(all(z["checks"].values())for z in [*changes.values(),*foreign.values()])
    verdict=dict(source=closure["source"],registered=sha((T/"guest-diagnostic-registration.json").read_bytes()),
        original_six_pair_hardware_eligible=False,original_cold_byte_gate_failed=True,diagnostic_guest_eligible=eligible,
        exact_same_seed_bare_kernel_profiled=all_exact,actual_argv=comparable,absolute_inputs=dict(control=read(base/"first-B/products.json")["externs"],candidate=w["externs"]),
        unscored_native_candidate_freeze=sha((cand/"closed.json").read_bytes()),candidate_cold_differences=changes,
        changed_cold_externs=remaining,independent_registry_inputs=foreign,source_and_native_linked=sf,
        actual_emitted_production_A_B_B_schema_rc=[x["rc"]for x in source_api],
        scoped_query_mechanism=mech,actual_cold_raw_guarantee="only where the corresponding raw hashes agree or exact reconstruction explicitly passed")
    f=cand/"guest-eligibility.json";data=(json.dumps(verdict,sort_keys=True,separators=(",",":"))+"\n").encode()
    if f.exists():assert f.read_bytes()==data
    else:f.write_bytes(data)
    print("diagnostic eligibility",eligible,"cold-diff",list(changes),"same-seed",all_exact,"argv",{n:z["exact_after_sdk_and_issued_unit_salts"]for n,z in comparable.items()})
    print({n:{k:v for k,v in z.items()if k not in ("edges","same_in_new_observed_profile")}|{"same_prior_roots":len(z["same_in_new_observed_profile"])}for n,z in mech.items()})
if __name__=="__main__":main()
