"""Analyze every product from the second complete ordinary baseline, including all real direct externs."""
from collections import Counter
from pathlib import Path
import gzip
import hashlib
import json
import re
import runpy

T=Path(__file__).resolve().parent;H=T.parent;D=H.parents[1];Z=runpy.run_path(str(H/"semantic_bytes.py"))
M=runpy.run_path(str(D/"released-recent/22635-resolver-admission/run-41390566825/cold-inputs/permutation.py"))
E=runpy.run_path(str(D/"rustc-pmu-thread/exec_events.py"))
def read(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(p):
    result=gzip.decompress((T/"blobs"/(p[1]+".gz")).read_bytes());assert len(result)==p[0]and sha(result)==p[1];return result
def main():
    q=T/"mature-diagnostic-02";orig=H/"native26210096"
    w=read(q/"first-B/products.json");b=read(q/"fresh-B/products.json");s=read(q/"keyed-B/products.json")
    assert all(w[key]==s[key]for key in ("workspace","owners","externs"))
    W=w["workspace"];B=b["workspace"];assert W.keys()==B.keys()and len(W)==39
    diff={};cases={}
    for k in W:
        assert raw(W[k])and raw(B[k])
        if W[k]!=B[k]:diff[k]=(W[k],B[k])
    named_inputs={}
    for crate,z in w["externs"].items():
        assert set(z)==set(b["externs"][crate]);named_inputs[crate]=[]
        for key in z:
            a=z[key];c=b["externs"][crate][key];assert raw(a)and raw(c)
            if a!=c:
                p=Path(key).relative_to(H/"runtime/target").as_posix()
                assert diff[p]==(a,c)
                named_inputs[crate].append(p)
    for p,(wa,cb) in diff.items():
        name=Path(p).name[3:].split("-")[0];assert p.endswith(".rmeta")
        a,c=raw(wa),raw(cb);check=Z["delta"](a,c,name)
        try:
            exact=M["project"](a,c,name,extra_corruption_check=True)
            check["exact_reconstruction"]=exact
        except (AssertionError,ValueError,KeyError)as exc:
            check["exact_reconstruction_refusal"]=[type(exc).__name__,str(exc)]
        cases[name]=dict(path=p,warm=wa,cold=cb,actual=check)
    e=E["decode"](read(q/"cold-kernel-request/kernel-events.json"))
    native=[im for im in e["images"]if "--crate-name"in im.get("argv",[])and any(x.startswith("--emit")for x in im["argv"])]
    assert all(e["exits"][x["pid"]]==0 for x in native)
    counts=Counter(x["argv"][x["argv"].index("--crate-name")+1]for x in native)
    plan=json.loads(gzip.decompress((H/"unit-A.json.gz").read_bytes()))
    expected=Counter(u["target"]["name"].replace("-","_")for u in plan["units"]if u["mode"]!="run-custom-build")
    assert not (expected-counts),(expected-counts)
    bypid={v["pid"]:v for v in e["images"]};extras={}
    for n,count in (counts-expected).items():
        assert count==1 and re.fullmatch(r"autocfg_[0-9a-f]{16}_[0-9]+",n),n
        matched,=[v for v in native if v["argv"][v["argv"].index("--crate-name")+1]==n]
        a=matched["argv"];parent=bypid[e["births"][matched["pid"]]]
        assert a[1:4]==["--crate-name",n,"--crate-type=lib"] and "-"in a and "--emit=llvm-ir"in a
        assert Path(parent["exe"]).name=="build_script_build"
        outdir=Path(a[a.index("--out-dir")+1]);assert outdir.name=="out" and outdir.parent.parent.name in {"num-traits","fs-err"}
        extras[n]=dict(argv=a,parent=parent["exe"],exit=e["exits"][matched["pid"]])
    assert len(extras)==3 and len(native)-len(extras)==sum(expected.values())
    warm=read(q/"first-B/selectors.json");cold=read(q/"fresh-B/native-process.json")["picked"]
    threads={n:{"warm":[x for x in warm[n]if x.startswith("-Zthreads=")]if n in warm else None,
                "cold":[x for x in cold[n]["argv"]if x.startswith("-Zthreads=")]}for n in cold}
    original=read(orig/"result.json");intake=[read(orig/st/"products.json")["metadata"]for st in ("first-B","fresh-B")]
    sources={p:[(T/"blobs"/(r[p]["sha256"]+".gz")).is_file()for r in intake] for p in original["warm_cold_difference"]}
    result=dict(source=sha((H/"source.json").read_bytes()),registered=sha((T/"registration.json").read_bytes()),
        native_closure=sha((q/"closed.json").read_bytes()),original_gate=sha((orig/"result.json").read_bytes()),
        all_cold_completed_compilers=len(native),planned_compiler_units=sum(expected.values()),build_script_autocfg_compiler_probes=extras,
        all_543_units_exactly_reconciled=len(plan["units"]),actual_threads=threads,
        all_native_keyed_same_seed_material=True,direct_extern_counts={n:len(z)for n,z in w["externs"].items()},
        differing_cold_externs=named_inputs,original_mismatch_custody_in_second_bank=sources,
        comparisons=cases)
    dest=q/"canonical.json";data=(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n").encode()
    if dest.exists():assert dest.read_bytes()==data
    else:dest.write_bytes(data)
    print(sha(data),counts.total(),threads)
    for n,z in cases.items():
        s=z["actual"]["semantic"]
        print(n,s["defs"],s["physical_moved_classes"],s["changed_RDR_key_count"],s["def_key_descriptor_differences"],
              s["exact_all_dependencies"],s["exact_keyed_reachable_expansions"],s["allocations"]["multisets_identical"],
              z["actual"].get("exact_reconstruction_refusal"))
if __name__=="__main__":main()
