"""Retain all actual workspace bytes and terminal externs while opening a genuine warmed history."""
from pathlib import Path
import fcntl
import gzip
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import sys

T=Path(__file__).resolve().parent;H=T.parent;D=H.parents[1]
P=runpy.run_path(str(H/"plan.py"));S=P["S"];E=runpy.run_path(str(D/"rustc-pmu-thread/exec_events.py"))
PRIMARY=runpy.run_path(str(H/"native.py"))
MNT=H/"runtime";TARGET=MNT/"target";G=2**30
ROLES={"mature":(P["SDK"],P["INSTALL_SHA"],"26210096e48c5c62ef4a5e8fd1aa612631b2f7d7"),
       "callable":(D/"ohm-session-parser/callable-21041-hardware/run-41395027122/child/sdk",
                   "911af5d9074a74cd35b36ded014af495c3de7da255ca7b629a2bd06f9d96ca01","f22825348d834ad9a8ef3934647181fb69f778ae")}
ORACLE="9ea7f68f5812b671a5546440742aa5e10acdd7529e4f6ed7f8bb55111c785ac0"

def sha(p):
    with p.open("rb")as f:return hashlib.file_digest(f,"sha256").hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):
    with p.open("x")as f:json.dump(x,f,sort_keys=True,separators=(",",":"));f.write("\n")
def blob(f):
    original=f.read_bytes();ck=hashlib.sha256(original).hexdigest();b=T/"blobs"/(ck+".gz")
    if not b.exists():b.write_bytes(gzip.compress(original,compresslevel=2,mtime=0))
    assert hashlib.sha256(gzip.decompress(b.read_bytes())).hexdigest()==ck
    return [f.stat().st_size,ck]
def execute(a,e,where,default=True):
    with (where/"stdout").open("xb")as out,(where/"stderr").open("xb")as err:
        p=subprocess.run(list(map(str,a)),cwd=S["SOURCE"],env=e,stdout=out,stderr=err,timeout=2700)
    save(where/"return.json",dict(argv=list(map(str,a)),rc=p.returncode))
    assert p.returncode==0,(p.returncode,(where/"stderr").read_text(errors="replace")[-1200:])
def capture(where,argv,e,sdk):
    E["capture"](where,argv,e,str(S["SOURCE"]),E["file_id"](sdk/"bin/rustc"))
    d=E["decode"](read(where/"kernel-events.json"));assert d["exits"][d["root"]]==0
    selected={}
    for x in d["images"]:
        a=x.get("argv",[])
        if "--crate-name" not in a:continue
        n=a[a.index("--crate-name")+1];assert x["file"]==E["file_id"](sdk/"bin/rustc") and d["exits"][x["pid"]]==0
        assert n not in selected and a[0]==str(sdk/"bin/rustc")
        selected[n]=a
    assert set(selected)=={"uv_client","uv_configuration"},sorted(selected)
    save(where/"selectors.json",selected)
    return selected
def extern_paths(a):
    for i,v in enumerate(a):
        item=a[i+1]if v=="--extern" else v[9:]if v.startswith("--extern=")else None
        if item is not None and "=" in item:
            _,s=item.split("=",1);p=Path(s);assert p.is_absolute()and p.is_file(),item
            yield p
def snap(d,sdk,env,labels):
    work=set(read(H/"unit-plans-26210096.json")["states"]["A"]["workspace_packages"])
    rows={}
    for f in sorted((TARGET/"debug").rglob("libuv_*.rmeta")):
        name=f.name.split("-")[0][3:].replace("_","-")
        if name in work:rows[str(f.relative_to(TARGET))]=blob(f)
    assert len(rows)==39
    graph={};owned={}
    for n in ("uv_client","uv_configuration"):
        fs=[TARGET/z for z in rows if Path(z).name.startswith("lib"+n+"-")]
        assert len(fs)==1,n
        graphfiles=[g for g in TARGET.rglob("dep-graph.bin")if g.parent.parent.name.startswith(n+"-")];assert len(graphfiles)==1,n
        graph[n]=[str(graphfiles[0].relative_to(TARGET)),blob(graphfiles[0])]
        root=d/(n+"-root");root.mkdir();execute([sdk/"bin/rustc","-Zls=root",fs[0]],env,root)
        owned[n]=dict(rmeta=blob(fs[0]),header=sha(root/"stdout"))
    externs={}
    for n,a in labels.items():
        externs[n]={str(f):blob(f)for f in sorted(set(extern_paths(a)))}
    doc=dict(workspace=rows,owners=owned,graphs=graph,externs=externs)
    save(d/"products.json",doc);return doc
def freeze(path):
    assert TARGET.is_dir() and TARGET.parent==MNT and not path.exists()
    assert shutil.disk_usage(H).free>=25*G
    subprocess.run(["tar","--format=posix","-I","zstd -1 -T2","-cf",str(path),"-C",str(MNT),"target"],check=True)
    assert 1<<20<path.stat().st_size<3*G and shutil.disk_usage(H).free>=22*G
    return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
def restore(reg):
    path=Path(reg["path"]);assert path.is_file() and sha(path)==reg["sha256"]
    if TARGET.exists():
        assert TARGET.parent==MNT and os.path.ismount(MNT);shutil.rmtree(TARGET)
    subprocess.run(["tar","-I","zstd -d -T2","-xf",str(path),"-C",str(MNT)],check=True)
    assert (TARGET/"debug").is_dir()
def setup(role):
    sdk,h,commit=ROLES[role];assert sha(sdk.parent/"installed.json")==h and read(sdk.parent/"installed.json")["source"]["commit"]==commit
    assert sha(T/"registration.json")==ORACLE and P["h"](P["CARGO"].read_bytes())==P["CARGO_SHA"]
    assert os.path.ismount(MNT) and 12*G<=shutil.disk_usage(MNT).total<=16*G and shutil.disk_usage(H).free>24*G
    (MNT/"tmp").mkdir(exist_ok=True);os.environ["TMPDIR"]=str(MNT/"tmp")
    e=P["env"](TARGET);e.update(RUSTC=str(sdk/"bin/rustc"),RUSTDOC=str(sdk/"bin/rustdoc"),
       PATH=str(sdk/"bin")+":/usr/bin:/bin",LD_LIBRARY_PATH=str(sdk/"lib"),TMPDIR=str(MNT/"tmp"))
    assert set(e).isdisjoint({"RUSTC_WRAPPER","CARGO_ENCODED_RUSTFLAGS","RUSTFLAGS","CARGO_LOG"})
    if role=="callable":assert read(T/"mature-admission.json")["eligible"],"hold until independent baseline admission"
    return sdk,e,[str(P["CARGO"]),*P["COMMAND"]]
def main(role):
    sdk,e,argv=setup(role);q=T/(role+"-diagnostic-01");assert not q.exists()and not TARGET.exists()
    q.mkdir();(T/"blobs").mkdir(exist_ok=True);v={}
    def folder(z):
        d=q/z;d.mkdir();return d
    S["check"]("A")
    try:
        a=folder("A");execute(argv,e,a);v["A"]=snap(a,sdk,e,{})
        seed=freeze(q/"target-A.tar.zst");save(q/"seed.json",seed)
        S["change"]("B");n=folder("first-B");labels=capture(n,argv,e,sdk);v["first-B"]=snap(n,sdk,e,labels)
        # Revisit the same A after the ordinary B, preserving all direct inputs/physical products before requesting telemetry.
        restore(seed);ap=folder("restored-A");v["restored-A"]=snap(ap,sdk,e,labels)
        assert all(v["A"][key]==v["restored-A"][key] for key in ("workspace","owners","graphs"))
        k=folder("keyed-B");diag=MNT/"keyed-evidence";diag.mkdir()
        ke=dict(e,RUSTC_WRAPPER=str(T/"wrapper.py"),OHM22958_MODE="keyed",
                OHM22958_SELECTOR=str(n/"selectors.json"),OHM22958_DIAGNOSTIC=str(diag))
        execute(argv,ke,k);v["keyed-B"]=snap(k,sdk,e,labels)
        markers={}
        for name,commands in labels.items():
            marker=read(diag/(name+".json"));assert marker["original"]==commands and marker["cwd"]==str(S["SOURCE"])
            assert marker["executed"][:len(commands)]==commands and len(marker["executed"])==len(commands)+2
            profile,=diag.glob(name+"-*.mm_profdata");assert int(profile.stem.split("-")[-1])==marker["pid"]
            markers[name]={"process":marker,"self_profile":blob(profile)}
        save(k/"keyed-processes.json",markers)
        # Keep diagnosed divergences rather than ending before the independent cold B.
        c=folder("fresh-B");assert os.path.ismount(MNT);shutil.rmtree(TARGET)
        execute(argv,e,c);v["fresh-B"]=snap(c,sdk,e,labels)
        comparisons={}
        for other in ("keyed-B","fresh-B"):
            comparisons[other]={}
            for cat in ("workspace","owners","externs"):
                l=v["first-B"][cat];r=v[other][cat];assert set(l)==set(r)
                comparisons[other][cat]=[k for k in l if l[k]!=r[k]]
        save(q/"closed.json",dict(role=role,source=ROLES[role][2],registered=ORACLE,
             native_kernel=sha(n/"kernel-events.json"),actual_dirty=sorted(labels),seed=seed,
             materials={phase:sha(q/phase/"products.json")for phase in v},comparisons=comparisons,
             no_score=True))
    finally:
        if S["git"]("diff","--name-only"):S["change"]("A")
if __name__=="__main__":
    assert len(sys.argv)==2 and sys.argv[1]in ROLES
    with (T/"source-lease").open("a")as lease:
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);main(sys.argv[1])
