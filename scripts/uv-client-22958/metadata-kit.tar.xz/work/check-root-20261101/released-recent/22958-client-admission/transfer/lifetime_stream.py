"""Reproduce variable-length, re-ordered rustc DefKey/span streams from the first-B bytes."""
from pathlib import Path
import gzip
import hashlib
import json
import runpy

T=Path(__file__).resolve().parent
C=runpy.run_path(str(T/"canonical.py"));M=C["M"];di=M["di"];keys=M["keys"]
def require(x,msg):
    if not x:raise ValueError(msg)
def project(warm,cold):
    r=M["C"]["root"](warm);s=M["C"]["root"](cold);t=r["tables"];v=di.keyed(warm,r);u=di.keyed(cold,s)
    require(len(warm)==len(cold) and t==s["tables"] and len(v)==len(set(v)) and set(v)==set(u),"layout or identities")
    dst=bytearray(warm);occupied={};metrics={}
    def emit(pos,data,name):
        require(pos>=0 and pos+len(data)<=len(dst),"offset")
        for j,val in enumerate(data,pos):
            require(j not in occupied or occupied[j]==val,"conflicting projections")
            occupied[j]=val
        before=dst[pos:pos+len(data)];dst[pos:pos+len(data)]=data
        metrics[name]=metrics.get(name,0)+sum(x!=y for x,y in zip(before,data))
    reverse={k:i for i,k in enumerate(v)};order=[reverse[k]for k in u]
    moved={j for j,i in enumerate(order)if i!=j};require(moved and set(order[j]for j in moved)==moved,"not a permutation")
    first,last=min(moved),max(moved)
    idx=range(first,last+1);require(moved.issubset(idx),"run")
    addrs={n:[int.from_bytes(x,"little")for x in di.rows(warm,t[n])]for n in ("def_keys","def_span","def_ident_span")}
    records={}
    for i in idx:
        p=addrs["def_keys"][i];d,end=keys.key_at(warm,p,v)
        require(d["kind"]=="OpaqueLifetime" and(d["parent"]is None or bytes.fromhex(d["parent"])not in {v[j]for j in moved}),"non-lifetime or moved parent")
        records[i]=warm[p:end]
        if i<last:require(end==addrs["def_keys"][i+1],"noncontiguous variable-size primary keys")
    def put_cell(table,phys,data):
        pos=M["cell"](warm,t[table],phys);require(pos is not None,"unrepresented sparse cell")
        emit(pos,data,table)
    def ptr(table,phys,n):put_cell(table,phys,n.to_bytes(t[table]["width"],"little"))
    key_start=keypos=addrs["def_keys"][first]
    for j in idx:
        old=order[j];ptr("def_keys",j,keypos);emit(keypos,records[old],"serialized DefKey with unchanged parent")
        keypos+=len(records[old])
    require(keypos==addrs["def_keys"][last]+len(records[last]),"variable key section length")
    # Verify the actual warm position stream before independently encoding the
    # permuted sequence. No cold addresses, bytes or widths drive the reconstruction.
    notes={};cursor=addrs["def_span"][first];spanstart=cursor
    for i in idx:
        for name in ("def_span","def_ident_span"):
            q=addrs[name][i];require(q==cursor,"unexpected/interleaved span input")
            to,size=M["span"](warm,q);require(to<spanstart,"span target inside moving region")
            notes[(i,name)]=to;cursor+=size
    endspan=cursor;cursor=spanstart
    for j in idx:
        for name in ("def_span","def_ident_span"):
            dest=notes[(order[j],name)];encoded=M["encode_span"](cursor,dest)
            ptr(name,j,cursor);emit(cursor,encoded,"span shorthand to unchanged actual source span");cursor+=len(encoded)
    require(cursor==endspan,"length-changing span section")
    for name in ("def_path_hashes","rdr_hashes.local"):
        table=t[name]
        for j in idx:
            left,right=[M["cell"](warm,table,i)for i in (order[j],j)]
            require((left is None)==(right is None),"moved sparse mask")
            if right is not None:emit(right,warm[left:left+table["width"]],name)
    length,start=M["vi"](warm,t["def_path_hash_map"]["position"]);area=warm[start:start+length];require(len(area)==length,"ODHT bounds")
    new={key:j for j,key in enumerate(u)}
    for i,key in enumerate(v):
        needle=key+i.to_bytes(4,"little");hit=area.find(needle);require(hit>=0 and area.find(needle,hit+1)<0,"ODHT keys")
        if new[key]!=i:emit(start+hit+8,new[key].to_bytes(4,"little"),"native ODHT Hash64 to DefIndex")
    require(bytes(dst)==cold,"residual bytes outside the typed transformation")
    return dict(verified_all_original_ODHT_rows=len(v),moved=len(moved),defkey_span=[key_start,keypos],span_span=[spanstart,endspan],
        check_sha256=hashlib.sha256(dst).hexdigest(),bytes=len(dst),different_bytes=sum(metrics.values()),metric=metrics)
def main():
    q=T/"mature-diagnostic-02";records=C["read"](q/"canonical.json")["comparisons"];r=records["uv_configuration"]
    a,b=C["raw"](r["warm"]),C["raw"](r["cold"]);v=project(a,b);fail=0
    for ix in (128,v["defkey_span"][0],v["span_span"][0],len(b)-57):
        hostile=bytearray(b);hostile[ix]^=1
        try:project(a,bytes(hostile))
        except (ValueError,AssertionError,IndexError):fail+=1
    require(fail==4,"accepted altered input");v["hostile_refusals"]=fail
    path=q/"variable-lifetime-reconstruction.json";data=(json.dumps(v,sort_keys=True,indent=2)+"\n").encode()
    if path.exists():assert path.read_bytes()==data
    else:path.write_bytes(data)
    print(v)
if __name__=="__main__":main()
