"""Read the actual CrateRoot options and edition for both registry and workspace crates."""
from pathlib import Path
from types import FunctionType,ModuleType
import hashlib
import inspect
import re

def adjusted(original):
    def read(self):
        assert self.byte()==0
        target=self.string();private,public=self.fingerprint(),self.fingerprint();form,name=self.symbol()
        assert self.raw(2)==bytes(2)
        extra=self.string();stable=self.raw(8)[::-1].hex()
        required=self.byte();assert required in (0,1)
        strategy=self.byte()if required else None;assert strategy in (None,0,1)
        drop=self.byte();edition=self.byte();booleans=self.raw(4)
        assert drop in (0,1)and 0<=edition<=3 and all(v in (0,1)for v in booleans)
        src=original.source;fields=src[src.index("    externally_implementable_items: LazyArray"):src.index("    impls: EncodedTraitImpls")]
        for field in re.findall(r"^    (\w+): LazyArray<",fields,re.M):self.array(field)
        assert self.u()in (0,1)
        for f in ("impls","incoherent_impls","interpret_alloc_index"):self.array(f)
        assert self.byte()==0,"a proc macro requires its own documented payload schema"
        for f in ("debugger_visualizers","exportable_items","stable_order_of_exportable_impls","exported_non_generic_symbols","exported_generic_symbols"):self.array(f)
        for f in original.table_names+["syntax_contexts","expn_data","expn_hashes"]:self.table(f)
        self.value("def_path_hash_map");self.table("source_map");self.array("target_modifiers");self.array("denied_partial_mitigations")
        tail=self.raw(9);assert self.byte()==1,"a missing per-definition RDR table cannot be used as an affirmative equality"
        self.table("rdr_hashes.local");self.table("rdr_hashes.expn");global_hash=self.fingerprint()
        assert self.d[self.p:]==b"rust-end-file"
        return dict(target=target,crate_name=name,symbol_form=form,private_svh=private,public_svh=public,extra_filename=extra,
            stable_crate_id=stable,root=self.root,root_sha256=hashlib.sha256(self.d[self.root:self.p]).hexdigest(),
            global_public_hash=global_hash,tables=self.tables,actual_options=[required,strategy,drop,edition,booleans.hex(),tail.hex()])
    return read
def configure(*contexts):
    work=Path(__file__).resolve().parents[4]
    seen=set();todo=list(contexts);types=set()
    def inside(d):
        file=d.get("__file__","")
        return isinstance(file,(str,Path))and Path(file).resolve().is_relative_to(work)
    while todo:
        obj=todo.pop()
        if id(obj)in seen:continue
        seen.add(id(obj))
        for v in obj.values():
            if isinstance(v,dict)and "__file__"in v and inside(v):todo.append(v)
            elif isinstance(v,FunctionType)and inside(v.__globals__):todo.append(v.__globals__)
            elif isinstance(v,ModuleType)and inside(vars(v)):todo.append(vars(v))
            elif isinstance(v,type)and v.__name__=="Reader21":types.add(v)
    assert types
    for r in types:
        f=r.read
        if f.__module__==__name__ and f.__qualname__.startswith("adjusted."):continue
        source=inspect.getsource(f)
        assert "self.raw(7)=="in source and "'rdr_hashes.expn'"in source
        original=f.__globals__["original"];assert all(field in original.source for field in
            ("required_panic_strategy: Option<PanicStrategy>","panic_in_drop_strategy: PanicStrategy","edition: Edition",
             "has_global_allocator: bool","has_default_lib_allocator: bool"))
        r.read=adjusted(original)
