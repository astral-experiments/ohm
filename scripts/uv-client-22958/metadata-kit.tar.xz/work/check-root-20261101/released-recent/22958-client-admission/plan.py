"""Compare the two source-true Cargo unit graphs and preserve both original signed streams."""
from collections import deque
from pathlib import Path
import gzip
import hashlib
import json
import os
import runpy
import subprocess

H=Path(__file__).resolve().parent
D=H.parents[1]
S=runpy.run_path(str(H/"source.py"))
SRC=S["SOURCE"]
OFFICIAL=D/"released-sdk/sdk"
SDK=D/"remainder/virtual-project-impl/stage1/run-41371136314/child/sdk"
CARGO=OFFICIAL/"bin/cargo"
COMMAND=["check","-p","uv-client","--locked","--offline","-j8"]
CARGO_SHA="3ce4e300d4463dfc769b6c18e138d1c951b02dfb15416a39cb5301303d168871"
INSTALL_SHA="05c0fc4aafb700feacf28d0f56c24de1f36287d47efedf33da5982a744f92c3d"
def h(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,b):
    if p.exists():assert p.read_bytes()==b,p
    else:p.write_bytes(b)
def dump(p,x):write(p,(json.dumps(x,sort_keys=True,indent=2)+"\n").encode())

def env(target):
    private=H/"home";private.mkdir(exist_ok=True)
    return {"HOME":str(private),"PATH":str(SDK/"bin")+":/usr/bin:/bin","LD_LIBRARY_PATH":str(SDK/"lib"),
            "RUSTC":str(SDK/"bin/rustc"),"RUSTDOC":str(SDK/"bin/rustdoc"),
            "CARGO_HOME":str(H/"cargo-home"),"CARGO_TARGET_DIR":str(target),
            "RUSTC_BOOTSTRAP":"1","CARGO_NET_OFFLINE":"true","CARGO_CACHE_AUTO_CLEAN_FREQUENCY":"never",
            "GIT_CONFIG_GLOBAL":"/dev/null","GIT_CONFIG_NOSYSTEM":"1","GIT_NO_LAZY_FETCH":"1",
            "GIT_ALLOW_PROTOCOL":"file","LC_ALL":"C"}

def owner(u):
    path=Path(u["target"]["src_path"])
    return path.relative_to(SRC/"crates").parts[0] if path.is_relative_to(SRC/"crates") else None

def main():
    assert h(CARGO.read_bytes())==CARGO_SHA and h((SDK.parent/"installed.json").read_bytes())==INSTALL_SHA
    assert (H/"registry.json").is_file()
    argv=[str(CARGO),*COMMAND,"--unit-graph","-Zunstable-options"]
    e=env(H/"plan-target");rows={};raws={}
    S["check"]("A")
    try:
        for state in ("A","B"):
            source=S["check"]("A") if state=="A" else S["change"]("B")
            proc=subprocess.run(argv,cwd=SRC,env=e,capture_output=True,timeout=360)
            write(H/("unit-"+state+".stderr"),proc.stderr)
            if proc.returncode:raise RuntimeError(proc.stderr.decode(errors="replace")[-2400:])
            g=json.loads(proc.stdout);raws[state]=proc.stdout
            write(H/("unit-"+state+".json.gz"),gzip.compress(proc.stdout,mtime=0))
            u=g["units"];roots=g["roots"];assert len(roots)==1 and owner(u[roots[0]])=="uv-client"
            seen={roots[0]};queue=deque([(roots[0],[])])
            paths={}
            while queue:
                idx,parents=queue.popleft();path=parents+[idx]
                if owner(u[idx]) is not None:paths.setdefault(owner(u[idx]),[owner(u[j]) for j in path])
                for dep in u[idx]["dependencies"]:
                    j=dep["index"]
                    if j not in seen:seen.add(j);queue.append((j,path))
            assert len(seen)==len(u)
            changed={k.split("/")[1]for k in S["CHANGED"] if k.startswith("crates/")}
            participants={k:[dict(unit=i,features=x["features"],target=x["target"]["name"],mode=x["mode"])
                              for i,x in enumerate(u)if owner(x)==k]for k in sorted(changed)}
            assert set(k for k,v in participants.items()if v)=={"uv-configuration"}
            root=u[roots[0]]
            assert paths["uv-configuration"]==["uv-client","uv-configuration"]
            rows[state]=dict(tree=source["tree"],root_idx=roots[0],root_name=root["target"]["name"],
                             root_features=root["features"],registry_names=len({x["pkg_id"]for x in u if owner(x)is None}),
                             all_units=len(u),workspace_units=sum(owner(x)is not None for x in u),
                             workspace_packages=sorted(paths),source_participation=participants,
                             shortest_provider_chain=paths["uv-configuration"],raw_unit_graph=h(proc.stdout))
    finally:
        if S["git"]("diff","--name-only"):S["change"]("A")
    assert raws["A"]==raws["B"]
    result=dict(command=argv, cargo_sha=CARGO_SHA, installed=INSTALL_SHA, registry=h((H/"registry.json").read_bytes()),
                source=h((H/"source.json").read_bytes()),identical_raw_unit_graph=True,states=rows)
    dump(H/"unit-plans-26210096.json",result);return result

if __name__=="__main__":print(json.dumps(main(),indent=2))
