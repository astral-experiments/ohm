"""Unscored mature-stack plain check at three source histories, on a private capped tmpfs."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import sys

H=Path(__file__).resolve().parent
P=runpy.run_path(str(H/"plan.py"))
S=P["S"];ROOT=P["SRC"];SDK=P["SDK"];CARGO=P["CARGO"]
MNT=H/"runtime";TARGET=MNT/"target"
ENV=P["env"](TARGET); DUMP=P["dump"]; read=P["read"]; h=P["h"]
OUT=H/"native26210096"
GiB=1024**3

def digest(path):
    with path.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def record(src,dst):
    raw=src.read_bytes();dst.write_bytes(gzip.compress(raw,compresslevel=2,mtime=0))
    return dict(path=str(src.relative_to(TARGET)),bytes=len(raw),sha256=h(raw),compressed_sha256=digest(dst))
def run(argv,path,expected=0,env=None,cwd=None):
    with path.with_suffix(".stdout").open("wb") as out,path.with_suffix(".stderr").open("wb") as err:
        p=subprocess.run(list(map(str,argv)),cwd=cwd or ROOT,env=env or ENV,stdout=out,stderr=err,timeout=2400)
    DUMP(path.with_suffix(".return.json"),dict(argv=list(map(str,argv)),cwd=str(cwd or ROOT),code=p.returncode))
    if p.returncode!=expected:
        raise RuntimeError((path,p.returncode,path.with_suffix(".stderr").read_text(errors="replace")[-1500:]))

def source_meta(state):
    return S["check"](state)

def phase(label,state):
    current=source_meta(state)
    d=OUT/label;d.mkdir()
    # The registered command is bare, with no message extension, wrapper or query options.
    argv=[CARGO,*P["COMMAND"]]
    assert set(ENV).isdisjoint({"RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","CARGO_LOG"})
    run(argv,d/"cargo")
    metadata={}
    names=set(read(H/"unit-plans-26210096.json")["states"][state]["workspace_packages"])
    for f in sorted((TARGET/"debug").rglob("libuv_*.rmeta")):
        crate=f.name.split("-")[0][3:].replace("_","-")
        if crate not in names:continue
        metadata[str(f.relative_to(TARGET))]=dict(sha256=digest(f),bytes=f.stat().st_size,owner=crate)
    owners={}
    for crate in ("uv-client","uv-configuration"):
        stem=crate.replace("-","_");fs=[TARGET/p for p,x in metadata.items() if x["owner"]==crate]
        # Cargo's check-output projection can include identical physical files in two known target lanes.
        assert len(fs)>0 and len({digest(f) for f in fs})==1,(crate,fs)
        rm=fs[0]
        graphs=[g for g in TARGET.rglob("dep-graph.bin")if g.parent.parent.name.startswith(stem+"-")]
        assert len(graphs)==1,(crate,graphs)
        z=d/(crate+"-root")
        run([SDK/"bin/rustc","-Zls=root",rm],z)
        assert (z.with_suffix(".stdout").stat().st_size)>100
        owners[crate]=dict(rmeta=record(rm,d/(crate+".rmeta.gz")),dep_graph=record(graphs[0],d/(crate+".dep-graph.bin.gz")),
                           fingerprint_file=[str(x.relative_to(TARGET)) for x in TARGET.rglob("lib-"+stem+".json")],
                           header=digest(z.with_suffix(".stdout")))
    assert metadata and len({x["owner"]for x in metadata.values()})>=30
    DUMP(d/"products.json",dict(source=current,metadata=metadata,owners=owners))
    print(label,len(metadata),flush=True)

def main():
    assert digest(CARGO)==P["CARGO_SHA"] and digest(SDK.parent/"installed.json")==P["INSTALL_SHA"]
    assert read(SDK.parent/"installed.json")["source"]["commit"]=="26210096e48c5c62ef4a5e8fd1aa612631b2f7d7"
    assert not OUT.exists() and os.path.ismount(MNT)
    assert shutil.disk_usage(MNT).total<=16*GiB and shutil.disk_usage(MNT).free>=12*GiB
    assert shutil.disk_usage(H).free>=25*GiB and not (TARGET/"debug").exists()
    (MNT/"tmp").mkdir();os.environ["TMPDIR"]=str(MNT/"tmp");ENV["TMPDIR"]=os.environ["TMPDIR"]
    OUT.mkdir();DUMP(OUT/"guard.json",dict(bytes=shutil.disk_usage(MNT).total,runner="private size-limited tmpfs",
         source=h((H/"source.json").read_bytes()),registry=h((H/"registry.json").read_bytes()),
         unit_plan=digest(H/"unit-plans-26210096.json"),installed=P["INSTALL_SHA"],signed_cargo=P["CARGO_SHA"]))
    source_meta("A")
    try:
        phase("A","A");S["change"]("B");phase("first-B","B")
        run([CARGO,"clean","--offline"],OUT/"clean")
        assert not (TARGET/"debug").exists()
        phase("fresh-B","B")
        warm=read(OUT/"first-B/products.json");cold=read(OUT/"fresh-B/products.json")
        assert warm["metadata"].keys()==cold["metadata"].keys()
        changes=[p for p in warm["metadata"] if warm["metadata"][p]!=cold["metadata"][p]]
        DUMP(OUT/"result.json",dict(ordinary_checks=3,unchanged_index=S["A"],no_performance_observations=True,
             workspace_metadata=len(warm["metadata"]),warm_cold_difference=changes,
             roots={k:dict(warm=warm["owners"][k]["rmeta"]["sha256"],cold=cold["owners"][k]["rmeta"]["sha256"])
                    for k in warm["owners"]}))
    finally:
        if S["git"]("diff","--name-only"):S["change"]("A")

if __name__=="__main__":main()
