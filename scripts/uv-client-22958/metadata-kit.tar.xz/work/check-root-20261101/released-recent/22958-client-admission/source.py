"""Reconstruct nearby authentic Git tags and retain the full selected working-tree edit."""
from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile


HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DONOR=ROOT.parent/"uv-inherent-edit-history.git"
SOURCE=HERE/"source"
A="8ca75796365f348e25d3f7bea9daa1440218d40b"
B="362613dbf38f60fe285cdd6bca53641149a23c04"
TAG="329bf9448afd9f9088d14a4d57fbc61eb454f117"
SELECT=ROOT/"ohm-session-parser/coroutine-21041-hardware/second-edit-selection-multifile"
CHANGED=["crates/uv-cli/src/lib.rs","crates/uv-cli/src/settings.rs","crates/uv-configuration/src/output_format.rs",
         "crates/uv-lock/src/lock/export/metadata.rs","crates/uv-workspace-commands/src/metadata.rs","crates/uv/src/lib.rs",
         "crates/uv/tests/workspace/workspace_metadata.rs","docs/reference/internals/metadata.md"]
EN={**os.environ,"GIT_NO_LAZY_FETCH":"1","GIT_TERMINAL_PROMPT":"0","LC_ALL":"C"}

def git(*args,bare=False,stdin=None,env=None):
    pre=["git","--git-dir="+str(DONOR)] if bare else ["git","-C",str(SOURCE)]
    return subprocess.check_output([*pre,*map(str,args)],input=stdin,env=EN|(env or {}))

def sha(b):return sha256(b).hexdigest()
def wr(path,data):
    if path.exists():assert path.read_bytes()==data
    else:path.write_bytes(data)
def check(state):
    target=A if state=="A" else B
    assert state in ("A","B") and git("rev-parse","HEAD").decode().strip()==A
    assert git("diff","--cached","--name-only")==b"" and not git("ls-files","--others","--exclude-standard")
    actual=git("diff","--name-only").decode().splitlines()
    assert actual==([] if state=="A" else CHANGED)
    with tempfile.TemporaryDirectory(prefix="ohm-22958-verify-index-") as d:
        env={"GIT_INDEX_FILE":str(Path(d)/"index")}
        git("read-tree",A,env=env)
        git("add","-u","--",env=env)
        tree=git("write-tree",env=env).decode().strip()
    assert tree==git("rev-parse",target+"^{tree}").decode().strip()
    assert (SOURCE/"Cargo.lock").read_bytes()==git("show",A+":Cargo.lock")
    return dict(commit=target,tree=tree,HEAD=A,changed=actual,
                committed_describe=git("describe","--tags","--always","--long",target).decode().strip(),
                working_describe=git("describe","--tags","--always","--long","--dirty").decode().strip(),
                lock_sha256=sha((SOURCE/"Cargo.lock").read_bytes()))

def change(state):
    prior="A" if state=="B" else "B"
    check(prior)
    git("apply","--whitespace=nowarn","--reverse" if state=="A" else "--allow-empty",str(HERE/"edit.patch"))
    return check(state)

def enroll():
    assert git("rev-parse",B+"^",bare=True).decode().strip()==A
    assert git("diff","--name-only",A,B,bare=True).decode().splitlines()==CHANGED
    o=json.loads((HERE/"upstream-tag-0.13.6.json").read_bytes())
    assert (o["ref"],o["object"]["type"],o["object"]["sha"])==("refs/tags/0.13.6","commit",TAG)
    assert sha((SELECT/"census.json").read_bytes()) and B in (SELECT/"census.json").read_text()
    assert A in (SELECT/"census.json").read_text() and B in (SELECT/"upstream-22958.json").read_text()
    if not SOURCE.exists():
        SOURCE.mkdir();git("init","--quiet")
        (SOURCE/".git/objects/info/alternates").write_text(str(DONOR/"objects")+"\n")
        if (DONOR/"shallow").exists():shutil.copyfile(DONOR/"shallow",SOURCE/".git/shallow")
        git("config","core.autocrlf","false");git("config","core.filemode","true")
        # Use all retained actual public tag refs whose objects are in the immutable donor.
        tags=[]
        for line in (ROOT/"banks/public-tags.tsv").read_text().splitlines():
            oid,name=line.split()
            if name.endswith("^{}"):continue
            tags.append((oid,name))
        batch=git("cat-file","--batch-check=%(objectname) %(objecttype)",
                  stdin="".join(o+"\n"for o,_ in tags).encode()).decode().splitlines()
        for (oid,name),record in zip(tags,batch,strict=True):
            value,kind=record.split()
            if kind!="missing":
                assert value==oid and kind in ("commit","tag");git("update-ref",name,oid)
        assert git("rev-parse","refs/tags/0.13.6").decode().strip()==TAG
        git("checkout","--detach","--quiet",A)
    diff=git("diff","--binary",A,B);wr(HERE/"edit.patch",diff);wr(HERE/"Cargo.lock",git("show",A+":Cargo.lock"))
    a=check("A");b=change("B");change("A")
    assert a["committed_describe"].startswith("0.13.6-") and b["committed_describe"].startswith("0.13.6-")
    result=dict(A=a,B=b,donor=str(DONOR),common_dir=git("rev-parse","--path-format=absolute","--git-common-dir").decode().strip(),
                selection=sha((SELECT/"registration.json").read_bytes()),census=sha((SELECT/"census.json").read_bytes()),
                merge_receipt=sha((SELECT/"upstream-22958.json").read_bytes()),tag_receipt=sha((HERE/"upstream-tag-0.13.6.json").read_bytes()),
                files=[dict(path=k,A=sha(git("show",A+":"+k)),B=sha(git("show",B+":"+k))) for k in CHANGED],
                patch_sha256=sha(diff),lock_sha256=a["lock_sha256"])
    wr(HERE/"source.json",(json.dumps(result,sort_keys=True,indent=2)+"\n").encode())
    return result

if __name__=="__main__":
    if len(sys.argv)==1:print(json.dumps(enroll(),indent=2))
    else:print(json.dumps(change(sys.argv[1]),indent=2))
