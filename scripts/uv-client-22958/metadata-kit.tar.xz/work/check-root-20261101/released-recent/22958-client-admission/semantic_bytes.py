"""Independently compare keyed row values and root/AST/foreign records for each raw mismatch."""
from collections import Counter
from pathlib import Path
import gzip
import hashlib
import json
import runpy
import sys

H=Path(__file__).resolve().parent;D=H.parents[1]
C=runpy.run_path(str(D/"released-recent/22635-production-discovery/actual-fingerprint-successor/run-41386773674/forensics/classify.py"))
ROOT=C["C"]["root"];DI=C["S"]["sig"].di
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def delta(a,b,name):
    ar,br=ROOT(a),ROOT(b);ks=[DI.keyed(v,z)for v,z in ((a,ar),(b,br))]
    assert all(len(set(k))==len(k)for k in ks)
    m1,m2=[{k:i for i,k in enumerate(kk)}for kk in ks]
    same=set(m1)==set(m2)
    d,C1,C2=C["diff_rmeta"](a,b,name),{},{}
    for t in ar["tables"]:
        x,y=ar["tables"][t],br["tables"][t]
        if x["type"]!="table":continue
        if x["length"]==len(ks[0]) and y["length"]==len(ks[1]):
            s1=list(DI.rows(a,x));s2=list(DI.rows(b,y));assert len(s1)==len(m1)and len(s2)==len(m2)
            if not same:continue
            physical=sum(v!=w for v,w in zip(s1,s2));logical=sum(s1[i]!=s2[m2[k]]for k,i in m1.items())
            if physical or logical:C1[t]=[physical,logical]
    return dict(semantic=d,identical_stable_def_set=same,stable_def_counts=list(map(len,ks)),
                local_index_swaps=sum(i!=m2.get(k)for k,i in m1.items()),indexed_fixed_width_rows=C1,
                exact_native_headers=ar["private"]==br["private"]if "private"in ar else None)
def main():
    p=H/"native26210096";n="uv-client";src=[gzip.decompress((p/s/(n+".rmeta.gz")).read_bytes())for s in ("first-B","fresh-B")]
    result=delta(*src,"uv_client");dest=H/"terminal-keyed-semantics.json";encoded=(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n").encode()
    if dest.exists():assert dest.read_bytes()==encoded
    else:dest.write_bytes(encoded)
    print(sha(encoded),list(result["semantic"]),result["stable_def_counts"],result["local_index_swaps"],result["indexed_fixed_width_rows"])

if __name__=="__main__":main()
