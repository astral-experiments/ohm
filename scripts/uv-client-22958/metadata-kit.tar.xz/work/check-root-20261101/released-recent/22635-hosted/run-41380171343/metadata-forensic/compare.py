"""Inspect every original #22635 workspace product for warm/cold metadata divergence."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,io,json,runpy,struct,zipfile
H=Path(__file__).resolve().parent;D=H.parents[3]
C=runpy.run_path(str(D/'remainder/data-layout/visibility-observer-v3/consumers.py'))
Q=runpy.run_path(str(D/'remainder/virtual-project-impl/stage1/panel-payload/scripts/handwritten-panel/deep.py'))
P=Q['parser'](D/'ctfe-root-attribution/metadata.py')
META=runpy.run_path(str(D/'ctfe-root-attribution/metadata.py'));R=C['Reader'];S=C['R'];sha=C['sha']
def needed(b,msg):
    if not b:raise ValueError(msg)
def deps(data,root):
    t=root['tables']['crate_deps'];r=R(data,t['position']);out=[]
    for i in range(1,t['length']+1):
        name=C['symbol'](data,r);svh=r.raw(16)[::-1].hex();o=r.u();needed(o in (0,1),'host optional hash');host=r.raw(16)[::-1].hex()if o else None
        kind,ext,priv=r.u(),r.string(),r.u();needed(priv in (0,1)and kind<5,'dependency tail')
        out.append((i,name,svh,host,kind,ext,priv))
    return out
def compare(x,y,n):
    one,two=C['root'](x),C['root'](y);a,ad,ae,ar,ah=P(x,n);b,bd,be,br,bh=P(y,n)
    ix=[e.hex()for e in S['sig'].di.keyed(x,one)];iy=[e.hex()for e in S['sig'].di.keyed(y,two)]
    dx,dy=deps(x,one),deps(y,two);extra1={k:ar[k]-br[k]for k in ar.keys()|br.keys()if ar[k]>br[k]};extra2={k:br[k]-ar[k]for k in ar.keys()|br.keys()if br[k]>ar[k]}
    changed=[k for k in ad.keys()&bd.keys()if ad[k][0]!=bd[k][0]];descriptor=[k for k in ad.keys()&bd.keys()if ad[k][1:]!=bd[k][1:]]
    lrec=lambda tx,ty,f:[{'key':k,'copies':[tx[k],ty[k]],'bytes':f[k]['bytes'],'tag':f[k]['tag'],'immutable_pointer_free_utf8':f[k]['immutable_pointer_free_utf8']}for k in sorted(tx.keys()|ty.keys())if tx[k]>ty[k]][:10]
    detail={'bytes':[len(x),len(y)],'raw_sha256':[sha(x),sha(y)],'header':{k:[a[k],b[k]]for k in ('target','crate_name','stable_crate_id','private_svh','public_svh','global_public_hash')},
        'exact_all_dependencies':dx==dy,'dependency_count':[len(dx),len(dy)],'different_dependency_rows':[[i,dx[i]if i<len(dx)else None,dy[i]if i<len(dy)else None]for i in range(max(len(dx),len(dy)))if dx[i:i+1]!=dy[i:i+1]],
        'defs':[len(ad),len(bd)],'missing_keys':[sorted(ad.keys()-bd.keys()),sorted(bd.keys()-ad.keys())],'def_key_descriptor_differences':descriptor,
        'physical_def_index_disagreements':sum(aa!=bb for aa,bb in zip(ix,iy))+abs(len(ix)-len(iy)),'changed_RDR_key_count':len(changed),
        'changed_RDR_keys':{k:[ad[k][0],bd[k][0],S['label'](bd,k)]for k in sorted(changed)},
        'keyed_reachable_expansion_counts':[len(ae),len(be)],'exact_keyed_reachable_expansions':ae==be,
        'allocations':{'total':[sum(ar.values()),sum(br.values())],'tags':[a['allocation_tags'],b['allocation_tags']],'ordered_sha256':[a['allocation_order_sha256'],b['allocation_order_sha256']],
        'multisets_identical':ar==br,'distinct':[len(ar),len(br)],'positive_excess_records':[sum(extra1.values()),sum(extra2.values())],
        'shared_bytes_with_different_multiplicities':sum(ar[k]!=br[k]for k in ar.keys()&br.keys()),
        'shared_immutable_pointer_free_text_with_different_multiplicities':sum(ar[k]!=br[k]and ah[k]['immutable_pointer_free_utf8']is not None for k in ar.keys()&br.keys()),
        'examples_warm_excess':lrec(ar,br,ah),'examples_cold_excess':lrec(br,ar,bh)}}
    return detail
def run():
    p=H.parent/'original.zip';outer=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();needed(outer=='e2da304579097125ac234698f769d8a99f1ae61dba96456af5801f6e271210b1','expected authority');z=zipfile.ZipFile(p);obs=json.loads(z.read('observation.json'))
    all3={s:zipfile.ZipFile(io.BytesIO(z.read(n)))for s,n in [('A','parent-workspace.zip'),('B-warm','edited-workspace.zip'),('B-cold','cold-B-workspace.zip')]}
    rosters=[set(q.namelist())for q in all3.values()];needed(rosters[0]==rosters[1]==rosters[2]and len(rosters[0])==96,'96 actual workspace outputs in all snapshots')
    diffs={};eq={};no_data=[];source_control={}
    for k in sorted(rosters[0]):
        x=all3['B-warm'].read(k);y=all3['B-cold'].read(k)
        if x==y:eq[k]=sha(x)
        if not x or not y:needed(x==y,'zero vs nonzero artifact');no_data.append(k);continue
        if x==y and k not in obs['provider_warm']:continue
        n=Path(k).name.removeprefix('lib').split('-',1)[0];needed(C['root'](x)['crate_name']==C['root'](y)['crate_name']==n,'diff crate name')
        if x!=y:diffs[k]=compare(x,y,n)
        if k in obs['provider_warm']:
            needed(sha(x)==obs['provider_warm'][k]and sha(y)==obs['provider_cold'][k],'provider digests');source_control[k]=compare(all3['A'].read(k),x,n)
    needed(len(eq)==80 and len(diffs)==16 and len(source_control)==1,'registered original discrepancy')
    return {'archive_sha256':outer,'raw_equal':len(eq),'raw_different':len(diffs),'all_equal_member_sha256':eq,'all_warm_cold_differences':diffs,
            'genuine_A_to_warm_B_provider':source_control,'empty_equal_cargo_products':no_data,'observation':obs,
            'strict_byte_gate':False,'scope':'Stable-path declarations and RDR values, reachable expansion hashes, exact encoded dependency rows, and ordered and multiset CTFE allocation bytes. Diagnostic only. Different byte order or pointer identity outside these fields is not accepted as interchangeable.'}
if __name__=='__main__':print(json.dumps(run(),sort_keys=True,indent=2))
