"""Resolve every memory provenance edge in #22635's two original provider tables."""
import hashlib,io,json,runpy,zipfile
from collections import Counter
from pathlib import Path
H=Path(__file__).resolve().parent;S=runpy.run_path(str(H/'compare.py'))
CC=S['C'];R=S['R'];ck=S['needed'];sha=S['sha'];META=S['META'];SN=CC['R']
def pack(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def alloc(raw,root):
    t=root['tables']['interpret_alloc_index'];r=R(raw,t['position'])
    pts=[r.u()for _ in range(t['length'])]+[t['position']];rows=[raw[x:y]for x,y in zip(pts,pts[1:])]
    ck(pts==sorted(set(pts))and all(q for q in rows),'allocation framing')
    parent=[];tags=Counter();nodes=[];names={};edges={}
    for i,b in enumerate(rows):
        r=R(b,0);tag=r.byte();tags[tag]+=1
        if tag!=0:
            ck(tag in (2,3),'unexpected allocation kind for this evidence')
            nodes.append(('opaque-nonmemory-tag-and-bytes',b.hex()));continue
        flags=r.byte();size=r.u();ck(0<=size<=1<<20,'unexpected scope')
        payload=r.raw(size) if not flags&128 else b'';n=r.u();ck(0<=n<=size,'provenance map length')
        pointers=[]
        for x in range(n):
            off,idx,imm,shared=r.u(),r.u(),r.byte(),r.byte()
            ck(0<=off<=size-8 and 0<=idx<len(rows)and imm in(0,1)and shared in(0,1),'invalid selected pointer')
            pointers.append((off,idx,imm,shared))
        ck(all(pointers[j][0]<pointers[j+1][0]for j in range(n-1)),'ordered map')
        tail=b[r.p:];ck(tail,'missing initialization data')
        nodes.append(('memory',flags,size,payload.hex(),tail.hex()));edges[i]=pointers
        leaf=META['text_leaf'](b)
        if leaf is not None:names[i]=leaf
    cached={}
    def node(i,seen):
        if i in cached:return cached[i]
        ck(i not in seen,'cyclic allocation graph, cannot apply this reader')
        v=sha(pack([nodes[i],[[off,node(dest,seen|{i}),imm,shared] for off,dest,imm,shared in edges.get(i,())]]))
        cached[i]=v;return v
    count=Counter(node(i,set())for i in range(len(rows)))
    return rows,names,dict(edges),cached,count,dict(tags)
def run():
    z=zipfile.ZipFile(H.parent/'original.zip');az=[zipfile.ZipFile(io.BytesIO(z.read(n+'-workspace.zip')))for n in ('edited','cold-B')]
    authority=json.loads((H/'results.json').read_bytes());inventory={};provider=None
    for member,e in authority['all_warm_cold_differences'].items():
        blobs=[x.read(member)for x in az];roots=[CC['root'](x)for x in blobs];ix=[list(map(bytes.hex,SN['sig'].di.keyed(x,h)))for x,h in zip(blobs,roots)]
        class Blob:
            def __init__(self,data):self.data=data
            def read_bytes(self):return self.data
        desc=[SN['crate'](Blob(b))['rows']for b in blobs]
        ck(set(ix[0])==set(ix[1])and len(ix[0])==len(set(ix[0])),'physical keys unique')
        moves=[(i,k,l)for i,(k,l)in enumerate(zip(*ix))if k!=l];ck(len(moves)==e['physical_def_index_disagreements'],'cross-read DefIndex')
        inv={k:i for i,k in enumerate(ix[1])}
        inventory[member]={'moved':len(moves),'classes':dict(Counter(desc[0][k][2]for _,k,_ in moves)),
                           'positions':[[i,inv[k],k,SN['label'](desc[0],k)]for i,k,_ in moves]}
        if '/uv-workspace/'not in member:continue
        x,y=[alloc(raw,root)for raw,root in zip(blobs,roots)]
        wc,cc=x[4],y[4];target={k:x[1][i]for i,k in x[3].items()if i in x[1]}
        extra={target.get(k,k):v for k,v in(wc-cc).items()}
        ck(extra=={'message':1,'uv_workspace::workspace':1,'crates/uv-workspace/src/workspace.rs':1}and not cc-wc,'unexpected allocation graph after resolving all provenance')
        def selected(one,other):
            cnt=Counter(other[0]);which=[];index={}
            for i,b in enumerate(one[0]):
                if cnt[b]:cnt[b]-=1;continue
                if i in one[1]:continue
                ck(len(b)==36 and len(one[2][i])==1,'new unexplained CTFE delta')
                ((off,idx,imm,shared),)=one[2][i];ck(off==0 and imm==shared==1 and idx in one[1],'36-byte record provenance differs')
                which.append((one[1][idx],idx))
            return {str((name,idx)):n for(name,idx),n in Counter(which).items()}
        provider={'member':member,'rows':[len(x[0]),len(y[0])],'roots_by_recursive_content':[len(wc),len(cc)],'canonical_multiset_warm_excess':extra,'canonical_multiset_cold_excess':dict(cc-wc),
                  'all_memory_provenance_edges':[sum(map(len,a[2].values()))for a in (x,y)],'exact_nonmemory_record_multiset':Counter(b for b in x[0]if b[0]!=0)==Counter(b for b in y[0]if b[0]!=0),
                  'pointees_for_all_excess_nonleaf_originals':[selected(x,y),selected(y,x)],'tag_histograms':[x[5],y[5]]}
    ck(provider is not None,'missing provider')
    return {'archive':authority['archive_sha256'],'physical_DefIndex_moves':inventory,'provider_CTFE':provider,
            'boundary':'Exact raw nonmemory record atoms include potential DefIds or types and are not recursively interpreted. Memory fingerprints retain flags, alignment, bytes, init data, offset, provenance flags and recursively referenced value, but deliberately distinguish alias topology separately from content. They are diagnostic only.'}
if __name__=='__main__':print(json.dumps(run(),indent=2,sort_keys=True))
