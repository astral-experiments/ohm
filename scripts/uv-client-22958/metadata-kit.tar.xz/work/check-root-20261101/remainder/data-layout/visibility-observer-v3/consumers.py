"""Bind the visibility projection to direct ADTs in independently emitted downstream type_of tables."""
from collections import Counter
from functools import cache
from pathlib import Path
import gzip, hashlib, json, runpy, struct, subprocess, zipfile

V = Path(__file__).resolve().parent
O = V / 'run-41376572352'
D = V.parents[2]
H = D / 'edit-selection/inherent-history-20261102'
R = runpy.run_path(str(D.parent / 'uv-workflow-search/rdr_snapshot.py'))
S = R['sig']
Reader = S.original.Reader
REPO = D.parent / 'uv-inherent-edit-history.git'
B = 'd952be66482a298658f39f314ba8c337154ed0e7'
PH = 'uv-client/hold-0-fa7a_stack_ctfe318_handwritten/typed-B/'
ARCHIVE = H / 'hosted-client/run-41373554647/raw.zip'

def need(value, msg):
    if not value:
        raise ValueError(msg)

def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_bytes())
def root(b): return R['Reader21'](b, struct.unpack_from('<Q', b, 8)[0]).read()
class Blob:
    def __init__(self, data): self.read_bytes = lambda: data

def stable_paths(data):
    rows = R['crate'](Blob(data))['rows']
    @cache
    def path(key):
        if key is None: return ()
        _, parent, kind, name, dis = rows[key]
        return path(parent) + ((kind, name, dis),)
    paths = {k:path(k) for k in rows}
    need(len(paths)==len(set(paths.values())), 'canonical DefKey path ambiguous')
    return rows, paths

def symbol(data, r):
    tag = r.u()
    if tag == 0: return r.string()
    if tag == 1: return Reader(data, r.u()).string()
    need(tag == 2, 'symbol tag')
    return ('preinterned', r.u())

def deps(data, head):
    tbl = head['tables']['crate_deps']
    r = Reader(data, tbl['position'])
    for i in range(1, tbl['length']+1):
        name = symbol(data, r)
        svh = r.raw(16)[::-1].hex()
        host = r.u()
        need(host in (0,1), 'host hash')
        if host: r.raw(16)
        kind, extra, private = r.u(), r.string(), r.u()
        need(kind <= 5 and private in (0,1), 'dependency shape')
        yield i, name, svh, extra, private

def collect():
    a = json.loads((O/'162-stabilized-definitions.json').read_bytes())
    need(len(a) == len({x['key'] for x in a}) == 162, 'projection inventory')
    source_path, = (V/'run-bracket02/same-seed-warm-B/marked').glob('*.rmeta')
    source = source_path.read_bytes()
    rows, source_paths = stable_paths(source)
    z = zipfile.ZipFile(ARCHIVE)
    product = json.loads(z.read(PH+'raw-products.json'))
    roster = json.loads(z.read(PH+'roster.json'))
    executed = set(roster['artifact_crates'])
    need(len(executed)==9 and 'uv_client' in executed, 'true first edit process roster')
    def raw(name):
        size, h = product['raw'][name]
        b = gzip.decompress(z.read('rmeta-by-content/'+h+'.gz'))
        need(len(b)==size and sha(b)==h and root(b)['crate_name']==name, 'archived role/product disagreement')
        return b
    provider = raw('uv_pypi_types')
    hp = root(provider)
    archived, remote_paths = stable_paths(provider)
    reverse = {value:key for key,value in remote_paths.items()}
    selected = {reverse[source_paths[x['key']]]:x for x in a}
    need(len(selected)==162 and all(R['label'](archived,k)==x['def_path'] for k,x in selected.items()), 'cross-profile identity')
    consumers, fixtures = [], []
    for name in sorted(product['raw']):
        data = raw(name)
        head = root(data)
        dep = [x for x in deps(data,head) if x[1]=='uv_pypi_types']
        if not dep: continue
        need(len(dep)==1, 'dependency ambiguity')
        num, n, svh, extra, private = dep[0]
        need((svh,extra)==(hp['public_svh'],hp['extra_filename']), 'wire dependency hash/filename differs from authenticated supplier')
        direct = []
        ids = S.di.keyed(data,head)
        down_rows = None
        for i, row in enumerate(S.di.rows(data,head['tables']['type_of'])):
            ptr = int.from_bytes(row, 'little')
            if not ptr: continue
            r = Reader(data, ptr); kind = r.u()
            if kind >= 0x80:
                r = Reader(data, kind - 0x80); kind = r.u()
                need(kind < 0x80, 'nested Ty shorthand')
            if kind != 5: continue
            ref_at = r.p
            if r.u() != num: continue
            key = r.raw(8).hex()
            if key not in selected: continue
            if down_rows is None: down_rows = R['crate'](Blob(data))['rows']
            x = selected[key]
            direct.append({'consumer_owner':R['label'](down_rows, ids[i].hex()),'consumer_index':i,
                           'consumer_local_key':ids[i].hex(),'type_of_position':ptr,'adt_did_position':ref_at,
                           'provider_remote_key':key,'provider_local_key':x['key'],'provider_owner':x['def_path']})
        consumers.append({'crate':name,'compiled_after_edit':name in executed,'crate_number':num,
                          'provider_public_svh':svh,'extra_filename':extra,'provider_private_edge':private,
                          'rmeta_sha256':sha(data),'direct_counts':dict(Counter(x['provider_owner'] for x in direct)),
                          'direct_external_adt_in_type_of':direct})
    for file, lines, words in (
        ('crates/uv-client/src/html.rs',list(range(47,54)), ['SimpleDetailHTML','base: BaseUrl']),
        ('crates/uv-client/src/flat_index.rs',list(range(283,293)),['SimpleDetailHTML','base.as_str()']),
        ('crates/uv-pypi-types/src/base_url.rs',list(range(6,24)), ['struct BaseUrl','fn as_str']),
        ('crates/uv-distribution-types/src/cached.rs',list(range(31,38)), ['struct CachedDirectUrlDist','pub url: VerbatimParsedUrl']),
    ):
        data=subprocess.check_output(['git','--git-dir',str(REPO),'show',B+':'+file]);s=data.decode().splitlines()
        window={i:s[i-1] for i in lines}
        need(all(term in '\n'.join(window.values()) for term in words),'consumer source witness '+file)
        fixtures.append({'path':file,'blob_sha256':sha(data),'lines':window})
    direct=[(c['crate'],e)for c in consumers for e in c['direct_external_adt_in_type_of']]
    base = 'CrateRoot::base_url::BaseUrl'
    need(any(n=='uv_client'and e['provider_owner']==base and e['consumer_owner'].endswith('SimpleDetailHTML::base') for n,e in direct),'expected actual direct field')
    return {'source_uv':B,'archive_sha256':sha(ARCHIVE.read_bytes()),'archive_typed_phase':PH,
            'retained_workspace_outputs':len(product['raw']),'actual_recompiled_crates':sorted(executed),
            'observed_supplier':{k:root(source)[k]for k in ('stable_crate_id','public_svh','extra_filename')},
            'archived_supplier':{k:hp[k]for k in ('stable_crate_id','public_svh','extra_filename')},
            'all_source_paths':len(source_paths),'all_archived_paths':len(remote_paths),
            'shared_full_defkey_paths':len(set(source_paths.values()) & set(remote_paths.values())),
            'all_162_unique_path_equivalences':True,'recompiled_consumers_with_direct_adt_reference':sorted({n for n,e in direct if n in executed}),
            'unique_proven_provider_direct_adt_types':sorted({e['provider_owner']for n,e in direct}),
            'total_direct_type_of_rows':len(direct),'source_calls':fixtures,'consumers':consumers,
            'scope':'Only the leading AdtDefData.did of actual downstream type_of(TyKind::Adt) values is decoded. A use-site in checked Rust source and an independently emitted exact DefId do not measure warm query evaluations, first-red vetoes or saved wall time.'}

if __name__=='__main__':
    result=collect()
    print(json.dumps(result,sort_keys=True,indent=2))
