"""Compare rustc's own per-definition RDR fingerprints for local uv crates."""
import collections
import hashlib
import importlib.util
from pathlib import Path
import struct
import traceback

HERE = Path(__file__).resolve().parent
COMPILER = HERE.parent / "round18-compiler"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sig = load("workflow_decoder", COMPILER / "proof-archive-decoder-v2/signature.py")
keys = load("workflow_keys", COMPILER / "proof-archive-admission/definition-keys.py")


class Reader21(sig.Reader):
    def table(self, name):
        if name == sig.original.table_names[0]:
            # New CrateRoot member immediately before LazyTables in signed -21.
            assert self.byte() in (0, 1)
        super().table(name)


def crate(path):
    data = path.read_bytes()
    if data.startswith(b"\x7fELF"):
        data = sig.ar.payload(data)
    assert data.startswith(b"rust\0\0\0\n")
    offset = struct.unpack_from("<Q", data, 8)[0]
    try:
        root = sig.Reader(data, offset).read()
    except (AssertionError, IndexError, struct.error):
        root = Reader21(data, offset).read()
    ids = sig.di.keyed(data, root)
    table = root["tables"]["rdr_hashes.local"]
    hashes = sig.di.rows(data, table)
    assert len(hashes) <= len(ids)
    hashes += [bytes(table["width"])] * (len(ids) - len(hashes))
    entries = {}
    dim = root["tables"]["def_keys"]
    ptrs = [int.from_bytes(b, "little") for b in sig.di.rows(data, dim)]
    assert len(ptrs) == len(ids)
    for i, (key, fingerprint) in enumerate(zip(ids, hashes)):
        desc, _ = keys.key_at(data, ptrs[i], ids)
        name = desc["name"]
        entries[key.hex()] = (fingerprint.hex(), desc["parent"], desc["kind"], name[1] if name else None, desc["disambiguator"])
    return {"public": root["public_svh"], "global": root["global_public_hash"],
            "expansions": hashlib.sha256(b"".join(sig.di.rows(data, root["tables"]["rdr_hashes.expn"]))).hexdigest(),
            "rows": entries}


def collect(target, requested):
    result = {}
    candidates = list((target / "debug/build").glob("uv*/*/out/libuv*.rmeta"))
    if not candidates:
        candidates = list((target / "debug/deps").glob("libuv*.rmeta"))
    for p in sorted(candidates):
        if p.name.split("-")[0][3:] not in requested:
            continue
        try:
            result[p.name] = crate(p)
        except Exception:
            result[p.name] = {"error": traceback.format_exc(limit=3), "bytes": p.stat().st_size}
    return result


def label(rows, key):
    path = []
    while key is not None and len(path) < 40:
        _, key, kind, name, n = rows[key]
        ident = str(name) if name is not None else kind
        path.append(ident + (("#" + str(n)) if n else ""))
    return "::".join(reversed(path))


def compare(before, after):
    result = {}
    for unit in sorted(set(before) | set(after)):
        a, b = before.get(unit), after.get(unit)
        if a is None or b is None or "error" in a or "error" in b:
            result[unit] = {"before": a and a.get("error"), "after": b and b.get("error")}
            continue
        x, y = a["rows"], b["rows"]
        diff = [k for k in x.keys() & y.keys() if x[k][0] != y[k][0]]
        result[unit] = {"before": {k:a[k] for k in ("public","global","expansions")},
                        "after": {k:b[k] for k in ("public","global","expansions")},
                        "matched": len(x.keys() & y.keys()), "added": len(y.keys() - x.keys()),
                        "removed": len(x.keys() - y.keys()), "changed": len(diff),
                        "changed_kinds": dict(collections.Counter(y[k][2] for k in diff)),
                        "examples": [label(y,k) for k in sorted(diff)[:80]]}
    return result
