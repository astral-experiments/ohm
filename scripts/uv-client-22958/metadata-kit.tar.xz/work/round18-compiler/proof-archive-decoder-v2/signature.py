"""Read optional semantic diagnostics without changing the original archive or the admission oracle."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,re,struct
HERE=Path(__file__).resolve().parent;ORIGINAL=HERE.parent/'proof-archive-admission'
def module(name):
 sp=importlib.util.spec_from_file_location(name,ORIGINAL/(name+'.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
original=module('root');di=module('defindex');ar=module('audit-one');sha=lambda b:hashlib.sha256(b).hexdigest()
class Reader(original.Reader):
 def symbol(self):
  tag=self.byte()
  if tag==0:return 'inline',self.string()
  if tag==1:return 'offset',original.Reader(self.d,self.u()).string()
  if tag==2:return 'predefined',self.u()
  raise ValueError(f'invalid rustc metadata symbol tag {tag}')
 def read(self):
  assert self.byte()==0;target=self.string();private,public=self.fingerprint(),self.fingerprint();form,name=self.symbol();assert self.raw(2)==b'\0\0';extra=self.string();stable_id=self.raw(8)[::-1].hex();assert self.raw(7)==b'\0\0\3\0\0\0\0';src=original.source;fields=src[src.index('    externally_implementable_items: LazyArray'):src.index('    impls: EncodedTraitImpls')]
  for field in re.findall(r'^    (\w+): LazyArray<',fields,re.M):self.array(field)
  assert self.u() in (0,1);self.array('impls');self.array('incoherent_impls');self.array('interpret_alloc_index');assert self.byte()==0
  for field in ['debugger_visualizers','exportable_items','stable_order_of_exportable_impls','exported_non_generic_symbols','exported_generic_symbols']:self.array(field)
  for field in original.table_names+['syntax_contexts','expn_data','expn_hashes']:self.table(field)
  self.value('def_path_hash_map');self.table('source_map');self.array('target_modifiers');self.array('denied_partial_mitigations');self.raw(9);assert self.byte()==1;self.table('rdr_hashes.local');self.table('rdr_hashes.expn');global_hash=self.fingerprint();assert self.d[self.p:]==b'rust-end-file';return {'target':target,'crate_name':name,'symbol_form':form,'private_svh':private,'public_svh':public,'extra_filename':extra,'stable_crate_id':stable_id,'root':self.root,'root_sha256':sha(self.d[self.root:self.p]),'global_public_hash':global_hash,'tables':self.tables}

def signature(path,expected=None):
 d=path.read_bytes();fullsha=sha(d);assert expected is None or expected==fullsha
 if d[:4]==b'\x7fELF':d=ar.payload(d)
 assert d[:8]==b'rust\0\0\0\n';r=Reader(d,struct.unpack_from('<Q',d,8)[0]).read();assert r['crate_name']=='uv' and r['target']=='x86_64-unknown-linux-gnu';ids=di.keyed(d,r);f=di.rows(d,r['tables']['rdr_hashes.local']);w=r['tables']['rdr_hashes.local']['width'];f.extend([b'\0'*w]*(len(ids)-len(f)));sem={'target':r['target'],'crate_name':r['crate_name'],'private_svh':r['private_svh'],'public_svh':r['public_svh'],'stable_crate_id':r['stable_crate_id'],'public_global_fingerprint':r['global_public_hash'],'expansion_fingerprint_rows_sha256':sha(b''.join(di.rows(d,r['tables']['rdr_hashes.expn']))),'stable_def_hashes_sorted_sha256':sha(b''.join(sorted(ids))),'definition_count':len(ids),'stable_keyed_item_fingerprints_sha256':sha(b''.join(h+f[i]for i,h in sorted(enumerate(ids),key=lambda p:p[1])))};return {**sem,'stable_semantic_sha256':sha(json.dumps(sem,sort_keys=True,separators=(',',':')).encode()),'metadata_root_sha256':r['root_sha256'],'raw_rmeta_section_sha256':sha(d),'input_sha256':fullsha,'crate_name_symbol_form':r['symbol_form'],'stable_def_hashes_in_index_order_sha256':sha(b''.join(ids))}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('rmeta',type=Path);p.add_argument('--sha256');a=p.parse_args();print(json.dumps(signature(a.rmeta,a.sha256),indent=2))
