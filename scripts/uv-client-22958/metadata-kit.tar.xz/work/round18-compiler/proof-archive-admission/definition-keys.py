"""Decode DefKey and canonicalize its one local reference to a DefPathHash."""
from pathlib import Path
import importlib.util,collections,json,sys
here=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('decl_index',here/'defindex.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);Reader=m.mod.Reader
kinds='CrateRoot Impl ForeignMod Use GlobalAsm TypeNs ValueNs MacroNs LifetimeNs Closure Ctor AnonConst OpaqueTy OpaqueLifetime AnonAssocTy SyntheticCoroutineBody NestedStatic'.split()
def key_at(d,p,index):
 r=Reader(d,p);t=r.byte();assert t in (0,1);parent=None if t==0 else index[r.u()].hex();kind=kinds[r.u()];sym=None
 if kind in ('TypeNs','ValueNs','MacroNs','LifetimeNs','OpaqueLifetime','AnonAssocTy'):
  tag=r.byte();assert tag in (0,1,2);sym=('str',r.string() if tag==0 else Reader(d,r.u()).string()) if tag in (0,1) else ('sym',r.u())
 q=r.u();return {'parent':parent,'kind':kind,'name':sym,'disambiguator':q},r.p

def read(d,root):
 ids=m.keyed(d,root);ptrs=[int.from_bytes(x,'little') for x in m.rows(d,root['tables']['def_keys'])];out=[];ends=[]
 for i,p in enumerate(ptrs):
  k,e=key_at(d,p,ids);out.append(k);ends.append(e)
  if i+1<len(ptrs):assert e==ptrs[i+1],(i,e,ptrs[i+1])
 return ids,out,(ptrs[0],ends[-1])
if __name__=='__main__':
 a,r=m.mod.get('base');b,z=m.mod.get('stack');ax,ak,ar=read(a,r);bx,bk,br=read(b,z);assert ar==br;idx={h:i for i,h in enumerate(bx)};moved=[i for i,h in enumerate(ax) if idx[h]!=i];assert all(ak[i]==bk[idx[ax[i]]] for i in range(len(ax)));print('every defkey even for moved definitions equal',len(ax),'moved kinds',collections.Counter(ak[i]['kind'] for i in moved),ar);print('moved labels',collections.Counter(str(ak[i]['name']) for i in moved).most_common(12));out={'def_count':len(ax),'stable_key_agreement_count':len(ax),'def_key_section':ar,'raw_differing_bytes':sum(x!=y for x,y in zip(a[ar[0]:ar[1]],b[ar[0]:ar[1]])),'moved_kinds':dict(collections.Counter(ak[i]['kind'] for i in moved)),'moved':[{**ak[i],'base_index':i,'stack_index':idx[ax[i]],'stable_hash_bytes':ax[i].hex()} for i in moved]};(here/'definition-keys.json').write_text(json.dumps(out,indent=2)+'\n')
