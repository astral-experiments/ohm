"""Compare the stable identities and fingerprints of every crate-local metadata row."""
from pathlib import Path
import importlib.util,json,collections,struct,hashlib
here=Path(__file__).parent
s=importlib.util.spec_from_file_location('pinned_root',here/'root.py');mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod)
def rows(d,t):
 p=t['position'];w=t['width'];n=t['length'];start=t['values_position'];out=[]
 for i in range(n):
  if t['sparse']:
   b,q=struct.unpack_from('<QI',d,p+(i//64)*12);j=i%64
   if not (b>>j)&1:out.append(b'\0'*w);continue
   k=q+(b&((1<<j)-1)).bit_count()
  else:k=i
  out.append(d[start+k*w:start+(k+1)*w]);
 return out

def keyed(d,r):
 h=rows(d,r['tables']['def_path_hashes']);assert len(set(h))==len(h);return h

def compare():
 a,r=mod.get('base');b,s=mod.get('stack');assert r==s
 ax,bx=keyed(a,r),keyed(b,s);assert set(ax)==set(bx);index={h:i for i,h in enumerate(bx)};ab=[index[h] for h in ax];moved={str(i):j for i,j in enumerate(ab) if i!=j};stats={};print('local definition count/moved',len(ab),len(moved));print('permutation',list(moved.items())[:18]);
 for k,t in r['tables'].items():
  if t['type']!='table' or k in ['source_map','expn_data','expn_hashes','syntax_contexts','rdr_hashes.expn']:continue
  v,w=rows(a,t),rows(b,t)
  # These tables are keyed by DefIndex and may elide a suffix containing only zero/default rows.
  if len(v)>len(ab):continue
  zero=b'\0'*t['width'];v.extend([zero]*(len(ab)-len(v)));w.extend([zero]*(len(ab)-len(w))); changes=sum(v[i]!=w[j] for i,j in enumerate(ab));same=sum(p!=q for p,q in zip(v,w));stats[k]={'raw_row_differences':same,'stable_key_row_differences':changes}
  if same or changes:print(k,same,changes)
 print('rdr_hashes.expn unchanged', rows(a,r['tables']['rdr_hashes.expn'])==rows(b,r['tables']['rdr_hashes.expn']));return {'local_definition_count':len(ab),'moved_definition_count':len(moved),'base_to_stack_moved_indices':moved,'by_stable_definition':stats}
if __name__=='__main__': (here/'defindex.json').write_text(json.dumps(compare(),indent=2)+'\n')
