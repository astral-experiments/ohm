"""Compare headers and freshly read payloads in the two preserved release-proof archives."""
import hashlib,json,mmap,re,struct
from pathlib import Path
HERE=Path(__file__).resolve().parent;LAB=HERE.parents[1]/'round18-lab';B=Path('/tmp/ohm-uv-bench.0H03f2TH/round18/a/r18-proof')
NAME=re.compile(rb'(uv-[0-9a-f]{16}\.[a-z0-9]+\.)([a-z0-9]{7})(\.rcgu\.o)'); sha=lambda b:hashlib.sha256(b).hexdigest()

def members(blob):
    assert blob[:8]==b'!<arch>\n';offset=8;names=b'';out=[]
    while offset<len(blob):
        h=blob[offset:offset+60];assert len(h)==60 and h[-2:]==b'`\n';size=int(h[48:58]);n=h[:16].rstrip();at=offset+60;data=blob[at:at+size];assert len(data)==size
        if n==b'//':names=data
        if n.startswith(b'/') and n[1:].isdigit():
            ix=int(n[1:]); n=names[ix:names.index(b'/\n',ix)]
        rec=dict(offset=offset,payload_offset=at,name=n.decode(),key=NAME.sub(lambda m:m[1]+b'0000000'+m[3],n).decode(),size=size,header_sha256=sha(h),raw_sha256=sha(data),padding_hex=blob[at+size:at+size+(size%2)].hex()); normalized=NAME.sub(lambda m:m[1]+b'0000000'+m[3],data) if n in (b'//',b'lib.rmeta-link/') else data
        rec['existing_normalized_member_sha256']=sha(normalized) if normalized is not data else rec['raw_sha256'];out.append(rec);offset=at+size+(size%2)
    assert offset==len(blob);return out

if __name__=='__main__':
    allrows={};files={}
    for a in ['base','stack']:
        p=B/a/'debug/libuv.rlib';j=json.loads((LAB/'r18-proof/initial/build'/('admission-'+a)/'receipt.json').read_text());f=p.open('rb');b=mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ);h=sha(b);assert h==j['raw_artifact_receipts']['archive']['raw_sha256'];ms=members(b);files[a]={'file':str(p),'sha256':h,'bytes':len(b),'nonce':j['raw_artifact_receipts']['archive']['member_nonce'],'members':ms};allrows[a]=ms;b.close();f.close()
    diffs=[];a=allrows['base'];b=allrows['stack'];assert len(a)==len(b)
    for i,(x,y) in enumerate(zip(a,b)):
        if any(x[k]!=y[k] for k in ('key','offset','size','header_sha256','raw_sha256','padding_hex')):diffs.append([i,x['key'],y['key'],x['size'],y['size'],x['raw_sha256']==y['raw_sha256'],x['existing_normalized_member_sha256']==y['existing_normalized_member_sha256']])
    (HERE/'members.json').write_text(json.dumps({'archives':files,'different_at_same_position':diffs},indent=2)+'\n');print('total',len(a),'differ',len(diffs),'normalized differing',sum(not r[-1] for r in diffs));print(diffs[:12]);print('headers',sum(x['header_sha256']!=y['header_sha256'] for x,y in zip(a,b)),'name order',sum(x['key']!=y['key'] for x,y in zip(a,b)))
