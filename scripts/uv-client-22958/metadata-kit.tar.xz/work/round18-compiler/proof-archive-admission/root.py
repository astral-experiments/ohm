"""Read the exact release's rustc metadata root and its sparse/dense table layout."""
from pathlib import Path
import json,hashlib,struct,re,collections
here=Path(__file__).parent
sourcetree=here.parent/'full-toolchain/src/compiler/rustc_metadata/src/rmeta'
source=(sourcetree/'mod.rs').read_text()
table_names=re.findall(r'^\s*(\w+): Table<',source[source.index('define_tables! {'):].split('\n}',1)[0],re.M)
assert len(table_names)>50
sha=lambda x: hashlib.sha256(x).hexdigest()
class Reader:
 def __init__(self,d,p): self.d=d;self.p=p;self.root=p;self.previous=None;self.tables={}
 def raw(self,n): r=self.d[self.p:self.p+n];assert len(r)==n;self.p+=n;return r
 def byte(self): return self.raw(1)[0]
 def u(self):
  n=i=0
  while True:
   b=self.byte();n|=(b&127)<<i
   if b<128:return n
   i+=7;assert i<70
 def string(self): s=self.raw(self.u()).decode();assert self.byte()==0xc1;return s
 def offset(self):
  n=self.u();self.previous=self.root-n if self.previous is None else self.previous+n;assert 0<self.previous<=self.root;return self.previous
 def array(self,name):
  n=self.u(); self.tables[name]={'type':'array','length':n,'position':self.offset() if n else None}
 def value(self,name):self.tables[name]={'type':'value','position':self.offset()}
 def table(self,name):
  wraw,n=self.u(),self.u(); p=self.offset(); w=wraw&~128;wstart=p;count=n
  if wraw&128:
   count=0
   for i in range((n+63)//64):
    bitmap,prefix=struct.unpack_from('<QI',self.d,p+i*12);assert prefix==count;count+=bitmap.bit_count()
   wstart+=12*((n+63)//64)
  end=wstart+w*count;assert 0<=p<=wstart<=end<=self.root
  self.tables[name]={'type':'table','width':w,'sparse':bool(wraw&128),'length':n,'position':p,'values_position':wstart,'entries':count,'end':end}
 def fingerprint(self): return format(int.from_bytes(self.raw(16),'little'),'032x')
 def read(self):
  assert self.byte()==0;target=self.string();private,public=self.fingerprint(),self.fingerprint();assert self.byte()==1;name=Reader(self.d,self.u()).string();assert self.raw(2)==b'\0\0';extra=self.string();stable_id=self.raw(8)[::-1].hex();assert self.raw(7)==b'\0\0\3\0\0\0\0';
  begin=source.index('    externally_implementable_items: LazyArray');end=source.index('    impls: EncodedTraitImpls',begin)
  for field in re.findall(r'^    (\w+): LazyArray<',source[begin:end],re.M): self.array(field)
  representation=self.u(); assert representation in (0,1);self.array('impls');self.array('incoherent_impls');self.array('interpret_alloc_index');assert self.byte()==0
  for field in ['debugger_visualizers','exportable_items','stable_order_of_exportable_impls','exported_non_generic_symbols','exported_generic_symbols']:self.array(field)
  for field in table_names+['syntax_contexts','expn_data','expn_hashes']:self.table(field)
  self.value('def_path_hash_map');self.table('source_map');self.array('target_modifiers');self.array('denied_partial_mitigations');flags=self.raw(9).hex();assert self.byte()==1;self.table('rdr_hashes.local');self.table('rdr_hashes.expn');global_hash=self.fingerprint();assert self.d[self.p:]==b'rust-end-file';
  return {'target':target,'crate_name':name,'private_svh':private,'public_svh':public,'extra_filename':extra,'stable_crate_id':stable_id,'root':self.root,'root_length':self.p-self.root,'root_sha256':sha(self.d[self.root:self.p]),'global_public_hash':global_hash,'end_offset':self.p,'data_len':len(self.d),'tables':self.tables}

def get(arm):
 d=(here/f'{arm}-lib.rmeta').read_bytes()[96:96+15347948];r=Reader(d,struct.unpack_from('<Q',d,8)[0]);return d,r.read()
if __name__=='__main__':
 a,x=get('base');b,y=get('stack');assert x==y
 stats={}
 for k,t in x['tables'].items():
  if 'end' in t:
   p,e=t['position'],t['end'];n=sum(v!=w for v,w in zip(a[p:e],b[p:e]));stats[k]=n
   if n:print(k,p,e,n)
 print({k:v for k,v in x.items() if k!='tables'});print({k:t for k,t in x['tables'].items() if t['type']!='table' and t['position']});print('other changed bytes',8365-sum(stats.values()));(here/'crate-root.json').write_text(json.dumps({'identical':x,'fixed_table_changed_bytes':stats},indent=2)+'\n')
