"""Print diagnostic hashes from a single uv archive. This does not admit or score any arm."""
import argparse,hashlib,importlib.util,json,mmap,struct
from pathlib import Path
here=Path(__file__).resolve().parent

def load(name):
 spec=importlib.util.spec_from_file_location(name,here/(name+'.py'));r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);return r
scan=load('scan');root=load('root');index=load('defindex');sha=lambda b:hashlib.sha256(b).hexdigest()

def payload(elf):
 assert elf[:6]==b'\x7fELF\x02\x01';off=struct.unpack_from('<Q',elf,40)[0];size,num,idx=struct.unpack_from('<HHH',elf,58);s=[struct.unpack_from('<IIQQQQIIQQ',elf,off+size*i) for i in range(num)];names=elf[s[idx][4]:s[idx][4]+s[idx][5]]
 [(p,n)]=[(sh[4],sh[5]) for sh in s if names[sh[0]:names.index(b'\0',sh[0])]==b'.rmeta'];return elf[p:p+n]

def audit(path,all_members):
 with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as ar:
  ms=scan.members(ar);j=next(m for m in ms if m['name']=='lib.rmeta/');p=j['payload_offset'];rmeta=ar[p:p+j['size']];data=payload(rmeta);r=root.Reader(data,struct.unpack_from('<Q',data,8)[0]).read();ids=index.keyed(data,r);fp=index.rows(data,r['tables']['rdr_hashes.local']);width=r['tables']['rdr_hashes.local']['width'];assert len(fp)<=len(ids);fp+= [b'\0'*width]*(len(ids)-len(fp));assert len(set(ids))==len(ids);objects={x['key']:x['raw_sha256'] for x in ms if x['key'].endswith('.rcgu.o')};assert len(objects)==sum(x['key'].endswith('.rcgu.o') for x in ms)
  out={'path':str(path),'archive_sha256':sha(ar),'member_count':len(ms),'object_count':len(objects),'named_object_digests_sha256':sha(json.dumps(objects,sort_keys=True,separators=(',',':')).encode()),'metadata_elf_sha256':sha(rmeta),'raw_rmeta_section_sha256':sha(data),'metadata_root_sha256':r['root_sha256'],'crate_private_svh':r['private_svh'],'crate_public_svh':r['public_svh'],'public_global_fingerprint':r['global_public_hash'],'expansion_fingerprint_rows_sha256':sha(b''.join(index.rows(data,r['tables']['rdr_hashes.expn']))),'stable_def_hashes_sorted_sha256':sha(b''.join(sorted(ids))),'definition_count':len(ids),'stable_def_hashes_in_index_order_sha256':sha(b''.join(ids)),'stable_keyed_item_fingerprints_sha256':sha(b''.join(h+fp[i] for i,h in sorted(enumerate(ids),key=lambda pair:pair[1])))}
  if all_members:out['members']=ms
  return out
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('archive',type=Path);parser.add_argument('--members',action='store_true');args=parser.parse_args();print(json.dumps(audit(args.archive,args.members),indent=2))
