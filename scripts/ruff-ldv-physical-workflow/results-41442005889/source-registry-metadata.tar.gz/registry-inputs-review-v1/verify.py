"""Reopen classified Rust metadata and archive stubs without running a compiler."""
import argparse
import gzip
import hashlib
import itertools
import json
from pathlib import Path
import re
import runpy
import struct
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent
PROOF = json.loads((ROOT / "observations.json").read_bytes())
RECONSTRUCT = runpy.run_path(str(ROOT / "metadata-fields.py"))["reconstruct"]


def digest(value):
    return hashlib.sha256(value).hexdigest()


class Inputs:
    def __init__(self, directories, archives):
        self.directories = directories
        self.archives = []
        expected = {
            row["sha256"]: row for boot in PROOF["archives"].values() for row in boot.values()
        }
        for path in archives:
            with path.open("rb") as stream:
                row = expected[hashlib.file_digest(stream, "sha256").hexdigest()]
            assert path.stat().st_size == row["bytes"]
            self.archives.append(zipfile.ZipFile(path))

    def read(self, key, optional=False):
        assert re.fullmatch(r"[0-9a-f]{64}", key)
        for directory in self.directories:
            path = directory / key
            if path.is_file():
                data = path.read_bytes()
                break
        else:
            for archive in self.archives:
                try:
                    member = archive.getinfo("physical/extern-inputs/" + key)
                except KeyError:
                    continue
                assert member.file_size < 64 << 20
                with archive.open(member) as compressed, gzip.GzipFile(fileobj=compressed) as reader:
                    data = reader.read((128 << 20) + 1)
                assert len(data) <= 128 << 20
                break
            else:
                if optional:
                    return None
                raise ValueError(f"missing original body {key}")
        assert digest(data) == key
        return data


def verify_commitments():
    roles = PROOF["boots"]["input"]
    assert len(set(r["source"] for r in roles.values())) == 1
    assert len(set(r["registry_namespace"] for r in roles.values())) == 4
    assert len(set(r["sha"] for r in roles.values())) == 4
    expected_pairs = {frozenset(x) for x in itertools.combinations(roles, 2)}
    assert {frozenset(k.split("-")) for k in PROOF["boots"]["pairs"]} == expected_pairs
    mask = PROOF["membership_masks"]
    assert mask["local"]["present"] == 1002 and mask["expn"] == {"present": 173, "changed": []}
    indices = mask["local"]["changed"]
    assert len(indices) == 607 and indices == sorted(set(indices))
    expected = digest(",".join(map(str, indices)).encode())
    for key, pair in PROOF["boots"]["pairs"].items():
        assert pair["index_set_sha"] == expected and pair["changed_local_defindices"] == indices
        assert pair["items"]["changed_and_present"] == {"local": [607, 1002], "expn": [0, 173]}
        assert pair["raw_candidate"] == pair["reconstructed_candidate"] == roles[key.split("-")[1]]["sha"]
    for files in PROOF["metadata"].values():
        for entry in files.values():
            assert entry["candidate"] == entry["reconstructed_candidate"] != entry["parent"]
    assert sum(entry["bytes"] for files in PROOF["metadata"].values() for entry in files.values()) == 6375237
    for suite in PROOF["real_reader"].values():
        assert suite["roles"]["P"] == suite["roles"]["C"]
    assert len(PROOF["stubs"]["option"]) == 1 and len(PROOF["stubs"]["e2e"]) == 5
    return expected


def verify_metadata(inputs, sources):
    names = 0
    for files in PROOF["metadata"].values():
        for entry in files.values():
            data = [inputs.read(entry[r]) for r in ("parent", "candidate")]
            result = RECONSTRUCT(data, entry["decoded_diff"], entry["producers"], sources)
            assert result["candidate"] == result["reconstructed_candidate"] == entry["candidate"]
            assert result["parent"] == entry["parent"] and result["bytes"] == entry["bytes"]
            assert [x for x in result["records"] if not x[0].startswith("ItemPublicHashes.")] == entry["records"]
            names += 1
    return names


def verify_boots(inputs, sources):
    roles = PROOF["boots"]["input"]
    values = {r: inputs.read(v["sha"]) for r, v in roles.items()}
    producer = [{"name": "pep440_rs", "argv": ["-Zpublic-api-hash"], "generated": {}}] * 2
    for key, pair in PROOF["boots"]["pairs"].items():
        l, r = key.split("-")
        result = RECONSTRUCT([values[l], values[r]], pair["decoded_diff"], producer, sources)
        assert result["reconstructed_candidate"] == digest(values[r]) == pair["reconstructed_candidate"]
        changed = sorted(int(x[0].split("[")[1][:-1]) for x in result["records"] if x[0].startswith("ItemPublicHashes.local["))
        assert changed == pair["changed_local_defindices"]
        assert json.loads(json.dumps(result["item_public_hashes"])) == pair["items"]
        assert [x for x in result["records"] if not x[0].startswith("ItemPublicHashes.local[")] == pair["other_fields"]
    return len(values)


def verify_serde_core(inputs, sources):
    info = PROOF["serde_core"]
    private = info["generated_private_rs_sha"]
    assert len((sources / private).read_bytes()) == info["generated_size"] == 90
    producers = [{"name": "serde_core", "out_dir": path, "generated": {"private.rs": {"sha": private}}}
                 for path in info["out_dirs"]]
    hashes = info["CrateDep_hash_in_real_serde_listing"]
    lines = [sign + label + " " + h for h, sign in zip(hashes, "-+", strict=True)
             for label in ("private hash", "public_hash")]
    source = [inputs.read(info[k]) for k in ("parent", "candidate")]
    result = RECONSTRUCT(source, {"truncated": False, "differences": lines}, producers, sources)
    assert result["records"] == info["records"] and result["reconstructed_candidate"] == info["candidate"]
    return result["bytes"]


def elf_rmeta(image):
    assert image.startswith(b"\x7fELF\x02\x01")
    offset = struct.unpack_from("<Q", image, 40)[0]
    width, count, strings = struct.unpack_from("<HHH", image, 58)
    assert width == 64 and 0 < strings < count
    headers = [struct.unpack_from("<IIQQQQIIQQ", image, offset + i * width) for i in range(count)]
    names_start, names_len = headers[strings][4:6]
    names = image[names_start:names_start + names_len]
    target, = (h for h in headers if names[h[0]:].split(b"\x00", 1)[0] == b".rmeta")
    assert target[2] == 0x80000000
    return target[4], target[4] + target[5]


def verify_archive(parent, child, row):
    assert parent.startswith(b"!<arch>\n") and len(parent) == len(child)
    members = 0
    position = 8
    stub = None
    while position < len(parent):
        header = parent[position:position + 60]
        assert header == child[position:position + 60] and header[58:] == b"`\n"
        size = int(header[48:58])
        start = position + 60
        if header[:16].rstrip() == b"lib.rmeta/":
            assert stub is None
            stub = (start, start + size)
        members += 1
        position = start + size + size % 2
    assert position == len(parent) and members == row["members"]
    start, end = stub
    lo, hi = elf_rmeta(parent[start:end])
    assert (lo, hi) == elf_rmeta(child[start:end])
    n = row["header_hash_pair_location_in_original_wrapper_member"]
    assert lo <= n and n + 32 <= hi
    k = start + n
    assert [x[k:k + 32].hex() for x in (parent, child)] == row["source_bound_root_header_hex"]
    assert parent[:k] == child[:k] and parent[k + 32:] == child[k + 32:]
    assert sum(a != b for a, b in zip(parent[k:k + 32], child[k:k + 32], strict=True)) == row["actual_changed_bytes"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--blobs", type=Path, action="append", default=[], help="directory of SHA256-named uncompressed bodies")
    parser.add_argument("--zip", type=Path, action="append", default=[], help="an original GitHub artifact ZIP; checked before reading")
    parser.add_argument("--all-archives", action="store_true", help="require all six original .rlib pairs")
    parser.add_argument("--self-test", action="store_true", help="reject an alteration outside the classified metadata fields")
    args = parser.parse_args()
    index_sha = verify_commitments()
    counts = {"verified_index_set_sha256": index_sha, "independent_worker_pairs": 6, "metadata_images_reopened": 0, "archive_pairs_reopened": 0}
    if args.blobs or args.zip:
        inputs = Inputs(args.blobs, args.zip)
        with tempfile.TemporaryDirectory() as working:
            sources = Path(working)
            for k, text in PROOF["generated_source_utf8"].items():
                assert digest(text.encode()) == k
                (sources / k).write_bytes(text.encode())
            counts["metadata_images_reopened"] = verify_metadata(inputs, sources)
            counts["distinct_pep440_rs_bodies_reopened"] = verify_boots(inputs, sources)
            counts["upstream_serde_core_bytes_per_image"] = verify_serde_core(inputs, sources)
            for group in PROOF["stubs"].values():
                for row in group.values():
                    pair = [inputs.read(x, optional=not args.all_archives) for x in row["raw_archive"]]
                    if all(p is not None for p in pair):
                        verify_archive(*pair, row)
                        counts["archive_pairs_reopened"] += 1
            if args.self_test:
                en = PROOF["metadata"]["option"]["libpep440_rs.rmeta"]
                raw = [inputs.read(en[k]) for k in ("parent", "candidate")]
                bad = bytearray(raw[1])
                bad[128] ^= 1
                try:
                    RECONSTRUCT([raw[0], bytes(bad)], en["decoded_diff"], en["producers"], sources)
                except AssertionError:
                    counts["unclassified_corruption_rejected"] = True
                else:
                    raise AssertionError("unclassified byte mutation accepted")
        for z in inputs.archives:
            z.close()
    elif args.all_archives or args.self_test:
        parser.error("supply --blobs or --zip to verify original bytes")
    print(json.dumps(counts, sort_keys=True))


if __name__ == "__main__":
    main()
