# Shared-registry inputs in the Ruff LiveDebugValues comparison

Two fresh installations of the same compiler produced different public fingerprints for exactly 607 of the 1,002 populated definitions in Ruff's locked `pep440_rs` 0.7.3. The same 607 indices changed in all six comparisons among the two parent installations and the two candidate installations. All 173 populated expansion fingerprints matched. Each installation reproduced its own complete input files from independently empty states and on the actual Ruff edit. The Rust source hash and stable crate identity matched across installations.

Both source-built compilers include the coalescer in [Ohm Rust #326](https://github.com/astral-experiments/ohm-rust/pull/326). Signed Ohm -22 Cargo selected a different shared-registry directory for each physical installation. A generated 90-byte `serde_core` file contained identical Rust source in each directory. The two copies of its filename, its stable source-file ID and its two crate-header hashes account for every changed byte in the 4,246,757-byte `serde_core` metadata. The real downstream `serde` decoder reported this same crate hash. `observations.json` records the locked crate checksum, build script and generated source digests.

Five inputs to the Ruff option-edit workflow and ten to the e2e workflow contained different bytes across the two compilers. Nine standalone Rust metadata files total 6,375,237 bytes per compiler. In the other six inputs, only the two 16-byte crate hashes inside the archive member `lib.rmeta` changed. All real object members, their order and the archive symbol tables matched. The dirty `ruff_workspace` compiler opened four changed metadata files, including `pep440_rs`. All ten changed e2e inputs were opened by their actual root compilers. A successful file open establishes access to the file. It does not identify which individual definition a downstream query evaluated.

The source-native workers verified the Ruff edits, error, repair, independent clean executables and the actual compiler/linker jobs on both boots. The hardware confirmation measures the complete ordinary toolchain with these naturally generated inputs. Fixed-input pass and object comparisons are reported separately. [First native run](https://github.com/astral-experiments/ohm/actions/runs/41436324816) · [Independent boot](https://github.com/astral-experiments/ohm/actions/runs/41439952662) · [Native and hardware replay source](https://github.com/astral-experiments/ohm/tree/a43236131847bb5906247e46656d702e543d3c50/scripts/ruff-ldv-physical-workflow)

## Verify

Python 3.11 or newer can verify the compact commitments offline.

```sh
sha256sum -c SHA256SUMS
python3 -IB verify.py
```

For the original bodies, run the following from an authenticated Ohm checkout while its GitHub Actions artifacts remain available. Three inputs total about 374 MB. The verifier checks each complete artifact digest before reading its members. It reconstructs all nine metadata images, compares the six complete archives, checks the four actual `pep440_rs` bodies in every pairing, and reconstructs the upstream `serde_core` image. The negative control changes a byte outside the classified records and requires the reconstruction to fail.

```sh
for id in 13138200465 13136967651 13139237726; do
  gh-auto api "repos/astral-experiments/ohm/actions/artifacts/$id/zip" > "native-$id.zip"
done
python3 -IB verify.py --zip native-13138200465.zip --zip native-13136967651.zip \
  --zip native-13139237726.zip --all-archives --self-test
```

The alternative `--blobs DIRECTORY` takes one or more directories of SHA256-named uncompressed original files and prints the number of complete archive pairs it actually found. The coordinator reopened all nine metadata pairs, the four `pep440_rs` identities, both `serde_core` bodies and two of the six archive pairs in that mode. The original hosted readers independently reopened all six complete archive pairs.
