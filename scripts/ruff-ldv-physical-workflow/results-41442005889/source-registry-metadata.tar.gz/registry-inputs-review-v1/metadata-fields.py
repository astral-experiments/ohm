"""Authenticate field positions in metadata from the original pass, then reconstruct the other entire body."""
import hashlib,json,re,runpy,sys
from pathlib import Path
B=Path(__file__).resolve().parent
def H(b):return hashlib.sha256(b).hexdigest()
def leb(n):
 out=bytearray()
 while n>=128:
  out.append((n&127)|128);n>>=7
 return bytes((*out,n))
def refs(diff,kind):
 rows={}
 for line in diff['differences']:
  if not line.startswith(kind) or line[:3] in ('---','+++'):continue
  s=line[1:];m=re.fullmatch(r'(private hash|public_hash|Public hash:) ([0-9a-f]{32})(?: stable_crate_id StableCrateId\(([0-9]+)\))?',s)
  if m:
   rows[(m[1],m[3])]=bytes.fromhex(m[2])[::-1];continue
  m=re.fullmatch(r'(\d+) ([^ ]+) hash ([0-9a-f]{32}) (.*)',s)
  if m:rows[('dependency',int(m[1]),m[2],m[4])]=bytes.fromhex(m[3])[::-1];continue
  assert not s,(kind,repr(s))
 return rows
def offsets(b,x):
 return [m.start() for m in re.finditer(re.escape(x),b)]
def reconstruct(data,decoded,prods,dirname):
 assert not decoded['truncated']
 a,c=data;before,after=refs(decoded,'-'),refs(decoded,'+');assert before.keys()==after.keys() and len(a)==len(c)
 roles='PC';v=bytearray(a);ledger=[];changed=set()
 def write(label,at,old,new):
  assert len(old)==len(new) and old!=new
  assert a[at:at+len(old)]==old and c[at:at+len(new)]==new,(label,at)
  owned=set(range(at,at+len(old)));assert not changed&owned;changed.update(owned)
  v[at:at+len(old)]=new;ledger.append([label,at,len(old),sum(i!=j for i,j in zip(old,new,strict=True))])
 assert a[:8]==c[:8]==b'rust\0\0\0\n'
 roots=[int.from_bytes(d[8:16],'little') for d in data];assert roots[0]==roots[1]
 triple=b'x86_64-unknown-linux-gnu';hdr=b'\0'+leb(len(triple))+triple+b'\xc1'
 assert all(d[roots[0]:].startswith(hdr) for d in data)
 at=roots[0]+len(hdr)
 for j,attr in enumerate(('private hash','public_hash')):
  keys=[k for k in before if k[0]==attr];assert len(keys)<=1
  if keys:
   key,=keys;write('CrateHeader.'+attr,at+16*j,before[key],after[key])
  else:assert a[at+16*j:at+16*(j+1)]==c[at+16*j:at+16*(j+1)]
 for key in before:
  if key[0]!='dependency':continue
  old,new=before[key],after[key]
  where=offsets(a,old);assert len(where)==1 and where[0]<roots[0] and offsets(c,new)==where,(key,where)
  write('CrateDep.hash for '+key[2],where[0],old,new)
 for candidate in sorted(set(prods[0]['generated'])&set(prods[1]['generated'])):
  if not candidate.endswith('.rs'):continue
  file=[str(Path(p['out_dir'])/candidate).encode() for p in prods]
  starts=[offsets(d,path) for d,path in zip(data,file,strict=True)]
  assert starts[0]==starts[1],(candidate,starts)
  if not starts[0]:continue
  assert len(starts[0])==2
  for start in starts[0]:write('SourceFile.name '+candidate,start,*file)
  shas=[p['generated'][candidate]['sha'] for p in prods];assert shas[0]==shas[1]
  content=(dirname/shas[0]).read_bytes();assert H(content)==shas[0] and content.isascii() and b'\r' not in content
  lines=content.splitlines(keepends=True);assert 1< len(lines)<128 and max(map(len,lines))<=255
  # The trailing C1 is rustc's encoded-string terminator. RealFileName flags, Md5 kind, 32-byte hash,
  # absent secondary hash, both source lengths, delta-encoded lines and absent multibyte chars precede the stable id.
  prefix=b'\xc1\0\0\x20'+hashlib.md5(content).digest()+bytes(16)+b'\0'+leb(len(content))*2+leb(len(lines))+b'\1'+bytes(map(len,lines[:-1]))+b'\0'
  loc=starts[0][-1]+len(file[0]);assert all(d[loc:].startswith(prefix) for d in data),(candidate,loc,prefix.hex(),a[loc:loc+len(prefix)].hex())
  idx=loc+len(prefix)
  assert all(d[idx+16:idx+18]==b'\0\0' for d in data)
  write('SourceFile.stable_id '+candidate,idx,a[idx:idx+16],c[idx:idx+16])
 typed_tables=None
 if prods[0]['name']=='pep440_rs':
  assert all([k for k in p['argv'] if k.startswith('-Zpublic-api-hash')]==['-Zpublic-api-hash'] for p in prods)
  typed_tables=runpy.run_path(str(B/'item-fingerprints.py'))['classify'](a,c,write)
 assert bytes(v)==c,('unclassified difference',[(k,i,j) for k,(i,j) in enumerate(zip(v,c,strict=True)) if i!=j][:8])
 return {'bytes':len(a),'parent':H(a),'candidate':H(c),'reconstructed_candidate':H(bytes(v)),'records':ledger,'item_public_hashes':typed_tables}
def run(suite):
 idx={'option':1,'e2e':2}[suite];d=B/f'extern-body-{idx}';table=json.loads((B/f'extern-delta-{idx}.json').read_bytes())[suite]
 audits=[json.loads((d/f'{suite}-{r}-clean-clean-new-extern-audit.json').read_bytes()) for r in 'PC']
 output={}
 for name,f in table['cross'].items():
  if not name.endswith('.rmeta'):continue
  rows=[g['named'][name] for g in audits];producers=[q['producers'][str(r['producer'])] for q,r in zip(audits,rows,strict=True)]
  raw=[(d/r['body']['sha']).read_bytes() for r in rows];assert [H(b) for b in raw]==f['sha']
  output[Path(name).name]=reconstruct(raw,f['decoder'],producers,d)
 out=B/f'byte-closure-{suite}.json';out.write_text(json.dumps(output,sort_keys=True,indent=2)+'\n')
 print(suite,len(output),sum(x['bytes'] for x in output.values()),H(out.read_bytes()))
if __name__=='__main__':run(sys.argv[1])
