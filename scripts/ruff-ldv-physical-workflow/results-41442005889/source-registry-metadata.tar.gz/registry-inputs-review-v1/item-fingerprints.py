from struct import unpack_from
def leb(b,p):
 v=0
 for i in range(10):
  x=b[p+i];v|=(x&127)<<(7*i)
  if not x&128:return v,p+i+1
 assert False,'oversized integer'
def desc(b):
 root=int.from_bytes(b[8:16],'little');assert b.endswith(b'rust-end-file')
 end=len(b)-len(b'rust-end-file')-16
 valid=[]
 for p in range(max(root,end-32),end):
  if b[p:p+2]!=b'\1\1':continue
  pos=p+2;v=[]
  for _ in range(6):
   x,pos=leb(b,pos);v.append(x)
  if pos==end and v[0]==145 and v[3]==145 and 0<v[1]<8192 and 0<v[4]<8192:
   valid.append((v,end))
 assert len(valid)==1,valid
 return valid[0]
def table(b,start,n,end):
 buckets=(n+63)//64
 if start<0 or start+12*buckets>end:return
 index=[];ns=0
 for j in range(buckets):
  bits,prev=unpack_from('<QI',b,start+12*j)
  if prev!=ns or j==buckets-1 and n%64 and bits>>(n%64):return
  index.append(bits);ns+=bits.bit_count()
 base=start+12*buckets
 if not ns or base+17*ns>end:return
 entries={}
 emitted=0
 for j,bits in enumerate(index):
  for k in range(64):
   if not bits>>k&1:continue
   cursor=base+17*emitted
   if b[cursor]!=1:return
   entries[j*64+k]=cursor+1;emitted+=1
 return entries,base+17*ns
def both(b):
 data,global_pos=desc(b);_,n,_,_,m,gap=data;root=int.from_bytes(b[8:16],'little')
 assert gap>=12*((n+63)//64) and (gap-12*((n+63)//64))%17==0
 valid=[]
 for start in range(16,root-gap):
  if b[start+8:start+12]!=b'\0'*4:continue
  local=table(b,start,n,root)
  if local is None or local[1]!=start+gap:continue
  expn=table(b,local[1],m,root)
  if expn is not None:valid.append((start,local,expn,global_pos,data))
 assert len(valid)==1,(len(valid),data)
 return valid[0]
def classify(a,b,write):
 l,r=[both(x) for x in (a,b)];assert l==r,(l[0],r[0])
 start,local,expn,global_pos,data=l;changed={}
 for label,t in [('local',local),('expn',expn)]:
  total=0
  for idx,pos in t[0].items():
   if a[pos:pos+16]!=b[pos:pos+16]:
    write(f'ItemPublicHashes.{label}[{idx}]',pos,a[pos:pos+16],b[pos:pos+16]);total+=1
  changed[label]=(total,len(t[0]))
 if a[global_pos:global_pos+16]!=b[global_pos:global_pos+16]:
  write('ItemPublicHashes.public_global_hash',global_pos,a[global_pos:global_pos+16],b[global_pos:global_pos+16])
 return {'local_start':start,'local_end':local[1],'expn_end':expn[1],'encoded_lengths':[data[1],data[4]],'changed_and_present':changed,'global_hash_changed':a[global_pos:global_pos+16]!=b[global_pos:global_pos+16]}
