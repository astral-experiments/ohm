//! # Interact with the compiler
//!
//! If you consider [`ops::cargo_compile::compile`] as a `rustc` driver but on
//! Cargo side, this module is kinda the `rustc_interface` for that merits.
//! It contains all the interaction between Cargo and the rustc compiler,
//! from preparing the context for the entire build process, to scheduling
//! and executing each unit of work (e.g. running `rustc`), to managing and
//! caching the output artifact of a build.
//!
//! However, it hasn't yet exposed a clear definition of each phase or session,
//! like what rustc has done. Also, no one knows if Cargo really needs that.
//! To be pragmatic, here we list a handful of items you may want to learn:
//!
//! * [`BuildContext`] is a static context containing all information you need
//!   before a build gets started.
//! * [`BuildRunner`] is the center of the world, coordinating a running build and
//!   collecting information from it.
//! * [`custom_build`] is the home of build script executions and output parsing.
//! * [`fingerprint`] not only defines but also executes a set of rules to
//!   determine if a re-compile is needed.
//! * [`job_queue`] is where the parallelism, job scheduling, and communication
//!   machinery happen between Cargo and the compiler.
//! * [`layout`] defines and manages output artifacts of a build in the filesystem.
//! * [`unit_dependencies`] is for building a dependency graph for compilation
//!   from a result of dependency resolution.
//! * [`Unit`] contains sufficient information to build something, usually
//!   turning into a compiler invocation in a later phase.
//!
//! [`ops::cargo_compile::compile`]: crate::ops::compile

pub mod artifact;
mod build_config;
pub(crate) mod build_context;
pub(crate) mod build_runner;
mod cached_doctests;
mod compilation;
mod compile_kind;
mod crate_type;
mod custom_build;
pub(crate) mod fingerprint;
pub mod future_incompat;
pub(crate) mod job_queue;
pub(crate) mod layout;
mod links;
mod locking;
mod lto;
#[cfg(all(
    feature = "ohm-defaults",
    any(
        all(target_os = "macos", target_arch = "aarch64"),
        all(target_os = "linux", target_env = "gnu", target_arch = "x86_64")
    )
))]
mod native_link;
#[cfg(all(
    feature = "ohm-defaults",
    any(
        all(target_os = "macos", target_arch = "aarch64"),
        all(target_os = "linux", target_env = "gnu", target_arch = "x86_64")
    )
))]
pub mod native_link_driver;
mod ohm_deferred_dev_deps;
mod ohm_early_tests;
mod ohm_linker;
mod ohm_thinlto_cache;
mod output_depinfo;
mod output_sbom;
pub mod rustdoc;
pub mod standard_lib;
pub mod timings;
pub(crate) mod trim_paths;
mod unit;
pub mod unit_dependencies;
pub mod unit_graph;
pub mod unused_deps;

use crate::util::data_structures::{HashMap, HashSet};
use std::borrow::Cow;
use std::cell::OnceCell;
use std::collections::BTreeMap;
use std::env;
use std::ffi::{OsStr, OsString};
use std::fmt::Display;
use std::fs::{self, File};
use std::io::{BufRead, BufReader, BufWriter, Read, Seek, Write};
use std::ops::{Deref, Range};
use std::path::{Path, PathBuf};
use std::sync::{Arc, LazyLock};
use std::time::{Instant, UNIX_EPOCH};

use anyhow::{Context as _, Error};
use cargo_platform::{Cfg, Platform};
use cargo_util_terminal::report::{AnnotationKind, Group, Level, Renderer, Snippet};
use itertools::Itertools;
use regex::Regex;
use tracing::{debug, instrument, trace};

pub use self::build_config::UserIntent;
pub use self::build_config::{BuildConfig, CompileMode, MessageFormat};
pub use self::build_context::BuildContext;
pub use self::build_context::DepKindSet;
pub use self::build_context::FileFlavor;
pub use self::build_context::FileType;
pub use self::build_context::RustcTargetData;
pub use self::build_context::TargetInfo;
pub use self::build_runner::{BuildRunner, Metadata, UnitHash};
pub use self::compilation::{Compilation, Doctest, UnitOutput};
pub use self::compile_kind::{CompileKind, CompileKindFallback, CompileTarget};
pub use self::crate_type::CrateType;
pub use self::custom_build::LinkArgTarget;
pub use self::custom_build::{BuildOutput, BuildScriptOutputs, BuildScripts, LibraryPath};
use self::fingerprint::BuildState;
pub(crate) use self::fingerprint::DirtyReason;
pub use self::fingerprint::RustdocFingerprint;
pub use self::job_queue::Freshness;
use self::job_queue::{Job, JobQueue, JobState, PublicApiHash, Work};
pub(crate) use self::layout::Layout;
pub use self::lto::Lto;
use self::output_depinfo::output_depinfo;
use self::output_sbom::build_sbom;
use self::trim_paths::trim_paths_args;
use self::trim_paths::trim_paths_args_rustdoc;
use self::unit_graph::UnitDep;

use crate::GlobalContext;
use crate::compiler::future_incompat::FutureIncompatReport;
use crate::compiler::locking::LockKey;
use crate::compiler::timings::SectionTiming;
pub use crate::compiler::unit::Unit;
pub use crate::compiler::unit::UnitIndex;
pub use crate::compiler::unit::UnitInterner;
use crate::diagnostics::get_key_value;
use crate::util::OnceExt;
use crate::util::errors::{CargoResult, VerboseError};
use crate::util::interning::InternedString;
use crate::util::machine_message::{self, Message};
use crate::util::{add_path_args, internal, path_args};
use crate::workspace::manifest::TargetSourcePath;
use crate::workspace::profiles::{PanicStrategy, Profile, ProfileRoot, StripInner};
use crate::workspace::{Feature, PackageId, Target};

use cargo_util::{ProcessBuilder, ProcessError, paths};
use cargo_util_schemas::manifest::TomlDebugInfo;
use cargo_util_terminal::Verbosity;
use rustfix::diagnostics::Applicability;

const RUSTDOC_CRATE_VERSION_FLAG: &str = "--crate-version";
const OHM_DEFAULT_RUSTFLAGS: [&str; 2] = ["-Zpublic-api-hash", "-Zthreads=8"];
const OHM_EARLY_METADATA_RUSTFLAG: &str = "-Zohm-early-metadata";
const OHM_INCREMENTAL_CODEGEN_RUSTFLAGS: [&str; 2] =
    ["-Zohm-caller-local-cgus", "-Zohm-stable-cgu-merging"];

/// Marks a workspace/profile namespace prepared under the current seed policy.
pub(crate) const OHM_WORKTREE_SEED_MARKER: &str = ".ohm-worktree-seed-v7";
/// Permanently excludes a namespace with unsupported inputs from seeding.
pub(crate) const OHM_WORKTREE_SEED_DENY_MARKER: &str = ".ohm-worktree-seed-deny-v7";
/// Requires explicit trust at import time, including when a recipient is re-exported.
pub(crate) const OHM_WORKTREE_SEED_LOCAL_PROC_MACRO_MARKER: &str =
    ".ohm-worktree-seed-local-proc-macro-v7";
/// Private Clippy state is retained locally but never imported into another worktree.
pub(crate) const OHM_WORKTREE_CLIPPY_DIRECTORY: &str = ".ohm-clippy-v1";
// Version the compiler-visible prefix too: changing only Cargo's fingerprint
// cannot invalidate an older incremental session containing untracked macro output.
const OHM_WORKTREE_SEED_RUSTFLAG: &str = "-Zremap-cwd-prefix=/ohm-workspace/v7";

/// A successful non-check registry build can make a later check worth speculating on.
///
/// This lives in the build root so worktrees sharing registry artifacts observe the same hint.
/// The normal artifact, fingerprint, and compiler-provenance checks remain authoritative.
pub(crate) const OHM_BUILT_REGISTRY_READY_MARKER: &str = ".ohm-built-registry-ready";

/// Loader overrides can change a genuine compiler's behavior without changing
/// its executable path, version output, or Cargo's normal fingerprints.
pub(crate) const OHM_COMPILER_LOADER_ENVIRONMENT: &[&str] = &[
    "DYLD_INSERT_LIBRARIES",
    "DYLD_FORCE_FLAT_NAMESPACE",
    "DYLD_LIBRARY_PATH",
    "DYLD_FALLBACK_LIBRARY_PATH",
    "DYLD_FRAMEWORK_PATH",
    "DYLD_FALLBACK_FRAMEWORK_PATH",
    "DYLD_VERSIONED_LIBRARY_PATH",
    "DYLD_VERSIONED_FRAMEWORK_PATH",
    "DYLD_IMAGE_SUFFIX",
    "DYLD_ROOT_PATH",
    "LD_PRELOAD",
    "LD_AUDIT",
    "LD_LIBRARY_PATH",
];

/// Unlike ordinary library search paths, these overrides can insert arbitrary
/// executable code or replace the compiler's loaded images outright.
pub(crate) const OHM_COMPILER_LOADER_INJECTION_ENVIRONMENT: &[&str] = &[
    "DYLD_INSERT_LIBRARIES",
    "DYLD_FORCE_FLAT_NAMESPACE",
    "DYLD_VERSIONED_LIBRARY_PATH",
    "DYLD_VERSIONED_FRAMEWORK_PATH",
    "DYLD_IMAGE_SUFFIX",
    "DYLD_ROOT_PATH",
    "LD_PRELOAD",
    "LD_AUDIT",
];

fn unit_rustflags_without_ohm_defaults<'a>(
    gctx: &GlobalContext,
    rustflags: &'a [String],
) -> &'a [String] {
    if gctx.cli_unstable().ohm_defaults()
        && rustflags.len() >= OHM_DEFAULT_RUSTFLAGS.len()
        && rustflags
            .iter()
            .zip(OHM_DEFAULT_RUSTFLAGS)
            .all(|(actual, expected)| actual == expected)
    {
        &rustflags[OHM_DEFAULT_RUSTFLAGS.len()..]
    } else {
        rustflags
    }
}

/// Detects either spelling of the compiler's path remapping option.
fn has_remap_path_prefix(args: &[impl AsRef<str>]) -> bool {
    args.iter()
        .map(AsRef::as_ref)
        .any(|arg| arg == "--remap-path-prefix" || arg.starts_with("--remap-path-prefix="))
}

/// Checks whether the effective codegen options produce a source-based coverage map.
fn instruments_coverage<'a>(mut args: impl Iterator<Item = &'a str>) -> bool {
    let mut coverage = false;
    while let Some(arg) = args.next() {
        let option = match arg {
            "-C" | "--codegen" => args.next(),
            _ => arg
                .strip_prefix("-C")
                .or_else(|| arg.strip_prefix("--codegen=")),
        };
        if let Some(option) = option {
            let (name, value) = option.split_once('=').unwrap_or((option, "yes"));
            if matches!(name, "instrument-coverage" | "instrument_coverage") {
                coverage = !matches!(value, "0" | "n" | "no" | "off" | "false");
            }
        }
    }
    coverage
}

/// Keeps mutable-package source identities stable when a completed build is
/// copied into a new worktree. Immutable dependencies retain their existing
/// compiler flags and shared-cache fingerprints.
fn unit_uses_ohm_worktree_seeds(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    let flags = if unit.mode.is_doc() || unit.mode.is_doc_scrape() {
        &unit.rustdocflags
    } else {
        &unit.rustflags
    };
    let extra_args = build_runner
        .bcx
        .extra_args_for(unit)
        .map(Vec::as_slice)
        .unwrap_or_default();
    let compiler_args = unit
        .profile
        .rustflags
        .iter()
        .map(|arg| arg.as_str())
        .chain(extra_args.iter().map(String::as_str))
        .chain(flags.iter().map(String::as_str));
    build_runner.bcx.gctx.cli_unstable().ohm_worktree_seeds()
        && !unit.is_std
        && unit.pkg.package_id().source_id().is_path()
        // The seed's cwd mapping wins over explicit rules, including rules in response files.
        && unit.profile.trim_paths.as_ref().is_none_or(|trim| trim.is_none())
        && !has_remap_path_prefix(&unit.profile.rustflags)
        && !has_remap_path_prefix(flags)
        && !has_remap_path_prefix(extra_args)
        && !compiler_args.clone().any(|arg| arg.starts_with('@'))
        // llvm-cov opens the source filenames embedded in instrumented artifacts.
        && !instruments_coverage(compiler_args)
}

/// A library can assemble external inputs before any executable is linked.
/// Ask the driver that actually emits this unit's objects whether it can track them.
fn unit_checks_relink_inputs(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    let bcx = build_runner.bcx;
    let unstable = bcx.gctx.cli_unstable();
    (unstable.ohm_defaults() || unstable.relink_only())
        // Shared check/build stages need the same tracked compiler options.
        && (matches!(unit.mode, CompileMode::Build | CompileMode::Test)
            || unit_uses_ohm_shared_stages(build_runner, unit))
        && !(bcx.build_config.primary_unit_rustc.is_some() && build_runner.is_primary_package(unit))
        && bcx
            .rustc()
            .supports_relink_input_checks(bcx.gctx, bcx.ws.is_member(&unit.pkg))
}

/// Restoring an unchanged public metadata generation can preserve the mtime of a
/// rewritten file. Units that reuse compilation or codegen must check the contents
/// of direct inputs, including when the dependency was built by a previous command.
fn unit_uses_checksum_freshness(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    build_runner.bcx.gctx.cli_unstable().checksum_freshness
        || unit_uses_ohm_worktree_seeds(build_runner, unit)
        || fingerprint::unit_can_use_early_cutoff(build_runner, unit)
        || fingerprint::unit_can_use_relink_only(build_runner, unit)
}

/// Returns the private namespace whose completed artifacts may seed another worktree.
fn unit_worktree_seed_namespace(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> Option<PathBuf> {
    (unit_uses_ohm_worktree_seeds(build_runner, unit)
        && build_runner.bcx.ws.shared_registry_cache_enabled())
    .then(|| build_runner.files().worktree_seed_namespace(unit))
}

/// Skips public API production when an output cannot expose a reusable changed interface.
fn unit_suppresses_default_public_api_hash(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> bool {
    build_runner.bcx.gctx.cli_unstable().ohm_defaults()
        && ((build_runner.is_terminal_check_unit(unit)
            && !unit_uses_ohm_shared_stages(build_runner, unit))
            || matches!(unit.mode, CompileMode::Test | CompileMode::Doctest)
            || (matches!(unit.mode, CompileMode::Build | CompileMode::Check { .. })
                && unit.target.is_lib()
                && !unit.target.proc_macro()
                && !unit.artifact.is_true()
                && unit
                    .target
                    .rustc_crate_types()
                    .iter()
                    .all(|kind| matches!(kind, CrateType::Lib | CrateType::Rlib))
                && build_runner.is_immutable_shared_registry_unit(unit)))
        && fingerprint::unit_public_api_hash_override(build_runner, unit).is_none()
}

/// Shares compiler identity across ordinary debug checks and builds, including
/// non-incremental dependencies whose identity reaches an incremental consumer.
/// Cargo's artifact and fingerprint identities remain distinct for each mode.
fn unit_uses_ohm_shared_stages(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    let bcx = build_runner.bcx;
    bcx.gctx.cli_unstable().ohm_shared_stages()
        && unit.profile.root == ProfileRoot::Debug
        && unit.profile.codegen_backend.is_none()
        && matches!(
            unit.mode,
            CompileMode::Build | CompileMode::Check { test: false }
        )
        && !unit.is_std
        && !unit.target.is_compile_time_dependency()
        && !unit.artifact.is_true()
        && (bcx.rustc().workspace_wrapper.is_none() || !bcx.ws.is_member(&unit.pkg))
        && bcx.rustc().supports_ohm_shared_stages(bcx.gctx)
}

fn unit_uses_ohm_incremental_codegen(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    let gctx = build_runner.bcx.gctx;
    if !gctx.cli_unstable().ohm_defaults()
        || unit.profile.root != ProfileRoot::Debug
        || !unit.profile.incremental
        || !matches!(unit.profile.opt_level.as_str(), "0" | "1")
        || unit.profile.codegen_backend.is_some()
        || !(matches!(unit.mode, CompileMode::Build | CompileMode::Test)
            || unit_uses_ohm_shared_stages(build_runner, unit))
        || unit.target.is_compile_time_dependency()
        || !build_runner.bcx.ws.is_member(&unit.pkg)
    {
        return false;
    }

    let extra_args = build_runner
        .bcx
        .extra_args_for(unit)
        .map(Vec::as_slice)
        .unwrap_or_default();
    let user_rustflags = unit_rustflags_without_ohm_defaults(gctx, &unit.rustflags);
    let mut options = unit
        .pkg
        .manifest()
        .lint_rustflags()
        .iter()
        .map(String::as_str)
        .chain(unit.profile.rustflags.iter().map(|flag| flag.as_str()))
        .chain(extra_args.iter().map(String::as_str))
        .chain(user_rustflags.iter().map(String::as_str));

    while let Some(argument) = options.next() {
        let option = if argument == "-C" || argument == "-Z" {
            options.next()
        } else {
            argument
                .strip_prefix("-C")
                .or_else(|| argument.strip_prefix("-Z"))
        };
        let Some(option) = option else {
            continue;
        };
        if option.starts_with("instrument-coverage")
            || option.starts_with("profile-generate")
            || option.starts_with("profile-use")
            || option.starts_with("sanitizer")
            || option.starts_with("codegen-backend")
            || option
                .strip_prefix("opt-level=")
                .is_some_and(|level| !matches!(level, "0" | "1"))
        {
            return false;
        }
    }

    build_runner
        .bcx
        .rustc()
        .supports_ohm_incremental_codegen(gctx)
}

/// Enables local monomorphization reuse without requiring a public API hash.
fn unit_uses_ohm_incremental_mono_partitions(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> bool {
    unit_uses_ohm_incremental_codegen(build_runner, unit)
        && build_runner
            .bcx
            .rustc()
            .supports_ohm_incremental_mono_partitions(build_runner.bcx.gctx)
}

/// A glorified callback for executing calls to rustc. Rather than calling rustc
/// directly, we'll use an `Executor`, giving clients an opportunity to intercept
/// the build calls.
pub trait Executor: Send + Sync + 'static {
    /// Called after a rustc process invocation is prepared up-front for a given
    /// unit of work (may still be modified for runtime-known dependencies, when
    /// the work is actually executed).
    fn init(&self, _build_runner: &BuildRunner<'_, '_>, _unit: &Unit) {}

    /// In case of an `Err`, Cargo will not continue with the build process for
    /// this package.
    fn exec(
        &self,
        cmd: &ProcessBuilder,
        id: PackageId,
        target: &Target,
        mode: CompileMode,
        on_stdout_line: &mut dyn FnMut(&str) -> CargoResult<()>,
        on_stderr_line: &mut dyn FnMut(&str) -> CargoResult<()>,
    ) -> CargoResult<()>;

    /// Queried when queuing each unit of work. If it returns true, then the
    /// unit will always be rebuilt, independent of whether it needs to be.
    fn force_rebuild(&self, _unit: &Unit) -> bool {
        false
    }
}

/// A `DefaultExecutor` calls rustc without doing anything else. It is Cargo's
/// default behaviour.
#[derive(Copy, Clone)]
pub struct DefaultExecutor;

impl Executor for DefaultExecutor {
    #[instrument(name = "rustc", skip_all, fields(package = id.name().as_str(), process = cmd.to_string()))]
    fn exec(
        &self,
        cmd: &ProcessBuilder,
        id: PackageId,
        _target: &Target,
        _mode: CompileMode,
        on_stdout_line: &mut dyn FnMut(&str) -> CargoResult<()>,
        on_stderr_line: &mut dyn FnMut(&str) -> CargoResult<()>,
    ) -> CargoResult<()> {
        cmd.exec_with_streaming(on_stdout_line, on_stderr_line, false)
            .map(drop)
    }
}

/// Builds up and enqueue a list of pending jobs onto the `job` queue.
///
/// Starting from the `unit`, this function recursively calls itself to build
/// all jobs for dependencies of the `unit`. Each of these jobs represents
/// compiling a particular package.
///
/// Note that **no actual work is executed as part of this**, that's all done
/// next as part of [`JobQueue::execute`] function which will run everything
/// in order with proper parallelism.
#[tracing::instrument(skip(build_runner, jobs, exec))]
fn compile<'gctx>(
    build_runner: &mut BuildRunner<'_, 'gctx>,
    jobs: &mut JobQueue<'gctx>,
    unit: &Unit,
    exec: &Arc<dyn Executor>,
    force_rebuild: bool,
) -> CargoResult<()> {
    if !build_runner.compiled.insert(unit.clone()) {
        return Ok(());
    }

    let lock = if build_runner.bcx.gctx.cli_unstable().fine_grain_locking {
        Some(build_runner.lock_manager.lock_shared(build_runner, unit)?)
    } else {
        None
    };

    // If we are in `--compile-time-deps` and the given unit is not a compile time
    // dependency, skip compiling the unit and jumps to dependencies, which still
    // have chances to be compile time dependencies
    if !unit.skip_non_compile_time_dep {
        // Build up the work to be done to compile this unit, enqueuing it once
        // we've got everything constructed.
        fingerprint::prepare_init(build_runner, unit)?;

        let job = if unit.mode.is_run_custom_build() {
            custom_build::prepare(build_runner, unit)?
        } else if unit.mode.is_doc_test() && !cached_doctests::enabled(build_runner.bcx, unit) {
            // Rustdoc builds these targets when the test runner executes them.
            Job::new_fresh()
        } else {
            let force = exec.force_rebuild(unit) || force_rebuild;
            let reused_test = build_runner
                .reused_test_check(unit)
                .filter(|_| !force)
                .cloned();
            let mut job = if reused_test.is_some() {
                Job::new_fresh()
            } else {
                fingerprint::prepare_target(build_runner, unit, force)?
            };
            job.before(if let Some(native) = &reused_test {
                reused_test_check_work(build_runner, unit, native)?.then(link_targets(
                    build_runner,
                    unit,
                    true,
                )?)
            } else if unit.mode.is_doc_test() {
                if job.freshness().is_dirty() {
                    cached_doctests::prepare(build_runner, unit, force)?
                } else {
                    Work::noop()
                }
            } else if job.freshness().is_dirty() {
                let work = if unit.mode.is_doc() || unit.mode.is_doc_scrape() {
                    rustdoc(build_runner, unit)?
                } else {
                    rustc(build_runner, unit, exec, force)?
                };
                work.then(link_targets(build_runner, unit, false)?)
            } else {
                let output_options = OutputOptions::for_fresh(build_runner, unit);
                let manifest = ManifestErrorContext::new(build_runner, unit);
                let work = replay_output_cache(
                    unit.pkg.package_id(),
                    manifest,
                    &unit.target,
                    build_runner.files().message_cache_path(unit),
                    output_options,
                );
                // Need to link targets on both the dirty and fresh.
                work.then(link_targets(build_runner, unit, true)?)
            });

            // If -Zfine-grain-locking is enabled, we wrap the job with an upgrade to exclusive
            // lock before starting, then downgrade to a shared lock after the job is finished.
            if build_runner.bcx.gctx.cli_unstable().fine_grain_locking
                && (job.freshness().is_dirty() || reused_test.is_some())
            {
                if let Some(lock) = lock {
                    // Here we unlock the current shared lock to avoid deadlocking with other cargo
                    // processes. Then we configure our compile job to take an exclusive lock
                    // before starting. Once we are done compiling (including both rmeta and rlib)
                    // we downgrade to a shared lock to allow other cargo's to read the build unit.
                    // We will hold this shared lock for the remainder of compilation to prevent
                    // other cargo from re-compiling while we are still using the unit.
                    build_runner.lock_manager.unlock(&lock)?;
                    job.before(prebuild_lock_exclusive(lock.clone()));
                    job.after(downgrade_lock_to_shared(lock));
                }
            }

            job
        };
        jobs.enqueue(build_runner, unit, job)?;
    }

    // Be sure to compile all dependencies of this target as well.
    let deps = Vec::from(build_runner.unit_deps(unit)); // Create vec due to mutable borrow.
    for dep in deps {
        if build_runner
            .deferred_dev_deps
            .dependencies
            .contains(&dep.unit)
            && build_runner.bcx.roots.contains(unit)
        {
            continue;
        }
        compile(build_runner, jobs, &dep.unit, exec, false)?;
    }

    Ok(())
}

/// Generates the warning message used when fallible doc-scrape units fail,
/// either for rustdoc or rustc.
fn make_failed_scrape_diagnostic(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
    top_line: impl Display,
) -> String {
    let manifest_path = unit.pkg.manifest_path();
    let relative_manifest_path = manifest_path
        .strip_prefix(build_runner.bcx.ws.root())
        .unwrap_or(&manifest_path);

    format!(
        "\
{top_line}
    Try running with `--verbose` to see the error message.
    If an example should not be scanned, then consider adding `doc-scrape-examples = false` to its `[[example]]` definition in {}",
        relative_manifest_path.display()
    )
}

const RELINK_CACHE_VERSION: u32 = 5;

#[derive(Hash, serde::Deserialize, serde::Serialize)]
struct RelinkCacheFile {
    path: PathBuf,
    blake3: String,
}

#[derive(Hash, serde::Deserialize, serde::Serialize)]
struct RelinkCacheObject {
    path: PathBuf,
    len: u64,
    modified_nanos: u64,
}

#[derive(serde::Deserialize, serde::Serialize)]
struct RelinkCacheManifest {
    version: u32,
    rlink: RelinkCacheFile,
    executable: RelinkCacheObject,
    objects: Vec<RelinkCacheFile>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    unused_extern_names: Option<Vec<String>>,
}

impl RelinkCacheManifest {
    fn input_checksum(&self) -> u64 {
        crate::util::hash_u64((self.version, &self.rlink, &self.executable, &self.objects))
    }
}

#[derive(serde::Deserialize, serde::Serialize)]
struct CheckedRelinkManifest {
    input_checksum: u64,
    proof_checksum: u64,
    #[serde(flatten)]
    manifest: RelinkCacheManifest,
}

fn read_relink_manifest_slice(bytes: &[u8]) -> Option<CheckedRelinkManifest> {
    #[derive(serde::Deserialize)]
    #[serde(deny_unknown_fields)]
    struct File {
        path: PathBuf,
        blake3: String,
    }

    #[derive(serde::Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Object {
        path: PathBuf,
        len: u64,
        modified_nanos: u64,
    }

    #[derive(serde::Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Fields {
        input_checksum: u64,
        proof_checksum: u64,
        version: u32,
        rlink: File,
        executable: Object,
        objects: Vec<File>,
        #[serde(default)]
        unused_extern_names: Option<Vec<String>>,
    }

    fn file(value: File) -> RelinkCacheFile {
        RelinkCacheFile {
            path: value.path,
            blake3: value.blake3,
        }
    }

    // The writer emits a compact object. Read its fields directly rather than
    // buffering the manifest in serde's intermediate flatten representation.
    if bytes.first() == Some(&b'{') {
        if let Ok(fields) = serde_json::from_slice::<Fields>(bytes) {
            return Some(CheckedRelinkManifest {
                input_checksum: fields.input_checksum,
                proof_checksum: fields.proof_checksum,
                manifest: RelinkCacheManifest {
                    version: fields.version,
                    rlink: file(fields.rlink),
                    executable: RelinkCacheObject {
                        path: fields.executable.path,
                        len: fields.executable.len,
                        modified_nanos: fields.executable.modified_nanos,
                    },
                    objects: fields.objects.into_iter().map(file).collect(),
                    unused_extern_names: fields.unused_extern_names,
                },
            });
        }
    }

    // Flatten also validates unknown values, including nested out-of-range
    // numbers. Preserve that behavior and the original map-only root format.
    serde_json::from_slice(bytes).ok()
}

const RELINK_MANIFEST_SLICE_LIMIT: u64 = 1024 * 1024;

fn read_relink_manifest_json(
    mut reader: impl Read + Seek,
    len: Option<u64>,
) -> Option<CheckedRelinkManifest> {
    if let Some(len) = len.filter(|len| *len <= RELINK_MANIFEST_SLICE_LIMIT) {
        // The length is only a hint: read an extra byte so a growing file cannot
        // turn a valid JSON prefix into an accepted manifest. Bound the buffer
        // independently of the file's current size.
        let mut bytes = Vec::with_capacity(len as usize + 1);
        reader.by_ref().take(len + 1).read_to_end(&mut bytes).ok()?;
        if bytes.len() as u64 == len {
            return read_relink_manifest_slice(&bytes);
        }
        reader.rewind().ok()?;
    }

    // Keep streaming large files, or files whose length changed, from the same
    // opened descriptor rather than reopening a potentially different path.
    serde_json::from_reader(BufReader::new(reader)).ok()
}

struct RelinkCachePaths {
    rlink: PathBuf,
    executable: PathBuf,
    manifest: PathBuf,
    objects: PathBuf,
}

impl RelinkCachePaths {
    fn new(executable: PathBuf) -> Self {
        let rlink = executable.with_extension("rlink");
        let manifest = executable.with_extension("rlink-cache.json");
        let objects = executable.with_extension("rlink-objects");
        Self {
            rlink,
            executable,
            manifest,
            objects,
        }
    }

    /// Retains the objects referenced by this cache across full and link-only invocations.
    fn preserve_codegen(&self, rustc: &mut ProcessBuilder) {
        rustc.arg("-Z").arg("emit-rlink");
        let mut temps_dir = OsString::from("temps-dir=");
        temps_dir.push(&self.objects);
        rustc.arg("-Z").arg(temps_dir);
    }

    fn is_valid(&self) -> bool {
        let manifest = self.read_manifest();
        let Some(manifest) = manifest else {
            return false;
        };
        manifest.version == RELINK_CACHE_VERSION
            && manifest.rlink.path == self.rlink
            && manifest.executable.path == self.executable
            && self.has_object_directory()
            && !manifest.objects.is_empty()
            && file_matches(&manifest.rlink)
            && object_matches(&manifest.executable)
            && manifest.objects.iter().all(file_matches)
    }

    fn initialize(
        &self,
        unused_externs: Option<&std::collections::BTreeSet<InternedString>>,
    ) -> CargoResult<()> {
        let mut objects = Vec::new();
        for path in self.codegen_temps()? {
            match path.extension().and_then(OsStr::to_str) {
                Some("o" | "obj") => objects.push(cached_file(path)?),
                Some("bc") => paths::remove_file(&path)?,
                _ => {}
            }
        }
        objects.sort_by(|left, right| left.path.cmp(&right.path));
        if objects.is_empty() {
            // A successful wrapper invocation may intentionally skip compilation.
            // The cache was invalidated before running rustc, so leave it absent.
            return Ok(());
        }
        let manifest = RelinkCacheManifest {
            version: RELINK_CACHE_VERSION,
            rlink: cached_file(self.rlink.clone())?,
            executable: cached_object(self.executable.clone())?,
            objects,
            unused_extern_names: unused_externs.map(|unused_externs| {
                unused_externs
                    .iter()
                    .map(|unused_extern| unused_extern.as_str().to_owned())
                    .collect()
            }),
        };
        self.write_manifest(manifest)
    }

    fn has_object_directory(&self) -> bool {
        self.objects
            .symlink_metadata()
            .is_ok_and(|meta| meta.is_dir())
    }

    fn codegen_temps(&self) -> CargoResult<Vec<PathBuf>> {
        if !self.has_object_directory() {
            return Ok(Vec::new());
        }
        let entries = match fs::read_dir(&self.objects) {
            Ok(entries) => entries,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
            Err(error) => return Err(error.into()),
        };
        Ok(entries
            .filter_map(Result::ok)
            .map(|entry| entry.path())
            .filter(|path| {
                matches!(
                    path.extension().and_then(OsStr::to_str),
                    Some("bc" | "o" | "obj")
                )
            })
            .collect())
    }

    fn clear_codegen_temps(&self) -> CargoResult<()> {
        // rustc recreates this private directory on demand. Remove the entry
        // itself so a saved symlink cannot redirect cleanup or the next build.
        match fs::symlink_metadata(&self.objects) {
            Ok(meta) if meta.is_dir() => fs::remove_dir_all(&self.objects)
                .with_context(|| format!("failed to clear `{}`", self.objects.display())),
            Ok(_) => paths::remove_file(&self.objects),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(error) => Err(error.into()),
        }
    }

    fn refresh_executable(&self) -> CargoResult<()> {
        let mut manifest = self
            .read_manifest()
            .ok_or_else(|| internal("validated relink cache manifest disappeared"))?;
        manifest.executable = cached_object(self.executable.clone())?;
        self.write_manifest(manifest)
    }

    fn write_manifest(&self, manifest: RelinkCacheManifest) -> CargoResult<()> {
        let input_checksum = manifest.input_checksum();
        let checked = CheckedRelinkManifest {
            input_checksum,
            proof_checksum: crate::util::hash_u64((input_checksum, &manifest.unused_extern_names)),
            manifest,
        };
        paths::write_atomic_no_follow(&self.manifest, serde_json::to_vec(&checked)?)?;
        Ok(())
    }

    fn read_manifest(&self) -> Option<RelinkCacheManifest> {
        let file = paths::open_regular(&self.manifest).ok()?;
        let len = file.metadata().ok().map(|metadata| metadata.len());
        let mut checked = read_relink_manifest_json(file, len)?;
        if checked.input_checksum != checked.manifest.input_checksum() {
            return None;
        }
        if checked.proof_checksum
            != crate::util::hash_u64((
                checked.input_checksum,
                &checked.manifest.unused_extern_names,
            ))
        {
            checked.manifest.unused_extern_names = None;
        }
        Some(checked.manifest)
    }

    fn proves_unused_extern(&self, extern_name: InternedString) -> bool {
        self.unused_extern_names()
            .is_some_and(|unused_externs| unused_externs.contains(&extern_name))
    }

    fn unused_extern_names(&self) -> Option<HashSet<InternedString>> {
        let Some(manifest) = self.read_manifest() else {
            return None;
        };

        if manifest.version != RELINK_CACHE_VERSION
            || manifest.executable.path != self.executable
            || !object_matches(&manifest.executable)
        {
            return None;
        }

        Some(
            manifest
                .unused_extern_names?
                .into_iter()
                .map(InternedString::from)
                .collect(),
        )
    }

    fn invalidate(&self) -> CargoResult<()> {
        for path in [&self.manifest, &self.rlink] {
            if let Err(error) = paths::remove_file(path)
                && !error
                    .downcast_ref::<std::io::Error>()
                    .is_some_and(|e| e.kind() == std::io::ErrorKind::NotFound)
            {
                return Err(error).with_context(|| {
                    format!("failed to invalidate relink cache `{}`", path.display())
                });
            }
        }
        Ok(())
    }
}

fn cached_file(path: PathBuf) -> CargoResult<RelinkCacheFile> {
    let mut hasher = blake3::Hasher::new();
    hasher
        .update_reader(paths::open_regular(&path)?)
        .with_context(|| format!("failed to hash `{}`", path.display()))?;
    Ok(RelinkCacheFile {
        path,
        blake3: hasher.finalize().to_hex().to_string(),
    })
}

fn file_matches(expected: &RelinkCacheFile) -> bool {
    cached_file(expected.path.clone()).is_ok_and(|actual| actual.blake3 == expected.blake3)
}

fn cached_object(path: PathBuf) -> CargoResult<RelinkCacheObject> {
    let metadata = fs::metadata(&path)?;
    let modified_nanos = metadata
        .modified()?
        .duration_since(UNIX_EPOCH)
        .map_err(|error| internal(format!("invalid mtime for `{}`: {error}", path.display())))?
        .as_nanos()
        .try_into()
        .map_err(|_| {
            internal(format!(
                "mtime for `{}` does not fit in u64",
                path.display()
            ))
        })?;
    Ok(RelinkCacheObject {
        path,
        len: metadata.len(),
        modified_nanos,
    })
}

fn object_matches(expected: &RelinkCacheObject) -> bool {
    cached_object(expected.path.clone())
        .map(|actual| {
            actual.len == expected.len && actual.modified_nanos == expected.modified_nanos
        })
        .unwrap_or(false)
}

/// Finds an unused-self-library candidate that cannot be linked transitively.
///
/// Cargo permits development-dependency cycles, so a package library can still be
/// linked through another dependency even when its direct `--extern` is unused.
fn unused_integration_self_dependency(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> Option<(UnitIndex, InternedString)> {
    let check = unit.mode == CompileMode::Check { test: true }
        && build_runner.bcx.gctx.cli_unstable().ohm_early_tests();
    if !build_runner.bcx.gctx.cli_unstable().ohm_defaults()
        || (unit.mode != CompileMode::Test && !check)
        || !unit.target.is_test()
        || build_runner.bcx.build_config.primary_unit_rustc.is_some()
        || matches!(unit.kind, CompileKind::Target(CompileTarget::Json { .. }))
        || build_runner.compilation.target_linker(unit.kind).is_some()
        || !build_runner
            .bcx
            .rustc()
            .supports_transparent_unused_externs(build_runner.bcx.gctx)
        || has_opaque_integration_linker_flags(build_runner, unit)
    {
        return None;
    }

    let dependencies = build_runner.unit_deps(unit);
    let mut self_dependencies = dependencies.iter().enumerate().filter(|(_, dependency)| {
        dependency.unit.pkg.package_id() == unit.pkg.package_id()
            && (dependency.unit.mode == CompileMode::Build
                || (check && dependency.unit.mode == CompileMode::Check { test: false }))
            && dependency.unit.target.is_lib()
            && !dependency.unit.artifact.is_true()
            && dependency.manifest_deps.0.is_none()
            && !dependency.nounused
            && dependency
                .unit
                .target
                .rustc_crate_types()
                .iter()
                .all(|crate_type| matches!(crate_type, CrateType::Lib | CrateType::Rlib))
    });
    let (self_index, self_dependency) = self_dependencies.next()?;
    if self_dependencies.next().is_some() {
        return None;
    }

    let mut pending = dependencies
        .iter()
        .enumerate()
        .filter(|(index, dependency)| *index != self_index && dependency.unit.target.is_linkable())
        .map(|(_, dependency)| dependency.unit.clone())
        .collect::<Vec<_>>();
    let mut visited = HashSet::default();
    while let Some(dependency) = pending.pop() {
        if dependency.pkg.package_id() == unit.pkg.package_id() && dependency.target.is_lib() {
            return None;
        }
        if visited.insert(dependency.clone()) {
            pending.extend(
                build_runner
                    .unit_deps(&dependency)
                    .iter()
                    .filter(|dependency| dependency.unit.target.is_linkable())
                    .map(|dependency| dependency.unit.clone()),
            );
        }
    }

    Some((
        build_runner.bcx.unit_to_index[&self_dependency.unit],
        self_dependency.extern_crate_name,
    ))
}

/// Finds workspace libraries that cannot contribute to this test executable.
///
/// An unused direct `--extern` is insufficient: the same package may still be
/// linked through a different, actually used dependency. Walk only the roots
/// which the previous compiler invocation did not prove unused, then reject
/// every candidate package reachable from one of those roots. Comparing package
/// identities also rules out alternate features, profiles, and renamed edges.
fn unused_integration_workspace_dependencies(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
    unused_extern_names: &HashSet<InternedString>,
) -> HashSet<UnitIndex> {
    let dependencies = build_runner.unit_deps(unit);
    let mut pending = dependencies
        .iter()
        .filter(|dependency| {
            dependency.unit.target.is_linkable()
                && !unused_extern_names.contains(&dependency.extern_crate_name)
        })
        .map(|dependency| dependency.unit.clone())
        .collect::<Vec<_>>();
    let mut reachable_units = HashSet::default();
    let mut reachable_packages = HashSet::default();

    while let Some(dependency) = pending.pop() {
        if reachable_units.insert(dependency.clone()) {
            reachable_packages.insert(dependency.pkg.package_id());
            pending.extend(
                build_runner
                    .unit_deps(&dependency)
                    .iter()
                    .filter(|dependency| dependency.unit.target.is_linkable())
                    .map(|dependency| dependency.unit.clone()),
            );
        }
    }

    let mut unused_dependencies = HashSet::default();
    for dependency in dependencies.iter().filter(|dependency| {
        let package_id = dependency.unit.pkg.package_id();

        package_id != unit.pkg.package_id()
            && build_runner.bcx.ws.is_member_id(package_id)
            && dependency.unit.kind == unit.kind
            && dependency.unit.mode == CompileMode::Build
            && dependency.unit.target.is_lib()
            && !dependency.unit.artifact.is_true()
            && !dependency.nounused
            && dependency.manifest_deps.0.is_some()
            && dependency.extern_crate_name.as_str() == dependency.unit.target.crate_name()
            && dependency.unit.pkg.manifest().links().is_none()
            && build_runner
                .find_build_script_units(&dependency.unit)
                .is_none()
            && !has_opaque_integration_linker_flags(build_runner, &dependency.unit)
            && dependency
                .unit
                .target
                .rustc_crate_types()
                .iter()
                .all(|crate_type| matches!(crate_type, CrateType::Lib | CrateType::Rlib))
            && unused_extern_names.contains(&dependency.extern_crate_name)
            && !reachable_packages.contains(&package_id)
            && dependencies
                .iter()
                .filter(|other| other.unit.pkg.package_id() == package_id)
                .count()
                == 1
    }) {
        unused_dependencies.insert(build_runner.bcx.unit_to_index[&dependency.unit]);
    }

    unused_dependencies
}

/// Whether user-controlled compiler arguments can add untracked linker inputs.
fn has_opaque_integration_linker_flags(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    let arguments = unit
        .profile
        .rustflags
        .iter()
        .map(|argument| argument.as_str())
        .chain(
            build_runner
                .bcx
                .extra_args_for(unit)
                .into_iter()
                .flatten()
                .map(String::as_str),
        )
        .chain(
            build_runner
                .rustflags_for_cache_admission(unit)
                .iter()
                .map(String::as_str),
        );
    let mut arguments = arguments.peekable();

    while let Some(argument) = arguments.next() {
        if argument.starts_with('@')
            || argument == "-l"
            || argument.starts_with("-l")
            || argument == "-L"
            || argument.starts_with("-L")
            || argument == "--extern"
            || argument.starts_with("--extern=")
            || argument == "--library-path"
            || argument.starts_with("--library-path=")
        {
            return true;
        }

        let codegen_option = if argument == "-C" || argument == "--codegen" {
            arguments.next()
        } else {
            argument
                .strip_prefix("-C")
                .or_else(|| argument.strip_prefix("--codegen="))
        };
        if codegen_option.is_some_and(|option| {
            option.split_once('=').is_some_and(|(name, _)| {
                matches!(
                    name,
                    "link-arg" | "link_arg" | "link-args" | "link_args" | "linker"
                )
            })
        }) {
            return true;
        }

        let unstable_option = if argument == "-Z" {
            arguments.next()
        } else {
            argument.strip_prefix("-Z")
        };
        if unstable_option.is_some_and(|option| {
            option.split_once('=').is_some_and(|(name, _)| {
                matches!(
                    name,
                    "pre-link-arg" | "pre_link_arg" | "pre-link-args" | "pre_link_args"
                )
            })
        }) {
            return true;
        }
    }

    false
}

/// Dependency artifacts whose unchanged public metadata permits reusing consumer codegen.
fn relinkable_dependencies(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> HashSet<UnitIndex> {
    build_runner
        .unit_deps(unit)
        .iter()
        .filter(|dep| {
            dep.unit.mode == CompileMode::Build
                && !dep.unit.artifact.is_true()
                && dep.unit.target.is_lib()
                && dep
                    .unit
                    .target
                    .rustc_crate_types()
                    .iter()
                    .all(|crate_type| matches!(crate_type, CrateType::Lib | CrateType::Rlib))
        })
        .map(|dep| build_runner.bcx.unit_to_index[&dep.unit])
        .collect()
}

/// Creates a unit of work invoking `rustc` for building the `unit`.
fn rustc(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
    exec: &Arc<dyn Executor>,
    force: bool,
) -> CargoResult<Work> {
    let mut rustc = prepare_rustc(build_runner, unit)?;

    let name = unit.pkg.name();

    let outputs = build_runner.outputs(unit)?;
    let root = build_runner.files().output_dir(unit);
    let unstable = build_runner.bcx.gctx.cli_unstable();
    let relink_cache = (unstable.collect_relink_cache()
        && fingerprint::unit_can_use_relink_only(build_runner, unit))
    .then(|| {
        outputs
            .iter()
            .find(|output| output.flavor == FileFlavor::Normal)
            .map(|output| RelinkCachePaths::new(output.path.clone()))
    })
    .flatten();
    #[cfg(all(feature = "ohm-defaults", target_os = "macos", target_arch = "aarch64"))]
    let use_native_driver =
        relink_cache.is_some() && native_link_driver::supported(build_runner, unit);
    let check_relink_inputs = unit_checks_relink_inputs(build_runner, unit);
    if check_relink_inputs {
        rustc.arg("-Zohm-check-relink-inputs");
    }
    let reuse_codegen = relink_cache.is_some() && unstable.relink_only() && check_relink_inputs;
    let source_arg = path_args(build_runner.bcx.ws, unit).0;
    let relinkable_dependencies = relinkable_dependencies(build_runner, unit);
    let unused_integration_dependency = unused_integration_self_dependency(build_runner, unit);
    let record_dev_unused = ohm_deferred_dev_deps::supported(build_runner, unit);
    let dev_native_output_dirs = record_dev_unused
        .then(|| ohm_deferred_dev_deps::native_output_dirs(build_runner))
        .unwrap_or_default();
    let previous_dev_unused = record_dev_unused
        .then(|| {
            relink_cache
                .as_ref()
                .and_then(RelinkCachePaths::unused_extern_names)
        })
        .flatten();
    let deferred_dev_names =
        ohm_deferred_dev_deps::plan(build_runner, unit, previous_dev_unused.as_ref());
    let deferred_dev_retry = build_runner.deferred_dev_deps.retry.clone();
    let workspace_integration_proof = unused_integration_dependency
        .and_then(|_| relink_cache.as_ref())
        .and_then(RelinkCachePaths::unused_extern_names);
    let check_hint = unused_integration_dependency
        .filter(|_| build_runner.bcx.gctx.cli_unstable().ohm_early_tests())
        .map(|(_, name)| ohm_early_tests::CheckHint::new(build_runner, unit, name));
    let early_test = ohm_early_tests::dependency(
        build_runner,
        unit,
        workspace_integration_proof.as_ref(),
        check_hint.as_ref(),
    )
    .map(|(dependency, name)| {
        build_runner
            .early_test_dependencies
            .insert(unit.clone(), dependency.clone());
        let completion = build_runner
            .early_test_completions
            .entry(dependency)
            .or_default()
            .clone();
        (completion, name)
    });
    if let Some(cache) = &relink_cache {
        cache.preserve_codegen(&mut rustc);
    }

    // Prepare the native lib state (extra `-L` and `-l` flags).
    let build_script_outputs = Arc::clone(&build_runner.build_script_outputs);
    let current_id = unit.pkg.package_id();
    let manifest = ManifestErrorContext::new(build_runner, unit);
    let build_scripts = build_runner.build_scripts.get(unit).cloned();
    #[cfg(all(
        feature = "ohm-defaults",
        any(
            all(target_os = "macos", target_arch = "aarch64"),
            all(target_os = "linux", target_env = "gnu", target_arch = "x86_64")
        )
    ))]
    let declared_link = relink_cache.as_ref().and_then(|_| {
        let scripts = build_scripts.as_ref()?;
        let linker = native_link_driver::declared_driver(build_runner, unit)?;
        let roots = scripts
            .to_link
            .iter()
            .map(|(id, metadata)| {
                Some((
                    *metadata,
                    build_runner
                        .bcx
                        .packages
                        .get_one(*id)
                        .ok()?
                        .root()
                        .to_owned(),
                ))
            })
            .collect::<Option<Vec<_>>>()?;
        Some((linker, roots))
    });

    // If we are a binary and the package also contains a library, then we
    // don't pass the `-l` flags.
    let pass_l_flag = unit.target.is_lib() || !unit.pkg.targets().iter().any(|t| t.is_lib());

    let dep_info_name =
        if let Some(c_extra_filename) = build_runner.files().metadata(unit).c_extra_filename() {
            format!("{}-{}.d", unit.target.crate_name(), c_extra_filename)
        } else {
            format!("{}.d", unit.target.crate_name())
        };
    let rustc_dep_info_loc = root.join(dep_info_name);
    let dep_info_loc = fingerprint::dep_info_loc(build_runner, unit);

    let mut output_options = OutputOptions::for_dirty(build_runner, unit);
    let package_id = unit.pkg.package_id();
    let target = Target::clone(&unit.target);
    let mode = unit.mode;

    exec.init(build_runner, unit);
    let exec = exec.clone();

    let root_output = build_runner.files().host_dest().map(|v| v.to_path_buf());
    let build_dir = build_runner.files().build_root(unit);
    let shared_registry_root = build_runner
        .bcx
        .ws
        .shared_registry_cache_enabled()
        .then(|| {
            build_runner
                .bcx
                .ws
                .configured_build_dir()
                .into_path_unlocked()
        });
    let pkg_root = unit.pkg.root().to_path_buf();
    let cwd = rustc
        .get_cwd()
        .unwrap_or_else(|| build_runner.bcx.gctx.cwd())
        .to_path_buf();
    let fingerprint_dir = build_runner.files().fingerprint_dir(unit);
    let cached_output_path = build_runner.files().message_cache_path(unit);
    let mut message_provenance = if (unit.mode == CompileMode::Build
        && unit.pkg.package_id().source_id().is_remote_registry())
        || (build_runner.bcx.gctx.cli_unstable().ohm_reuse_built_deps()
            && build_runner.bcx.ws.is_member(&unit.pkg)
            && !unit.target.for_host()
            && ((unit.mode == CompileMode::Build
                && (unit.target.is_lib() || unit.target.is_executable()))
                || (unit.mode == CompileMode::Test
                    && (unit.target.is_lib()
                        || unit.target.is_executable()
                        || unit.target.is_test()
                        || unit.target.is_bench())
                    && unit.target.harness())))
    {
        build_runner
            .registry_message_provenance()?
            .map(|provenance| {
                (
                    build_runner.registry_message_provenance_path(unit),
                    provenance,
                )
            })
    } else {
        None
    };
    let registry_reuse_readiness_path = (message_provenance.is_some()
        && build_runner.bcx.gctx.cli_unstable().ohm_reuse_built_deps()
        && !matches!(
            build_runner.bcx.build_config.intent,
            UserIntent::Check { .. }
        ))
    .then(|| build_dir.join(OHM_BUILT_REGISTRY_READY_MARKER));
    let mut cached_output_options = OutputOptions::for_fresh(build_runner, unit);
    let script_metadatas = build_runner.find_build_script_metadatas(unit);
    let is_local = unit.is_local();
    let worktree_seed_namespace = unit_worktree_seed_namespace(build_runner, unit);
    let artifact = unit.artifact;
    let sbom_files = build_runner.sbom_output_files(unit)?;
    let sbom = if sbom_files.is_empty() {
        None
    } else {
        Some(build_sbom(build_runner, unit)?)
    };

    let unremap_files = build_runner.unremap_output_files(unit)?;
    let unremap_content = if unremap_files.is_empty() {
        None
    } else {
        let mut buf = Vec::new();
        trim_paths::write_unremap_file(&mut buf, build_runner, unit)?;
        Some(buf)
    };

    let hide_diagnostics_for_scrape_unit = build_runner.bcx.unit_can_fail_for_docscraping(unit)
        && !matches!(
            build_runner.bcx.gctx.shell().verbosity(),
            Verbosity::Verbose
        );
    let failed_scrape_diagnostic = hide_diagnostics_for_scrape_unit.then(|| {
        // If this unit is needed for doc-scraping, then we generate a diagnostic that
        // describes the set of reverse-dependencies that cause the unit to be needed.
        let target_desc = unit.target.description_named();
        let mut for_scrape_units = build_runner
            .bcx
            .scrape_units_have_dep_on(unit)
            .into_iter()
            .map(|unit| unit.target.description_named())
            .collect::<Vec<_>>();
        for_scrape_units.sort();
        let for_scrape_units = for_scrape_units.join(", ");
        make_failed_scrape_diagnostic(build_runner, unit, format_args!("failed to check {target_desc} in package `{name}` as a prerequisite for scraping examples from: {for_scrape_units}"))
    });
    if hide_diagnostics_for_scrape_unit {
        output_options.show_diagnostics = false;
    }
    let env_config = Arc::clone(build_runner.bcx.gctx.env_config()?);

    let fingerprint = build_runner.fingerprints.get(unit).cloned();
    let unit_name = format!("{} v{}", unit.pkg.name(), unit.pkg.version());
    let consumes_native_inputs = matches!(unit.mode, CompileMode::Build | CompileMode::Test)
        && unit.requires_upstream_objects();
    let recheck_rebuilt_dependencies = !force
        && check_relink_inputs
        && relink_cache.is_some()
        && fingerprint
            .as_ref()
            .is_some_and(|fp| fp.native_recheck_can_reuse_codegen(build_runner, unit));
    let can_skip_compilation = fingerprint::unit_can_use_early_cutoff(build_runner, unit)
        && fingerprint
            .as_ref()
            .is_some_and(|fingerprint| fingerprint.is_early_cutoff_candidate());

    return Ok(Work::new(move |state| {
        // Build-script outputs are only authoritative after their jobs finish.
        // An unused Rust extern can still be consumed through native linking.
        let record_dev_unused = record_dev_unused
            && build_scripts.as_ref().is_none_or(|scripts| {
                let script_outputs = build_script_outputs.lock().unwrap();
                scripts.to_link.iter().all(|(package, metadata)| {
                    script_outputs.get(*metadata).is_some_and(|output| {
                        let has_linker_args = output.linker_args.iter().any(|(link_target, _)| {
                            // Match add_native_deps: a dependency's ordinary
                            // link arguments do not reach this test compiler.
                            link_target.applies_to(&target, mode)
                                && (*package == current_id || *link_target == LinkArgTarget::Cdylib)
                        });
                        if has_linker_args {
                            return false;
                        }
                        if output.library_paths.is_empty() && output.library_links.is_empty() {
                            return true;
                        }
                        // Dependency -l flags belong to their retained Rust
                        // libraries; only their -L paths reach this compiler.
                        *package != current_id
                            && dev_native_output_dirs.get(metadata).is_some_and(|out_dir| {
                                ohm_deferred_dev_deps::native_search_paths_supported(
                                    output, out_dir,
                                )
                            })
                    })
                })
            });
        if !deferred_dev_names.is_empty() && !record_dev_unused {
            tracing::info!(target: "cargo::compiler::ohm_deferred_dev_deps", "native linker inputs require complete graph");
            deferred_dev_retry.store(true, std::sync::atomic::Ordering::Relaxed);
            return Err(ohm_deferred_dev_deps::Retry.into());
        }
        let unused_integration_dependency = unused_integration_dependency.filter(|_| {
            let Some(build_scripts) = build_scripts.as_ref() else {
                return true;
            };
            let script_outputs = build_script_outputs.lock().unwrap();
            build_scripts.to_link.iter().all(|(package_id, metadata)| {
                if *package_id != current_id {
                    // add_native_deps forwards every dependency's search paths to
                    // the linker, even when the test does not use its Rust library.
                    return mode != CompileMode::Test
                        || script_outputs
                            .get(*metadata)
                            .is_some_and(|output| output.library_paths.is_empty());
                }
                script_outputs.get(*metadata).is_some_and(|output| {
                    output.library_paths.is_empty()
                        && output.library_links.is_empty()
                        && !output
                            .linker_args
                            .iter()
                            .any(|(link_target, _)| link_target.applies_to(&target, mode))
                })
            })
        });
        let early_test = if let Some((completion, _)) = &early_test
            && (unused_integration_dependency.is_none() || completion.is_finished())
        {
            // A test that starts after its library finished can compile against it normally.
            completion.wait()?;
            None
        } else {
            early_test
        };
        let observes_foreign_span = fingerprint
            .as_ref()
            .is_some_and(|fp| fp.observes_foreign_span());
        // An unchanged public API does not cover files read directly by the compiler,
        // e.g. a dependency's metadata consumed by include_bytes! through a symlink.
        let compiler_inputs_are_fresh = std::cell::LazyCell::new(|| {
            fingerprint
                .as_ref()
                .is_some_and(|fp| fp.dep_info_files_are_fresh(&pkg_root, &build_dir))
        });
        if let Some(ref fp) = fingerprint
            && !observes_foreign_span
        {
            tracing::info!(
                "early cutoff check for {}: fs_status={:?}, outputs={:?}",
                unit_name,
                fp.fs_status(),
                outputs
                    .iter()
                    .map(|o| (&o.path, o.path.exists()))
                    .collect::<Vec<_>>()
            );

            if early_test.is_none()
                && deferred_dev_names.is_empty()
                && can_skip_compilation
                && fingerprint::can_skip_due_to_early_cutoff(fp)
                && *compiler_inputs_are_fresh
            {
                let essential_outputs = outputs
                    .iter()
                    .filter(|output| output.flavor != FileFlavor::DebugInfo)
                    .collect::<Vec<_>>();
                let all_outputs_exist = !essential_outputs.is_empty()
                    && essential_outputs.iter().all(|o| o.path.exists());
                if all_outputs_exist {
                    replay_output_cache_inner(
                        state,
                        package_id,
                        &manifest,
                        &target,
                        &cached_output_path,
                        &mut cached_output_options,
                    )?;

                    // Touch output files to update their mtimes so future builds
                    // don't see them as stale compared to rebuilt dependencies.
                    let now = filetime::FileTime::now();
                    for output in &essential_outputs {
                        if fingerprint::can_preserve_skipped_output(fp, &output.path) {
                            continue;
                        }
                        if let Err(e) = filetime::set_file_mtime(&output.path, now) {
                            tracing::debug!(
                                "early cutoff: failed to touch output {:?}: {}",
                                output.path,
                                e
                            );
                        }
                    }
                    tracing::info!(
                        "early cutoff: skipping compilation of {} (all deps unchanged)",
                        unit_name
                    );
                    fp.set_build_state(BuildState::SkippedEarlyCutoff);
                    state.skipped_early_cutoff();
                    return Ok(());
                } else {
                    tracing::info!(
                        "early cutoff: cannot skip {} (outputs don't exist yet)",
                        unit_name
                    );
                }
            }
        }

        let can_relink_dependencies = (reuse_codegen || recheck_rebuilt_dependencies)
            && fingerprint.as_ref().is_some_and(|fingerprint| {
                // An unused Rust library can leave this test's codegen valid even if its
                // public API changed. Native inputs are resolved independently by the linker.
                fingerprint::can_relink_due_to_early_cutoff(fingerprint, &relinkable_dependencies)
                    || reuse_codegen
                        && unused_integration_dependency.is_some_and(|(dependency, extern_name)| {
                            fingerprint::can_relink_unused_integration_dependency(
                                fingerprint,
                                dependency,
                            ) && relink_cache
                                .as_ref()
                                .is_some_and(|cache| cache.proves_unused_extern(extern_name))
                        })
            });
        let validation_started = Instant::now();
        let use_cached_relink = early_test.is_none()
            && deferred_dev_names.is_empty()
            && can_relink_dependencies
            && !observes_foreign_span
            && relink_cache
                .as_ref()
                .is_some_and(RelinkCachePaths::is_valid)
            && *compiler_inputs_are_fresh;
        if can_relink_dependencies {
            tracing::info!(
                "relink-only: cache validation for {unit_name} took {:?}",
                validation_started.elapsed()
            );
        }
        if use_cached_relink {
            tracing::info!("relink-only: reusing cached codegen for {unit_name}");
        } else {
            if let Some(cache) = &relink_cache {
                cache.invalidate()?;
                cache.clear_codegen_temps()?;
            }
            output_options.prepare_for_compiler();
        }

        // Artifacts are in a different location than typical units,
        // hence we must assure the crate- and target-dependent
        // directory is present.
        if artifact.is_true() {
            paths::create_dir_all(&root)?;
        }

        // Only at runtime have we discovered what the extra -L and -l
        // arguments are for native libraries, so we process those here. We
        // also need to be sure to add any -L paths for our plugins to the
        // dynamic library load path as a plugin's dynamic library may be
        // located somewhere in there.
        // Finally, if custom environment variables have been produced by
        // previous build scripts, we include them in the rustc invocation.
        #[cfg(all(feature = "ohm-defaults", target_os = "macos", target_arch = "aarch64"))]
        let before_script_args = rustc.get_args().count();
        let mut build_script_overrides_loader = false;
        #[cfg(all(
            feature = "ohm-defaults",
            any(
                all(target_os = "macos", target_arch = "aarch64"),
                all(target_os = "linux", target_env = "gnu", target_arch = "x86_64")
            )
        ))]
        let mut declared_inputs = None;
        if let Some(build_scripts) = build_scripts {
            let script_outputs = build_script_outputs.lock().unwrap();
            #[cfg(all(
                feature = "ohm-defaults",
                any(
                    all(target_os = "macos", target_arch = "aarch64"),
                    all(target_os = "linux", target_env = "gnu", target_arch = "x86_64")
                )
            ))]
            if let Some((linker, roots)) = &declared_link {
                declared_inputs = native_link_driver::declarations(
                    linker,
                    roots.iter().map(|(key, root)| {
                        script_outputs
                            .get(*key)
                            .map(|output| (root.as_path(), output))
                    }),
                );
            }
            add_native_deps(
                &mut rustc,
                &script_outputs,
                &build_scripts,
                pass_l_flag,
                &target,
                current_id,
                mode,
            )?;
            if let Some(ref root_output) = root_output {
                add_plugin_deps(
                    &mut rustc,
                    &script_outputs,
                    &build_scripts,
                    root_output,
                    shared_registry_root.as_deref(),
                )?;
            }
            if message_provenance.is_some() {
                build_script_overrides_loader = script_metadatas
                    .as_ref()
                    .into_iter()
                    .flatten()
                    .filter_map(|metadata| script_outputs.get(*metadata))
                    .any(|output| {
                        output.env.iter().any(|(name, _)| {
                            build_runner::is_sensitive_compiler_environment(name, cfg!(windows))
                        })
                    });
            }
            add_custom_flags(&mut rustc, &script_outputs, script_metadatas)?;
        }

        if let (Some(fingerprint), Some(namespace)) =
            (fingerprint.as_ref(), worktree_seed_namespace.as_deref())
            && early_test.is_none()
            && deferred_dev_names.is_empty()
            && !observes_foreign_span
            && fingerprint::can_reuse_after_scripts(
                fingerprint,
                &pkg_root,
                &build_dir,
                namespace,
                &rustc_dep_info_loc,
                &rustc,
                consumes_native_inputs,
            )
        {
            replay_output_cache_inner(
                state,
                package_id,
                &manifest,
                &target,
                &cached_output_path,
                &mut cached_output_options,
            )?;
            tracing::info!(
                "worktree seed: reusing {unit_name} after unchanged build script results"
            );
            fingerprint.mark_worktree_reused();
            state.skipped_early_cutoff();
            return Ok(());
        }

        if let Some((_, provenance)) = &mut message_provenance {
            provenance.capture_compiler_environment(&rustc, build_script_overrides_loader);
        }

        #[cfg(all(feature = "ohm-defaults", target_os = "macos", target_arch = "aarch64"))]
        if use_native_driver
            && check_relink_inputs
            && let (Some(cache), Some(fp)) = (relink_cache.as_ref(), fingerprint.as_ref())
            && fp.needs_native_link_driver()
            && rustc.get_args().skip(before_script_args).all(|arg| {
                arg.to_str().is_some_and(|arg| {
                    !arg.starts_with("link-arg")
                        && !arg.starts_with("link_arg")
                        && !arg.starts_with("-Clink-arg")
                        && !arg.starts_with('@')
                })
            })
        {
            native_link_driver::install(&mut rustc, cache);
        }
        #[cfg(all(
            feature = "ohm-defaults",
            any(
                all(target_os = "macos", target_arch = "aarch64"),
                all(target_os = "linux", target_env = "gnu", target_arch = "x86_64")
            )
        ))]
        if let (Some(inputs), Some(cache), Some(fp)) =
            (declared_inputs, &relink_cache, &fingerprint)
            && check_relink_inputs
            && fp.needs_native_link_driver()
        {
            native_link_driver::install_declared(&mut rustc, cache, &inputs);
        }
        let link_only = if let Some(cache) = &relink_cache {
            let mut link_only = rustc.clone();
            if !link_only.replace_arg(&source_arg, &cache.rlink) {
                return Err(internal(format!(
                    "could not replace rustc input `{}` with cached rlink `{}`",
                    source_arg.display(),
                    cache.rlink.display()
                )));
            }
            link_only.arg("-Z").arg("link-only");
            Some(link_only)
        } else {
            None
        };

        for output in outputs.iter() {
            // If there is both an rmeta and rlib, rustc will prefer to use the
            // rlib, even if it is older. Therefore, we must delete the rlib to
            // force using the new rmeta.
            if output.path.extension() == Some(OsStr::new("rmeta")) {
                let dst = root.join(&output.path).with_extension("rlib");
                if dst.exists() {
                    paths::remove_file(&dst)?;
                }
            }

            // Some linkers do not remove the executable, but truncate and modify it.
            // That results in the old hard-link being modified even after renamed.
            // We delete the old artifact here to prevent this behavior from confusing users.
            // See rust-lang/cargo#8348.
            if output.hardlink.is_some() && output.path.exists() {
                _ = paths::remove_file(&output.path).map_err(|e| {
                    tracing::debug!(
                        "failed to delete previous output file `{:?}`: {e:?}",
                        output.path
                    );
                });
            }
        }

        if use_cached_relink {
            replay_output_cache_inner(
                state,
                package_id,
                &manifest,
                &target,
                &cached_output_path,
                &mut cached_output_options,
            )?;
            let cache = relink_cache.as_ref().expect("relink cache was validated");
            let link_only = link_only.as_ref().expect("relink command was prepared");
            state.running(link_only);
            let link_started = Instant::now();
            exec.exec(
                link_only,
                package_id,
                &target,
                mode,
                &mut |line| on_stdout_line(state, line, package_id, &target),
                &mut |line| {
                    on_stderr_line(
                        state,
                        line,
                        package_id,
                        &manifest,
                        &target,
                        &mut cached_output_options,
                    )
                },
            )
            .map_err(verbose_if_simple_exit_code)
            .with_context(|| format!("could not relink `{unit_name}` from cached codegen"))?;
            tracing::info!(
                "relink-only: rustc link for {unit_name} took {:?}",
                link_started.elapsed()
            );
            let update_started = Instant::now();
            cache.refresh_executable()?;
            tracing::info!(
                "relink-only: cache update for {unit_name} took {:?}",
                update_started.elapsed()
            );
            return Ok(());
        }

        if let Some((path, _)) = &message_provenance {
            match fs::remove_file(path) {
                Ok(()) => {}
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(error.into()),
            }
        }

        if mode.is_check()
            && let Some(hint) = &check_hint
        {
            hint.clear();
        }
        state.running(&rustc);
        let timestamp = paths::set_invocation_time(&fingerprint_dir)?;
        if let Some(sbom) = &sbom {
            for file in sbom_files {
                tracing::debug!("writing sbom to {}", file.display());
                let outfile = BufWriter::new(paths::create(&file)?);
                serde_json::to_writer(outfile, sbom)?;
            }
        }

        if let Some(content) = &unremap_content {
            for file in &unremap_files {
                tracing::debug!("writing unremap file to {}", file.display());
                paths::write_atomic(file, content)?;
            }
        }

        let mut accepted_early_test = false;
        if !deferred_dev_names.is_empty() || early_test.is_some() {
            let output = std::cell::RefCell::new(ohm_early_tests::Output::default());
            let result = exec.exec(
                &rustc,
                package_id,
                &target,
                mode,
                &mut |line| {
                    output.borrow_mut().push(line, false);
                    Ok(())
                },
                &mut |line| {
                    if early_test.is_some()
                        && let Ok(timing) = serde_json::from_str::<SectionTiming>(line)
                    {
                        state.on_section_timing_emitted(timing);
                    } else {
                        output.borrow_mut().push(line, true);
                    }
                    Ok(())
                },
            );
            let output = output.into_inner();
            if let Some((completion, extern_name)) = &early_test {
                // Wait for the producer before publishing provisional output.
                let producer_result = completion.wait();
                accepted_early_test =
                    producer_result.is_ok() && result.is_ok() && output.proves_unused(*extern_name);
                if accepted_early_test {
                    // Linking may have finished before the producer. Record the
                    // acceptance time so the next build sees a fresh executable.
                    let accepted_at = filetime::FileTime::now();
                    for artifact in outputs
                        .iter()
                        .filter(|output| output.flavor == FileFlavor::Normal)
                    {
                        filetime::set_file_mtime(&artifact.path, accepted_at)?;
                    }
                    tracing::info!(target: "cargo::compiler::ohm_early_tests", "accepted early {}", target.name());
                } else {
                    if let Some(cache) = &relink_cache {
                        cache.clear_codegen_temps()?;
                    }
                    for output in outputs.iter() {
                        if output.path.exists() {
                            paths::remove_file(&output.path)?;
                        }
                    }
                    producer_result?;
                    tracing::info!(target: "cargo::compiler::ohm_early_tests", "retrying {} after dependency completion", target.name());
                }
            } else {
                if result.is_err()
                    || !deferred_dev_names
                        .iter()
                        .all(|name| output.proves_unused(*name))
                {
                    if let Some(cache) = &relink_cache {
                        cache.clear_codegen_temps()?;
                        if cache.rlink.exists() {
                            paths::remove_file(&cache.rlink)?;
                        }
                    }
                    for output in outputs.iter() {
                        if output.path.is_dir() {
                            // macOS debug bundles are directories.
                            paths::remove_dir_all(&output.path)?;
                        } else if output.path.exists() {
                            paths::remove_file(&output.path)?;
                        }
                    }
                    // Only ordinary diagnostics can be repaired by building
                    // deferred dependencies. Preserve crashes and interruptions.
                    if let Err(error) = result
                        && error
                            .downcast_ref::<ProcessError>()
                            .and_then(|error| error.code)
                            != Some(1)
                    {
                        for line in output.stderr {
                            on_stderr_line(
                                state,
                                &line,
                                package_id,
                                &manifest,
                                &target,
                                &mut output_options,
                            )?;
                        }
                        return Err(error);
                    }
                    deferred_dev_retry.store(true, std::sync::atomic::Ordering::Relaxed);
                    return Err(ohm_deferred_dev_deps::Retry.into());
                }
                tracing::info!(target: "cargo::compiler::ohm_deferred_dev_deps", "accepted current unused-dependency proof");
                accepted_early_test = true;
            }
            if accepted_early_test {
                for line in output.stdout {
                    on_stdout_line(state, &line, package_id, &target)?;
                }
                for line in output.stderr {
                    on_stderr_line(
                        state,
                        &line,
                        package_id,
                        &manifest,
                        &target,
                        &mut output_options,
                    )?;
                }
            }
        }

        let result = if accepted_early_test {
            Ok(())
        } else {
            exec.exec(
                &rustc,
                package_id,
                &target,
                mode,
                &mut |line| on_stdout_line(state, line, package_id, &target),
                &mut |line| {
                    on_stderr_line(
                        state,
                        line,
                        package_id,
                        &manifest,
                        &target,
                        &mut output_options,
                    )
                },
            )
        }
        .map_err(|e| {
            if output_options.errors_seen == 0 {
                // If we didn't expect an error, do not require --verbose to fail.
                // This is intended to debug
                // https://github.com/rust-lang/crater/issues/733, where we are seeing
                // Cargo exit unsuccessfully while seeming to not show any errors.
                e
            } else {
                verbose_if_simple_exit_code(e)
            }
        })
        .with_context(|| {
            // adapted from rustc_errors/src/lib.rs
            let warnings = match output_options.warnings_seen {
                0 => String::new(),
                1 => "; 1 warning emitted".to_string(),
                count => format!("; {} warnings emitted", count),
            };
            let errors = match output_options.errors_seen {
                0 => String::new(),
                1 => " due to 1 previous error".to_string(),
                count => format!(" due to {} previous errors", count),
            };
            let name = descriptive_pkg_name(&name, &target, &mode);
            format!("could not compile {name}{errors}{warnings}")
        });

        if let Err(e) = result {
            if let Some(diagnostic) = failed_scrape_diagnostic {
                state.warning(diagnostic);
            }

            return Err(e);
        }

        // Exec should never return with success *and* generate an error.
        debug_assert_eq!(output_options.errors_seen, 0);

        if let Some(hint) = &check_hint {
            if mode.is_check() {
                hint.record(state.recorded_unused_externs().as_ref());
            } else {
                hint.clear();
            }
        }

        if let Some((path, provenance)) = &message_provenance {
            let mut provenance = provenance.clone();
            provenance.capture_messages(&cached_output_path)?;
            paths::write_atomic_no_follow(path, serde_json::to_vec(&provenance)?)?;

            if let Some(readiness_path) = &registry_reuse_readiness_path
                && let Err(error) = fs::OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .open(readiness_path)
                && error.kind() != std::io::ErrorKind::AlreadyExists
            {
                debug!(
                    path = %readiness_path.display(),
                    %error,
                    "could not record registry build readiness"
                );
            }
        }

        if let Some(cache) = &relink_cache {
            let unused_externs = (unused_integration_dependency.is_some() || record_dev_unused)
                .then(|| state.recorded_unused_externs())
                .flatten();
            cache.initialize(unused_externs.as_ref())?;
        }

        if rustc_dep_info_loc.exists() {
            let marked = fingerprint::translate_dep_info(
                &rustc_dep_info_loc,
                &dep_info_loc,
                &cwd,
                &pkg_root,
                &build_dir,
                &rustc,
                // Do not track source files in the fingerprint for registry dependencies.
                is_local,
                &env_config,
                worktree_seed_namespace.as_deref(),
            )
            .with_context(|| {
                internal(format!(
                    "could not parse/generate dep info at: {}",
                    rustc_dep_info_loc.display()
                ))
            })?;
            if let Some(fp) = &fingerprint {
                fp.record_native_link_inputs(marked);
            }
            // This mtime shift allows Cargo to detect if a source file was
            // modified in the middle of the build.
            paths::set_file_time_no_err(dep_info_loc, timestamp);
        }

        // This mtime shift for .rmeta is a workaround as rustc incremental build
        // since rust-lang/rust#114669 (1.90.0) skips unnecessary rmeta generation.
        //
        // The situation is like this:
        //
        // 1. When build script execution's external dependendies
        //    (rerun-if-changed, rerun-if-env-changed) got updated,
        //    the execution unit reran and got a newer mtime.
        // 2. rustc type-checked the associated crate, though with incremental
        //    compilation, no rmeta regeneration. Its `.rmeta` stays old.
        // 3. Run `cargo check` again. Cargo found build script execution had
        //    a new mtime than existing crate rmeta, so re-checking the crate.
        //    However the check is a no-op (input has no change), so stuck.
        if mode.is_check() {
            for output in outputs.iter() {
                paths::set_file_time_no_err(&output.path, timestamp);
            }
        }

        Ok(())
    }));

    // Add all relevant `-L` and `-l` flags from dependencies (now calculated and
    // present in `state`) to the command provided.
    fn add_native_deps(
        rustc: &mut ProcessBuilder,
        build_script_outputs: &BuildScriptOutputs,
        build_scripts: &BuildScripts,
        pass_l_flag: bool,
        target: &Target,
        current_id: PackageId,
        mode: CompileMode,
    ) -> CargoResult<()> {
        let mut library_paths = vec![];

        for key in build_scripts.to_link.iter() {
            let output = build_script_outputs.get(key.1).ok_or_else(|| {
                internal(format!(
                    "couldn't find build script output for {}/{}",
                    key.0, key.1
                ))
            })?;
            library_paths.extend(output.library_paths.iter());
        }

        // NOTE: This very intentionally does not use the derived ord from LibraryPath because we need to
        // retain relative ordering within the same type (i.e. not lexicographic). The use of a stable sort
        // is also important here because it ensures that paths of the same type retain the same relative
        // ordering (for an unstable sort to work here, the list would need to retain the idx of each element
        // and then sort by that idx when the type is equivalent.
        library_paths.sort_by_key(|p| match p {
            LibraryPath::CargoArtifact(_) => 0,
            LibraryPath::External(_) => 1,
        });

        for path in library_paths.iter() {
            rustc.arg("-L").arg(path.as_ref());
        }

        for key in build_scripts.to_link.iter() {
            let output = build_script_outputs.get(key.1).ok_or_else(|| {
                internal(format!(
                    "couldn't find build script output for {}/{}",
                    key.0, key.1
                ))
            })?;

            if key.0 == current_id {
                if pass_l_flag {
                    for name in output.library_links.iter() {
                        rustc.arg("-l").arg(name);
                    }
                }
            }

            for (lt, arg) in &output.linker_args {
                // There was an unintentional change where cdylibs were
                // allowed to be passed via transitive dependencies. This
                // clause should have been kept in the `if` block above. For
                // now, continue allowing it for cdylib only.
                // See https://github.com/rust-lang/cargo/issues/9562
                if lt.applies_to(target, mode)
                    && (key.0 == current_id || *lt == LinkArgTarget::Cdylib)
                {
                    rustc.arg("-C").arg(format!("link-arg={}", arg));
                }
            }
        }
        Ok(())
    }
}

fn verbose_if_simple_exit_code(err: Error) -> Error {
    // If a signal on unix (`code == None`) or an abnormal termination
    // on Windows (codes like `0xC0000409`), don't hide the error details.
    match err
        .downcast_ref::<ProcessError>()
        .as_ref()
        .and_then(|perr| perr.code)
    {
        Some(n) if cargo_util::is_simple_exit_code(n) => VerboseError::new(err).into(),
        _ => err,
    }
}

fn prebuild_lock_exclusive(lock: LockKey) -> Work {
    Work::new(move |state| {
        state.lock_exclusive(&lock)?;
        Ok(())
    })
}

/// Replays a validated native root as a check without publishing a check fingerprint.
/// Libraries retain their real native metadata. Executables and test harnesses
/// have empty metadata because no crate can import them. Future checks must
/// still validate the native proof or compile normally.
fn reused_test_check_work(
    build_runner: &mut BuildRunner<'_, '_>,
    check: &Unit,
    native: &Unit,
) -> CargoResult<Work> {
    let outputs = build_runner.outputs(check)?;
    let metadata = if native.mode == CompileMode::Build && native.target.is_lib() {
        Some(
            build_runner
                .outputs(native)?
                .iter()
                .find(|output| output.flavor == FileFlavor::Rmeta)
                .expect("validated native library metadata")
                .path
                .clone(),
        )
    } else {
        None
    };
    let fingerprint_path = build_runner.files().fingerprint_file_path(check, "");
    let messages = replay_output_cache(
        check.pkg.package_id(),
        ManifestErrorContext::new(build_runner, check),
        &check.target,
        build_runner.files().message_cache_path(native),
        OutputOptions::for_fresh(build_runner, check),
    );
    Ok(Work::new(move |_| {
        // Restoring a metadata file must not revive an older check
        // fingerprint whose output was missing. The native record remains
        // the sole proof for this result.
        paths::write(&fingerprint_path, b"")?;
        for output in outputs.iter() {
            paths::create_dir_all(output.path.parent().unwrap())?;
            if let Some(metadata) = &metadata {
                paths::copy(metadata, &output.path)?;
            } else {
                paths::write(&output.path, b"")?;
            }
        }
        Ok(())
    })
    .then(messages))
}

fn downgrade_lock_to_shared(lock: LockKey) -> Work {
    Work::new(move |state| {
        state.downgrade_to_shared(&lock)?;
        Ok(())
    })
}

/// Link the compiled target (often of form `foo-{metadata_hash}`) to the
/// final target. This must happen during both "Fresh" and "Compile".
fn link_targets(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
    fresh: bool,
) -> CargoResult<Work> {
    let bcx = build_runner.bcx;
    let outputs = build_runner.outputs(unit)?;
    if !bcx.build_config.emit_json() && outputs.iter().all(|output| output.hardlink.is_none()) {
        return Ok(Work::noop());
    }
    let export_dir = build_runner.files().export_dir();
    let private_export = (cfg!(any(target_os = "linux", target_os = "macos"))
        && export_dir.is_some()
        && bcx.ws.shared_registry_cache_enabled()
        && !build_runner.files().is_shared_registry_unit(unit))
    .then(|| {
        (
            bcx.ws.target_dir(),
            build_runner.files().private_context_dir(unit),
        )
    });
    let package_id = unit.pkg.package_id();
    let manifest_path = PathBuf::from(unit.pkg.manifest_path());
    let profile = unit.profile.clone();
    let unit_mode = unit.mode;
    let metadata_only_artifact = matches!(bcx.build_config.intent, UserIntent::Check { .. })
        && build_runner.is_metadata_only_reused_registry_dependency(unit);
    let additional_check_artifact = matches!(bcx.build_config.intent, UserIntent::Check { .. })
        && build_runner.is_reused_registry_dependency(unit)
        && !metadata_only_artifact;
    let features = unit.features.iter().map(|s| s.to_string()).collect();
    let json_messages = bcx.build_config.emit_json();
    let executable = build_runner.get_executable(unit)?;
    let mut target = Target::clone(&unit.target);
    if let TargetSourcePath::Metabuild = target.src_path() {
        // Give it something to serialize.
        let path = unit.pkg.manifest().metabuild_path(build_runner.bcx.ws);
        target.set_src_path(TargetSourcePath::Path(path));
    }

    Ok(Work::new(move |state| {
        // If we're a "root crate", e.g., the target of this compilation, then we
        // hard link our outputs out of the `deps` directory into the directory
        // above. This means that `cargo build` will produce binaries in
        // `target/debug` which one probably expects.
        let mut destinations = vec![];
        for output in outputs.iter() {
            let src = &output.path;
            // This may have been a `cargo rustc` command which changes the
            // output, so the source may not actually exist.
            if !src.exists() {
                continue;
            }
            let Some(dst) = output.hardlink.as_ref() else {
                destinations.push(src.clone());
                continue;
            };
            destinations.push(dst.clone());
            paths::link_or_copy(src, dst)?;
            if let Some(ref path) = output.export_path {
                let export_dir = export_dir.as_ref().unwrap();
                paths::create_dir_all(export_dir)?;

                // Cargo exports directory artifacts such as dSYMs as symlinks.
                // An external consumer can use that path long after this build.
                if let Some((root, context)) = &private_export
                    && src.is_dir()
                {
                    crate::workspace::build_cache_gc::worktrees::provenance::keep_export(
                        root.as_path_unlocked(),
                        context,
                        export_dir,
                    )?;
                }
                paths::link_or_copy(src, path)?;
            }
        }

        if json_messages {
            let debuginfo = match profile.debuginfo.into_inner() {
                TomlDebugInfo::None => machine_message::ArtifactDebuginfo::Int(0),
                TomlDebugInfo::Limited => machine_message::ArtifactDebuginfo::Int(1),
                TomlDebugInfo::Full => machine_message::ArtifactDebuginfo::Int(2),
                TomlDebugInfo::LineDirectivesOnly => {
                    machine_message::ArtifactDebuginfo::Named("line-directives-only")
                }
                TomlDebugInfo::LineTablesOnly => {
                    machine_message::ArtifactDebuginfo::Named("line-tables-only")
                }
            };
            let art_profile = machine_message::ArtifactProfile {
                opt_level: profile.opt_level.as_str(),
                debuginfo: Some(debuginfo),
                debug_assertions: profile.debug_assertions,
                overflow_checks: profile.overflow_checks,
                test: unit_mode.is_any_test(),
            };

            let mut artifact = machine_message::Artifact {
                package_id: package_id.to_spec(),
                manifest_path,
                target: &target,
                profile: art_profile,
                features,
                filenames: if metadata_only_artifact {
                    destinations
                        .into_iter()
                        .filter(|path| {
                            path.extension().and_then(|extension| extension.to_str())
                                == Some("rmeta")
                        })
                        .collect()
                } else {
                    destinations
                },
                executable,
                fresh,
            };
            state.stdout(artifact.to_json_string())?;

            // Ordinary check mode emits separate artifacts when the same
            // package is both a genuine build helper and a checked library.
            // Promotion can merge their units, but must not erase either
            // machine-readable event.
            if additional_check_artifact {
                artifact.filenames.retain(|path| {
                    path.extension().and_then(|extension| extension.to_str()) == Some("rmeta")
                });
                state.stdout(artifact.to_json_string())?;
            }
        }
        Ok(())
    }))
}

// For all plugin dependencies, add their -L paths (now calculated and present
// in `build_script_outputs`) to the dynamic library load path for the command
// to execute.
fn add_plugin_deps(
    rustc: &mut ProcessBuilder,
    build_script_outputs: &BuildScriptOutputs,
    build_scripts: &BuildScripts,
    root_output: &Path,
    shared_registry_root: Option<&Path>,
) -> CargoResult<()> {
    let var = paths::dylib_path_envvar();
    let existing_search_path = rustc.get_env(var);
    let mut search_path = existing_search_path
        .as_deref()
        .map(|path| env::split_paths(path).collect::<Vec<_>>())
        .unwrap_or_default();
    for (pkg_id, metadata) in &build_scripts.plugins {
        let output = build_script_outputs
            .get(*metadata)
            .ok_or_else(|| internal(format!("couldn't find libs for plugin dep {}", pkg_id)))?;
        search_path.append(&mut filter_dynamic_search_path(
            output.library_paths.iter().map(AsRef::as_ref),
            root_output,
            shared_registry_root,
        ));
    }
    if existing_search_path.is_some() || !search_path.is_empty() {
        let search_path = paths::join_paths(&search_path, var)?;
        rustc.env(var, &search_path);
    }
    Ok(())
}

fn get_dynamic_search_path(path: &Path) -> &Path {
    match path.to_str().and_then(|s| s.split_once("=")) {
        Some(("native" | "crate" | "dependency" | "framework" | "all", path)) => Path::new(path),
        _ => path,
    }
}

// Determine paths to add to the dynamic search path from -L entries
//
// Strip off prefixes like "native=" or "framework=" and filter out directories
// **not** inside our output directory since they are likely spurious and can cause
// clashes with system shared libraries (issue #3366).
fn filter_dynamic_search_path<'a, I>(
    paths: I,
    root_output: &Path,
    shared_registry_root: Option<&Path>,
) -> Vec<PathBuf>
where
    I: Iterator<Item = &'a PathBuf>,
{
    let mut search_path = vec![];
    let shared_registry_root = shared_registry_root.and_then(|root| root.canonicalize().ok());
    for dir in paths {
        let dir = get_dynamic_search_path(dir);
        if dir.starts_with(&root_output) {
            search_path.push(dir.to_path_buf());
        } else if let Some(root) = &shared_registry_root
            && let Ok(canonical) = dir.canonicalize()
            && let Ok(relative) = canonical.strip_prefix(root)
            && {
                let components = relative
                    .components()
                    .map(|component| component.as_os_str())
                    .collect::<Vec<_>>();
                components.windows(6).any(|directory| {
                    directory[0] == OsStr::new("build")
                        && directory[1] == OsStr::new("registries")
                        && directory[5] == OsStr::new("out")
                })
            }
        {
            search_path.push(canonical);
        } else {
            debug!(
                "Not including path {} in runtime library search path because it is \
                 outside target root {}",
                dir.display(),
                root_output.display()
            );
        }
    }
    search_path
}

/// Prepares flags and environments we can compute for a `rustc` invocation
/// before the job queue starts compiling any unit.
///
/// This builds a static view of the invocation. Flags depending on the
/// completion of other units will be added later in runtime, such as flags
/// from build scripts.
fn prepare_rustc(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> CargoResult<ProcessBuilder> {
    let gctx = build_runner.bcx.gctx;
    let is_primary = build_runner.is_primary_package(unit);
    let is_workspace = build_runner.bcx.ws.is_member(&unit.pkg);

    let mut base = build_runner
        .compilation
        .rustc_process(unit, is_primary, is_workspace)?;
    if unit_uses_ohm_shared_stages(build_runner, unit) {
        base.arg("-Zohm-shared-stages");
    }
    if gctx.cli_unstable().ohm_defaults() {
        base.args(&OHM_DEFAULT_RUSTFLAGS);
        // A small incremental check spends more time coordinating frontend workers
        // than checking in parallel. The last successful dep-info is a cheap size hint.
        if cfg!(all(target_os = "linux", target_arch = "x86_64"))
            && is_workspace
            && unit.kind == CompileKind::Host
            && unit.profile.root == ProfileRoot::Debug
            && unit.profile.incremental
            && matches!(unit.mode, CompileMode::Check { test: false })
            && fingerprint::dep_info_loc(build_runner, unit)
                .metadata()
                .is_ok_and(|info| info.is_file() && info.len() <= 16 * 1024)
        {
            base.arg("-Zthreads=1");
        }
        if unit_uses_ohm_incremental_codegen(build_runner, unit) {
            base.args(&OHM_INCREMENTAL_CODEGEN_RUSTFLAGS);
        }
        if unit_uses_ohm_incremental_mono_partitions(build_runner, unit) {
            base.arg("-Zohm-incremental-mono-partitions");
        }
        if unit_suppresses_default_public_api_hash(build_runner, unit) {
            base.arg("-Zpublic-api-hash=no");
        }
    }
    if unit_uses_ohm_worktree_seeds(build_runner, unit) {
        // Unlike a checkout-specific --remap-path-prefix, this keeps the real
        // working directory out of rustc's incremental compatibility hash.
        // Both the donor build and later builds must use this same mode.
        base.arg(OHM_WORKTREE_SEED_RUSTFLAG);
    }
    build_base_args(build_runner, &mut base, unit)?;
    if unit.pkg.manifest().is_embedded() {
        if !gctx.cli_unstable().script {
            anyhow::bail!(
                "parsing `{}` requires `-Zscript`",
                unit.pkg.manifest_path().display()
            );
        }
        base.arg("-Z").arg("crate-attr=feature(frontmatter)");
        base.arg("-Z").arg("crate-attr=allow(unused_features)");
    }

    base.inherit_jobserver(&build_runner.jobserver);
    build_deps_args(&mut base, build_runner, unit)?;
    add_cap_lints(build_runner.bcx, unit, &mut base);
    if let Some(args) = build_runner.bcx.extra_args_for(unit) {
        base.args(args);
    }
    let info = build_runner.bcx.target_data.info(unit.kind);
    let mut rustflags = unit_rustflags_without_ohm_defaults(gctx, &unit.rustflags);
    if info.ohm_linker_flags != 0 {
        // Profile flags and `cargo rustc -- ...` arrive after target discovery.
        // Preserve their explicit linker choices too, without dropping the
        // conservative linker identity already included in the unit fingerprint.
        let explicit = ohm_linker::has_linker_flags(
            unit.profile
                .rustflags
                .iter()
                .map(|flag| flag.as_str())
                .chain(
                    build_runner
                        .bcx
                        .extra_args_for(unit)
                        .into_iter()
                        .flatten()
                        .map(String::as_str),
                ),
        );
        if explicit {
            rustflags = &rustflags[..rustflags.len() - info.ohm_linker_flags];
        } else if gctx.cli_unstable().ohm_linker()
            == Some(crate::workspace::features::OhmLinker::Wild)
        {
            let linker = ohm_linker::wild_directory(&info.sysroot).join("ld.bfd");
            anyhow::ensure!(
                linker.is_file(),
                "bundled Wild linker not found at `{}`; install an Ohm toolchain that includes Wild or use `-Zohm-linker=lld`",
                linker.display()
            );
        }
    }
    base.args(rustflags);
    if gctx.cli_unstable().binary_dep_depinfo {
        base.arg("-Z").arg("binary-dep-depinfo");
    }
    if unit_uses_checksum_freshness(build_runner, unit) {
        base.arg("-Z").arg("checksum-hash-algorithm=blake3");
    }

    if is_primary {
        base.env("CARGO_PRIMARY_PACKAGE", "1");
        let file_list = build_runner.sbom_output_files(unit)?;
        if !file_list.is_empty() {
            let file_list = std::env::join_paths(file_list)?;
            base.env("CARGO_SBOM_PATH", file_list);
        }
    }

    if unit.target.is_test() || unit.target.is_bench() {
        let tmp = build_runner
            .files()
            .layout(unit.kind)
            .build_dir()
            .prepare_tmp()?;
        base.env("CARGO_TARGET_TMPDIR", tmp.display().to_string());
    }

    if build_runner.bcx.gctx.cli_unstable().cargo_lints {
        // Added last to reduce the risk of RUSTFLAGS or `[lints]` from interfering with
        // `unused_dependencies` tracking
        base.arg("--force-warn=unused_crate_dependencies");
    }

    ohm_thinlto_cache::configure(build_runner, unit, &mut base);
    build_runner.inherit_shared_cache_locks(&mut base)?;
    Ok(base)
}

/// Prepares flags and environments we can compute for a `rustdoc` invocation
/// before the job queue starts compiling any unit.
///
/// This builds a static view of the invocation. Flags depending on the
/// completion of other units will be added later in runtime, such as flags
/// from build scripts.
fn prepare_rustdoc(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> CargoResult<ProcessBuilder> {
    let bcx = build_runner.bcx;
    // script_metadata is not needed here, it is only for tests.
    let mut rustdoc = build_runner.compilation.rustdoc_process(unit, None)?;
    let wants_json_output = build_runner.bcx.build_config.intent.wants_doc_json_output();
    if unit_uses_ohm_worktree_seeds(build_runner, unit) {
        rustdoc.arg(OHM_WORKTREE_SEED_RUSTFLAG);
    }
    if unit.pkg.manifest().is_embedded() {
        if !bcx.gctx.cli_unstable().script {
            anyhow::bail!(
                "parsing `{}` requires `-Zscript`",
                unit.pkg.manifest_path().display()
            );
        }
        rustdoc.arg("-Z").arg("crate-attr=feature(frontmatter)");
        rustdoc.arg("-Z").arg("crate-attr=allow(unused_features)");
    }
    rustdoc.inherit_jobserver(&build_runner.jobserver);
    let crate_name = unit.target.crate_name();
    rustdoc.arg("--crate-name").arg(&crate_name);
    add_path_args(bcx.ws, unit, &mut rustdoc);
    add_cap_lints(bcx, unit, &mut rustdoc);

    unit.kind.add_target_arg(&mut rustdoc);

    let doc_dir = if wants_json_output {
        // Always use new layout for '--output-format=json'.
        // In fix for https://github.com/rust-lang/cargo/issues/16291

        build_runner.files().out_dir_new_layout(unit)
    } else {
        build_runner.files().output_dir(unit)
    };

    rustdoc.arg("-o").arg(&doc_dir);
    rustdoc.args(&features_args(unit));
    rustdoc.args(&check_cfg_args(unit));

    add_error_format_and_color(build_runner, unit, &mut rustdoc);
    add_allow_features(build_runner, &mut rustdoc);

    if build_runner.bcx.gctx.cli_unstable().rustdoc_depinfo {
        // html-static-files is required for keeping the shared styling resources
        // html-non-static-files is required for keeping the original rustdoc emission
        let mut arg = if wants_json_output {
            OsString::from("--emit=dep-info=")
        } else if build_runner.bcx.gctx.cli_unstable().rustdoc_mergeable_info {
            // toolchain resources are written at the end, at the same time as merging
            OsString::from("--emit=html-non-static-files,dep-info=")
        } else {
            // if not using mergeable CCI, everything is written every time
            OsString::from("--emit=html-static-files,html-non-static-files,dep-info=")
        };
        arg.push(rustdoc_dep_info_loc(build_runner, unit));
        rustdoc.arg(arg);

        if unit_uses_checksum_freshness(build_runner, unit) {
            rustdoc.arg("-Z").arg("checksum-hash-algorithm=blake3");
        }
    } else if build_runner.bcx.gctx.cli_unstable().rustdoc_mergeable_info && !wants_json_output {
        // toolchain resources are written at the end, at the same time as merging
        rustdoc.arg("--emit=html-non-static-files");
    }

    if build_runner.bcx.gctx.cli_unstable().rustdoc_mergeable_info && !wants_json_output {
        // write out mergeable data to be imported
        rustdoc.arg("-Zunstable-options");
        let mut arg = OsString::from("--write-doc-meta-dir=");
        // `-Zrustdoc-mergeable-info` always uses the new layout.
        arg.push(build_runner.files().out_dir_new_layout(unit));
        rustdoc.arg(arg);
    }

    if let Some(trim_paths) = unit.profile.trim_paths.as_ref() {
        trim_paths_args_rustdoc(&mut rustdoc, build_runner, unit, trim_paths)?;
    }

    rustdoc.args(unit.pkg.manifest().lint_rustflags());

    let metadata = build_runner.metadata_for_doc_units[unit];
    rustdoc
        .arg("-C")
        .arg(format!("metadata={}", metadata.c_metadata()));

    if unit.mode.is_doc_scrape() {
        debug_assert!(build_runner.bcx.scrape_units.contains(unit));

        if unit.target.is_test() {
            rustdoc.arg("--scrape-tests");
        }

        rustdoc.arg("-Zunstable-options");

        rustdoc
            .arg("--scrape-examples-output-path")
            .arg(scrape_output_path(build_runner, unit)?);

        // Only scrape example for items from crates in the workspace, to reduce generated file size
        for pkg in build_runner.bcx.packages.packages() {
            let names = pkg
                .targets()
                .iter()
                .map(|target| target.crate_name())
                .collect::<HashSet<_>>();
            for name in names {
                rustdoc.arg("--scrape-examples-target-crate").arg(name);
            }
        }
    }

    if should_include_scrape_units(build_runner.bcx, unit) {
        rustdoc.arg("-Zunstable-options");
    }

    build_deps_args(&mut rustdoc, build_runner, unit)?;
    rustdoc::add_root_urls(build_runner, unit, &mut rustdoc)?;

    rustdoc::add_output_format(build_runner, &mut rustdoc)?;

    if let Some(args) = build_runner.bcx.extra_args_for(unit) {
        rustdoc.args(args);
    }
    rustdoc.args(&unit.rustdocflags);

    if !crate_version_flag_already_present(&rustdoc) {
        append_crate_version_flag(unit, &mut rustdoc);
    }

    build_runner.inherit_shared_cache_locks(&mut rustdoc)?;
    Ok(rustdoc)
}

/// Creates a unit of work invoking `rustdoc` for documenting the `unit`.
fn rustdoc(build_runner: &mut BuildRunner<'_, '_>, unit: &Unit) -> CargoResult<Work> {
    let mut rustdoc = prepare_rustdoc(build_runner, unit)?;

    let crate_name = unit.target.crate_name();
    let is_json_output = build_runner.bcx.build_config.intent.wants_doc_json_output();
    let doc_dir = build_runner.files().output_dir(unit);
    // Create the documentation directory ahead of time as rustdoc currently has
    // a bug where concurrent invocations will race to create this directory if
    // it doesn't already exist.
    paths::create_dir_all(&doc_dir)?;

    let target_desc = unit.target.description_named();
    let name = unit.pkg.name();
    let build_script_outputs = Arc::clone(&build_runner.build_script_outputs);
    let package_id = unit.pkg.package_id();
    let target = Target::clone(&unit.target);
    let manifest = ManifestErrorContext::new(build_runner, unit);

    let rustdoc_dep_info_loc = rustdoc_dep_info_loc(build_runner, unit);
    let dep_info_loc = fingerprint::dep_info_loc(build_runner, unit);
    let build_dir = build_runner.files().build_root(unit);
    let pkg_root = unit.pkg.root().to_path_buf();
    let cwd = rustdoc
        .get_cwd()
        .unwrap_or_else(|| build_runner.bcx.gctx.cwd())
        .to_path_buf();
    let fingerprint_dir = build_runner.files().fingerprint_dir(unit);
    let is_local = unit.is_local();
    let worktree_seed_namespace = unit_worktree_seed_namespace(build_runner, unit);
    let env_config = Arc::clone(build_runner.bcx.gctx.env_config()?);
    let rustdoc_depinfo_enabled = build_runner.bcx.gctx.cli_unstable().rustdoc_depinfo;

    let mut output_options = OutputOptions::for_dirty(build_runner, unit);
    let script_metadatas = build_runner.find_build_script_metadatas(unit);
    let scrape_outputs = if should_include_scrape_units(build_runner.bcx, unit) {
        Some(
            build_runner
                .bcx
                .scrape_units
                .iter()
                .map(|unit| {
                    Ok((
                        build_runner.files().metadata(unit).unit_id(),
                        scrape_output_path(build_runner, unit)?,
                    ))
                })
                .collect::<CargoResult<HashMap<_, _>>>()?,
        )
    } else {
        None
    };

    let failed_scrape_units = Arc::clone(&build_runner.failed_scrape_units);
    let hide_diagnostics_for_scrape_unit = build_runner.bcx.unit_can_fail_for_docscraping(unit)
        && !matches!(
            build_runner.bcx.gctx.shell().verbosity(),
            Verbosity::Verbose
        );
    let failed_scrape_diagnostic = hide_diagnostics_for_scrape_unit.then(|| {
        make_failed_scrape_diagnostic(
            build_runner,
            unit,
            format_args!("failed to scan {target_desc} in package `{name}` for example code usage"),
        )
    });
    if hide_diagnostics_for_scrape_unit {
        output_options.show_diagnostics = false;
    }

    Ok(Work::new(move |state| {
        output_options.prepare_for_compiler();

        add_custom_flags(
            &mut rustdoc,
            &build_script_outputs.lock().unwrap(),
            script_metadatas,
        )?;

        // Add the output of scraped examples to the rustdoc command.
        // This action must happen after the unit's dependencies have finished,
        // because some of those deps may be Docscrape units which have failed.
        // So we dynamically determine which `--with-examples` flags to pass here.
        if let Some(scrape_outputs) = scrape_outputs {
            let failed_scrape_units = failed_scrape_units.lock().unwrap();
            for (metadata, output_path) in &scrape_outputs {
                if !failed_scrape_units.contains(metadata) {
                    rustdoc.arg("--with-examples").arg(output_path);
                }
            }
        }

        if !is_json_output {
            let crate_dir = doc_dir.join(&crate_name);
            if crate_dir.exists() {
                // Remove output from a previous build. This ensures that stale
                // files for removed items are removed.
                debug!("removing pre-existing doc directory {:?}", crate_dir);
                paths::remove_dir_all(&crate_dir)?;
            }
        };
        state.running(&rustdoc);
        let timestamp = paths::set_invocation_time(&fingerprint_dir)?;

        let result = rustdoc
            .exec_with_streaming(
                &mut |line| on_stdout_line(state, line, package_id, &target),
                &mut |line| {
                    on_stderr_line(
                        state,
                        line,
                        package_id,
                        &manifest,
                        &target,
                        &mut output_options,
                    )
                },
                false,
            )
            .map_err(verbose_if_simple_exit_code)
            .with_context(|| format!("could not document `{}`", name));

        if let Err(e) = result {
            if let Some(diagnostic) = failed_scrape_diagnostic {
                state.warning(diagnostic);
            }

            return Err(e);
        }

        if rustdoc_depinfo_enabled && rustdoc_dep_info_loc.exists() {
            fingerprint::translate_dep_info(
                &rustdoc_dep_info_loc,
                &dep_info_loc,
                &cwd,
                &pkg_root,
                &build_dir,
                &rustdoc,
                // Should we track source file for doc gen?
                is_local,
                &env_config,
                worktree_seed_namespace.as_deref(),
            )
            .with_context(|| {
                internal(format_args!(
                    "could not parse/generate dep info at: {}",
                    rustdoc_dep_info_loc.display()
                ))
            })?;
            // This mtime shift allows Cargo to detect if a source file was
            // modified in the middle of the build.
            paths::set_file_time_no_err(dep_info_loc, timestamp);
        }

        Ok(())
    }))
}

// The --crate-version flag could have already been passed in RUSTDOCFLAGS
// or as an extra compiler argument for rustdoc
fn crate_version_flag_already_present(rustdoc: &ProcessBuilder) -> bool {
    rustdoc.get_args().any(|flag| {
        flag.to_str()
            .map_or(false, |flag| flag.starts_with(RUSTDOC_CRATE_VERSION_FLAG))
    })
}

fn append_crate_version_flag(unit: &Unit, rustdoc: &mut ProcessBuilder) {
    rustdoc
        .arg(RUSTDOC_CRATE_VERSION_FLAG)
        .arg(unit.pkg.version().to_string());
}

enum CapLints {
    Allow,
    Warn,
}

fn compute_cap_lints(bcx: &BuildContext<'_, '_>, unit: &Unit) -> Option<CapLints> {
    // If this is an upstream dep we don't want warnings from, turn off all
    // lints.
    if !unit.show_warnings(bcx.gctx) {
        Some(CapLints::Allow)
    // If this is an upstream dep but we *do* want warnings, make sure that they
    // don't fail compilation.
    } else if !unit.is_local() {
        Some(CapLints::Warn)
    } else {
        None
    }
}

/// Adds [`--cap-lints`] to the command to execute.
///
/// [`--cap-lints`]: https://doc.rust-lang.org/nightly/rustc/lints/levels.html#capping-lints
fn add_cap_lints(bcx: &BuildContext<'_, '_>, unit: &Unit, cmd: &mut ProcessBuilder) {
    if let Some(cap_lints) = compute_cap_lints(bcx, unit) {
        match cap_lints {
            CapLints::Allow => {
                cmd.arg("--cap-lints").arg("allow");
            }
            CapLints::Warn => {
                cmd.arg("--cap-lints").arg("warn");
            }
        }
    }
}

/// Forwards [`-Zallow-features`] if it is set for cargo.
///
/// [`-Zallow-features`]: https://doc.rust-lang.org/nightly/cargo/reference/unstable.html#allow-features
fn add_allow_features(build_runner: &BuildRunner<'_, '_>, cmd: &mut ProcessBuilder) {
    if let Some(allow) = &build_runner.bcx.gctx.cli_unstable().allow_features {
        use std::fmt::Write;
        let mut arg = String::from("-Zallow-features=");
        for f in allow {
            let _ = write!(&mut arg, "{f},");
        }
        cmd.arg(arg.trim_end_matches(','));
    }
}

/// Adds [`--error-format`] to the command to execute.
///
/// Cargo always uses JSON output. This has several benefits, such as being
/// easier to parse, handles changing formats (for replaying cached messages),
/// ensures atomic output (so messages aren't interleaved), allows for
/// intercepting messages like rmeta artifacts, etc. rustc includes a
/// "rendered" field in the JSON message with the message properly formatted,
/// which Cargo will extract and display to the user.
///
/// [`--error-format`]: https://doc.rust-lang.org/nightly/rustc/command-line-arguments.html#--error-format-control-how-errors-are-produced
fn add_error_format_and_color(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
    cmd: &mut ProcessBuilder,
) {
    let enable_timings =
        build_runner.bcx.gctx.cli_unstable().section_timings && build_runner.bcx.logger.is_some();
    if enable_timings {
        cmd.arg("-Zunstable-options");
    }

    cmd.arg("--error-format=json");

    let mut json = String::from("--json=diagnostic-rendered-ansi,artifacts,future-incompat");
    if build_runner.bcx.gctx.cli_unstable().cargo_lints {
        json.push_str(",unused-externs-silent");
    } else if unused_integration_self_dependency(build_runner, unit).is_some()
        || ohm_deferred_dev_deps::supported(build_runner, unit)
    {
        json.push_str(",unused-externs-transparent");
    }
    if let MessageFormat::Short | MessageFormat::Json { short: true, .. } =
        build_runner.bcx.build_config.message_format
    {
        json.push_str(",diagnostic-short");
    } else if build_runner.bcx.gctx.shell().err_unicode()
        && build_runner.bcx.gctx.cli_unstable().rustc_unicode
    {
        json.push_str(",diagnostic-unicode");
    }
    if enable_timings {
        json.push_str(",timings");
    }
    cmd.arg(json);

    let gctx = build_runner.bcx.gctx;
    if let Some(width) = gctx.shell().err_width().diagnostic_terminal_width() {
        cmd.arg(format!("--diagnostic-width={width}"));
    }
}

/// Returns whether an immutable internal library can omit its embedded metadata.
fn unit_uses_no_embed_metadata(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    if let Some(embed) = build_runner.bcx.gctx.cli_unstable().embed_metadata {
        return !embed && unit.benefits_from_no_embed_metadata();
    }
    let source = unit.pkg.package_id().source_id();

    build_runner.bcx.gctx.cli_unstable().no_embed_metadata()
        && unit.benefits_from_no_embed_metadata()
        && (source.is_registry() || source.is_git())
        && !build_runner.bcx.roots.contains(unit)
        && !unit.target.rustc_crate_types().contains(&CrateType::Dylib)
}

/// Adds essential rustc flags and environment variables to the command to execute.
fn build_base_args(
    build_runner: &BuildRunner<'_, '_>,
    cmd: &mut ProcessBuilder,
    unit: &Unit,
) -> CargoResult<()> {
    assert!(!unit.mode.is_run_custom_build());

    let bcx = build_runner.bcx;
    let Profile {
        ref opt_level,
        codegen_backend,
        codegen_units,
        debuginfo,
        debug_assertions,
        split_debuginfo,
        overflow_checks,
        rpath,
        ref panic,
        incremental,
        strip,
        rustflags: profile_rustflags,
        trim_paths,
        hint_mostly_unused: profile_hint_mostly_unused,
        ..
    } = unit.profile.clone();
    let hints = unit.pkg.hints().cloned().unwrap_or_default();
    let test = unit.mode.is_any_test();

    let warn = |msg: &str| {
        bcx.gctx.shell().warn(format!(
            "{}@{}: {msg}",
            unit.pkg.package_id().name(),
            unit.pkg.package_id().version()
        ))
    };
    let unit_capped_warn = |msg: &str| {
        if unit.show_warnings(bcx.gctx) {
            warn(msg)
        } else {
            Ok(())
        }
    };

    cmd.arg("--crate-name").arg(&unit.target.crate_name());

    let edition = unit.target.edition();
    edition.cmd_edition_arg(cmd);

    add_path_args(bcx.ws, unit, cmd);
    add_error_format_and_color(build_runner, unit, cmd);
    add_allow_features(build_runner, cmd);

    let mut contains_dy_lib = false;
    if !test {
        for crate_type in &unit.target.rustc_crate_types() {
            cmd.arg("--crate-type").arg(crate_type.as_str());
            contains_dy_lib |= crate_type == &CrateType::Dylib;
        }
    }

    if unit.mode.is_check() {
        cmd.arg("--emit=dep-info,metadata");
        if unit_uses_ohm_shared_stages(build_runner, unit)
            && unit_uses_no_embed_metadata(build_runner, unit)
        {
            cmd.args(&["-Z", "embed-metadata=no"]);
        }
    } else if !build_runner.bcx.gctx.should_embed_metadata() {
        // Nightly rustc supports the -Zembed-metadata=no flag, which tells it to avoid including
        // full metadata in rlib/dylib artifacts, to save space on disk. In this case, metadata
        // will only be stored in .rmeta files.
        // When we use this flag, we should also pass --emit=metadata to all artifacts that
        // contain useful metadata (rlib/dylib/proc macros), so that a .rmeta file is actually
        // generated. If we didn't do this, the full metadata would not get written anywhere.
        // However, we do not want to pass --emit=metadata to artifacts that never produce useful
        // metadata, such as binaries, because that would just unnecessarily create empty .rmeta
        // files on disk.
        if unit.benefits_from_no_embed_metadata() {
            cmd.arg("--emit=dep-info,metadata,link");
            if unit_uses_no_embed_metadata(build_runner, unit) {
                cmd.args(&["-Z", "embed-metadata=no"]);
            }
        } else {
            cmd.arg("--emit=dep-info,link");
        }
    } else {
        // If we don't use -Zembed-metadata=no, we emit .rmeta files only for rlib outputs.
        // This metadata may be used in this session for a pipelined compilation, or it may
        // be used in a future Cargo session as part of a pipelined compile.
        if !unit.requires_upstream_objects() {
            cmd.arg("--emit=dep-info,metadata,link");
        } else {
            cmd.arg("--emit=dep-info,link");
        }
    }

    let prefer_dynamic = (unit.target.for_host() && !unit.target.is_custom_build())
        || (contains_dy_lib && !build_runner.is_primary_package(unit));
    if prefer_dynamic {
        cmd.arg("-C").arg("prefer-dynamic");
    }

    if opt_level.as_str() != "0" {
        cmd.arg("-C").arg(&format!("opt-level={}", opt_level));
    }

    if *panic != PanicStrategy::Unwind {
        cmd.arg("-C").arg(format!("panic={}", panic));
    }
    if *panic == PanicStrategy::ImmediateAbort {
        cmd.arg("-Z").arg("unstable-options");
    }

    cmd.args(&lto_args(build_runner, unit));

    if let Some(backend) = codegen_backend {
        cmd.arg("-Z").arg(&format!("codegen-backend={}", backend));
    }

    if let Some(n) = codegen_units {
        cmd.arg("-C").arg(&format!("codegen-units={}", n));
    }

    let debuginfo = debuginfo.into_inner();
    // Shorten the number of arguments if possible.
    if debuginfo != TomlDebugInfo::None {
        cmd.arg("-C").arg(format!("debuginfo={debuginfo}"));
        // This is generally just an optimization on build time so if we don't
        // pass it then it's ok. The values for the flag (off, packed, unpacked)
        // may be supported or not depending on the platform, so availability is
        // checked per-value. For example, at the time of writing this code, on
        // Windows the only stable valid value for split-debuginfo is "packed",
        // while on Linux "unpacked" is also stable.
        if let Some(split) = split_debuginfo {
            if build_runner
                .bcx
                .target_data
                .info(unit.kind)
                .supports_debuginfo_split(split)
            {
                cmd.arg("-C").arg(format!("split-debuginfo={split}"));
            }
        }
    }

    if let Some(trim_paths) = trim_paths {
        trim_paths_args(cmd, build_runner, unit, &trim_paths)?;
    }

    match compute_cap_lints(bcx, unit) {
        None | Some(CapLints::Warn) => {
            cmd.args(unit.pkg.manifest().lint_rustflags());
        }
        // If we pass --cap-lints=allow, there is no point in making the CLI larger by including
        // potentially a lot of --warn lint flags.
        Some(CapLints::Allow) => {}
    }
    cmd.args(&profile_rustflags);

    // `-C overflow-checks` is implied by the setting of `-C debug-assertions`,
    // so we only need to provide `-C overflow-checks` if it differs from
    // the value of `-C debug-assertions` we would provide.
    if opt_level.as_str() != "0" {
        if debug_assertions {
            cmd.args(&["-C", "debug-assertions=on"]);
            if !overflow_checks {
                cmd.args(&["-C", "overflow-checks=off"]);
            }
        } else if overflow_checks {
            cmd.args(&["-C", "overflow-checks=on"]);
        }
    } else if !debug_assertions {
        cmd.args(&["-C", "debug-assertions=off"]);
        if overflow_checks {
            cmd.args(&["-C", "overflow-checks=on"]);
        }
    } else if !overflow_checks {
        cmd.args(&["-C", "overflow-checks=off"]);
    }

    if test && unit.target.harness() {
        cmd.arg("--test");

        // Cargo has historically never compiled `--test` binaries with
        // `panic=abort` because the `test` crate itself didn't support it.
        // Support is now upstream, however, but requires an unstable flag to be
        // passed when compiling the test. We require, in Cargo, an unstable
        // flag to pass to rustc, so register that here. Eventually this flag
        // will simply not be needed when the behavior is stabilized in the Rust
        // compiler itself.
        if *panic == PanicStrategy::Abort || *panic == PanicStrategy::ImmediateAbort {
            cmd.arg("-Z").arg("panic-abort-tests");
        }
    } else if test {
        cmd.arg("--cfg").arg("test");
    }

    cmd.args(&features_args(unit));
    cmd.args(&check_cfg_args(unit));

    let meta = build_runner.files().metadata(unit);
    cmd.arg("-C")
        .arg(&format!("metadata={}", meta.c_metadata()));
    if let Some(c_extra_filename) = meta.c_extra_filename() {
        cmd.arg("-C")
            .arg(&format!("extra-filename=-{c_extra_filename}"));
    }

    if rpath {
        cmd.arg("-C").arg("rpath");
    }

    cmd.arg("--out-dir")
        .arg(&build_runner.files().output_dir(unit));

    unit.kind.add_target_arg(cmd);

    add_codegen_linker(cmd, build_runner, unit, bcx.gctx.target_applies_to_host()?);

    if incremental {
        add_codegen_incremental(cmd, build_runner, unit)
    }

    let pkg_hint_mostly_unused = match hints.mostly_unused {
        None => None,
        Some(toml::Value::Boolean(b)) => Some(b),
        Some(v) => {
            unit_capped_warn(&format!(
                "ignoring unsupported value type ({}) for 'hints.mostly-unused', which expects a boolean",
                v.type_str()
            ))?;
            None
        }
    };
    if profile_hint_mostly_unused
        .or(pkg_hint_mostly_unused)
        .unwrap_or(false)
    {
        if bcx.gctx.cli_unstable().profile_hint_mostly_unused {
            cmd.arg("-Zhint-mostly-unused");
        } else {
            if profile_hint_mostly_unused.is_some() {
                // Profiles come from the top-level unit, so we don't use `unit_capped_warn` here.
                warn(
                    "ignoring 'hint-mostly-unused' profile option, pass `-Zprofile-hint-mostly-unused` to enable it",
                )?;
            } else if pkg_hint_mostly_unused.is_some() {
                unit_capped_warn(
                    "ignoring 'hints.mostly-unused', pass `-Zprofile-hint-mostly-unused` to enable it",
                )?;
            }
        }
    }

    let strip = strip.into_inner();
    if strip != StripInner::None {
        cmd.arg("-C").arg(format!("strip={}", strip));
    }

    if unit.is_std {
        // -Zforce-unstable-if-unmarked prevents the accidental use of
        // unstable crates within the sysroot (such as "extern crate libc" or
        // any non-public crate in the sysroot).
        //
        // RUSTC_BOOTSTRAP allows unstable features on stable.
        cmd.arg("-Z")
            .arg("force-unstable-if-unmarked")
            .env("RUSTC_BOOTSTRAP", "1");
    }

    if let Some(version) = unit.pkg.manifest().rust_version()
        && bcx.gctx.cli_unstable().hint_msrv
    {
        cmd.arg("-Z").arg(format!("hint-msrv={version}"));
    }

    Ok(())
}

/// All active features for the unit passed as `--cfg features=<feature-name>`.
fn features_args(unit: &Unit) -> Vec<OsString> {
    let mut args = Vec::with_capacity(unit.features.len() * 2);

    for feat in &unit.features {
        args.push(OsString::from("--cfg"));
        args.push(OsString::from(format!("feature=\"{}\"", feat)));
    }

    args
}

/// Generates the `--check-cfg` arguments for the `unit`.
fn check_cfg_args(unit: &Unit) -> Vec<OsString> {
    // The routine below generates the --check-cfg arguments. Our goals here are to
    // enable the checking of conditionals and pass the list of declared features.
    //
    // In the simplified case, it would resemble something like this:
    //
    //   --check-cfg=cfg() --check-cfg=cfg(feature, values(...))
    //
    // but having `cfg()` is redundant with the second argument (as well-known names
    // and values are implicitly enabled when one or more `--check-cfg` argument is
    // passed) so we don't emit it and just pass:
    //
    //   --check-cfg=cfg(feature, values(...))
    //
    // This way, even if there are no declared features, the config `feature` will
    // still be expected, meaning users would get "unexpected value" instead of name.
    // This wasn't always the case, see rust-lang#119930 for some details.

    let gross_cap_estimation = unit.pkg.summary().features().len() * 7 + 25;
    let mut arg_feature = OsString::with_capacity(gross_cap_estimation);

    arg_feature.push("cfg(feature, values(");
    for (i, feature) in unit.pkg.summary().features().keys().enumerate() {
        if i != 0 {
            arg_feature.push(", ");
        }
        arg_feature.push("\"");
        arg_feature.push(feature);
        arg_feature.push("\"");
    }
    arg_feature.push("))");

    // In addition to the package features, we also include the `test` cfg (since
    // compiler-team#785, as to be able to someday apply it conditionally), as well
    // the `docsrs` cfg from the docs.rs service.
    //
    // We include `docsrs` here (in Cargo) instead of rustc, since there is a much closer
    // relationship between Cargo and docs.rs than rustc and docs.rs. In particular, all
    // users of docs.rs use Cargo, but not all users of rustc (like Rust-for-Linux) use docs.rs.

    vec![
        OsString::from("--check-cfg"),
        OsString::from("cfg(docsrs,test)"),
        OsString::from("--check-cfg"),
        arg_feature,
    ]
}

/// Adds LTO related codegen flags.
fn lto_args(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> Vec<OsString> {
    let mut result = Vec::new();
    let mut push = |arg: &str| {
        result.push(OsString::from("-C"));
        result.push(OsString::from(arg));
    };
    match build_runner.lto[unit] {
        lto::Lto::Run(None) => push("lto"),
        lto::Lto::Run(Some(s)) => push(&format!("lto={}", s)),
        lto::Lto::Off => {
            push("lto=off");
            push("embed-bitcode=no");
        }
        lto::Lto::ObjectAndBitcode => {} // this is rustc's default
        lto::Lto::OnlyBitcode => push("linker-plugin-lto"),
        lto::Lto::OnlyObject => push("embed-bitcode=no"),
    }
    result
}

/// Adds dependency-relevant rustc flags and environment variables
/// to the command to execute, such as [`-L`] and [`--extern`].
///
/// [`-L`]: https://doc.rust-lang.org/nightly/rustc/command-line-arguments.html#-l-add-a-directory-to-the-library-search-path
/// [`--extern`]: https://doc.rust-lang.org/nightly/rustc/command-line-arguments.html#--extern-specify-where-an-external-library-is-located
fn build_deps_args(
    cmd: &mut ProcessBuilder,
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> CargoResult<()> {
    let bcx = build_runner.bcx;

    for arg in lib_search_paths(build_runner, unit)? {
        cmd.arg(arg);
    }

    let deps = build_runner.unit_deps(unit);

    // If there is not one linkable target but should, rustc fails later
    // on if there is an `extern crate` for it. This may turn into a hard
    // error in the future (see PR #4797).
    if !deps
        .iter()
        .any(|dep| !dep.unit.mode.is_doc() && dep.unit.target.is_linkable())
    {
        if let Some(dep) = deps.iter().find(|dep| {
            !dep.unit.mode.is_doc() && dep.unit.target.is_lib() && !dep.unit.artifact.is_true()
        }) {
            let dep_name = dep.unit.target.crate_name();
            let name = unit.target.crate_name();
            bcx.gctx.shell().print_report(&[
                Level::WARNING.secondary_title(format!("the package `{dep_name}` provides no linkable target"))
                    .elements([
                        Level::NOTE.message(format!("this might cause `{name}` to fail compilation")),
                        Level::NOTE.message("this warning might turn into a hard error in the future"),
                        Level::HELP.message(format!("consider adding 'dylib' or 'rlib' to key 'crate-type' in `{dep_name}`'s Cargo.toml"))
                    ])
            ], false)?;
        }
    }

    let mut unstable_opts = false;

    // Add `OUT_DIR` environment variables for build scripts
    let first_custom_build_dep = deps.iter().find(|dep| dep.unit.mode.is_run_custom_build());
    if let Some(dep) = first_custom_build_dep {
        let out_dir = if bcx.gctx.cli_unstable().build_dir_new_layout {
            build_runner.files().out_dir_new_layout(&dep.unit)
        } else {
            build_runner.files().build_script_out_dir(&dep.unit)
        };
        cmd.env("OUT_DIR", &out_dir);
    }

    // Adding output directory for each build script
    let is_multiple_build_scripts_enabled = unit
        .pkg
        .manifest()
        .unstable_features()
        .require(Feature::multiple_build_scripts())
        .is_ok();

    if is_multiple_build_scripts_enabled {
        for dep in deps {
            if dep.unit.mode.is_run_custom_build() {
                let out_dir = if bcx.gctx.cli_unstable().build_dir_new_layout {
                    build_runner.files().out_dir_new_layout(&dep.unit)
                } else {
                    build_runner.files().build_script_out_dir(&dep.unit)
                };
                let target_name = dep.unit.target.name();
                let out_dir_prefix = target_name
                    .strip_prefix("build-script-")
                    .unwrap_or(target_name);
                let out_dir_name = format!("{out_dir_prefix}_OUT_DIR");
                cmd.env(&out_dir_name, &out_dir);
            }
        }
    }
    for arg in extern_args(build_runner, unit, &mut unstable_opts)? {
        cmd.arg(arg);
    }

    for (var, env) in artifact::get_env(build_runner, unit, deps)? {
        cmd.env(&var, env);
    }

    // This will only be set if we're already using a feature
    // requiring nightly rust
    if unstable_opts {
        cmd.arg("-Z").arg("unstable-options");
    }

    Ok(())
}

fn add_dep_arg<'a, 'b: 'a>(
    map: &mut BTreeMap<&'a Unit, PathBuf>,
    build_runner: &'b BuildRunner<'b, '_>,
    unit: &'a Unit,
) {
    for dep in build_runner.unit_deps(unit) {
        // Don't include build script out dir in the args to reduce rustc command bloat.
        if dep.unit.target.is_custom_build() {
            continue;
        }
        if map.contains_key(&dep.unit) {
            continue;
        }
        map.insert(&dep.unit, build_runner.files().deps_dir(&dep.unit));

        // Proc macros are statically linked, so when including a proc-macro dependency we can skip
        // adding it's dependencies. Note that we still do add them when we are compiling the
        // proc-macro itself.
        if dep.unit.target.proc_macro() {
            continue;
        }
        add_dep_arg(map, build_runner, &dep.unit);
    }
}

/// Adds extra rustc flags and environment variables collected from the output
/// of a build-script to the command to execute, include custom environment
/// variables and `cfg`.
fn add_custom_flags(
    cmd: &mut ProcessBuilder,
    build_script_outputs: &BuildScriptOutputs,
    metadata_vec: Option<Vec<UnitHash>>,
) -> CargoResult<()> {
    if let Some(metadata_vec) = metadata_vec {
        for metadata in metadata_vec {
            if let Some(output) = build_script_outputs.get(metadata) {
                for cfg in output.cfgs.iter() {
                    cmd.arg("--cfg").arg(cfg);
                }
                for check_cfg in &output.check_cfgs {
                    cmd.arg("--check-cfg").arg(check_cfg);
                }
                for (name, value) in output.env.iter() {
                    cmd.env(name, value);
                }
            }
        }
    }

    Ok(())
}

/// Generate a list of `-L` arguments
pub fn lib_search_paths(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> CargoResult<Vec<OsString>> {
    let mut lib_search_paths = Vec::new();
    if build_runner.bcx.gctx.cli_unstable().build_dir_new_layout {
        let dependencies = build_runner
            .unit_deps(unit)
            .iter()
            .filter(|dep| !dep.unit.target.is_custom_build())
            .map(|dep| dep.unit.clone())
            .collect();
        lib_search_paths = build_runner
            .files()
            .dependency_search_args(dependencies, || {
                let mut map = BTreeMap::new();

                // Recursively add all dependency args to rustc process.
                add_dep_arg(&mut map, build_runner, unit);

                let paths = map.into_iter().map(|(_, path)| path).sorted_unstable();

                let mut args = Vec::new();
                for path in paths {
                    let mut deps = OsString::from("dependency=");
                    deps.push(path);
                    args.extend(["-L".into(), deps]);
                }
                args
            });
    } else {
        let mut deps = OsString::from("dependency=");
        deps.push(build_runner.files().deps_dir(unit));
        lib_search_paths.extend(["-L".into(), deps]);
    }

    // Be sure that the host path is also listed. This'll ensure that proc macro
    // dependencies are correctly found (for reexported macros).
    if !unit.kind.is_host() {
        let mut deps = OsString::from("dependency=");
        deps.push(build_runner.files().host_deps(unit));
        lib_search_paths.extend(["-L".into(), deps]);
    }

    Ok(lib_search_paths)
}

fn is_public_dependency_enabled(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    unit.pkg
        .manifest()
        .unstable_features()
        .require(Feature::public_dependency())
        .is_ok()
        || build_runner.bcx.gctx.cli_unstable().public_dependency
}

/// Generates a list of `--extern` arguments.
pub fn extern_args(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
    unstable_opts: &mut bool,
) -> CargoResult<Vec<OsString>> {
    let mut result = Vec::new();
    let deps = build_runner.unit_deps(unit);

    let no_embed_metadata = !build_runner.bcx.gctx.should_embed_metadata();
    let public_dependency_enabled = is_public_dependency_enabled(build_runner, unit);

    // Closure to add one dependency to `result`.
    let mut link_to = |dep: &UnitDep,
                       extern_crate_name: InternedString,
                       noprelude: bool,
                       nounused: bool|
     -> CargoResult<()> {
        let mut value = OsString::new();
        let mut opts = Vec::new();
        if !dep.public && unit.target.is_lib() && public_dependency_enabled {
            opts.push("priv");
            *unstable_opts = true;
        }
        if noprelude {
            opts.push("noprelude");
            *unstable_opts = true;
        }
        if nounused {
            opts.push("nounused");
            *unstable_opts = true;
        }
        if !opts.is_empty() {
            value.push(opts.join(","));
            value.push(":");
        }
        value.push(extern_crate_name.as_str());
        value.push("=");

        let mut pass = |file| {
            let mut value = value.clone();
            value.push(file);
            result.push(OsString::from("--extern"));
            result.push(value);
        };

        let outputs = build_runner.outputs(&dep.unit)?;

        if build_runner.only_requires_rmeta(unit, &dep.unit) || dep.unit.mode.is_check() {
            // Example: rlib dependency for an rlib, rmeta is all that is required.
            let output = outputs
                .iter()
                .find(|output| output.flavor == FileFlavor::Rmeta)
                .expect("failed to find rmeta dep for pipelined dep");
            pass(&output.path);
        } else {
            // Example: a bin needs `rlib` for dependencies, it cannot use rmeta.
            for output in outputs.iter() {
                if output.flavor == FileFlavor::Linkable {
                    pass(&output.path);
                }
                // If we use -Zembed-metadata=no, we also need to pass the path to the
                // corresponding .rmeta file to the linkable artifact, because the
                // normal dependency (rlib) doesn't contain the full metadata.
                else if no_embed_metadata && output.flavor == FileFlavor::Rmeta {
                    pass(&output.path);
                }
            }
        }
        Ok(())
    };

    for dep in deps {
        if dep.unit.target.is_linkable() && !dep.unit.mode.is_doc() {
            link_to(dep, dep.extern_crate_name, dep.noprelude, dep.nounused)?;
        }
    }
    if unit.target.proc_macro() {
        // Automatically import `proc_macro`.
        result.push(OsString::from("--extern"));
        result.push(OsString::from("proc_macro"));
    }

    Ok(result)
}

/// Adds `-C linker=<path>` if specified.
fn add_codegen_linker(
    cmd: &mut ProcessBuilder,
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
    target_applies_to_host: bool,
) {
    let linker = if unit.target.for_host() && !target_applies_to_host {
        build_runner
            .compilation
            .host_linker()
            .map(|s| s.as_os_str())
    } else {
        build_runner
            .compilation
            .target_linker(unit.kind)
            .map(|s| s.as_os_str())
    };

    if let Some(linker) = linker {
        let mut arg = OsString::from("linker=");
        arg.push(linker);
        cmd.arg("-C").arg(arg);
    }
}

/// Adds `-C incremental=<path>`.
fn add_codegen_incremental(
    cmd: &mut ProcessBuilder,
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) {
    let dir = build_runner.files().incremental_dir(&unit);
    let mut arg = OsString::from("incremental=");
    arg.push(dir.as_os_str());
    cmd.arg("-C").arg(arg);
}

fn envify(s: &str) -> String {
    s.chars()
        .flat_map(|c| c.to_uppercase())
        .map(|c| if c == '-' { '_' } else { c })
        .collect()
}

/// Configuration of the display of messages emitted by the compiler,
/// e.g. diagnostics, warnings, errors, and message caching.
struct OutputOptions {
    /// What format we're emitting from Cargo itself.
    format: MessageFormat,
    /// Where to write the JSON messages to support playback later if the unit
    /// is fresh. The file is created lazily so that in the normal case, lots
    /// of empty files are not created. If this is None, the output will not
    /// be cached (such as when replaying cached messages).
    cache_cell: Option<(PathBuf, OnceCell<File>)>,
    /// If `true`, display any diagnostics.
    /// Other types of JSON messages are processed regardless
    /// of the value of this flag.
    ///
    /// This is used primarily for cache replay. If you build with `-vv`, the
    /// cache will be filled with diagnostics from dependencies. When the
    /// cache is replayed without `-vv`, we don't want to show them.
    show_diagnostics: bool,
    /// Tracks the number of warnings we've seen so far.
    warnings_seen: usize,
    /// Tracks the number of errors we've seen so far.
    errors_seen: usize,
}

impl OutputOptions {
    fn for_dirty(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> OutputOptions {
        let path = build_runner.files().message_cache_path(unit);
        let cache_cell = Some((path, OnceCell::new()));

        let show_diagnostics = true;

        let format = build_runner.bcx.build_config.message_format;

        OutputOptions {
            format,
            cache_cell,
            show_diagnostics,
            warnings_seen: 0,
            errors_seen: 0,
        }
    }

    /// Clears output from the previous invocation immediately before the compiler runs.
    ///
    /// Dirty units can still be reused by early cutoff, in which case their cached diagnostics
    /// must remain available for replay.
    fn prepare_for_compiler(&mut self) {
        if let Some((path, _)) = &self.cache_cell {
            // Ignore ENOENT, which is the common case.
            drop(fs::remove_file(path));
        }
    }

    fn for_fresh(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> OutputOptions {
        let cache_cell = None;

        // We always replay the output cache,
        // since it might contain future-incompat-report messages
        let show_diagnostics = unit.show_warnings(build_runner.bcx.gctx);

        let format = build_runner.bcx.build_config.message_format;

        OutputOptions {
            format,
            cache_cell,
            show_diagnostics,
            warnings_seen: 0,
            errors_seen: 0,
        }
    }
}

/// Cloned and sendable context about the manifest file.
///
/// Sometimes we enrich rustc's errors with some locations in the manifest file; this
/// contains a `Send`-able copy of the manifest information that we need for the
/// enriched errors.
struct ManifestErrorContext {
    /// The path to the manifest, also used by machine-readable compiler messages.
    path: PathBuf,
    /// Source information available for annotating compiler diagnostics.
    annotation: Option<ManifestDiagnosticContext>,
}

/// Retained manifest source and dependency information for diagnostic annotations.
struct ManifestDiagnosticContext {
    /// The locations of various spans within the manifest.
    spans: Arc<toml::Spanned<toml::de::DeTable<'static>>>,
    /// The raw manifest contents.
    contents: String,
    /// A lookup for all the unambiguous renamings, mapping from the original package
    /// name to the renamed one.
    rename_table: HashMap<InternedString, InternedString>,
    /// A list of targets we're compiling for, to determine which of the `[target.<something>.dependencies]`
    /// tables might be of interest.
    requested_kinds: Vec<CompileKind>,
    /// A list of all the collections of cfg values, one collection for each target, to determine
    /// which of the `[target.'cfg(...)'.dependencies]` tables might be of interest.
    cfgs: Vec<Vec<Cfg>>,
    host_name: InternedString,
    /// Cargo's working directory (for printing out a more friendly manifest path).
    cwd: PathBuf,
    /// Terminal width for formatting diagnostics.
    term_width: usize,
}

fn on_stdout_line(
    state: &JobState<'_, '_>,
    line: &str,
    _package_id: PackageId,
    _target: &Target,
) -> CargoResult<()> {
    state.stdout(line.to_string())?;
    Ok(())
}

fn on_stderr_line(
    state: &JobState<'_, '_>,
    line: &str,
    package_id: PackageId,
    manifest: &ManifestErrorContext,
    target: &Target,
    options: &mut OutputOptions,
) -> CargoResult<()> {
    if on_stderr_line_inner(state, line, package_id, manifest, target, options)? {
        // Check if caching is enabled.
        if let Some((path, cell)) = &mut options.cache_cell {
            // Cache the output, which will be replayed later when Fresh.
            let f = cell.try_borrow_mut_with(|| paths::create(path))?;
            debug_assert!(!line.contains('\n'));
            f.write_all(line.as_bytes())?;
            f.write_all(&[b'\n'])?;
        }
    }
    Ok(())
}

/// Returns true if the line should be cached.
fn on_stderr_line_inner(
    state: &JobState<'_, '_>,
    line: &str,
    package_id: PackageId,
    manifest: &ManifestErrorContext,
    target: &Target,
    options: &mut OutputOptions,
) -> CargoResult<bool> {
    // We primarily want to use this function to process JSON messages from
    // rustc. The compiler should always print one JSON message per line, and
    // otherwise it may have other output intermingled (think RUST_LOG or
    // something like that), so skip over everything that doesn't look like a
    // JSON message.
    if !line.starts_with('{') {
        state.stderr(line.to_string())?;
        return Ok(true);
    }

    let mut compiler_message: Box<serde_json::value::RawValue> = match serde_json::from_str(line) {
        Ok(msg) => msg,

        // If the compiler produced a line that started with `{` but it wasn't
        // valid JSON, maybe it wasn't JSON in the first place! Forward it along
        // to stderr.
        Err(e) => {
            debug!("failed to parse json: {:?}", e);
            state.stderr(line.to_string())?;
            return Ok(true);
        }
    };

    let count_diagnostic = |level, options: &mut OutputOptions| {
        if level == "warning" {
            options.warnings_seen += 1;
        } else if level == "error" {
            options.errors_seen += 1;
        }
    };

    if let Ok(report) = serde_json::from_str::<FutureIncompatReport>(compiler_message.get()) {
        for item in &report.future_incompat_report {
            count_diagnostic(&*item.diagnostic.level, options);
        }
        state.future_incompat_report(report.future_incompat_report);
        return Ok(true);
    }

    let res = serde_json::from_str::<SectionTiming>(compiler_message.get());
    if let Ok(timing_record) = res {
        state.on_section_timing_emitted(timing_record);
        return Ok(false);
    }

    // Returns `true` if the diagnostic was modified.
    let add_pub_in_priv_diagnostic = |diag: &mut String| -> bool {
        let Some(annotation) = &manifest.annotation else {
            return false;
        };
        // We are parsing the compiler diagnostic here, as this information isn't
        // currently exposed elsewhere.
        // At the time of writing this comment, rustc emits two different
        // "exported_private_dependencies" errors:
        //  - type `FromPriv` from private dependency 'priv_dep' in public interface
        //  - struct `FromPriv` from private dependency 'priv_dep' is re-exported
        // This regex matches them both. To see if it needs to be updated, grep the rust
        // source for "EXPORTED_PRIVATE_DEPENDENCIES".
        static PRIV_DEP_REGEX: LazyLock<Regex> =
            LazyLock::new(|| Regex::new("from private dependency '([A-Za-z0-9-_]+)'").unwrap());
        if let Some(crate_name) = PRIV_DEP_REGEX.captures(diag).and_then(|m| m.get(1))
            && let Some(span) = annotation.find_crate_span(crate_name.as_str())
        {
            let rel_path = pathdiff::diff_paths(&manifest.path, &annotation.cwd)
                .unwrap_or_else(|| manifest.path.clone())
                .display()
                .to_string();
            let report = [Group::with_title(Level::NOTE.secondary_title(format!(
                "dependency `{}` declared here",
                crate_name.as_str()
            )))
            .element(
                Snippet::source(&annotation.contents)
                    .path(rel_path)
                    .annotation(AnnotationKind::Context.span(span)),
            )];

            let rendered = Renderer::styled()
                .term_width(annotation.term_width)
                .render(&report);
            diag.push_str(&rendered);
            diag.push('\n');
            return true;
        }
        false
    };

    // Depending on what we're emitting from Cargo itself, we figure out what to
    // do with this JSON message.
    match options.format {
        // In the "human" output formats (human/short) or if diagnostic messages
        // from rustc aren't being included in the output of Cargo's JSON
        // messages then we extract the diagnostic (if present) here and handle
        // it ourselves.
        MessageFormat::Human
        | MessageFormat::Short
        | MessageFormat::Json {
            render_diagnostics: true,
            ..
        } => {
            #[derive(serde::Deserialize)]
            struct CompilerMessage<'a> {
                // `rendered` contains escape sequences, which can't be
                // zero-copy deserialized by serde_json.
                // See https://github.com/serde-rs/json/issues/742
                rendered: String,
                #[serde(borrow)]
                message: Cow<'a, str>,
                #[serde(borrow)]
                level: Cow<'a, str>,
                children: Vec<PartialDiagnostic>,
                code: Option<DiagnosticCode>,
            }

            // A partial rustfix::diagnostics::Diagnostic. We deserialize only a
            // subset of the fields because rustc's output can be extremely
            // deeply nested JSON in pathological cases involving macro
            // expansion. Rustfix's Diagnostic struct is recursive containing a
            // field `children: Vec<Self>`, and it can cause deserialization to
            // hit serde_json's default recursion limit, or overflow the stack
            // if we turn that off. Cargo only cares about the 1 field listed
            // here.
            #[derive(serde::Deserialize)]
            struct PartialDiagnostic {
                spans: Vec<PartialDiagnosticSpan>,
            }

            // A partial rustfix::diagnostics::DiagnosticSpan.
            #[derive(serde::Deserialize)]
            struct PartialDiagnosticSpan {
                suggestion_applicability: Option<Applicability>,
            }

            #[derive(serde::Deserialize)]
            struct DiagnosticCode {
                code: String,
            }

            if let Ok(mut msg) = serde_json::from_str::<CompilerMessage<'_>>(compiler_message.get())
            {
                if msg.message.starts_with("aborting due to")
                    || msg.message.ends_with("warning emitted")
                    || msg.message.ends_with("warnings emitted")
                {
                    // Skip this line; we'll print our own summary at the end.
                    return Ok(true);
                }
                // state.stderr will add a newline
                if msg.rendered.ends_with('\n') {
                    msg.rendered.pop();
                }
                let mut rendered = msg.rendered;
                if options.show_diagnostics {
                    let machine_applicable: bool = msg
                        .children
                        .iter()
                        .map(|child| {
                            child
                                .spans
                                .iter()
                                .filter_map(|span| span.suggestion_applicability)
                                .any(|app| app == Applicability::MachineApplicable)
                        })
                        .any(|b| b);
                    count_diagnostic(&msg.level, options);
                    if msg
                        .code
                        .as_ref()
                        .is_some_and(|c| c.code == "exported_private_dependencies")
                        && options.format != MessageFormat::Short
                    {
                        add_pub_in_priv_diagnostic(&mut rendered);
                    }
                    let lint = msg.code.is_some();
                    state.emit_diag(&msg.level, rendered, lint, machine_applicable)?;
                }
                return Ok(true);
            }
        }

        MessageFormat::Json { ansi, .. } => {
            #[derive(serde::Deserialize, serde::Serialize)]
            struct CompilerMessage<'a> {
                rendered: String,
                #[serde(flatten, borrow)]
                other: std::collections::BTreeMap<Cow<'a, str>, serde_json::Value>,
                code: Option<DiagnosticCode<'a>>,
            }

            #[derive(serde::Deserialize, serde::Serialize)]
            struct DiagnosticCode<'a> {
                code: String,
                #[serde(flatten, borrow)]
                other: std::collections::BTreeMap<Cow<'a, str>, serde_json::Value>,
            }

            if let Ok(mut error) =
                serde_json::from_str::<CompilerMessage<'_>>(compiler_message.get())
            {
                let modified_diag = if error
                    .code
                    .as_ref()
                    .is_some_and(|c| c.code == "exported_private_dependencies")
                {
                    add_pub_in_priv_diagnostic(&mut error.rendered)
                } else {
                    false
                };

                // Remove color information from the rendered string if color is not
                // enabled. Cargo always asks for ANSI colors from rustc. This allows
                // cached replay to enable/disable colors without re-invoking rustc.
                if !ansi {
                    error.rendered = anstream::adapter::strip_str(&error.rendered).to_string();
                }
                if !ansi || modified_diag {
                    let new_line = serde_json::to_string(&error)?;
                    compiler_message = serde_json::value::RawValue::from_string(new_line)?;
                }
            }
        }
    }

    // We always tell rustc to emit messages about artifacts being produced.
    // These messages feed into pipelined compilation, as well as timing
    // information.
    //
    // Look for a matching directive and inform Cargo internally that a
    // metadata file has been produced.
    #[derive(serde::Deserialize)]
    struct ArtifactNotification<'a> {
        #[serde(borrow)]
        artifact: Cow<'a, str>,
        public_api_hash: Option<serde_json::Value>,
    }

    #[derive(serde::Deserialize)]
    struct PublicApiHashNotification {
        version: u32,
        value: String,
    }

    if let Ok(artifact) = serde_json::from_str::<ArtifactNotification<'_>>(compiler_message.get()) {
        trace!("found directive from rustc: `{}`", artifact.artifact);
        if artifact.artifact.ends_with(".rmeta") {
            if let Some(public_api_hash) = artifact.public_api_hash {
                if let Ok(public_api_hash) =
                    serde_json::from_value::<PublicApiHashNotification>(public_api_hash)
                    && let Some(public_api_hash) =
                        PublicApiHash::new(public_api_hash.version, &public_api_hash.value)
                {
                    state.public_api_hash_produced(public_api_hash);
                } else {
                    state.invalid_public_api_hash();
                    debug!(
                        "rustc reported invalid public API hash for `{}`; disabling early cutoff",
                        artifact.artifact
                    );
                }
            }
            debug!("looks like metadata finished early!");
            state.rmeta_produced();
        }
        return Ok(false);
    }

    #[derive(serde::Deserialize)]
    struct CompilerNotification<'a> {
        #[serde(rename = "$message_type")]
        message_type: &'a str,
    }

    #[derive(serde::Deserialize)]
    struct UnusedExterns {
        unused_extern_names: std::collections::BTreeSet<InternedString>,
    }
    if let Ok(notification) =
        serde_json::from_str::<CompilerNotification<'_>>(compiler_message.get())
        && notification.message_type == "unused_extern"
    {
        match serde_json::from_str::<UnusedExterns>(compiler_message.get()) {
            Ok(unused_externs) => {
                trace!(
                    "obtained unused externs list from rustc: `{:?}`",
                    unused_externs.unused_extern_names
                );
                state.unused_externs(unused_externs.unused_extern_names);
            }
            Err(error) => {
                debug!("rustc reported malformed unused externs; disabling reuse: {error}");
                state.invalid_unused_externs();
            }
        }
        return Ok(true);
    }

    // And failing all that above we should have a legitimate JSON diagnostic
    // from the compiler, so wrap it in an external Cargo JSON message
    // indicating which package it came from and then emit it.

    if !options.show_diagnostics {
        return Ok(true);
    }

    #[derive(serde::Deserialize)]
    struct CompilerMessage<'a> {
        #[serde(borrow)]
        message: Cow<'a, str>,
        #[serde(borrow)]
        level: Cow<'a, str>,
    }

    if let Ok(msg) = serde_json::from_str::<CompilerMessage<'_>>(compiler_message.get()) {
        if msg.message.starts_with("aborting due to")
            || msg.message.ends_with("warning emitted")
            || msg.message.ends_with("warnings emitted")
        {
            // Skip this line; we'll print our own summary at the end.
            return Ok(true);
        }
        count_diagnostic(&msg.level, options);
    }

    let msg = machine_message::FromCompiler {
        package_id: package_id.to_spec(),
        manifest_path: &manifest.path,
        target,
        message: compiler_message,
    }
    .to_json_string();

    // Switch json lines from rustc/rustdoc that appear on stderr to stdout
    // instead. We want the stdout of Cargo to always be machine parseable as
    // stderr has our colorized human-readable messages.
    state.stdout(msg)?;
    Ok(true)
}

impl ManifestErrorContext {
    fn new(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> ManifestErrorContext {
        ManifestErrorContext {
            path: unit.pkg.manifest_path().to_owned(),
            annotation: ManifestDiagnosticContext::new(build_runner, unit),
        }
    }
}

impl ManifestDiagnosticContext {
    /// Skips annotation-only allocations when source spans or contents are unavailable.
    fn new(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> Option<Self> {
        let spans = unit.pkg.manifest().document_rc()?;
        let contents = unit.pkg.manifest().contents()?;
        let mut duplicates = HashSet::default();
        let mut rename_table = HashMap::default();

        for dep in build_runner.unit_deps(unit) {
            let unrenamed_id = dep.unit.pkg.package_id().name();
            if duplicates.contains(&unrenamed_id) {
                continue;
            }
            match rename_table.entry(unrenamed_id) {
                std::collections::hash_map::Entry::Occupied(occ) => {
                    occ.remove_entry();
                    duplicates.insert(unrenamed_id);
                }
                std::collections::hash_map::Entry::Vacant(vac) => {
                    vac.insert(dep.extern_crate_name);
                }
            }
        }

        let bcx = build_runner.bcx;
        Some(Self {
            spans,
            contents: contents.to_owned(),
            requested_kinds: bcx.target_data.requested_kinds().to_owned(),
            host_name: bcx.rustc().host,
            rename_table,
            cwd: path_args(build_runner.bcx.ws, unit).1,
            cfgs: bcx
                .target_data
                .requested_kinds()
                .iter()
                .map(|k| bcx.target_data.cfg(*k).to_owned())
                .collect(),
            term_width: bcx
                .gctx
                .shell()
                .err_width()
                .diagnostic_terminal_width()
                .unwrap_or(cargo_util_terminal::report::renderer::DEFAULT_TERM_WIDTH),
        })
    }

    fn requested_target_names(&self) -> impl Iterator<Item = &str> {
        self.requested_kinds.iter().map(|kind| match kind {
            CompileKind::Host => &self.host_name,
            CompileKind::Target(target) => target.short_name(),
        })
    }

    /// Find a span for the dependency that specifies this unrenamed crate, if it's unique.
    ///
    /// rustc diagnostics (at least for public-in-private) mention the un-renamed
    /// crate: if you have `foo = { package = "bar" }`, the rustc diagnostic will
    /// say "bar".
    ///
    /// This function does its best to find a span for "bar", but it could fail if
    /// there are multiple candidates:
    ///
    /// ```toml
    /// foo = { package = "bar" }
    /// baz = { path = "../bar", package = "bar" }
    /// ```
    fn find_crate_span(&self, unrenamed: &str) -> Option<Range<usize>> {
        let spans = &self.spans;

        let orig_name = self.rename_table.get(unrenamed)?.as_str();

        if let Some((k, v)) = get_key_value(&spans, &["dependencies", orig_name]) {
            // We make some effort to find the unrenamed text: in
            //
            // ```
            // foo = { package = "bar" }
            // ```
            //
            // we try to find the "bar", but fall back to "foo" if we can't (which might
            // happen if the renaming took place in the workspace, for example).
            if let Some(package) = v.get_ref().as_table().and_then(|t| t.get("package")) {
                return Some(package.span());
            } else {
                return Some(k.span());
            }
        }

        // The dependency could also be in a target-specific table, like
        // [target.x86_64-unknown-linux-gnu.dependencies] or
        // [target.'cfg(something)'.dependencies]. We filter out target tables
        // that don't match a requested target or a requested cfg.
        if let Some(target) = spans
            .deref()
            .as_ref()
            .get("target")
            .and_then(|t| t.as_ref().as_table())
        {
            for (platform, platform_table) in target.iter() {
                match platform.as_ref().parse::<Platform>() {
                    Ok(Platform::Name(name)) => {
                        if !self.requested_target_names().any(|n| n == name) {
                            continue;
                        }
                    }
                    Ok(Platform::Cfg(cfg_expr)) => {
                        if !self.cfgs.iter().any(|cfgs| cfg_expr.matches(cfgs)) {
                            continue;
                        }
                    }
                    Err(_) => continue,
                }

                let Some(platform_table) = platform_table.as_ref().as_table() else {
                    continue;
                };

                if let Some(deps) = platform_table
                    .get("dependencies")
                    .and_then(|d| d.as_ref().as_table())
                {
                    if let Some((k, v)) = deps.get_key_value(orig_name) {
                        if let Some(package) = v.get_ref().as_table().and_then(|t| t.get("package"))
                        {
                            return Some(package.span());
                        } else {
                            return Some(k.span());
                        }
                    }
                }
            }
        }
        None
    }
}

/// Creates a unit of work that replays the cached compiler message.
///
/// Usually used when a job is fresh and doesn't need to recompile.
fn replay_output_cache(
    package_id: PackageId,
    manifest: ManifestErrorContext,
    target: &Target,
    path: PathBuf,
    mut output_options: OutputOptions,
) -> Work {
    let target = target.clone();
    Work::new(move |state| {
        replay_output_cache_inner(
            state,
            package_id,
            &manifest,
            &target,
            &path,
            &mut output_options,
        )
    })
}

fn replay_output_cache_inner(
    state: &JobState<'_, '_>,
    package_id: PackageId,
    manifest: &ManifestErrorContext,
    target: &Target,
    path: &Path,
    output_options: &mut OutputOptions,
) -> CargoResult<()> {
    if !path.exists() {
        // No cached output, probably didn't emit anything.
        return Ok(());
    }
    // We sometimes have gigabytes of output from the compiler, so avoid
    // loading it all into memory at once, as that can cause OOM where
    // otherwise there would be none.
    let file = paths::open(path)?;
    let mut reader = std::io::BufReader::new(file);
    let mut line = String::new();
    loop {
        let length = reader.read_line(&mut line)?;
        if length == 0 {
            break;
        }
        let trimmed = line.trim_end_matches(&['\n', '\r'][..]);
        on_stderr_line(state, trimmed, package_id, manifest, target, output_options)?;
        line.clear();
    }
    Ok(())
}

/// Provides a package name with descriptive target information,
/// e.g., '`foo` (bin "bar" test)', '`foo` (lib doctest)'.
fn descriptive_pkg_name(name: &str, target: &Target, mode: &CompileMode) -> String {
    let desc_name = target.description_named();
    let mode = if mode.is_rustc_test() && !(target.is_test() || target.is_bench()) {
        " test"
    } else if mode.is_doc_test() {
        " doctest"
    } else if mode.is_doc() {
        " doc"
    } else {
        ""
    };
    format!("`{name}` ({desc_name}{mode})")
}

/// Applies environment variables from config `[env]` to [`ProcessBuilder`].
pub(crate) fn apply_env_config(
    gctx: &crate::GlobalContext,
    cmd: &mut ProcessBuilder,
) -> CargoResult<()> {
    for (key, value) in gctx.env_config()?.iter() {
        // never override a value that has already been set by cargo
        if cmd.get_envs().contains_key(key) {
            continue;
        }
        cmd.env(key, value);
    }
    Ok(())
}

/// Checks if there are some scrape units waiting to be processed.
fn should_include_scrape_units(bcx: &BuildContext<'_, '_>, unit: &Unit) -> bool {
    unit.mode.is_doc() && bcx.scrape_units.len() > 0 && bcx.ws.unit_needs_doc_scrape(unit)
}

/// Gets the file path of function call information output from `rustdoc`.
fn scrape_output_path(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> CargoResult<PathBuf> {
    assert!(unit.mode.is_doc() || unit.mode.is_doc_scrape());
    build_runner
        .outputs(unit)
        .map(|outputs| outputs[0].path.clone())
}

/// Gets the dep-info file emitted by rustdoc.
fn rustdoc_dep_info_loc(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> PathBuf {
    let mut loc = build_runner.files().fingerprint_file_path(unit, "");
    loc.set_extension("d");
    loc
}

#[cfg(test)]
mod relink_cache_tests {
    use super::*;

    fn manifest_json() -> CargoResult<Vec<u8>> {
        let manifest = RelinkCacheManifest {
            version: RELINK_CACHE_VERSION,
            rlink: RelinkCacheFile {
                path: PathBuf::from("quoted-\"-雪.rlink"),
                blake3: "hash".to_owned(),
            },
            executable: RelinkCacheObject {
                path: PathBuf::from("app"),
                len: 42,
                modified_nanos: u64::MAX,
            },
            objects: Vec::new(),
            unused_extern_names: Some(vec!["unused".to_owned()]),
        };
        let input_checksum = manifest.input_checksum();
        Ok(serde_json::to_vec(&CheckedRelinkManifest {
            input_checksum,
            proof_checksum: crate::util::hash_u64((input_checksum, &manifest.unused_extern_names)),
            manifest,
        })?)
    }

    #[test]
    fn relink_manifest_json_matches_streaming_at_size_boundaries() -> CargoResult<()> {
        let original = manifest_json()?;
        let expected: serde_json::Value = serde_json::from_slice(&original)?;
        for size in [
            original.len(),
            RELINK_MANIFEST_SLICE_LIMIT as usize,
            RELINK_MANIFEST_SLICE_LIMIT as usize + 1,
        ] {
            let mut bytes = original.clone();
            bytes.resize(size, b' ');
            // Include unknown, accurate, stale-short and stale-long file sizes.
            for len in [
                None,
                Some(size as u64),
                Some(1),
                Some(size as u64 - 1),
                Some(size as u64 + 1),
            ] {
                let actual = read_relink_manifest_json(std::io::Cursor::new(&bytes), len).unwrap();
                let streaming: CheckedRelinkManifest =
                    serde_json::from_reader(BufReader::new(bytes.as_slice()))?;
                assert_eq!(serde_json::to_value(actual)?, expected);
                assert_eq!(serde_json::to_value(streaming)?, expected);
            }
        }
        Ok(())
    }

    #[test]
    fn relink_manifest_json_rejects_truncation_trailing_and_invalid_data() -> CargoResult<()> {
        let original = manifest_json()?;
        let mut wrong_type: serde_json::Value = serde_json::from_slice(&original)?;
        wrong_type["version"] = serde_json::json!("not an integer");
        let mut large_trailing = original.clone();
        large_trailing.resize(RELINK_MANIFEST_SLICE_LIMIT as usize + 1, b' ');
        large_trailing.extend_from_slice(b"false");
        let invalid = [
            Vec::new(),
            original[..original.len() - 1].to_vec(),
            [original.as_slice(), b"{}"].concat(),
            [original.as_slice(), b"\0"].concat(),
            serde_json::to_vec(&wrong_type)?,
            large_trailing,
        ];
        for bytes in invalid {
            for len in [None, Some(bytes.len() as u64), Some(original.len() as u64)] {
                assert!(read_relink_manifest_json(std::io::Cursor::new(&bytes), len).is_none());
                assert!(
                    serde_json::from_reader::<_, CheckedRelinkManifest>(BufReader::new(
                        bytes.as_slice()
                    ))
                    .is_err()
                );
            }
        }
        Ok(())
    }

    fn assert_manifest_decoder_parity(bytes: &[u8], accepted: bool) -> CargoResult<()> {
        let expected = serde_json::from_slice::<CheckedRelinkManifest>(bytes)
            .ok()
            .map(|value| serde_json::to_vec(&value))
            .transpose()?;
        assert_eq!(expected.is_some(), accepted);
        for len in [
            None,
            Some(bytes.len() as u64),
            Some(1),
            Some(bytes.len() as u64 + 1),
        ] {
            let actual = read_relink_manifest_json(std::io::Cursor::new(bytes), len)
                .map(|value| serde_json::to_vec(&value))
                .transpose()?;
            assert_eq!(actual, expected);
        }
        Ok(())
    }

    #[test]
    fn relink_manifest_json_preserves_field_and_sequence_behavior() -> CargoResult<()> {
        let original = manifest_json()?;
        let mut value: serde_json::Value = serde_json::from_slice(&original)?;
        value["objects"] = serde_json::json!([{"path": "object.o", "blake3": "hash"}]);
        let bytes = serde_json::to_vec(&value)?;
        assert_manifest_decoder_parity(&bytes, true)?;
        assert_manifest_decoder_parity(&[b" \n\t\r".as_slice(), &bytes].concat(), true)?;

        for field in [
            "input_checksum",
            "proof_checksum",
            "version",
            "rlink",
            "executable",
            "objects",
        ] {
            let mut missing = value.clone();
            missing.as_object_mut().unwrap().remove(field);
            assert_manifest_decoder_parity(&serde_json::to_vec(&missing)?, false)?;
        }
        for (field, contents) in value.as_object().unwrap() {
            let duplicate = format!("{{{}:{},", serde_json::to_string(field)?, contents);
            assert_manifest_decoder_parity(&[duplicate.as_bytes(), &bytes[1..]].concat(), false)?;
        }

        let mut optional = value.clone();
        optional
            .as_object_mut()
            .unwrap()
            .remove("unused_extern_names");
        assert_manifest_decoder_parity(&serde_json::to_vec(&optional)?, true)?;
        optional["unused_extern_names"] = serde_json::Value::Null;
        assert_manifest_decoder_parity(&serde_json::to_vec(&optional)?, true)?;
        let duplicate_null = b"{\"unused_extern_names\":null,";
        assert_manifest_decoder_parity(&[duplicate_null.as_slice(), &bytes[1..]].concat(), false)?;

        let mut sequences = value.clone();
        sequences["rlink"] = serde_json::json!(["recipe.rlink", "hash"]);
        sequences["executable"] = serde_json::json!(["app", 42, u64::MAX]);
        sequences["objects"] = serde_json::json!([["object.o", "hash"]]);
        assert_manifest_decoder_parity(&serde_json::to_vec(&sequences)?, true)?;
        let root_sequence = serde_json::json!([
            value["input_checksum"],
            value["proof_checksum"],
            value["version"],
            value["rlink"],
            value["executable"],
            value["objects"],
            value["unused_extern_names"]
        ]);
        assert_manifest_decoder_parity(&serde_json::to_vec(&root_sequence)?, false)?;
        sequences["rlink"] = serde_json::json!(["recipe.rlink", "hash", "extra"]);
        assert_manifest_decoder_parity(&serde_json::to_vec(&sequences)?, false)?;
        Ok(())
    }

    #[test]
    fn relink_manifest_json_preserves_unknown_value_validation() -> CargoResult<()> {
        let mut value: serde_json::Value = serde_json::from_slice(&manifest_json()?)?;
        value["objects"] = serde_json::json!([{"path": "object.o", "blake3": "hash"}]);
        let original = serde_json::to_string(&value)?;
        let deep = format!("{}0{}", "[".repeat(130), "]".repeat(130));
        for (unknown, accepted) in [
            ("{\"nested\":[null,true,1.5,\"text\"]}", true),
            ("1e400", false),
            ("\"\\ud800\"", false),
            (deep.as_str(), false),
        ] {
            for prefix in ["{", "\"rlink\":{", "\"executable\":{", "\"objects\":[{"] {
                let replacement = format!("{prefix}\"future\":{unknown},");
                let bytes = original.replacen(prefix, &replacement, 1);
                assert_manifest_decoder_parity(bytes.as_bytes(), accepted)?;
            }
        }
        let duplicate_unknown = format!("{{\"future\":1,\"future\":null,{}", &original[1..]);
        assert_manifest_decoder_parity(duplicate_unknown.as_bytes(), true)?;
        let invalid_utf8 = [
            b"{\"future\":\"\xff\",".as_slice(),
            &original.as_bytes()[1..],
        ]
        .concat();
        assert_manifest_decoder_parity(&invalid_utf8, false)?;
        Ok(())
    }

    #[test]
    fn relink_manifest_json_keeps_checksum_failures_distinct() -> CargoResult<()> {
        let dir = tempfile::tempdir()?;
        let cache = RelinkCachePaths::new(dir.path().join("app"));
        let original = manifest_json()?;
        fs::write(&cache.manifest, &original)?;
        assert!(cache.read_manifest().unwrap().unused_extern_names.is_some());

        let mut value: serde_json::Value = serde_json::from_slice(&original)?;
        value["input_checksum"] = serde_json::json!(value["input_checksum"].as_u64().unwrap() ^ 1);
        fs::write(&cache.manifest, serde_json::to_vec(&value)?)?;
        assert!(cache.read_manifest().is_none());

        let mut value: serde_json::Value = serde_json::from_slice(&original)?;
        value["proof_checksum"] = serde_json::json!(value["proof_checksum"].as_u64().unwrap() ^ 1);
        fs::write(&cache.manifest, serde_json::to_vec(&value)?)?;
        assert!(cache.read_manifest().unwrap().unused_extern_names.is_none());
        Ok(())
    }

    #[cfg(unix)]
    #[test]
    fn relink_manifest_reads_and_writes_do_not_follow_a_final_symlink() -> CargoResult<()> {
        let dir = tempfile::tempdir()?;
        let cache = RelinkCachePaths::new(dir.path().join("app"));
        let target = dir.path().join("manifest.json");
        let original = manifest_json()?;
        fs::write(&target, &original)?;
        std::os::unix::fs::symlink(&target, &cache.manifest)?;
        assert!(cache.read_manifest().is_none());

        let mut manifest = serde_json::from_slice::<CheckedRelinkManifest>(&original)?.manifest;
        manifest.unused_extern_names = None;
        cache.write_manifest(manifest)?;
        assert_eq!(fs::read(target)?, original);
        assert!(cache.read_manifest().unwrap().unused_extern_names.is_none());
        Ok(())
    }

    #[test]
    fn incomplete_object_list_invalidates_relink_manifest() -> CargoResult<()> {
        let dir = tempfile::tempdir()?;
        let cache = RelinkCachePaths::new(dir.path().join("app"));
        fs::create_dir(&cache.objects)?;
        fs::write(&cache.rlink, b"recipe")?;
        fs::write(&cache.executable, b"exe")?;
        for name in ["a.o", "b.o"] {
            fs::write(cache.objects.join(name), b"codegen")?;
        }
        cache.initialize(None)?;
        assert!(cache.is_valid());

        let mut manifest: serde_json::Value = serde_json::from_slice(&fs::read(&cache.manifest)?)?;
        manifest["objects"].as_array_mut().unwrap().pop();
        fs::write(&cache.manifest, serde_json::to_vec(&manifest)?)?;
        fs::remove_file(cache.objects.join("b.o"))?;
        assert!(!cache.is_valid());
        Ok(())
    }

    #[cfg(unix)]
    #[test]
    fn cache_fifos_do_not_wait_for_a_writer() -> CargoResult<()> {
        let dir = tempfile::tempdir()?;
        let output = dir.path().join("out");
        std::os::unix::fs::symlink(dir.path(), &output)?;
        let cache = RelinkCachePaths::new(output.join("app"));
        fs::write(&cache.rlink, b"recipe")?;
        cached_file(cache.rlink.clone())?;
        fs::remove_file(&cache.rlink)?;
        let public_hash = dir.path().join("lib-dep.public-api-hash");
        assert!(
            std::process::Command::new("mkfifo")
                .args([&cache.manifest, &cache.rlink, &public_hash])
                .status()?
                .success()
        );

        let (send, receive) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let misses = fingerprint::read_public_api_hash(&public_hash).is_none()
                && cache.read_manifest().is_none()
                && cached_file(cache.rlink.clone()).is_err();
            let cleared =
                cache.invalidate().is_ok() && !cache.rlink.exists() && !cache.manifest.exists();
            send.send(misses && cleared).unwrap();
        });
        assert!(receive.recv_timeout(std::time::Duration::from_secs(5))?);
        Ok(())
    }
}
