//! Tracks changes to determine if something needs to be recompiled.
//!
//! This module implements change-tracking so that Cargo can know whether or
//! not something needs to be recompiled. A Cargo [`Unit`] can be either "dirty"
//! (needs to be recompiled) or "fresh" (it does not need to be recompiled).
//!
//! ## Mechanisms affecting freshness
//!
//! There are several mechanisms that influence a Unit's freshness:
//!
//! - The [`Fingerprint`] is a hash, saved to the filesystem in the
//!   `.fingerprint` directory, that tracks information about the Unit. If the
//!   fingerprint is missing (such as the first time the unit is being
//!   compiled), then the unit is dirty. If any of the fingerprint fields
//!   change (like the name of the source file), then the Unit is considered
//!   dirty.
//!
//!   The `Fingerprint` also tracks the fingerprints of all its dependencies,
//!   so a change in a dependency will propagate the "dirty" status up.
//!
//! - Filesystem mtime tracking is also used to check if a unit is dirty.
//!   See the section below on "Mtime comparison" for more details. There
//!   are essentially two parts to mtime tracking:
//!
//!   1. The mtime of a Unit's output files is compared to the mtime of all
//!      its dependencies' output file mtimes (see
//!      [`check_filesystem`]). If any output is missing, or is
//!      older than a dependency's output, then the unit is dirty.
//!   2. The mtime of a Unit's source files is compared to the mtime of its
//!      dep-info file in the fingerprint directory (see [`find_stale_file`]).
//!      The dep-info file is used as an anchor to know when the last build of
//!      the unit was done. See the "dep-info files" section below for more
//!      details. If any input files are missing, or are newer than the
//!      dep-info, then the unit is dirty.
//!
//!  - Alternatively if you're using the unstable feature `checksum-freshness`
//!    mtimes are ignored entirely in favor of comparing first the file size, and
//!    then the checksum with a known prior value emitted by rustc. Only nightly
//!    rustc will emit the needed metadata at the time of writing. This is dependent
//!    on the unstable feature `-Z checksum-hash-algorithm`.
//!
//! Note: Fingerprinting is not a perfect solution. Filesystem mtime tracking
//! is notoriously imprecise and problematic. Only a small part of the
//! environment is captured. This is a balance of performance, simplicity, and
//! completeness. Sandboxing, hashing file contents, tracking every file
//! access, environment variable, and network operation would ensure more
//! reliable and reproducible builds at the cost of being complex, slow, and
//! platform-dependent.
//!
//! ## Fingerprints and [`UnitHash`]s
//!
//! [`Metadata`] tracks several [`UnitHash`]s, including
//! [`Metadata::unit_id`], [`Metadata::c_metadata`], and [`Metadata::c_extra_filename`].
//! See its documentation for more details.
//!
//! NOTE: Not all output files are isolated via filename hashes (like dylibs).
//! The fingerprint directory uses a hash, but sometimes units share the same
//! fingerprint directory (when they don't have Metadata) so care should be
//! taken to handle this!
//!
//! Fingerprints and [`UnitHash`]s are similar, and track some of the same things.
//! [`UnitHash`]s contains information that is required to keep Units separate.
//! The Fingerprint includes additional information that should cause a
//! recompile, but it is desired to reuse the same filenames. A comparison
//! of what is tracked:
//!
//! Value                                      | Fingerprint | `Metadata::unit_id` [^8] | `Metadata::c_metadata`
//! -------------------------------------------|-------------|--------------------------|-----------------------
//! rustc                                      | ✓           | ✓                        | ✓
//! [`Profile`]                                | ✓           | ✓                        | ✓
//! `cargo rustc` extra args                   | ✓           | ✓[^7]                    |
//! [`CompileMode`]                            | ✓           | ✓                        | ✓
//! Target Name                                | ✓           | ✓                        | ✓
//! `TargetKind` (bin/lib/etc.)                | ✓           | ✓                        | ✓
//! Enabled Features                           | ✓           | ✓                        | ✓
//! Declared Features                          | ✓           |                          |
//! Immediate dependency’s hashes              | ✓[^1]       | ✓                        | ✓
//! [`CompileKind`] (host/target)              | ✓           | ✓                        | ✓
//! `__CARGO_DEFAULT_LIB_METADATA`[^4]         |             | ✓                        | ✓
//! `__CARGO_RUSTC_BOOTSTRAP_WS_REMAP`[^2]     | ✓           |                          |
//! `package_id`                               |             | ✓                        | ✓
//! Target src path relative to ws             | ✓           |                          |
//! Target flags (test/bench/for_host/edition) | ✓           |                          |
//! -C incremental=… flag                      | ✓           |                          |
//! mtime of sources                           | ✓[^3]       |                          |
//! RUSTFLAGS/RUSTDOCFLAGS                     | ✓           | ✓[^7]                    |
//! [`Lto`] flags                              | ✓           | ✓                        | ✓
//! config settings[^5]                        | ✓           |                          |
//! `is_std`                                   |             | ✓                        | ✓
//! `[lints]` table[^6]                        | ✓           |                          |
//! `[lints.rust.unexpected_cfgs.check-cfg]`   | ✓           |                          |
//! `--extern priv:`                           | ✓           |                          |
//!
//! [^1]: Bin dependencies are not included.
//!
//! [^2]: `__CARGO_RUSTC_BOOTSTRAP_WS_REMAP` is set by rustc bootstrap
//!       to customize remap-path-prefix
//!
//! [^3]: See below for details on mtime tracking.
//!
//! [^4]: `__CARGO_DEFAULT_LIB_METADATA` is set by rustbuild to embed the
//!        release channel (bootstrap/stable/beta/nightly) in libstd.
//!
//! [^5]: Config settings that are not otherwise captured anywhere else.
//!       Currently, this is only `doc.extern-map`.
//!
//! [^6]: Via [`Manifest::lint_rustflags`][crate::workspace::Manifest::lint_rustflags]
//!
//! [^7]: extra-flags and RUSTFLAGS are conditionally excluded when `--remap-path-prefix` is
//!       present to avoid breaking build reproducibility while we wait for trim-paths
//!
//! [^8]: including `-Cextra-filename`
//!
//! When deciding what should go in the Metadata vs the Fingerprint, consider
//! that some files (like dylibs) do not have a hash in their filename. Thus,
//! if a value changes, only the fingerprint will detect the change (consider,
//! for example, swapping between different features). Fields that are only in
//! Metadata generally aren't relevant to the fingerprint because they
//! fundamentally change the output (like target vs host changes the directory
//! where it is emitted).
//!
//! ## Fingerprint files
//!
//! Fingerprint information is stored in the
//! `target/{debug,release}/.fingerprint/` directory. Each Unit is stored in a
//! separate directory. Each Unit directory contains:
//!
//! - A file with a 16 hex-digit hash. This is the Fingerprint hash, used for
//!   quick loading and comparison.
//! - A `.json` file that contains details about the Fingerprint. This is only
//!   used to log details about *why* a fingerprint is considered dirty.
//!   `CARGO_LOG=cargo::compiler::fingerprint=trace cargo build` can be
//!   used to display this log information.
//! - A "dep-info" file which is a translation of rustc's `*.d` dep-info files
//!   to a Cargo-specific format that tweaks file names and is optimized for
//!   reading quickly.
//! - An `invoked.timestamp` file whose filesystem mtime is updated every time
//!   the Unit is built. This is used for capturing the time when the build
//!   starts, to detect if files are changed in the middle of the build. See
//!   below for more details.
//!
//! Note that some units are a little different. A Unit for *running* a build
//! script or for `rustdoc` does not have a dep-info file (it's not
//! applicable). Build script `invoked.timestamp` files are in the build
//! output directory.
//!
//! ## Fingerprint calculation
//!
//! After the list of Units has been calculated, the Units are added to the
//! [`JobQueue`]. As each one is added, the fingerprint is calculated, and the
//! dirty/fresh status is recorded. A closure is used to update the fingerprint
//! on-disk when the Unit successfully finishes. The closure will recompute the
//! Fingerprint based on the updated information. If the Unit fails to compile,
//! the fingerprint is not updated.
//!
//! Fingerprints are cached in the [`BuildRunner`]. This makes computing
//! Fingerprints faster, but also is necessary for properly updating
//! dependency information. Since a Fingerprint includes the Fingerprints of
//! all dependencies, when it is updated, by using `Arc` clones, it
//! automatically picks up the updates to its dependencies.
//!
//! ### dep-info files
//!
//! Cargo has several kinds of "dep info" files:
//!
//! * dep-info files generated by `rustc`.
//! * Fingerprint dep-info files translated from the first one.
//! * dep-info for external build system integration.
//! * Unstable `-Zbinary-dep-depinfo`.
//!
//! #### `rustc` dep-info files
//!
//! Cargo passes the `--emit=dep-info` flag to `rustc` so that `rustc` will
//! generate a "dep info" file (with the `.d` extension). This is a
//! Makefile-like syntax that includes all of the source files used to build
//! the crate. This file is used by Cargo to know which files to check to see
//! if the crate will need to be rebuilt. Example:
//!
//! ```makefile
//! /path/to/target/debug/deps/cargo-b6219d178925203d: src/bin/main.rs src/bin/cargo/cli.rs # … etc.
//! ```
//!
//! #### Fingerprint dep-info files
//!
//! After `rustc` exits successfully, Cargo will read the first kind of dep
//! info file and translate it into a binary format that is stored in the
//! fingerprint directory ([`translate_dep_info`]).
//!
//! These are used to quickly scan for any changed files. The mtime of the
//! fingerprint dep-info file itself is used as the reference for comparing the
//! source files to determine if any of the source files have been modified
//! (see [below](#mtime-comparison) for more detail).
//!
//! Note that Cargo parses the special `# env-var:...` comments in dep-info
//! files to learn about environment variables that the rustc compile depends on.
//! Cargo then later uses this to trigger a recompile if a referenced env var
//! changes (even if the source didn't change).
//! This also includes env vars generated from Cargo metadata like `CARGO_PKG_DESCRIPTION`.
//! (See [`crate::workspace::manifest::ManifestMetadata`]
//!
//! #### dep-info files for build system integration.
//!
//! There is also a third dep-info file. Cargo will extend the file created by
//! rustc with some additional information and saves this into the output
//! directory. This is intended for build system integration. See the
//! [`output_depinfo`] function for more detail.
//!
//! #### -Zbinary-dep-depinfo
//!
//! `rustc` has an experimental flag `-Zbinary-dep-depinfo`. This causes
//! `rustc` to include binary files (like rlibs) in the dep-info file. This is
//! primarily to support rustc development, so that Cargo can check the
//! implicit dependency to the standard library (which lives in the sysroot).
//! We want Cargo to recompile whenever the standard library rlib/dylibs
//! change, and this is a generic mechanism to make that work.
//!
//! ### Mtime comparison
//!
//! The use of modification timestamps is the most common way a unit will be
//! determined to be dirty or fresh between builds. There are many subtle
//! issues and edge cases with mtime comparisons. This gives a high-level
//! overview, but you'll need to read the code for the gritty details. Mtime
//! handling is different for different unit kinds. The different styles are
//! driven by the [`Fingerprint::local`] field, which is set based on the unit
//! kind.
//!
//! The status of whether or not the mtime is "stale" or "up-to-date" is
//! stored in [`Fingerprint::fs_status`].
//!
//! All units will compare the mtime of its newest output file with the mtimes
//! of the outputs of all its dependencies. If any output file is missing,
//! then the unit is stale. If any dependency is newer, the unit is stale.
//!
//! #### Normal package mtime handling
//!
//! [`LocalFingerprint::CheckDepInfo`] is used for checking the mtime of
//! packages. It compares the mtime of the input files (the source files) to
//! the mtime of the dep-info file (which is written last after a build is
//! finished). If the dep-info is missing, the unit is stale (it has never
//! been built). The list of input files comes from the dep-info file. See the
//! section above for details on dep-info files.
//!
//! Also note that although registry and git packages use [`CheckDepInfo`], none
//! of their source files are included in the dep-info (see
//! [`translate_dep_info`]), so for those kinds no mtime checking is done
//! (unless `-Zbinary-dep-depinfo` is used). Repository and git packages are
//! static, so there is no need to check anything.
//!
//! When a build is complete, the mtime of the dep-info file in the
//! fingerprint directory is modified to rewind it to the time when the build
//! started. This is done by creating an `invoked.timestamp` file when the
//! build starts to capture the start time. The mtime is rewound to the start
//! to handle the case where the user modifies a source file while a build is
//! running. Cargo can't know whether or not the file was included in the
//! build, so it takes a conservative approach of assuming the file was *not*
//! included, and it should be rebuilt during the next build.
//!
//! #### Rustdoc mtime handling
//!
//! Rustdoc does not emit a dep-info file, so Cargo currently has a relatively
//! simple system for detecting rebuilds. [`LocalFingerprint::Precalculated`] is
//! used for rustdoc units. For registry packages, this is the package
//! version. For git packages, it is the git hash. For path packages, it is
//! a string of the mtime of the newest file in the package.
//!
//! There are some known bugs with how this works, so it should be improved at
//! some point.
//!
//! #### Build script mtime handling
//!
//! Build script mtime handling runs in different modes. There is the "old
//! style" where the build script does not emit any `rerun-if` directives. In
//! this mode, Cargo will use [`LocalFingerprint::Precalculated`]. See the
//! "rustdoc" section above how it works.
//!
//! In the new-style, each `rerun-if` directive is translated to the
//! corresponding [`LocalFingerprint`] variant. The [`RerunIfChanged`] variant
//! compares the mtime of the given filenames against the mtime of the
//! "output" file.
//!
//! Similar to normal units, the build script "output" file mtime is rewound
//! to the time just before the build script is executed to handle mid-build
//! modifications.
//!
//! ## Considerations for inclusion in a fingerprint
//!
//! Over time we've realized a few items which historically were included in
//! fingerprint hashings should not actually be included. Examples are:
//!
//! * Modification time values. We strive to never include a modification time
//!   inside a `Fingerprint` to get hashed into an actual value. While
//!   theoretically fine to do, in practice this causes issues with common
//!   applications like Docker. Docker, after a layer is built, will zero out
//!   the nanosecond part of all filesystem modification times. This means that
//!   the actual modification time is different for all build artifacts, which
//!   if we tracked the actual values of modification times would cause
//!   unnecessary recompiles. To fix this we instead only track paths which are
//!   relevant. These paths are checked dynamically to see if they're up to
//!   date, and the modification time doesn't make its way into the fingerprint
//!   hash.
//!
//! * Absolute path names. We strive to maintain a property where if you rename
//!   a project directory Cargo will continue to preserve all build artifacts
//!   and reuse the cache. This means that we can't ever hash an absolute path
//!   name. Instead we always hash relative path names and the "root" is passed
//!   in at runtime dynamically. Some of this is best effort, but the general
//!   idea is that we assume all accesses within a crate stay within that
//!   crate.
//!
//! These are pretty tricky to test for unfortunately, but we should have a good
//! test suite nowadays and lord knows Cargo gets enough testing in the wild!
//!
//! ## Build scripts
//!
//! The *running* of a build script ([`CompileMode::RunCustomBuild`]) is treated
//! significantly different than all other Unit kinds. It has its own function
//! for calculating the Fingerprint ([`calculate_run_custom_build`]) and has some
//! unique considerations. It does not track the same information as a normal
//! Unit. The information tracked depends on the `rerun-if-changed` and
//! `rerun-if-env-changed` statements produced by the build script. If the
//! script does not emit either of these statements, the Fingerprint runs in
//! "old style" mode where an mtime change of *any* file in the package will
//! cause the build script to be re-run. Otherwise, the fingerprint *only*
//! tracks the individual "rerun-if" items listed by the build script.
//!
//! The "rerun-if" statements from a *previous* build are stored in the build
//! output directory in a file called `output`. Cargo parses this file when
//! the Unit for that build script is prepared for the [`JobQueue`]. The
//! Fingerprint code can then use that information to compute the Fingerprint
//! and compare against the old fingerprint hash.
//!
//! Care must be taken with build script Fingerprints because the
//! [`Fingerprint::local`] value may be changed after the build script runs
//! (such as if the build script adds or removes "rerun-if" items).
//!
//! Another complication is if a build script is overridden. In that case, the
//! fingerprint is the hash of the output of the override.
//!
//! ## Special considerations
//!
//! Registry dependencies do not track the mtime of files. This is because
//! registry dependencies are not expected to change (if a new version is
//! used, the Package ID will change, causing a rebuild). Cargo currently
//! partially works with Docker caching. When a Docker image is built, it has
//! normal mtime information. However, when a step is cached, the nanosecond
//! portions of all files is zeroed out. Currently this works, but care must
//! be taken for situations like these.
//!
//! HFS on macOS only supports 1 second timestamps. This causes a significant
//! number of problems, particularly with Cargo's testsuite which does rapid
//! builds in succession. Other filesystems have various degrees of
//! resolution.
//!
//! Various weird filesystems (such as network filesystems) also can cause
//! complications. Network filesystems may track the time on the server
//! (except when the time is set manually such as with
//! `filetime::set_file_times`). Not all filesystems support modifying the
//! mtime.
//!
//! See the [`A-rebuild-detection`] label on the issue tracker for more.
//!
//! [`check_filesystem`]: Fingerprint::check_filesystem
//! [`Metadata`]: crate::compiler::Metadata
//! [`Metadata::unit_id`]: crate::compiler::Metadata::unit_id
//! [`Metadata::c_metadata`]: crate::compiler::Metadata::c_metadata
//! [`Metadata::c_extra_filename`]: crate::compiler::Metadata::c_extra_filename
//! [`UnitHash`]: crate::compiler::UnitHash
//! [`Profile`]: crate::workspace::profiles::Profile
//! [`CompileMode`]: crate::compiler::CompileMode
//! [`Lto`]: crate::compiler::Lto
//! [`CompileKind`]: crate::compiler::CompileKind
//! [`JobQueue`]: super::job_queue::JobQueue
//! [`output_depinfo`]: super::output_depinfo()
//! [`CheckDepInfo`]: LocalFingerprint::CheckDepInfo
//! [`RerunIfChanged`]: LocalFingerprint::RerunIfChanged
//! [`CompileMode::RunCustomBuild`]: crate::compiler::CompileMode::RunCustomBuild
//! [`A-rebuild-detection`]: https://github.com/rust-lang/cargo/issues?q=is%3Aissue+is%3Aopen+label%3AA-rebuild-detection

pub(crate) mod dep_info;
mod dirty_reason;
mod rustdoc;
mod worktree;

use crate::util::data_structures::{HashMap, HashSet};
use std::borrow::Cow;
use std::collections::hash_map::Entry;
use std::env;
use std::ffi::{OsStr, OsString};
use std::fs;
use std::fs::File;
use std::hash::{self, Hash, Hasher};
use std::io::{self, Read as _};
use std::ops::Not;
use std::path::{Path, PathBuf};
#[cfg(unix)]
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::SystemTime;

use anyhow::Context as _;
use cargo_util::paths;
use filetime::FileTime;
use serde::de;
use serde::ser;
use serde::{Deserialize, Serialize};
use tracing::{debug, info};

use crate::compiler::unit_graph::UnitDep;
use crate::util;
use crate::util::errors::CargoResult;
use crate::util::interning::InternedString;
use crate::util::log_message::LogMessage;
use crate::util::{StableHasher, internal, path_args};
use crate::workspace::Package;
use crate::{CARGO_ENV, GlobalContext};

use super::BuildContext;
use super::BuildRunner;
use super::CompileKind;
use super::CompileMode;
use super::FileFlavor;
use super::Job;
use super::PublicApiHash;
use super::Unit;
use super::UnitIndex;
use super::Work;
use super::custom_build::BuildDeps;

pub use self::dep_info::Checksum;
pub(super) use self::dep_info::dep_info_paths;
pub use self::dep_info::parse_dep_info;
pub use self::dep_info::parse_rustc_dep_info;
pub use self::dep_info::translate_dep_info;
pub use self::dirty_reason::DirtyReason;
pub use self::rustdoc::RustdocFingerprint;
use self::worktree::ScriptResult;
pub(super) use self::worktree::can_reuse_after_scripts;
pub(crate) use self::worktree::{OHM_WORKTREE_SCRIPT_RERUN, OHM_WORKTREE_SCRIPT_RESULT};

fn parse_unstable_bool(value: Option<&str>) -> Option<bool> {
    match value {
        None | Some("y" | "yes" | "on" | "true") => Some(true),
        Some("n" | "no" | "off" | "false") => Some(false),
        Some(_) => None,
    }
}

fn rustflags_iter_unstable_option<'a>(
    rustflags: impl IntoIterator<Item = &'a str>,
    option_name: &str,
) -> Option<bool> {
    let mut enabled = None;
    let mut rustflags = rustflags.into_iter();
    while let Some(rustflag) = rustflags.next() {
        let option = if rustflag == "-Z" {
            rustflags.next()
        } else {
            rustflag.strip_prefix("-Z")
        };
        let Some(option) = option else {
            continue;
        };
        let (name, value) = option
            .split_once('=')
            .map_or((option, None), |(name, value)| (name, Some(value)));
        if name
            .bytes()
            .map(|byte| if byte == b'_' { b'-' } else { byte })
            .eq(option_name.bytes())
            && let Some(value) = parse_unstable_bool(value)
        {
            enabled = Some(value);
        }
    }
    enabled
}

#[cfg(test)]
fn rustflags_enable_public_api_hash(rustflags: &[String]) -> bool {
    rustflags_iter_unstable_option(rustflags.iter().map(String::as_str), "public-api-hash")
        .unwrap_or(false)
}

pub(super) fn unit_public_api_hash_override(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> Option<bool> {
    let gctx = build_runner.bcx.gctx;
    let extra_args = build_runner
        .bcx
        .extra_args_for(unit)
        .map(Vec::as_slice)
        .unwrap_or_default();
    let user_rustflags = super::unit_rustflags_without_ohm_defaults(gctx, &unit.rustflags);
    rustflags_iter_unstable_option(
        unit.pkg
            .manifest()
            .lint_rustflags()
            .iter()
            .map(String::as_str)
            .chain(unit.profile.rustflags.iter().map(|flag| flag.as_str()))
            .chain(extra_args.iter().map(String::as_str))
            .chain(user_rustflags.iter().map(String::as_str)),
        "public-api-hash",
    )
}

fn unit_uses_public_api_hash(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    if !matches!(
        unit.mode,
        CompileMode::Build | CompileMode::Test | CompileMode::Check { .. }
    ) {
        return false;
    }

    unit_public_api_hash_override(build_runner, unit).unwrap_or_else(|| {
        build_runner.bcx.gctx.cli_unstable().ohm_defaults()
            && !super::unit_suppresses_default_public_api_hash(build_runner, unit)
    })
}

fn unit_consumes_public_api_hash(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    unit_uses_public_api_hash(build_runner, unit)
        || super::unit_suppresses_default_public_api_hash(build_runner, unit)
}

/// Whether no other Cargo invocation can change this unit's metadata while it is prepared.
pub(super) fn unit_has_exclusive_metadata_access(
    build_runner: &BuildRunner<'_, '_>,
    unit: &Unit,
) -> bool {
    let unstable = build_runner.bcx.gctx.cli_unstable();
    if !unstable.fine_grain_locking {
        return true;
    }

    // Preserve the existing restriction to workspace-private early cutoff even when
    // the shared cache has an exclusive profile lease. A workspace namespace lock or
    // an exclusive profile lease on the host layout protects private metadata for the
    // whole invocation. Every invocation acquires that layout first, so it also
    // protects target layouts without locking duplicate target directories twice.
    build_runner.bcx.ws.shared_registry_cache_enabled()
        && !build_runner.files().is_shared_registry_unit(unit)
        && build_runner
            .files()
            .layout(CompileKind::Host)
            .build_dir()
            .has_workspace_lock()
}

#[derive(Default)]
struct PreviousDependencyChanges {
    any: bool,
    metadata: bool,
}

/// Returns the latest existing output from before this Cargo invocation.
fn previous_output_mtime<'a>(
    outputs: impl Iterator<Item = &'a PathBuf>,
    only_requires_rmeta: bool,
) -> Option<FileTime> {
    let mut latest = None;

    for output in outputs {
        if only_requires_rmeta
            && output.extension().and_then(|extension| extension.to_str()) != Some("rmeta")
        {
            continue;
        }

        let modified = paths::mtime(output).ok()?;
        latest = Some(latest.map_or(modified, |latest: FileTime| latest.max(modified)));
    }

    latest
}

/// Returns the oldest metadata generation that remains newer than every input.
///
/// Check units have no `.rlib`, so moving their metadata behind a build-script
/// output would make them stale again on every subsequent invocation.
fn restored_metadata_mtime(
    fingerprint: &Fingerprint,
    previous_mtime: FileTime,
) -> Option<FileTime> {
    let other_output_mtime = previous_output_mtime(
        fingerprint.outputs.iter().filter(|output| {
            output.extension().and_then(|extension| extension.to_str()) != Some("rmeta")
        }),
        false,
    );
    fingerprint
        .deps
        .iter()
        .try_fold(previous_mtime, |minimum_mtime, dependency| {
            dependency.previous_output_mtime().map(|dependency_mtime| {
                if other_output_mtime.is_some_and(|mtime| mtime >= dependency_mtime) {
                    minimum_mtime
                } else {
                    minimum_mtime.max(dependency_mtime)
                }
            })
        })
}

/// Keep skipped artifacts whose existing timestamp already satisfies their dependencies.
pub(super) fn can_preserve_skipped_output(fingerprint: &Fingerprint, output: &Path) -> bool {
    let Ok(mtime) = paths::mtime(output) else {
        return false;
    };
    match output.extension().and_then(|ext| ext.to_str()) {
        Some("rmeta") => restored_metadata_mtime(fingerprint, mtime) == Some(mtime),
        Some("rlib") => fingerprint.deps.iter().all(|dep| {
            dep.previous_output_mtime()
                .is_some_and(|required| required <= mtime)
        }),
        _ => false,
    }
}

/// Restores a metadata generation when its public semantics did not change.
fn preserve_metadata_generation(
    fingerprint: &Fingerprint,
    previous_metadata: Option<&(PathBuf, FileTime)>,
) {
    let Some((path, previous_mtime)) = previous_metadata else {
        return;
    };
    let Some(restored_mtime) = restored_metadata_mtime(fingerprint, *previous_mtime) else {
        debug!(
            "early_cutoff: unit {:?} cannot preserve metadata generation because a dependency output is unavailable",
            fingerprint.index
        );
        return;
    };

    if let Err(error) = filetime::set_file_mtime(path, restored_mtime) {
        debug!(
            "early_cutoff: unit {:?} could not preserve metadata generation for {:?}: {}",
            fingerprint.index, path, error
        );
    }
}

/// Detects dependencies rebuilt after this unit was last successfully built.
///
/// All jobs are prepared before any of them run, so these output mtimes still
/// describe the previous invocation even for dependencies about to rebuild.
fn previous_dependency_changes(fingerprint: &Fingerprint) -> PreviousDependencyChanges {
    let Some(parent_modified) = previous_output_mtime(fingerprint.outputs.iter(), false) else {
        return PreviousDependencyChanges {
            any: !fingerprint.deps.is_empty(),
            metadata: fingerprint
                .deps
                .iter()
                .any(|dependency| dependency.only_requires_rmeta),
        };
    };

    let mut changes = PreviousDependencyChanges::default();
    for dependency in &fingerprint.deps {
        let dependency_modified = dependency.previous_output_mtime();
        if dependency_modified.is_none_or(|modified| modified > parent_modified) {
            changes.any = true;
            changes.metadata |= dependency.only_requires_rmeta;
        }
    }

    changes
}

/// An unchanged crate-local API hash cannot hide changed metadata inherited
/// from a dependency, such as a newly available foreign trait implementation.
/// A pipelined check can finish before its dependency finalizes that metadata.
fn metadata_dependency_may_have_changed(fingerprint: &Fingerprint) -> bool {
    fingerprint
        .previously_changed_metadata_dependency
        .load(Ordering::Acquire)
        || fingerprint.deps.iter().any(|dependency| {
            dependency.only_requires_rmeta
                && matches!(
                    dependency.fingerprint.build_state(),
                    BuildState::Pending | BuildState::BuiltChanged
                )
        })
}

pub(super) fn read_public_api_hash(path: &Path) -> Option<PublicApiHash> {
    let bytes = paths::read_regular_bounded(path, 1024).ok()?;
    let hash: PublicApiHash = serde_json::from_slice(&bytes).ok()?;
    PublicApiHash::new(hash.version, &hash.value)
}

enum PublicApiHashUpdate {
    Preserve,
    Write(PublicApiHash),
    Remove,
}

/// Returns whether this unit can safely be reused after its dependencies'
/// metadata outputs are proven unchanged.
pub fn unit_can_use_early_cutoff(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    (matches!(unit.mode, CompileMode::Check { .. })
        || (unit.mode == CompileMode::Build && !unit.requires_upstream_objects()))
        && !unit.artifact.is_true()
        && unit_consumes_public_api_hash(build_runner, unit)
}

const RECHECK_DEPENDENT_LINKS: &str = "/dev/null/ohm-recheck-dependent-links";

/// Returns whether this unit can be split into codegen and reusable link steps.
///
/// The first prototype is intentionally limited to executable build and test
/// units. Other linkable crate types have more complicated downstream artifact
/// semantics and are left to future work. Terminal test executables still
/// consume their dependencies' public hashes without producing one themselves.
pub fn unit_can_use_relink_only(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> bool {
    !unit.artifact.is_true()
        && (matches!(unit.mode, CompileMode::Test | CompileMode::Doctest)
            || (unit.mode == CompileMode::Build && unit.target.is_bin()))
        && matches!(
            build_runner.lto[unit],
            super::lto::Lto::Off | super::lto::Lto::OnlyObject
        )
        && unit_consumes_public_api_hash(build_runner, unit)
}

fn is_early_cutoff_candidate(fingerprint: &Fingerprint, dirty_reason: &DirtyReason) -> bool {
    is_stale_due_to_dependency(fingerprint) && dirty_reason.is_dependency_only()
}

/// Returns whether this unit is stale only because one of its dependencies is
/// stale.
pub fn is_stale_due_to_dependency(fingerprint: &Fingerprint) -> bool {
    matches!(
        fingerprint.fs_status(),
        FsStatus::StaleDependency { .. } | FsStatus::StaleDepFingerprint { .. }
    )
}

/// Checks if early cutoff applies for a unit.
///
/// Early cutoff means: a dependency was rebuilt, but its output (.rmeta) didn't
/// change, so this unit doesn't need to be rebuilt.
///
/// Returns `true` if the unit can skip compilation due to early cutoff.
/// This only applies when:
/// 1. The unit was marked dirty due to a dependency (StaleDependency/StaleDepFingerprint)
/// 2. All dependencies have a `BuildState` that allows early cutoff
/// 3. At least one dependency was rebuilt with unchanged output
pub fn can_skip_due_to_early_cutoff(fingerprint: &Fingerprint) -> bool {
    if !fingerprint.is_early_cutoff_candidate() {
        debug!(
            "early_cutoff: unit {:?} is not a dependency-only candidate, cannot skip",
            fingerprint.index
        );
        return false;
    }

    let mut found_rebuilt_unchanged = false;

    for dep in &fingerprint.deps {
        let dep_build_state = dep.fingerprint.build_state.lock().unwrap();
        debug!(
            "early_cutoff: unit {:?} checking dep '{}' build_state={:?}",
            fingerprint.index, dep.name, &*dep_build_state
        );
        match &*dep_build_state {
            BuildState::BuiltUnchanged if !dep.only_requires_rmeta => {
                info!(
                    "early_cutoff: unit {:?} CANNOT skip - rebuilt dep '{}' requires its full artifact",
                    fingerprint.index, dep.name
                );
                return false;
            }
            BuildState::BuiltUnchanged | BuildState::SkippedEarlyCutoff => {
                found_rebuilt_unchanged = true;
            }
            BuildState::Fresh => {}
            BuildState::Pending | BuildState::BuiltChanged => {
                info!(
                    "early_cutoff: unit {:?} CANNOT skip - dep '{}' has build_state={:?}",
                    fingerprint.index, dep.name, &*dep_build_state
                );
                return false;
            }
        }
    }

    if found_rebuilt_unchanged {
        info!(
            "early_cutoff: unit {:?} CAN skip - all deps allow early cutoff",
            fingerprint.index
        );
    } else {
        debug!(
            "early_cutoff: unit {:?} cannot skip - no dep was rebuilt with unchanged output",
            fingerprint.index
        );
    }

    found_rebuilt_unchanged
}

/// Returns whether an integration test can reuse codegen after its unused library changed.
///
/// The caller separately verifies compiler-reported direct extern usage and rules out
/// transitive paths through cyclic development dependencies.
pub fn can_relink_unused_integration_dependency(
    fingerprint: &Fingerprint,
    unused_dependency: UnitIndex,
) -> bool {
    if !fingerprint.is_early_cutoff_candidate() {
        return false;
    }

    let mut found_unused_change = false;
    for dependency in &fingerprint.deps {
        match dependency.fingerprint.build_state() {
            BuildState::BuiltUnchanged | BuildState::BuiltChanged
                if dependency.fingerprint.index == unused_dependency =>
            {
                found_unused_change = true;
            }
            BuildState::Fresh => {}
            BuildState::Pending
            | BuildState::BuiltChanged
            | BuildState::BuiltUnchanged
            | BuildState::SkippedEarlyCutoff => return false,
        }
    }

    found_unused_change
}

/// Checks whether a dependency-only rebuild can reuse this unit's codegen and
/// run only its cached link step.
///
/// A dependency that was rebuilt with an unchanged public API hash is only
/// accepted when the caller has also established that its artifact is an
/// ordinary Rust library suitable for relinking. This prevents proc macros,
/// build scripts, and native-producing units from being mistaken for
/// link-only changes.
pub fn can_relink_due_to_early_cutoff(
    fingerprint: &Fingerprint,
    relinkable_dependencies: &HashSet<UnitIndex>,
) -> bool {
    if !fingerprint.is_early_cutoff_candidate() {
        return false;
    }

    let stale_link_dependency = match fingerprint.fs_status() {
        FsStatus::StaleDependency {
            unit,
            dep_mtime,
            max_mtime,
        } if dep_mtime > max_mtime && relinkable_dependencies.contains(&unit) => {
            Some((unit, max_mtime))
        }
        _ => None,
    };

    let mut found_relink_change = false;
    for dep in &fingerprint.deps {
        let dep_build_state = dep.fingerprint.build_state.lock().unwrap();
        match &*dep_build_state {
            BuildState::BuiltUnchanged
                if relinkable_dependencies.contains(&dep.fingerprint.index) =>
            {
                found_relink_change = true;
            }
            BuildState::SkippedEarlyCutoff => {
                // This dependency's own artifact is unchanged, but one of its
                // transitive link artifacts may have changed.
                found_relink_change = true;
            }
            BuildState::Fresh
                if stale_link_dependency.is_some_and(|(unit, root_mtime)| {
                    if unit != dep.fingerprint.index {
                        return false;
                    }

                    let dependency_status = dep.fingerprint.fs_status.lock().unwrap();
                    matches!(
                        &*dependency_status,
                        FsStatus::UpToDate {
                            mtimes,
                            link_mtime: Some(link_mtime),
                        } if *link_mtime > root_mtime
                            && mtimes
                                .iter()
                                .find(|(path, _)| {
                                    path.extension().and_then(|extension| extension.to_str())
                                        == Some("rmeta")
                                })
                                .is_some_and(|(_, metadata_mtime)| *metadata_mtime <= root_mtime)
                    )
                }) =>
            {
                // This ordinary library was already fresh at job preparation,
                // but a previously rebuilt transitive rlib is newer than the
                // executable. Its unchanged metadata proves cached frontend
                // results are still valid, so only linking must run again.
                found_relink_change = true;
            }
            BuildState::Fresh => {}
            BuildState::BuiltUnchanged | BuildState::Pending | BuildState::BuiltChanged => {
                return false;
            }
        }
    }

    found_relink_change
}

/// Result of comparing fingerprints between the current and previous builds.
enum FingerprintComparison {
    /// The unit does not need rebuilding.
    Fresh,
    /// The unit needs rebuilding.
    Dirty {
        /// The reason why the unit is dirty.
        reason: DirtyReason,
    },
}

/// Checks an existing unit without truncating, updating, or otherwise changing
/// its fingerprint. Registry build reuse must reject a stale candidate before
/// scheduling any compiler work; `prepare_target` is unsuitable here because
/// it intentionally clears a dirty fingerprint in preparation for a rebuild.
pub(crate) fn existing_unit_is_fresh(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
) -> CargoResult<bool> {
    let fingerprint_path = build_runner.files().fingerprint_file_path(unit, "");
    let fingerprint = calculate(build_runner, unit)?;
    Ok(matches!(
        _compare_old_fingerprint(&fingerprint_path, &fingerprint),
        Ok(FingerprintComparison::Fresh)
    ))
}

/// Whether an existing check root can keep its established dependency graph.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum ExistingCheckRoot {
    /// The root and its complete dependency graph are already up to date.
    Fresh,
    /// Workspace source or an existing dependency changed and must be rebuilt.
    WorkspaceChanged,
}

/// Validates an existing root without hiding the normal rebuild it still requires.
///
/// Missing artifacts and changed compiler options remain ineligible. A local
/// source edit is checked before dependencies, so callers must independently
/// validate registry units before preserving a dirty root's ordinary graph.
pub(crate) fn existing_check_root(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
) -> CargoResult<Option<ExistingCheckRoot>> {
    let fingerprint_path = build_runner.files().fingerprint_file_path(unit, "");
    let fingerprint = calculate(build_runner, unit)?;

    Ok(
        match _compare_old_fingerprint(&fingerprint_path, &fingerprint) {
            Ok(FingerprintComparison::Fresh) => Some(ExistingCheckRoot::Fresh),
            Ok(FingerprintComparison::Dirty {
                reason:
                    DirtyReason::FsStatusOutdated(
                        FsStatus::StaleItem(
                            StaleItem::ChangedFile { .. }
                            | StaleItem::ChangedChecksum { .. }
                            | StaleItem::FileSizeChanged { .. },
                        )
                        | FsStatus::StaleDependency { .. }
                        | FsStatus::StaleDepFingerprint { .. },
                    ),
            }) => Some(ExistingCheckRoot::WorkspaceChanged),
            _ => None,
        },
    )
}

/// Determines if a [`Unit`] is up-to-date, and if not prepares necessary work to
/// update the persisted fingerprint.
///
/// This function will inspect `Unit`, calculate a fingerprint for it, and then
/// return an appropriate [`Job`] to run. The returned `Job` will be a noop if
/// `unit` is considered "fresh", or if it was previously built and cached.
/// Otherwise the `Job` returned will write out the true fingerprint to the
/// filesystem, to be executed after the unit's work has completed.
///
/// The `force` flag is a way to force the `Job` to be "dirty", or always
/// update the fingerprint. **Beware using this flag** because it does not
/// transitively propagate throughout the dependency graph, it only forces this
/// one unit which is very unlikely to be what you want unless you're
/// exclusively talking about top-level units.
#[tracing::instrument(
    skip(build_runner, unit),
    fields(package_id = %unit.pkg.package_id(), target = unit.target.name())
)]
pub fn prepare_target(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
    force: bool,
) -> CargoResult<Job> {
    let bcx = build_runner.bcx;
    let loc = build_runner.files().fingerprint_file_path(unit, "");

    debug!("fingerprint at: {}", loc.display());

    // Figure out if this unit is up to date. After calculating the fingerprint
    // compare it to an old version, if any, and attempt to print diagnostic
    // information about failed comparisons to aid in debugging.
    let fingerprint = calculate(build_runner, unit)?;
    let mtime_on_use = build_runner.bcx.gctx.cli_unstable().mtime_on_use;
    let dirty_reason = match compare_old_fingerprint(unit, &loc, &*fingerprint, mtime_on_use, force)
    {
        FingerprintComparison::Fresh => None,
        FingerprintComparison::Dirty { reason } => Some(reason),
    };

    if dirty_reason.is_some() {
        build_runner.require_shared_cache_write_access(unit)?;
    }

    if let Some(logger) = bcx.logger {
        let index = bcx.unit_to_index[unit];
        let mut cause = None;
        let status = match dirty_reason.as_ref() {
            Some(reason) if reason.is_fresh_build() => util::log_message::FingerprintStatus::New,
            Some(reason) => {
                cause = Some(reason.clone());
                util::log_message::FingerprintStatus::Dirty
            }
            None => util::log_message::FingerprintStatus::Fresh,
        };
        logger.log(LogMessage::UnitFingerprint {
            index,
            status,
            cause,
        });
    }

    let Some(dirty_reason) = dirty_reason else {
        // Unit is already up-to-date, mark it as Fresh for early cutoff propagation
        debug!(
            "early_cutoff: unit {:?} is FRESH (already up-to-date)",
            fingerprint.index
        );
        fingerprint.set_build_state(BuildState::Fresh);
        return Ok(Job::new_fresh());
    };
    let previous_dependency_changes = if unit_consumes_public_api_hash(build_runner, unit)
        || fingerprint.ohm_worktree_namespace.is_some()
    {
        previous_dependency_changes(&fingerprint)
    } else {
        PreviousDependencyChanges::default()
    };
    fingerprint
        .previously_changed_metadata_dependency
        .store(previous_dependency_changes.metadata, Ordering::Release);
    let has_exclusive_metadata_access = unit_has_exclusive_metadata_access(build_runner, unit);
    fingerprint.set_early_cutoff_candidate(
        is_early_cutoff_candidate(&fingerprint, &dirty_reason)
            && !previous_dependency_changes.any
            && has_exclusive_metadata_access,
    );
    if fingerprint.ohm_worktree_namespace.is_some()
        && !fingerprint.must_recheck_native_link(unit)
        && !force
        && !unit.artifact.is_true()
        && !previous_dependency_changes.any
        && has_exclusive_metadata_access
    {
        // Retain the last successful identity before invalidating the on-disk
        // admission file. A late result check still has to verify every input.
        *fingerprint.worktree_reuse_hash.lock().unwrap() = paths::read(&loc)
            .ok()
            .filter(|hash| hash.len() == 16 && hash.bytes().all(|byte| byte.is_ascii_hexdigit()));
    }

    // We're going to rebuild, so ensure the source of the crate passes all
    // verification checks before we build it.
    //
    // The `Source::verify` method is intended to allow sources to execute
    // pre-build checks to ensure that the relevant source code is all
    // up-to-date and as expected. This is currently used primarily for
    // directory sources which will use this hook to perform an integrity check
    // on all files in the source to ensure they haven't changed. If they have
    // changed then an error is issued.
    let source_id = unit.pkg.package_id().source_id();
    let sources = bcx.packages.sources();
    let source = sources
        .get(source_id)
        .ok_or_else(|| internal("missing package source"))?;
    source.verify(unit.pkg.package_id())?;

    // Clear out the old fingerprint file if it exists. This protects when
    // compilation is interrupted leaving a corrupt file. For example, a
    // project with a lib.rs and integration test (two units):
    //
    // 1. Build the library and integration test.
    // 2. Make a change to lib.rs (NOT the integration test).
    // 3. Build the integration test, hit Ctrl-C while linking. With gcc, this
    //    will leave behind an incomplete executable (zero size, or partially
    //    written). NOTE: The library builds successfully, it is the linking
    //    of the integration test that we are interrupting.
    // 4. Build the integration test again.
    //
    // Without the following line, then step 3 will leave a valid fingerprint
    // on the disk. Then step 4 will think the integration test is "fresh"
    // because:
    //
    // - There is a valid fingerprint hash on disk (written in step 1).
    // - The mtime of the output file (the corrupt integration executable
    //   written in step 3) is newer than all of its dependencies.
    // - The mtime of the integration test fingerprint dep-info file (written
    //   in step 1) is newer than the integration test's source files, because
    //   we haven't modified any of its source files.
    //
    // But the executable is corrupt and needs to be rebuilt. Clearing the
    // fingerprint at step 3 ensures that Cargo never mistakes a partially
    // written output as up-to-date.
    if loc.exists() {
        // Truncate instead of delete so that compare_old_fingerprint will
        // still log the reason for the fingerprint failure instead of just
        // reporting "failed to read fingerprint" during the next build if
        // this build fails.
        paths::write(&loc, b"")?;
    }

    let public_api_hash_path = loc.with_extension("public-api-hash");
    let old_public_api_hash = read_public_api_hash(&public_api_hash_path);
    let previous_metadata = (unit_uses_public_api_hash(build_runner, unit)
        && has_exclusive_metadata_access)
        .then(|| {
            fingerprint
                .outputs
                .iter()
                .find(|output| {
                    output.extension().and_then(|extension| extension.to_str()) == Some("rmeta")
                })
                .and_then(|output| {
                    paths::mtime(output)
                        .ok()
                        .map(|mtime| (output.clone(), mtime))
                })
        })
        .flatten();

    let check_output_unchanged =
        move |state: &super::JobState<'_, '_>,
              fingerprint: &Arc<Fingerprint>,
              old_public_api_hash: &Option<PublicApiHash>| {
            if matches!(fingerprint.build_state(), BuildState::SkippedEarlyCutoff) {
                debug!(
                    "early_cutoff: unit {:?} was skipped; preserving its public API hash",
                    fingerprint.index
                );
                return PublicApiHashUpdate::Preserve;
            }

            let Some(new_public_api_hash) = state.public_api_hash() else {
                // A compiler without the expected hash field, or one that
                // emitted a malformed value, must never enable early cutoff.
                debug!(
                    "early_cutoff: unit {:?} received no valid public API hash from rustc",
                    fingerprint.index
                );
                fingerprint.set_build_state(BuildState::BuiltChanged);
                return PublicApiHashUpdate::Remove;
            };

            let unchanged_public_api_hash =
                old_public_api_hash.as_ref() == Some(&new_public_api_hash);
            if unchanged_public_api_hash && !metadata_dependency_may_have_changed(fingerprint) {
                preserve_metadata_generation(fingerprint, previous_metadata.as_ref());
                *fingerprint.fs_status.lock().unwrap() = FsStatus::OutputUnchanged {
                    unit: fingerprint.index,
                };
                fingerprint.set_build_state(BuildState::BuiltUnchanged);
                info!(
                    "early_cutoff: unit {:?} built with unchanged public API hash {}; dependents may skip",
                    fingerprint.index, new_public_api_hash
                );
            } else {
                fingerprint.set_build_state(BuildState::BuiltChanged);
                if unchanged_public_api_hash {
                    info!(
                        "early_cutoff: unit {:?} built with unchanged public API hash {}, but metadata dependency may have changed; dependents must rebuild",
                        fingerprint.index, new_public_api_hash
                    );
                } else {
                    info!(
                        "early_cutoff: unit {:?} built with changed public API hash (old={:?}, new={}); dependents must rebuild",
                        fingerprint.index, old_public_api_hash, new_public_api_hash
                    );
                }
            }
            PublicApiHashUpdate::Write(new_public_api_hash)
        };

    let write_fingerprint = if unit.mode.is_run_custom_build() {
        // For build scripts the `local` field of the fingerprint may change
        // while we're executing it. For example it could be in the legacy
        // "consider everything a dependency mode" and then we switch to "deps
        // are explicitly specified" mode.
        //
        // To handle this movement we need to regenerate the `local` field of a
        // build script's fingerprint after it's executed. We do this by
        // using the `build_script_local_fingerprints` function which returns a
        // thunk we can invoke on a foreign thread to calculate this.
        let build_script_outputs = Arc::clone(&build_runner.build_script_outputs);
        let metadata = build_runner.get_run_build_script_metadata(unit);
        let (gen_local, _overridden) = build_script_local_fingerprints(build_runner, unit)?;
        let output_path = build_runner.build_explicit_deps[unit]
            .build_script_output
            .clone();
        let result_paths = super::unit_worktree_seed_namespace(build_runner, unit).map(|_| {
            let out_dir = if build_runner.bcx.gctx.cli_unstable().build_dir_new_layout {
                build_runner.files().out_dir_new_layout(unit)
            } else {
                build_runner.files().build_script_out_dir(unit)
            };
            (build_runner.files().fingerprint_dir(unit), out_dir)
        });
        Work::new(move |state| {
            let outputs = build_script_outputs.lock().unwrap();
            let output = outputs
                .get(metadata)
                .expect("output must exist after running");
            let deps = BuildDeps::new(&output_path, Some(output));

            // FIXME: it's basically buggy that we pass `None` to `call_box`
            // here. See documentation on `build_script_local_fingerprints`
            // below for more information. Despite this just try to proceed and
            // hobble along if it happens to return `Some`.
            if let Some(new_local) = (gen_local)(&deps, None)? {
                *fingerprint.local.lock().unwrap() = new_local;
            }

            if let Some((directory, out_dir)) = &result_paths {
                let mut result = fingerprint.script_result.lock().unwrap();
                *result = worktree::record_script_result(
                    &directory.join(OHM_WORKTREE_SCRIPT_RESULT),
                    &output_path,
                    out_dir,
                    output,
                    result.as_ref(),
                )?;
            }

            // Check if output changed and update fs_status
            let public_api_hash_update =
                check_output_unchanged(state, &fingerprint, &old_public_api_hash);
            write_fingerprint_and_public_api_hash(
                &loc,
                &fingerprint,
                &public_api_hash_path,
                public_api_hash_update,
            )?;
            if let Some((directory, _)) = result_paths {
                let rerun = directory.join(OHM_WORKTREE_SCRIPT_RERUN);
                if rerun.symlink_metadata().is_ok() {
                    paths::remove_file(&rerun)?;
                }
            }
            Ok(())
        })
    } else {
        Work::new(move |state| {
            // Check if output changed and update fs_status
            let public_api_hash_update =
                check_output_unchanged(state, &fingerprint, &old_public_api_hash);
            write_fingerprint_and_public_api_hash(
                &loc,
                &fingerprint,
                &public_api_hash_path,
                public_api_hash_update,
            )
        })
    };

    Ok(Job::new_dirty(write_fingerprint, dirty_reason))
}

/// Dependency edge information for fingerprints. This is generated for each
/// dependency and is stored in a [`Fingerprint`].
#[derive(Clone)]
struct DepFingerprint {
    /// The hash of the package id that this dependency points to
    pkg_id: u64,
    /// The crate name we're using for this dependency, which if we change we'll
    /// need to recompile!
    name: InternedString,
    /// Whether or not this dependency is flagged as a public dependency or not.
    public: bool,
    /// Whether or not this dependency is an rmeta dependency or a "full"
    /// dependency. In the case of an rmeta dependency our dependency edge only
    /// actually requires the rmeta from what we depend on, so when checking
    /// mtime information all files other than the rmeta can be ignored.
    only_requires_rmeta: bool,
    /// The dependency's fingerprint we recursively point to, containing all the
    /// other hash information we'd otherwise need.
    fingerprint: Arc<Fingerprint>,
}

/// A fingerprint can be considered to be a "short string" representing the
/// state of a world for a package.
///
/// If a fingerprint ever changes, then the package itself needs to be
/// recompiled. Inputs to the fingerprint include source code modifications,
/// compiler flags, compiler version, etc. This structure is not simply a
/// `String` due to the fact that some fingerprints cannot be calculated lazily.
///
/// Path sources, for example, use the mtime of the corresponding dep-info file
/// as a fingerprint (all source files must be modified *before* this mtime).
/// This dep-info file is not generated, however, until after the crate is
/// compiled. As a result, this structure can be thought of as a fingerprint
/// to-be. The actual value can be calculated via [`hash_u64()`], but the operation
/// may fail as some files may not have been generated.
///
/// Note that dependencies are taken into account for fingerprints because rustc
/// requires that whenever an upstream crate is recompiled that all downstream
/// dependents are also recompiled. This is typically tracked through
/// [`DependencyQueue`], but it also needs to be retained here because Cargo can
/// be interrupted while executing, losing the state of the [`DependencyQueue`]
/// graph.
///
/// [`hash_u64()`]: crate::compiler::fingerprint::Fingerprint::hash_u64
/// [`DependencyQueue`]: crate::util::DependencyQueue
#[derive(Serialize, Deserialize)]
pub struct Fingerprint {
    /// Hash of the version of `rustc` used.
    rustc: u64,
    /// Sorted list of cfg features enabled.
    features: String,
    /// Sorted list of all the declared cfg features.
    declared_features: String,
    /// Hash of the `Target` struct, including the target name,
    /// package-relative source path, edition, etc.
    target: u64,
    /// Hash of the [`Profile`], [`CompileMode`], and any extra flags passed via
    /// `cargo rustc` or `cargo rustdoc`.
    ///
    /// [`Profile`]: crate::workspace::profiles::Profile
    /// [`CompileMode`]: crate::compiler::CompileMode
    profile: u64,
    /// Hash of the path to the base source file. This is relative to the
    /// workspace root for path members, or absolute for other sources.
    path: u64,
    /// Fingerprints of dependencies.
    deps: Vec<DepFingerprint>,
    /// Information about the inputs that affect this Unit (such as source
    /// file mtimes or build script environment variables).
    local: Mutex<Vec<LocalFingerprint>>,
    /// Build-root-relative private namespace used only to normalize dep-info
    /// identity. Filesystem checks must keep using the original paths above.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    ohm_worktree_namespace: Option<PathBuf>,
    /// Cached hash of the [`Fingerprint`] struct. Used to improve performance
    /// for hashing.
    #[serde(skip)]
    memoized_hash: Mutex<Option<MemoizedHash>>,
    /// A script's result is used by dependents, while its action hash still
    /// determines whether the script itself must run.
    #[serde(skip)]
    script_result: Mutex<Option<ScriptResult>>,
    /// The last successful compilation, retained for revalidation after scripts run.
    #[serde(skip)]
    worktree_reuse_hash: Mutex<Option<String>>,
    /// Late reuse proved all inputs unchanged, including transitive link artifacts.
    /// Ordinary metadata-only early cutoff does not provide this guarantee.
    #[serde(skip)]
    worktree_reused: AtomicBool,
    /// RUSTFLAGS/RUSTDOCFLAGS environment variable value (or config value).
    rustflags: Vec<String>,
    /// Hash of various config settings that change how things are compiled.
    config: u64,
    /// The rustc target. This is only relevant for `.json` files, otherwise
    /// the metadata hash segregates the units.
    compile_kind: u64,
    /// Unit index for this fingerprint, used for tracing cascading rebuilds.
    /// Not persisted to disk as indices can change between builds.
    #[serde(skip)]
    index: UnitIndex,
    /// Description of whether the filesystem status for this unit is up to date
    /// or should be considered stale. Uses a Mutex for interior mutability so
    /// that it can be updated after builds complete (e.g., to mark as
    /// OutputUnchanged if the output hash didn't change).
    #[serde(skip)]
    fs_status: Mutex<FsStatus>,
    /// Tracks the build state during the current build session.
    /// Used for early cutoff propagation through the dependency graph.
    #[serde(skip)]
    build_state: Mutex<BuildState>,
    /// Whether this unit or a dependency reused assembly that still requires native link checks.
    #[serde(skip)]
    recheck_dependent_links: AtomicBool,
    /// Whether a cached doctest was fresh before scheduling its final native link.
    #[serde(skip)]
    fresh_doctest_inputs: bool,
    /// Whether a procedural macro read foreign span data during the previous compile.
    #[serde(skip)]
    observes_foreign_span: bool,
    /// Whether the unit is dirty only because one of its dependencies changed.
    #[serde(skip)]
    early_cutoff_candidate: AtomicBool,
    /// Whether metadata used by this unit had already changed in an earlier
    /// Cargo invocation before its current dependencies were prepared.
    #[serde(skip)]
    previously_changed_metadata_dependency: AtomicBool,
    /// Files, relative to `target_root`, that are produced by the step that
    /// this `Fingerprint` represents. This is used to detect when the whole
    /// fingerprint is out of date if this is missing, or if previous
    /// fingerprints output files are regenerated and look newer than this one.
    #[serde(skip)]
    outputs: Vec<PathBuf>,
}

struct MemoizedHash {
    value: u64,
    /// The short file matched this value under exclusive metadata access.
    /// The first comparison consumes it, and clearing the hash discards it.
    matched_on_disk: bool,
}

impl MemoizedHash {
    fn new(value: u64) -> Self {
        Self {
            value,
            matched_on_disk: false,
        }
    }
}

/// Indication of the status on the filesystem for a particular unit.
#[derive(Clone, Default, Debug, Serialize, Deserialize)]
#[serde(tag = "fs_status", rename_all = "kebab-case")]
pub enum FsStatus {
    /// This unit is to be considered stale, even if hash information all
    /// matches.
    #[default]
    Stale,

    /// File system inputs have changed (or are missing), or there were
    /// changes to the environment variables that affect this unit. See
    /// the variants of [`StaleItem`] for more information.
    StaleItem(StaleItem),

    /// A dependency was stale.
    StaleDependency {
        unit: UnitIndex,
        #[serde(with = "serde_file_time")]
        dep_mtime: FileTime,
        #[serde(with = "serde_file_time")]
        max_mtime: FileTime,
    },

    /// A dependency's fingerprint was stale.
    StaleDepFingerprint { unit: UnitIndex },

    /// This unit was rebuilt, but rustc reported an unchanged public API hash.
    /// Dependents should not be marked dirty due to this dependency.
    OutputUnchanged { unit: UnitIndex },

    /// This unit is up-to-date. All outputs and their corresponding mtime are
    /// listed in the payload here for other dependencies to compare against.
    #[serde(skip)]
    UpToDate {
        mtimes: HashMap<PathBuf, FileTime>,
        /// Newest linkable input reachable through metadata-only dependencies.
        #[serde(skip)]
        link_mtime: Option<FileTime>,
    },
}

impl FsStatus {
    fn up_to_date(&self) -> bool {
        match self {
            FsStatus::UpToDate { .. } => true,
            // OutputUnchanged means the unit was rebuilt but output didn't change,
            // so dependents can treat it as up-to-date.
            FsStatus::OutputUnchanged { .. } => true,
            FsStatus::Stale
            | FsStatus::StaleItem(_)
            | FsStatus::StaleDependency { .. }
            | FsStatus::StaleDepFingerprint { .. } => false,
        }
    }
}

/// Tracks the build state of a unit during a build session.
///
/// This is separate from [`FsStatus`] which tracks *why* something is stale.
/// `BuildState` tracks *what happened* during the current build session,
/// which is needed for early cutoff to propagate correctly through the
/// dependency graph.
#[derive(Clone, Debug, Default)]
pub enum BuildState {
    /// Not yet processed in this build session.
    #[default]
    Pending,
    /// Compiled and output changed - dependents must rebuild.
    BuiltChanged,
    /// Compiled but output unchanged - dependents can skip via early cutoff.
    BuiltUnchanged,
    /// Skipped due to early cutoff - treat same as `BuiltUnchanged` for dependents.
    SkippedEarlyCutoff,
    /// Was already up-to-date, no rebuild needed.
    Fresh,
}

impl BuildState {
    /// Returns true if dependents can potentially skip rebuilding due to early cutoff.
    pub fn allows_early_cutoff(&self) -> bool {
        match self {
            BuildState::BuiltUnchanged | BuildState::SkippedEarlyCutoff | BuildState::Fresh => true,
            BuildState::Pending | BuildState::BuiltChanged => false,
        }
    }

    /// Returns true if this unit was rebuilt with unchanged output.
    pub fn is_rebuilt_unchanged(&self) -> bool {
        match self {
            BuildState::BuiltUnchanged | BuildState::SkippedEarlyCutoff => true,
            BuildState::Pending | BuildState::BuiltChanged | BuildState::Fresh => false,
        }
    }
}

mod serde_file_time {
    use filetime::FileTime;
    use serde::Deserialize;
    use serde::Serialize;

    /// Serialize FileTime as milliseconds with nano.
    pub(super) fn serialize<S>(ft: &FileTime, s: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let secs_as_millis = ft.unix_seconds() as f64 * 1000.0;
        let nanos_as_millis = ft.nanoseconds() as f64 / 1_000_000.0;
        (secs_as_millis + nanos_as_millis).serialize(s)
    }

    /// Deserialize FileTime from milliseconds with nano.
    pub(super) fn deserialize<'de, D>(d: D) -> Result<FileTime, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let millis = f64::deserialize(d)?;
        let secs = (millis / 1000.0) as i64;
        let nanos = ((millis % 1000.0) * 1_000_000.0) as u32;
        Ok(FileTime::from_unix_time(secs, nanos))
    }
}

impl Serialize for DepFingerprint {
    fn serialize<S>(&self, ser: S) -> Result<S::Ok, S::Error>
    where
        S: ser::Serializer,
    {
        (
            &self.pkg_id,
            &self.name,
            &self.public,
            &self.dependency_hash(),
        )
            .serialize(ser)
    }
}

impl<'de> Deserialize<'de> for DepFingerprint {
    fn deserialize<D>(d: D) -> Result<DepFingerprint, D::Error>
    where
        D: de::Deserializer<'de>,
    {
        let (pkg_id, name, public, hash) = <(u64, String, bool, u64)>::deserialize(d)?;
        Ok(DepFingerprint {
            pkg_id,
            name: name.into(),
            public,
            fingerprint: Arc::new(Fingerprint {
                memoized_hash: Mutex::new(Some(MemoizedHash::new(hash))),
                ..Fingerprint::new()
            }),
            // This field is never read since it's only used in
            // `check_filesystem` which isn't used by fingerprints loaded from
            // disk.
            only_requires_rmeta: false,
        })
    }
}

/// A `LocalFingerprint` represents something that we use to detect direct
/// changes to a `Fingerprint`.
///
/// This is where we track file information, env vars, etc. This
/// `LocalFingerprint` struct is hashed and if the hash changes will force a
/// recompile of any fingerprint it's included into. Note that the "local"
/// terminology comes from the fact that it only has to do with one crate, and
/// `Fingerprint` tracks the transitive propagation of fingerprint changes.
///
/// Note that because this is hashed its contents are carefully managed. Like
/// mentioned in the above module docs, we don't want to hash absolute paths or
/// mtime information.
///
/// Also note that a `LocalFingerprint` is used in `check_filesystem` to detect
/// when the filesystem contains stale information (based on mtime currently).
/// The paths here don't change much between compilations but they're used as
/// inputs when we probe the filesystem looking at information.
#[derive(Clone, Debug, Serialize, Deserialize, Hash)]
enum LocalFingerprint {
    /// This is a precalculated fingerprint which has an opaque string we just
    /// hash as usual. This variant is primarily used for rustdoc where we
    /// don't have a dep-info file to compare against.
    ///
    /// This is also used for build scripts with no `rerun-if-*` statements, but
    /// that's overall a mistake and causes bugs in Cargo. We shouldn't use this
    /// for build scripts.
    Precalculated(String),

    /// This is used for crate compilations. The `dep_info` file is a relative
    /// path anchored at `target_root(...)` to the dep-info file that Cargo
    /// generates (which is a custom serialization after parsing rustc's own
    /// `dep-info` output).
    ///
    /// The `dep_info` file, when present, also lists a number of other files
    /// for us to look at. If any of those files are newer than this file then
    /// we need to recompile.
    ///
    /// If the `checksum` bool is true then the `dep_info` file is expected to
    /// contain file checksums instead of file mtimes.
    CheckDepInfo { dep_info: PathBuf, checksum: bool },

    /// This represents a nonempty set of `rerun-if-changed` annotations printed
    /// out by a build script. The `output` file is a relative file anchored at
    /// `target_root(...)` which is the actual output of the build script. That
    /// output has already been parsed and the paths printed out via
    /// `rerun-if-changed` are listed in `paths`. The `paths` field is relative
    /// to `pkg.root()`
    ///
    /// This is considered up-to-date if all of the `paths` are older than
    /// `output`, otherwise we need to recompile.
    RerunIfChanged {
        output: PathBuf,
        paths: Vec<PathBuf>,
    },

    /// This represents a single `rerun-if-env-changed` annotation printed by a
    /// build script. The exact env var and value are hashed here. There's no
    /// filesystem dependence here, and if the values are changed the hash will
    /// change forcing a recompile.
    RerunIfEnvChanged { var: String, val: BuildEnvValue },
}

/// A build script can observe native environment bytes that are not UTF-8.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(untagged)]
enum BuildEnvValue {
    Bytes(Vec<u8>),
    Text(String),
    // The old JSON null and Option::None hash also covered every non-Unicode value.
    // Use a new representation and discriminant so Cargo can discard those records.
    Unset {},
}

impl BuildEnvValue {
    fn diagnostic_value(&self) -> Option<String> {
        match self {
            Self::Text(text) => Some(text.clone()),
            Self::Bytes(bytes) => Some(format!("0x{}", hex::encode(bytes))),
            Self::Unset {} => None,
        }
    }
}

#[test]
fn build_env_value_invalidates_legacy_null() {
    let unset = BuildEnvValue::Unset {};
    assert_ne!(util::hash_u64(&unset), util::hash_u64(None::<String>));
    assert!(serde_json::from_str::<BuildEnvValue>("null").is_err());

    let encoded = serde_json::to_string(&unset).unwrap();
    assert_eq!(
        serde_json::from_str::<BuildEnvValue>(&encoded).unwrap(),
        unset
    );
}

/// See [`FsStatus::StaleItem`].
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "stale_item", rename_all = "kebab-case")]
pub enum StaleItem {
    MissingFile {
        path: PathBuf,
    },
    UnableToReadFile {
        path: PathBuf,
    },
    FailedToReadMetadata {
        path: PathBuf,
    },
    FileSizeChanged {
        path: PathBuf,
        old_size: u64,
        new_size: u64,
    },
    ChangedFile {
        reference: PathBuf,
        #[serde(with = "serde_file_time")]
        reference_mtime: FileTime,
        stale: PathBuf,
        #[serde(with = "serde_file_time")]
        stale_mtime: FileTime,
    },
    ChangedChecksum {
        source: PathBuf,
        stored_checksum: Checksum,
        new_checksum: Checksum,
    },
    MissingChecksum {
        path: PathBuf,
    },
    ChangedEnv {
        var: String,
        previous: Option<String>,
        current: Option<String>,
    },
}

impl LocalFingerprint {
    /// Read the environment variable of the given env `key`, and creates a new
    /// [`LocalFingerprint::RerunIfEnvChanged`] for it. The `env_config` is used firstly
    /// to check if the env var is set in the config system as some envs need to be overridden.
    /// Otherwise it reads the value inherited by Cargo.
    ///
    // TODO: Reading the process environment is allowed at this moment. Should figure out
    // if it makes sense if permitting to read env from the env snapshot.
    #[allow(clippy::disallowed_methods)]
    fn from_env<K: AsRef<str>>(
        key: K,
        env_config: &Arc<HashMap<String, OsString>>,
    ) -> LocalFingerprint {
        let key = key.as_ref();
        let var = key.to_owned();
        let val = env_config.get(key).cloned().or_else(|| env::var_os(key));
        let val = match val.map(OsString::into_string) {
            Some(Ok(text)) => BuildEnvValue::Text(text),
            Some(Err(value)) => BuildEnvValue::Bytes(value.into_encoded_bytes()),
            None => BuildEnvValue::Unset {},
        };
        LocalFingerprint::RerunIfEnvChanged { var, val }
    }

    /// Checks dynamically at runtime if this `LocalFingerprint` has a stale
    /// item inside of it.
    ///
    /// The main purpose of this function is to handle two different ways
    /// fingerprints can be invalidated:
    ///
    /// * One is a dependency listed in rustc's dep-info files is invalid. Note
    ///   that these could either be env vars or files. We check both here.
    ///
    /// * Another is the `rerun-if-changed` directive from build scripts. This
    ///   is where we'll find whether files have actually changed
    fn find_stale_item(
        &self,
        mtime_cache: &mut HashMap<PathBuf, FileTime>,
        checksum_cache: &mut HashMap<PathBuf, Checksum>,
        pkg: &Package,
        build_root: &Path,
        cargo_exe: &Path,
        gctx: &GlobalContext,
        worktree_seed: bool,
        checksum_parallelism: ChecksumParallelism<'_>,
        observes_foreign_span: &mut bool,
        recheck_dependent_links: &mut bool,
    ) -> CargoResult<Option<StaleItem>> {
        let pkg_root = pkg.root();
        match self {
            // We need to parse `dep_info`, learn about the crate's dependencies.
            //
            // For each env var we see if our current process's env var still
            // matches, and for each file we see if any of them are newer than
            // the `dep_info` file itself whose mtime represents the start of
            // rustc.
            LocalFingerprint::CheckDepInfo { dep_info, checksum } => {
                let dep_info = build_root.join(dep_info);
                let Some(info) = parse_dep_info(pkg_root, build_root, &dep_info)? else {
                    return Ok(Some(StaleItem::MissingFile { path: dep_info }));
                };
                *recheck_dependent_links |= info.recheck_dependent_links;
                if let Some(path) = info.foreign_span_marker {
                    *observes_foreign_span = true;
                    return Ok(Some(StaleItem::MissingFile { path }));
                }
                for (key, previous) in info.env.iter() {
                    let manifest_value = pkg.manifest().metadata().env_var(key);
                    let current = if let Some(value) = manifest_value.as_deref() {
                        Some(OsStr::new(value))
                    } else if worktree_seed && key == "CARGO_MANIFEST_DIR" {
                        Some(pkg.root().as_os_str())
                    } else if worktree_seed && key == "CARGO_MANIFEST_PATH" {
                        Some(pkg.manifest_path().as_os_str())
                    } else if key == CARGO_ENV {
                        Some(cargo_exe.as_os_str())
                    } else {
                        gctx.env_config()?
                            .get(key)
                            .map(OsString::as_os_str)
                            .or_else(|| gctx.get_env_os(key))
                    };
                    if current == previous.as_deref().map(OsStr::new) {
                        continue;
                    }
                    return Ok(Some(StaleItem::ChangedEnv {
                        var: key.clone(),
                        previous: previous.clone(),
                        current: current.map(|value| value.to_string_lossy().into_owned()),
                    }));
                }
                if *checksum {
                    Ok(find_stale_file_with_parallelism(
                        mtime_cache,
                        checksum_cache,
                        &dep_info,
                        info.files.iter().map(|(file, checksum)| (file, *checksum)),
                        true,
                        Some(checksum_parallelism),
                    ))
                } else {
                    Ok(find_stale_file(
                        mtime_cache,
                        checksum_cache,
                        &dep_info,
                        info.files.into_keys().map(|p| (p, None)),
                        *checksum,
                    ))
                }
            }

            // We need to verify that no paths listed in `paths` are newer than
            // the `output` path itself, or the last time the build script ran.
            LocalFingerprint::RerunIfChanged { output, paths } => Ok(find_stale_file(
                mtime_cache,
                checksum_cache,
                &build_root.join(output),
                paths.iter().map(|p| (pkg_root.join(p), None)),
                false,
            )),

            // These have no dependencies on the filesystem, and their values
            // are included natively in the `Fingerprint` hash so nothing
            // tocheck for here.
            LocalFingerprint::RerunIfEnvChanged { .. } => Ok(None),
            LocalFingerprint::Precalculated(..) => Ok(None),
        }
    }

    fn kind(&self) -> &'static str {
        match self {
            LocalFingerprint::Precalculated(..) => "precalculated",
            LocalFingerprint::CheckDepInfo { .. } => "dep-info",
            LocalFingerprint::RerunIfChanged { .. } => "rerun-if-changed",
            LocalFingerprint::RerunIfEnvChanged { .. } => "rerun-if-env-changed",
        }
    }
}

impl Fingerprint {
    /// Rechecks files rustc read after prerequisites have had a chance to rewrite them.
    pub(super) fn dep_info_files_are_fresh(&self, pkg_root: &Path, build_root: &Path) -> bool {
        // Preparation-time caches may still describe the previous contents.
        let mut mtimes = HashMap::default();
        let mut checksums = HashMap::default();
        let local = self.local.lock().unwrap();
        !local.is_empty()
            && local.iter().all(|local| {
                let LocalFingerprint::CheckDepInfo {
                    dep_info,
                    checksum: true,
                } = local
                else {
                    return false;
                };
                let dep_info = build_root.join(dep_info);
                let Ok(Some(info)) = parse_dep_info(pkg_root, build_root, &dep_info) else {
                    return false;
                };
                !info.files.is_empty()
                    && find_stale_file(
                        &mut mtimes,
                        &mut checksums,
                        &dep_info,
                        info.files.iter().map(|(path, checksum)| (path, *checksum)),
                        true,
                    )
                    .is_none()
            })
    }

    fn new() -> Fingerprint {
        Fingerprint {
            rustc: 0,
            target: 0,
            profile: 0,
            path: 0,
            features: String::new(),
            declared_features: String::new(),
            deps: Vec::new(),
            local: Mutex::new(Vec::new()),
            ohm_worktree_namespace: None,
            memoized_hash: Mutex::new(None),
            script_result: Mutex::new(None),
            worktree_reuse_hash: Mutex::new(None),
            worktree_reused: AtomicBool::new(false),
            rustflags: Vec::new(),
            config: 0,
            compile_kind: 0,
            index: UnitIndex::default(),
            fs_status: Mutex::new(FsStatus::Stale),
            build_state: Mutex::new(BuildState::Pending),
            recheck_dependent_links: AtomicBool::new(false),
            fresh_doctest_inputs: false,
            observes_foreign_span: false,
            early_cutoff_candidate: AtomicBool::new(false),
            previously_changed_metadata_dependency: AtomicBool::new(false),
            outputs: Vec::new(),
        }
    }

    /// For performance reasons fingerprints will memoize their own hash, but
    /// there's also internal mutability with its `local` field which can
    /// change, for example with build scripts, during a build.
    ///
    /// This method can be used to bust all memoized hashes just before a build
    /// to ensure that after a build completes everything is up-to-date.
    pub fn clear_memoized(&self) {
        *self.memoized_hash.lock().unwrap() = None;
    }

    /// Returns a copy of the current filesystem status for debugging purposes.
    pub fn fs_status(&self) -> FsStatus {
        self.fs_status.lock().unwrap().clone()
    }

    /// Returns a copy of the current build state.
    pub fn build_state(&self) -> BuildState {
        self.build_state.lock().unwrap().clone()
    }

    /// Sets the build state for this fingerprint.
    pub fn set_build_state(&self, state: BuildState) {
        *self.build_state.lock().unwrap() = state;
    }

    /// Records full input revalidation separately from metadata-only early cutoff.
    pub(super) fn mark_worktree_reused(&self) {
        self.worktree_reused.store(true, Ordering::Release);
        self.set_build_state(BuildState::SkippedEarlyCutoff);
    }

    /// Native links can read inputs that are absent from an upstream rlib's dep-info.
    fn must_recheck_native_link(&self, unit: &Unit) -> bool {
        // A doctest can link an unbundled native archive from a dependency's
        // link attribute without any Cargo rerun-if-changed declaration.
        unit.mode.is_doc_test()
            || (self.recheck_dependent_links.load(Ordering::Acquire)
                && matches!(unit.mode, CompileMode::Build | CompileMode::Test)
                && unit.requires_upstream_objects())
    }

    /// Custom compilers and wrappers retain their ordinary compilation behavior.
    pub(super) fn native_recheck_can_reuse_codegen(
        &self,
        build_runner: &BuildRunner<'_, '_>,
        unit: &Unit,
    ) -> bool {
        self.must_recheck_native_link(unit)
            && build_runner.bcx.build_config.primary_unit_rustc.is_none()
            && build_runner.bcx.rustc().wrapper.is_none()
            && build_runner.bcx.rustc().workspace_wrapper.is_none()
    }

    /// Read completed prerequisites too, since their first dep-info may arrive after scheduling.
    pub(super) fn needs_native_link_driver(&self) -> bool {
        self.recheck_dependent_links.load(Ordering::Acquire)
            || self.deps.iter().any(|dep| {
                dep.fingerprint
                    .recheck_dependent_links
                    .load(Ordering::Acquire)
            })
    }

    /// An intermediate job can finish with early metadata before a leaf reports its marker.
    /// Traverse the completed graph before reusing a seeded executable without invoking rustc.
    fn inherited_native_recheck(&self) -> bool {
        let mut pending = vec![self];
        let mut seen = HashSet::default();
        while let Some(fp) = pending.pop() {
            if seen.insert(fp.index) {
                if fp.recheck_dependent_links.load(Ordering::Acquire) {
                    return true;
                }
                pending.extend(fp.deps.iter().map(|dep| dep.fingerprint.as_ref()));
            }
        }
        false
    }

    pub(super) fn record_native_link_inputs(&self, marked: bool) {
        if marked || self.needs_native_link_driver() {
            self.recheck_dependent_links.store(true, Ordering::Release);
        }
    }

    /// Dependencies may have rebuilt since the doctest's inputs were checked.
    pub(super) fn can_reuse_doctest_codegen(&self) -> bool {
        self.fresh_doctest_inputs
            && self
                .deps
                .iter()
                .all(|dep| matches!(dep.fingerprint.build_state(), BuildState::Fresh))
    }

    /// These compilers can read bytes that are absent from the public dependency metadata.
    pub(super) fn observes_foreign_span(&self) -> bool {
        self.observes_foreign_span
    }

    /// Returns whether this unit is dirty only because of its dependencies.
    pub fn is_early_cutoff_candidate(&self) -> bool {
        self.early_cutoff_candidate.load(Ordering::Acquire)
    }

    /// Records whether this unit is dirty only because of its dependencies.
    fn set_early_cutoff_candidate(&self, candidate: bool) {
        self.early_cutoff_candidate
            .store(candidate, Ordering::Release);
    }

    fn hash_u64(&self) -> u64 {
        if let Some(cached) = self.memoized_hash.lock().unwrap().as_ref() {
            return cached.value;
        }
        let ret = util::hash_u64(self);
        *self.memoized_hash.lock().unwrap() = Some(MemoizedHash::new(ret));
        ret
    }

    /// Removes only this worktree's namespace from dep-info identity. A cloned
    /// fingerprint still describes the same profile, compiler, package and unit,
    /// while its actual dep-info file lives under the recipient's namespace.
    fn local_identity<'a>(&self, local: &'a [LocalFingerprint]) -> Cow<'a, [LocalFingerprint]> {
        let Some(namespace) = &self.ohm_worktree_namespace else {
            return Cow::Borrowed(local);
        };
        let mut normalized = local.to_vec();
        for local in &mut normalized {
            if let LocalFingerprint::CheckDepInfo { dep_info, .. } = local
                && let Ok(relative) = dep_info.strip_prefix(namespace)
            {
                *dep_info = namespace.with_file_name("$ohm-workspace").join(relative);
            }
        }
        Cow::Owned(normalized)
    }

    /// Compares this fingerprint with an old version which was previously
    /// serialized to filesystem.
    ///
    /// The purpose of this is exclusively to produce a diagnostic message
    /// [`DirtyReason`], indicating why we're recompiling something.
    fn compare(&self, old: &Fingerprint) -> DirtyReason {
        if self.rustc != old.rustc {
            return DirtyReason::RustcChanged;
        }
        if self.features != old.features {
            return DirtyReason::FeaturesChanged {
                old: old.features.clone(),
                new: self.features.clone(),
            };
        }
        if self.declared_features != old.declared_features {
            return DirtyReason::DeclaredFeaturesChanged {
                old: old.declared_features.clone(),
                new: self.declared_features.clone(),
            };
        }
        if self.target != old.target {
            return DirtyReason::TargetConfigurationChanged;
        }
        if self.path != old.path {
            return DirtyReason::PathToSourceChanged;
        }
        if self.profile != old.profile {
            return DirtyReason::ProfileConfigurationChanged;
        }
        if self.rustflags != old.rustflags {
            return DirtyReason::RustflagsChanged {
                old: old.rustflags.clone(),
                new: self.rustflags.clone(),
            };
        }
        if self.config != old.config {
            return DirtyReason::ConfigSettingsChanged;
        }
        if self.compile_kind != old.compile_kind {
            return DirtyReason::CompileKindChanged;
        }
        let my_local = self.local.lock().unwrap();
        let old_local = old.local.lock().unwrap();
        let my_local = self.local_identity(&my_local);
        let old_local = old.local_identity(&old_local);
        if my_local.len() != old_local.len() {
            return DirtyReason::LocalLengthsChanged;
        }
        for (new, old) in my_local.iter().zip(old_local.iter()) {
            match (new, old) {
                (LocalFingerprint::Precalculated(a), LocalFingerprint::Precalculated(b)) => {
                    if a != b {
                        return DirtyReason::PrecalculatedComponentsChanged {
                            old: b.to_string(),
                            new: a.to_string(),
                        };
                    }
                }
                (
                    LocalFingerprint::CheckDepInfo {
                        dep_info: a_dep,
                        checksum: checksum_a,
                    },
                    LocalFingerprint::CheckDepInfo {
                        dep_info: b_dep,
                        checksum: checksum_b,
                    },
                ) => {
                    if a_dep != b_dep {
                        return DirtyReason::DepInfoOutputChanged {
                            old: b_dep.clone(),
                            new: a_dep.clone(),
                        };
                    }
                    if checksum_a != checksum_b {
                        return DirtyReason::ChecksumUseChanged { old: *checksum_b };
                    }
                }
                (
                    LocalFingerprint::RerunIfChanged {
                        output: a_out,
                        paths: a_paths,
                    },
                    LocalFingerprint::RerunIfChanged {
                        output: b_out,
                        paths: b_paths,
                    },
                ) => {
                    if a_out != b_out {
                        return DirtyReason::RerunIfChangedOutputFileChanged {
                            old: b_out.clone(),
                            new: a_out.clone(),
                        };
                    }
                    if a_paths != b_paths {
                        return DirtyReason::RerunIfChangedOutputPathsChanged {
                            old: b_paths.clone(),
                            new: a_paths.clone(),
                        };
                    }
                }
                (
                    LocalFingerprint::RerunIfEnvChanged {
                        var: a_key,
                        val: a_value,
                    },
                    LocalFingerprint::RerunIfEnvChanged {
                        var: b_key,
                        val: b_value,
                    },
                ) => {
                    if *a_key != *b_key {
                        return DirtyReason::EnvVarsChanged {
                            old: b_key.clone(),
                            new: a_key.clone(),
                        };
                    }
                    if *a_value != *b_value {
                        return DirtyReason::EnvVarChanged {
                            name: a_key.clone(),
                            old_value: b_value.diagnostic_value(),
                            new_value: a_value.diagnostic_value(),
                        };
                    }
                }
                (a, b) => {
                    return DirtyReason::LocalFingerprintTypeChanged {
                        old: b.kind().to_owned(),
                        new: a.kind().to_owned(),
                    };
                }
            }
        }

        if self.deps.len() != old.deps.len() {
            return DirtyReason::NumberOfDependenciesChanged {
                old: old.deps.len(),
                new: self.deps.len(),
            };
        }
        for (a, b) in self.deps.iter().zip(old.deps.iter()) {
            if a.name != b.name {
                return DirtyReason::UnitDependencyNameChanged {
                    old: b.name,
                    new: a.name,
                };
            }

            if a.dependency_hash() != b.dependency_hash() {
                return DirtyReason::UnitDependencyInfoChanged {
                    unit: a.fingerprint.index,
                };
            }
        }

        let fs_status = self.fs_status.lock().unwrap();
        if !fs_status.up_to_date() {
            return DirtyReason::FsStatusOutdated(fs_status.clone());
        }
        drop(fs_status);

        // This typically means some filesystem modifications happened or
        // something transitive was odd. In general we should strive to provide
        // a better error message than this, so if you see this message a lot it
        // likely means this method needs to be updated!
        DirtyReason::NothingObvious
    }

    /// Dynamically inspect the local filesystem to update the `fs_status` field
    /// of this `Fingerprint`.
    ///
    /// This function is used just after a `Fingerprint` is constructed to check
    /// the local state of the filesystem and propagate any dirtiness from
    /// dependencies up to this unit as well. This function assumes that the
    /// unit starts out as [`FsStatus::Stale`] and then it will optionally switch
    /// it to `UpToDate` if it can.
    fn check_filesystem(
        &mut self,
        mtime_cache: &mut HashMap<PathBuf, FileTime>,
        checksum_cache: &mut HashMap<PathBuf, Checksum>,
        pkg: &Package,
        build_root: &Path,
        cargo_exe: &Path,
        gctx: &GlobalContext,
        checksum_parallelism: ChecksumParallelism<'_>,
    ) -> CargoResult<()> {
        assert!(!self.fs_status.get_mut().unwrap().up_to_date());

        let pkg_root = pkg.root();
        let mut mtimes = HashMap::default();

        // Get the `mtime` of all outputs. Optionally update their mtime
        // afterwards based on the `mtime_on_use` flag. Afterwards we want the
        // minimum mtime as it's the one we'll be comparing to inputs and
        // dependencies.
        for output in self.outputs.iter() {
            let Ok(mtime) = paths::mtime(output) else {
                // This path failed to report its `mtime`. It probably doesn't
                // exists, so leave ourselves as stale and bail out.
                let item = StaleItem::FailedToReadMetadata {
                    path: output.clone(),
                };
                *self.fs_status.get_mut().unwrap() = FsStatus::StaleItem(item);
                return Ok(());
            };
            assert!(mtimes.insert(output.clone(), mtime).is_none());
        }

        let opt_max = mtimes.iter().max_by_key(|kv| kv.1);
        let Some((max_path, max_mtime)) = opt_max else {
            // We had no output files. This means we're an overridden build
            // script and we're just always up to date because we aren't
            // watching the filesystem.
            *self.fs_status.get_mut().unwrap() = FsStatus::UpToDate {
                mtimes,
                link_mtime: None,
            };
            return Ok(());
        };
        debug!(
            "max output mtime for {:?} is {:?} {}",
            pkg_root, max_path, max_mtime
        );

        // Check local inputs before dependencies. If dependency checking
        // returned first, a simultaneous local source change could be masked
        // as dependency-only and incorrectly become eligible for early cutoff.
        let worktree_seed = self.ohm_worktree_namespace.is_some();
        for local in self.local.get_mut().unwrap().iter() {
            if let Some(item) = local.find_stale_item(
                mtime_cache,
                checksum_cache,
                pkg,
                build_root,
                cargo_exe,
                gctx,
                worktree_seed,
                checksum_parallelism,
                &mut self.observes_foreign_span,
                self.recheck_dependent_links.get_mut(),
            )? {
                item.log();
                *self.fs_status.get_mut().unwrap() = FsStatus::StaleItem(item);
                return Ok(());
            }
        }

        for dep in self.deps.iter() {
            // Extract needed data from the dependency's fs_status under the lock,
            // then drop the lock before potentially modifying self.fs_status.
            let dep_info = {
                let dep_fs_status = dep.fingerprint.fs_status.lock().unwrap();
                match &*dep_fs_status {
                    FsStatus::UpToDate { mtimes, link_mtime } => {
                        // If our dependency edge only requires the rmeta file to be present
                        // then we only need to look at that one output file, otherwise we
                        // need to consider all output files to see if we're out of date.
                        if let Some(result) = dep.fingerprint.script_result.lock().unwrap().as_ref()
                        {
                            Some((dep.fingerprint.outputs[0].clone(), result.generation))
                        } else if dep.only_requires_rmeta {
                            let (dep_path, dep_mtime) = mtimes
                                .iter()
                                .find(|(path, _mtime)| {
                                    path.extension().and_then(|s| s.to_str()) == Some("rmeta")
                                })
                                .expect("failed to find rmeta");
                            Some((dep_path.clone(), *dep_mtime))
                        } else {
                            mtimes.iter().max_by_key(|kv| kv.1).map(|(path, mtime)| {
                                (
                                    path.clone(),
                                    link_mtime
                                        .map_or(*mtime, |link_mtime| (*mtime).max(link_mtime)),
                                )
                            })
                        }
                    }
                    // Dependency was rebuilt but output didn't change - don't propagate
                    // dirtiness. Skip this dependency since the content is semantically
                    // unchanged.
                    FsStatus::OutputUnchanged { .. } => None,
                    // If our dependency is stale, so are we, so bail out.
                    FsStatus::Stale
                    | FsStatus::StaleItem(_)
                    | FsStatus::StaleDependency { .. }
                    | FsStatus::StaleDepFingerprint { .. } => {
                        *self.fs_status.get_mut().unwrap() = FsStatus::StaleDepFingerprint {
                            unit: dep.fingerprint.index,
                        };
                        return Ok(());
                    }
                }
            };

            let Some((dep_path, dep_mtime)) = dep_info else {
                continue;
            };

            debug!(
                "max dep mtime for {:?} is {:?} {}",
                pkg_root, dep_path, dep_mtime
            );

            // If the dependency is newer than our own output then it was
            // recompiled previously. We transitively become stale ourselves in
            // that case, so bail out.
            //
            // Note that this comparison should probably be `>=`, not `>`, but
            // for a discussion of why it's `>` see the discussion about #5918
            // below in `find_stale`.
            if dep_mtime > *max_mtime {
                info!(
                    "dependency on `{}` is newer than we are {} > {} {:?}",
                    dep.name, dep_mtime, max_mtime, pkg_root
                );

                *self.fs_status.get_mut().unwrap() = FsStatus::StaleDependency {
                    unit: dep.fingerprint.index,
                    dep_mtime,
                    max_mtime: *max_mtime,
                };

                return Ok(());
            }
        }

        let mut link_mtime = mtimes
            .iter()
            .filter(|(path, _)| {
                path.extension().and_then(|extension| extension.to_str()) == Some("rlib")
            })
            .map(|(_, mtime)| *mtime)
            .max();
        // Metadata may have been preserved by an earlier invocation, so carry
        // its link generation even when this one disables hashing or enables
        // fine-grained locking. This only reads existing output generations.
        if link_mtime.is_some() {
            for dependency in self
                .deps
                .iter()
                .filter(|dependency| dependency.only_requires_rmeta)
            {
                let dependency_status = dependency.fingerprint.fs_status.lock().unwrap();
                if let FsStatus::UpToDate {
                    link_mtime: Some(dependency_mtime),
                    ..
                } = &*dependency_status
                {
                    link_mtime = link_mtime.map(|mtime| mtime.max(*dependency_mtime));
                }
            }
        }

        // Everything was up to date! Record such.
        *self.fs_status.get_mut().unwrap() = FsStatus::UpToDate { mtimes, link_mtime };
        debug!("filesystem up-to-date {:?}", pkg_root);

        Ok(())
    }
}

impl hash::Hash for Fingerprint {
    fn hash<H: Hasher>(&self, h: &mut H) {
        let Fingerprint {
            rustc,
            ref features,
            ref declared_features,
            target,
            path,
            profile,
            ref deps,
            ref local,
            config,
            compile_kind,
            ref rustflags,
            ..
        } = *self;
        let local = local.lock().unwrap();
        let local = self.local_identity(&local);
        (
            rustc,
            features,
            declared_features,
            target,
            path,
            profile,
            &*local,
            config,
            compile_kind,
            rustflags,
        )
            .hash(h);

        h.write_usize(deps.len());
        for dependency in deps {
            dependency.pkg_id.hash(h);
            dependency.name.hash(h);
            dependency.public.hash(h);
            // use memoized dep hashes to avoid exponential blowup
            h.write_u64(dependency.dependency_hash());
        }
    }
}

impl DepFingerprint {
    /// Build scripts expose their validated result, not the identity of the action.
    fn dependency_hash(&self) -> u64 {
        let result = self.fingerprint.script_result.lock().unwrap();
        if let Some(result) = result.as_ref() {
            return result.dependency_hash();
        }
        drop(result);
        self.fingerprint.hash_u64()
    }

    fn previous_output_mtime(&self) -> Option<FileTime> {
        if let Some(result) = self.fingerprint.script_result.lock().unwrap().as_ref() {
            return Some(result.generation);
        }
        previous_output_mtime(self.fingerprint.outputs.iter(), self.only_requires_rmeta)
    }

    fn new(
        build_runner: &mut BuildRunner<'_, '_>,
        parent: &Unit,
        dep: &UnitDep,
    ) -> CargoResult<DepFingerprint> {
        let fingerprint = calculate(build_runner, &dep.unit)?;
        // We need to be careful about what we hash here. We have a goal of
        // supporting renaming a project directory and not rebuilding
        // everything. To do that, however, we need to make sure that the cwd
        // doesn't make its way into any hashes, and one source of that is the
        // `SourceId` for `path` packages.
        //
        // We already have a requirement that `path` packages all have unique
        // names (sort of for this same reason), so if the package source is a
        // `path` then we just hash the name, but otherwise we hash the full
        // id as it won't change when the directory is renamed.
        let pkg_id = if dep.unit.pkg.package_id().source_id().is_path() {
            util::hash_u64(dep.unit.pkg.package_id().name())
        } else {
            util::hash_u64(dep.unit.pkg.package_id())
        };

        Ok(DepFingerprint {
            pkg_id,
            name: dep.extern_crate_name,
            public: dep.public,
            fingerprint,
            only_requires_rmeta: build_runner.only_requires_rmeta(parent, &dep.unit),
        })
    }
}

impl StaleItem {
    /// Use the `log` crate to log a hopefully helpful message in diagnosing
    /// what file is considered stale and why. This is intended to be used in
    /// conjunction with `CARGO_LOG` to determine why Cargo is recompiling
    /// something. Currently there's no user-facing usage of this other than
    /// that.
    fn log(&self) {
        match self {
            StaleItem::MissingFile { path } => {
                info!("stale: missing {:?}", path);
            }
            StaleItem::UnableToReadFile { path } => {
                info!("stale: unable to read {:?}", path);
            }
            StaleItem::FailedToReadMetadata { path } => {
                info!("stale: couldn't read metadata {:?}", path);
            }
            StaleItem::ChangedFile {
                reference,
                reference_mtime,
                stale,
                stale_mtime,
            } => {
                info!("stale: changed {:?}", stale);
                info!("          (vs) {:?}", reference);
                info!("               {:?} < {:?}", reference_mtime, stale_mtime);
            }
            StaleItem::FileSizeChanged {
                path,
                new_size,
                old_size,
            } => {
                info!("stale: changed {:?}", path);
                info!("prior file size {old_size}");
                info!("  new file size {new_size}");
            }
            StaleItem::ChangedChecksum {
                source,
                stored_checksum,
                new_checksum,
            } => {
                info!("stale: changed {:?}", source);
                info!("prior checksum {stored_checksum}");
                info!("  new checksum {new_checksum}");
            }
            StaleItem::MissingChecksum { path } => {
                info!("stale: no prior checksum {:?}", path);
            }
            StaleItem::ChangedEnv {
                var,
                previous,
                current,
            } => {
                info!("stale: changed env {:?}", var);
                info!("       {:?} != {:?}", previous, current);
            }
        }
    }
}

/// Calculates the fingerprint for a [`Unit`].
///
/// This fingerprint is used by Cargo to learn about when information such as:
///
/// * A non-path package changes (changes version, changes revision, etc).
/// * Any dependency changes
/// * The compiler changes
/// * The set of features a package is built with changes
/// * The profile a target is compiled with changes (e.g., opt-level changes)
/// * Any other compiler flags change that will affect the result
///
/// Information like file modification time is only calculated for path
/// dependencies.
fn calculate(build_runner: &mut BuildRunner<'_, '_>, unit: &Unit) -> CargoResult<Arc<Fingerprint>> {
    // This function is slammed quite a lot, so the result is memoized.
    if let Some(s) = build_runner.fingerprints.get(unit) {
        return Ok(Arc::clone(s));
    }
    let mut fingerprint = if unit.mode.is_run_custom_build() {
        calculate_run_custom_build(build_runner, unit)?
    } else {
        calculate_normal(build_runner, unit)?
    };

    // After we built the initial `Fingerprint` be sure to update the
    // `fs_status` field of it.
    let build_root = build_runner.files().build_root(unit);
    let cargo_exe = build_runner.bcx.gctx.cargo_exe()?;
    fingerprint.check_filesystem(
        &mut build_runner.mtime_cache,
        &mut build_runner.checksum_cache,
        &unit.pkg,
        &build_root,
        cargo_exe,
        build_runner.bcx.gctx,
        ChecksumParallelism {
            #[cfg(unix)]
            jobserver: &build_runner.jobserver,
            #[cfg(unix)]
            reserved_tokens: &build_runner.checksum_tokens,
            #[cfg(not(unix))]
            _lifetime: std::marker::PhantomData,
            jobs: build_runner.bcx.jobs(),
            #[cfg(all(test, unix))]
            workers_started: None,
        },
    )?;

    // A native input marker restricts reuse when Cargo needs to rebuild. A warm
    // unit still follows Cargo's ordinary source and build-script declarations.
    fingerprint.record_native_link_inputs(false);
    // An extracted doctest may link an unbundled archive outside the crate's
    // dep-info. Recheck the link while retaining fresh Rust inputs for reuse.
    if unit.mode.is_doc_test() && fingerprint.fs_status.get_mut().unwrap().up_to_date() {
        fingerprint.fresh_doctest_inputs = fingerprint
            .native_recheck_can_reuse_codegen(build_runner, unit)
            && matches!(
                fingerprint.fs_status.get_mut().unwrap(),
                FsStatus::UpToDate { .. }
            )
            && unit_has_exclusive_metadata_access(build_runner, unit)
            && !previous_dependency_changes(&fingerprint).any
            && short_fingerprint_matches(
                &build_runner.files().fingerprint_file_path(unit, ""),
                fingerprint.hash_u64(),
            );
        *fingerprint.fs_status.get_mut().unwrap() = FsStatus::StaleItem(StaleItem::MissingFile {
            path: RECHECK_DEPENDENT_LINKS.into(),
        });
    }

    // A downstream library may have finished using provisional metadata before
    // this producer failed. Reverting the source can satisfy the old dep-info
    // checksums, but an uncommitted producer must still dirty its dependents.
    if fingerprint.fs_status.get_mut().unwrap().up_to_date()
        && fingerprint
            .outputs
            .iter()
            .any(|output| output.extension().is_some_and(|ext| ext == "rmeta"))
    {
        let loc = build_runner.files().fingerprint_file_path(unit, "");
        let hash = fingerprint.hash_u64();
        if !short_fingerprint_matches(&loc, hash) {
            *fingerprint.fs_status.get_mut().unwrap() = FsStatus::Stale;
        } else if unit_has_exclusive_metadata_access(build_runner, unit) {
            *fingerprint.memoized_hash.get_mut().unwrap() = Some(MemoizedHash {
                value: hash,
                matched_on_disk: true,
            });
        }
    }

    if unit.mode.is_run_custom_build()
        && !fingerprint.outputs.is_empty()
        && super::unit_worktree_seed_namespace(build_runner, unit).is_some()
    {
        let loc = build_runner.files().fingerprint_file_path(unit, "");
        let rerun = build_runner
            .files()
            .fingerprint_dir(unit)
            .join(OHM_WORKTREE_SCRIPT_RERUN);
        let action_matches =
            paths::read(&loc).is_ok_and(|old| old == util::to_hex(fingerprint.hash_u64()));
        if rerun.symlink_metadata().is_ok() || !action_matches {
            // Result hashes must not conceal action-only changes (for example
            // rerun-if-env-changed) from the consumer's initial scheduling pass.
            *fingerprint.fs_status.get_mut().unwrap() = FsStatus::Stale;
        }
    }

    let fingerprint = Arc::new(fingerprint);
    build_runner
        .fingerprints
        .insert(unit.clone(), Arc::clone(&fingerprint));
    Ok(fingerprint)
}

/// Hashes the profile and mode used by an existing compilation fingerprint.
pub(crate) fn unit_profile_hash(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> u64 {
    util::hash_u64((
        &unit.profile,
        unit.mode,
        build_runner.bcx.extra_args_for(unit),
        build_runner.lto[unit],
        unit.pkg.manifest().lint_rustflags(),
        unit.profile
            .trim_paths
            .as_ref()
            .filter(|trim_paths| !trim_paths.is_none())
            .map(|_| {
                build_runner
                    .bcx
                    .gctx
                    .get_env(super::trim_paths::WS_REMAP_ENV)
                    .ok()
                    .filter(|prefix| !prefix.is_empty())
            }),
    ))
}

/// Calculate a fingerprint for a "normal" unit, or anything that's not a build
/// script. This is an internal helper of [`calculate`], don't call directly.
fn calculate_normal(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
) -> CargoResult<Fingerprint> {
    let deps = {
        // Recursively calculate the fingerprint for all of our dependencies.
        //
        // Skip fingerprints of binaries because they don't actually induce a
        // recompile, they're just dependencies in the sense that they need to be
        // built. The only exception here are artifact dependencies,
        // which is an actual dependency that needs a recompile.
        //
        // Create Vec since mutable build_runner is needed in closure.
        let deps = Vec::from(build_runner.unit_deps(unit));
        let mut deps = deps
            .into_iter()
            .filter(|dep| !dep.unit.target.is_bin() || dep.unit.artifact.is_true())
            .map(|dep| DepFingerprint::new(build_runner, unit, &dep))
            .collect::<CargoResult<Vec<_>>>()?;
        deps.sort_by(|a, b| a.pkg_id.cmp(&b.pkg_id));
        deps
    };

    // Afterwards calculate our own fingerprint information.
    let build_root = build_runner.files().build_root(unit);
    let is_any_doc_gen = unit.mode.is_doc() || unit.mode.is_doc_scrape();
    let rustdoc_depinfo_enabled = build_runner.bcx.gctx.cli_unstable().rustdoc_depinfo;
    let mut local = if is_any_doc_gen && !rustdoc_depinfo_enabled {
        // rustdoc does not have dep-info files.
        let fingerprint = pkg_fingerprint(build_runner.bcx, &unit.pkg).with_context(|| {
            format!(
                "failed to determine package fingerprint for documenting {}",
                unit.pkg
            )
        })?;
        vec![LocalFingerprint::Precalculated(fingerprint)]
    } else {
        let dep_info = dep_info_loc(build_runner, unit);
        let dep_info = dep_info.strip_prefix(&build_root).unwrap().to_path_buf();
        vec![LocalFingerprint::CheckDepInfo {
            dep_info,
            checksum: super::unit_uses_checksum_freshness(build_runner, unit),
        }]
    };

    if unit.mode.is_doc_test() {
        let dir = build_runner.files().fingerprint_dir(unit);
        let info = super::cached_doctests::extraction_dep_info(&dir);
        local.push(LocalFingerprint::CheckDepInfo {
            dep_info: info.strip_prefix(&build_root).unwrap().to_owned(),
            checksum: super::unit_uses_checksum_freshness(build_runner, unit),
        });
    }

    // Figure out what the outputs of our unit is, and we'll be storing them
    // into the fingerprint as well.
    let unit_outputs = build_runner.outputs(unit)?;
    let outputs = unit_outputs
        .iter()
        .filter(|output| !matches!(output.flavor, FileFlavor::DebugInfo | FileFlavor::Auxiliary))
        .map(|output| output.path.clone())
        .collect::<Vec<_>>();
    // Fill out a bunch more information that we'll be tracking typically
    // hashed to take up less space on disk as we just need to know when things
    // change.
    let extra_flags = if unit.mode.is_doc() || unit.mode.is_doc_scrape() {
        &unit.rustdocflags
    } else {
        &unit.rustflags
    }
    .to_vec();

    let profile_hash = unit_profile_hash(build_runner, unit);
    let mut config = StableHasher::new();
    if unit.mode.is_doc_test() {
        // A different generator or rustdoc can change the executable even
        // when the package and rustc itself are unchanged.
        "ohm-cached-doctests-v1".hash(&mut config);
        let rustdoc = paths::resolve_executable(build_runner.bcx.gctx.rustdoc()?)?;
        rustdoc.hash(&mut config);
        rustdoc.metadata()?.modified()?.hash(&mut config);
    }
    let linker = if unit.target.for_host() && !build_runner.bcx.gctx.target_applies_to_host()? {
        build_runner.compilation.host_linker()
    } else {
        build_runner.compilation.target_linker(unit.kind)
    };
    if let Some(linker) = linker {
        linker.hash(&mut config);
    }
    if unit.mode.is_doc() && build_runner.bcx.gctx.cli_unstable().rustdoc_map {
        if let Ok(map) = build_runner.bcx.gctx.doc_extern_map() {
            map.hash(&mut config);
        }
    }
    if let Some(allow_features) = &build_runner.bcx.gctx.cli_unstable().allow_features {
        allow_features.hash(&mut config);
    }
    // -Zpublic-dependency changes how library units pass dependency privacy
    // to rustc via `--extern`.
    (unit.target.is_lib()
        && build_runner.unit_deps(unit).iter().any(|dep| !dep.public)
        && super::is_public_dependency_enabled(build_runner, unit))
    .hash(&mut config);
    // -Zembed-metadata changes how all units are compiled, and it also changes how we tell
    // rustc to link to deps using `--extern`. If it changes, we should rebuild everything.
    build_runner
        .bcx
        .gctx
        .should_embed_metadata()
        .not()
        .hash(&mut config);
    // The same immutable package can become a root in another invocation, so
    // its effective embedding policy must also invalidate its own fingerprint.
    super::unit_uses_no_embed_metadata(build_runner, unit).hash(&mut config);
    // Legacy dynamic-library and executable outputs may omit the unit-id suffix,
    // so this injected default must also invalidate their shared fingerprint.
    super::unit_uses_ohm_incremental_mono_partitions(build_runner, unit).hash(&mut config);
    if super::unit_uses_ohm_shared_stages(build_runner, unit) {
        "ohm-shared-stages-v1".hash(&mut config);
    }
    if super::unit_uses_ohm_worktree_seeds(build_runner, unit) {
        // An ordinary build must not appear prepared just because its outputs
        // were copied. This injected path mapping also changes rustc's output.
        ("ohm-worktree-seeds", 6_u8).hash(&mut config);
    }
    if unit_consumes_public_api_hash(build_runner, unit) {
        // Older generations could miss a changed link or retain diagnostics from a failed build.
        ("ohm-reduced-dependency-rebuild", 3_u8).hash(&mut config);
    }
    if super::unit_suppresses_default_public_api_hash(build_runner, unit) {
        ("ohm-terminal-check-public-api-hash", 1_u8).hash(&mut config);
    }
    if unit_can_use_relink_only(build_runner, unit) {
        // Cache collection changes the rustc arguments even when both modes
        // use full codegen. A proc macro can observe those arguments.
        let unstable = build_runner.bcx.gctx.cli_unstable();
        (
            "ohm-native-codegen-reuse",
            unstable.relink_only(),
            unstable.collect_relink_cache(),
        )
            .hash(&mut config);
    }
    if super::unit_checks_relink_inputs(build_runner, unit) {
        // Previous Cargo versions discarded the original marker from cached dep-info.
        "ohm-checked-native-inputs-v3".hash(&mut config);
    }

    let compile_kind = unit.kind.fingerprint_hash();
    let mut declared_features = unit.pkg.summary().features().keys().collect::<Vec<_>>();
    declared_features.sort(); // to avoid useless rebuild if the user orders it's features
    // differently
    let ohm_worktree_namespace = super::unit_worktree_seed_namespace(build_runner, unit)
        .map(|namespace| namespace.strip_prefix(&build_root).map(Path::to_path_buf))
        .transpose()?;
    Ok(Fingerprint {
        rustc: util::hash_u64(&build_runner.bcx.rustc().verbose_version),
        target: util::hash_u64(&unit.target),
        profile: profile_hash,
        // Note that .0 is hashed here, not .1 which is the cwd. That doesn't
        // actually affect the output artifact so there's no need to hash it.
        path: util::hash_u64(path_args(build_runner.bcx.ws, unit).0),
        features: format!("{:?}", unit.features),
        declared_features: format!("{declared_features:?}"),
        deps,
        local: Mutex::new(local),
        ohm_worktree_namespace,
        memoized_hash: Mutex::new(None),
        script_result: Mutex::new(None),
        worktree_reuse_hash: Mutex::new(None),
        worktree_reused: AtomicBool::new(false),
        config: Hasher::finish(&config),
        compile_kind,
        index: build_runner.bcx.unit_to_index[unit],
        recheck_dependent_links: AtomicBool::new(false),
        fresh_doctest_inputs: false,
        observes_foreign_span: false,
        rustflags: extra_flags,
        fs_status: Mutex::new(FsStatus::Stale),
        build_state: Mutex::new(BuildState::Pending),
        early_cutoff_candidate: AtomicBool::new(false),
        previously_changed_metadata_dependency: AtomicBool::new(false),
        outputs,
    })
}

/// Calculate a fingerprint for an "execute a build script" unit.  This is an
/// internal helper of [`calculate`], don't call directly.
fn calculate_run_custom_build(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
) -> CargoResult<Fingerprint> {
    assert!(unit.mode.is_run_custom_build());
    // Using the `BuildDeps` information we'll have previously parsed and
    // inserted into `build_explicit_deps` built an initial snapshot of the
    // `LocalFingerprint` list for this build script. If we previously executed
    // the build script this means we'll be watching files and env vars.
    // Otherwise if we haven't previously executed it we'll just start watching
    // the whole crate.
    let (gen_local, overridden) = build_script_local_fingerprints(build_runner, unit)?;
    let deps = &build_runner.build_explicit_deps[unit];
    let local = (gen_local)(
        deps,
        Some(&|| {
            const IO_ERR_MESSAGE: &str = "\
An I/O error happened. Please make sure you can access the file.

By default, if your project contains a build script, cargo scans all files in
it to determine whether a rebuild is needed. If you don't expect to access the
file, specify `rerun-if-changed` in your build script.
See https://doc.rust-lang.org/cargo/reference/build-scripts.html#rerun-if-changed for more information.";
            pkg_fingerprint(build_runner.bcx, &unit.pkg).map_err(|err| {
                let mut message = format!("failed to determine package fingerprint for build script for {}", unit.pkg);
                if err.root_cause().is::<io::Error>() {
                    message = format!("{}\n{}", message, IO_ERR_MESSAGE)
                }
                err.context(message)
            })
        }),
    )?
    .unwrap();
    let output = deps.build_script_output.clone();

    // Include any dependencies of our execution, which is typically just the
    // compilation of the build script itself. (if the build script changes we
    // should be rerun!). Note though that if we're an overridden build script
    // we have no dependencies so no need to recurse in that case.
    let deps = if overridden {
        // Overridden build scripts don't need to track deps.
        vec![]
    } else {
        // Create Vec since mutable build_runner is needed in closure.
        let deps = Vec::from(build_runner.unit_deps(unit));
        deps.into_iter()
            .map(|dep| DepFingerprint::new(build_runner, unit, &dep))
            .collect::<CargoResult<Vec<_>>>()?
    };

    let rustflags = unit.rustflags.to_vec();
    let script_result =
        if !overridden && super::unit_worktree_seed_namespace(build_runner, unit).is_some() {
            let (previous, _) = super::custom_build::prev_build_output(build_runner, unit);
            previous.and_then(|previous| {
                let out_dir = if build_runner.bcx.gctx.cli_unstable().build_dir_new_layout {
                    build_runner.files().out_dir_new_layout(unit)
                } else {
                    build_runner.files().build_script_out_dir(unit)
                };
                worktree::load_script_result(
                    &build_runner
                        .files()
                        .fingerprint_dir(unit)
                        .join(OHM_WORKTREE_SCRIPT_RESULT),
                    &output,
                    &out_dir,
                    &previous,
                )
            })
        } else {
            None
        };

    Ok(Fingerprint {
        local: Mutex::new(local),
        rustc: util::hash_u64(&build_runner.bcx.rustc().verbose_version),
        deps,
        outputs: if overridden { Vec::new() } else { vec![output] },
        rustflags,
        script_result: Mutex::new(script_result),
        index: build_runner.bcx.unit_to_index[unit],

        // Most of the other info is blank here as we don't really include it
        // in the execution of the build script, but... this may be a latent
        // bug in Cargo.
        ..Fingerprint::new()
    })
}

/// Get ready to compute the [`LocalFingerprint`] values
/// for a [`RunCustomBuild`] unit.
///
/// This function has, what's on the surface, a seriously wonky interface.
/// You'll call this function and it'll return a closure and a boolean. The
/// boolean is pretty simple in that it indicates whether the `unit` has been
/// overridden via `.cargo/config.toml`. The closure is much more complicated.
///
/// This closure is intended to capture any local state necessary to compute
/// the `LocalFingerprint` values for this unit. It is `Send` and `'static` to
/// be sent to other threads as well (such as when we're executing build
/// scripts). That deduplication is the rationale for the closure at least.
///
/// The arguments to the closure are a bit weirder, though, and I'll apologize
/// in advance for the weirdness too. The first argument to the closure is a
/// `&BuildDeps`. This is the parsed version of a build script, and when Cargo
/// starts up this is cached from previous runs of a build script.  After a
/// build script executes the output file is reparsed and passed in here.
///
/// The second argument is the weirdest, it's *optionally* a closure to
/// call [`pkg_fingerprint`]. The `pkg_fingerprint` requires access to
/// "source map" located in `Context`. That's very non-`'static` and
/// non-`Send`, so it can't be used on other threads, such as when we invoke
/// this after a build script has finished. The `Option` allows us to for sure
/// calculate it on the main thread at the beginning, and then swallow the bug
/// for now where a worker thread after a build script has finished doesn't
/// have access. Ideally there would be no second argument or it would be more
/// "first class" and not an `Option` but something that can be sent between
/// threads. In any case, it's a bug for now.
///
/// This isn't the greatest of interfaces, and if there's suggestions to
/// improve please do so!
///
/// FIXME(#6779) - see all the words above
///
/// [`RunCustomBuild`]: crate::compiler::CompileMode::RunCustomBuild
fn build_script_local_fingerprints(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
) -> CargoResult<(
    Box<
        dyn FnOnce(
                &BuildDeps,
                Option<&dyn Fn() -> CargoResult<String>>,
            ) -> CargoResult<Option<Vec<LocalFingerprint>>>
            + Send,
    >,
    bool,
)> {
    assert!(unit.mode.is_run_custom_build());
    // First up, if this build script is entirely overridden, then we just
    // return the hash of what we overrode it with. This is the easy case!
    if let Some(fingerprint) = build_script_override_fingerprint(build_runner, unit) {
        debug!("override local fingerprints deps {}", unit.pkg);
        return Ok((
            Box::new(
                move |_: &BuildDeps, _: Option<&dyn Fn() -> CargoResult<String>>| {
                    Ok(Some(vec![fingerprint]))
                },
            ),
            true, // this is an overridden build script
        ));
    }

    // ... Otherwise this is a "real" build script and we need to return a real
    // closure. Our returned closure classifies the build script based on
    // whether it prints `rerun-if-*`. If it *doesn't* print this it's where the
    // magical second argument comes into play, which fingerprints a whole
    // package. Remember that the fact that this is an `Option` is a bug, but a
    // longstanding bug, in Cargo. Recent refactorings just made it painfully
    // obvious.
    let pkg_root = unit.pkg.root().to_path_buf();
    let build_dir = build_runner.files().build_root(unit);
    let env_config = Arc::clone(build_runner.bcx.gctx.env_config()?);
    let calculate =
        move |deps: &BuildDeps, pkg_fingerprint: Option<&dyn Fn() -> CargoResult<String>>| {
            if deps.rerun_if_changed.is_empty() && deps.rerun_if_env_changed.is_empty() {
                match pkg_fingerprint {
                    // FIXME: this is somewhat buggy with respect to docker and
                    // weird filesystems. The `Precalculated` variant
                    // constructed below will, for `path` dependencies, contain
                    // a stringified version of the mtime for the local crate.
                    // This violates one of the things we describe in this
                    // module's doc comment, never hashing mtimes. We should
                    // figure out a better scheme where a package fingerprint
                    // may be a string (like for a registry) or a list of files
                    // (like for a path dependency). Those list of files would
                    // be stored here rather than the mtime of them.
                    Some(f) => {
                        let s = f()?;
                        debug!(
                            "old local fingerprints deps {:?} precalculated={:?}",
                            pkg_root, s
                        );
                        return Ok(Some(vec![LocalFingerprint::Precalculated(s)]));
                    }
                    None => return Ok(None),
                }
            }

            // Ok so now we're in "new mode" where we can have files listed as
            // dependencies as well as env vars listed as dependencies. Process
            // them all here.
            Ok(Some(local_fingerprints_deps(
                deps,
                &build_dir,
                &pkg_root,
                &env_config,
            )))
        };

    // Note that `false` == "not overridden"
    Ok((Box::new(calculate), false))
}

/// Create a [`LocalFingerprint`] for an overridden build script.
/// Returns None if it is not overridden.
fn build_script_override_fingerprint(
    build_runner: &mut BuildRunner<'_, '_>,
    unit: &Unit,
) -> Option<LocalFingerprint> {
    // Build script output is only populated at this stage when it is
    // overridden.
    let build_script_outputs = build_runner.build_script_outputs.lock().unwrap();
    let metadata = build_runner.get_run_build_script_metadata(unit);
    // Returns None if it is not overridden.
    let output = build_script_outputs.get(metadata)?;
    let s = format!(
        "overridden build state with hash: {}",
        util::hash_u64(output)
    );
    Some(LocalFingerprint::Precalculated(s))
}

/// Compute the [`LocalFingerprint`] values for a [`RunCustomBuild`] unit for
/// non-overridden new-style build scripts only. This is only used when `deps`
/// is already known to have a nonempty `rerun-if-*` somewhere.
///
/// [`RunCustomBuild`]: crate::compiler::CompileMode::RunCustomBuild
fn local_fingerprints_deps(
    deps: &BuildDeps,
    build_root: &Path,
    pkg_root: &Path,
    env_config: &Arc<HashMap<String, OsString>>,
) -> Vec<LocalFingerprint> {
    debug!("new local fingerprints deps {:?}", pkg_root);
    let mut local = Vec::new();

    if !deps.rerun_if_changed.is_empty() {
        // Note that like the module comment above says we are careful to never
        // store an absolute path in `LocalFingerprint`, so ensure that we strip
        // absolute prefixes from them.
        let output = deps
            .build_script_output
            .strip_prefix(build_root)
            .unwrap()
            .to_path_buf();
        let paths = deps
            .rerun_if_changed
            .iter()
            .map(|p| p.strip_prefix(pkg_root).unwrap_or(p).to_path_buf())
            .collect();
        local.push(LocalFingerprint::RerunIfChanged { output, paths });
    }

    local.extend(
        deps.rerun_if_env_changed
            .iter()
            .map(|s| LocalFingerprint::from_env(s, env_config)),
    );

    local
}

/// Writes the short fingerprint hash value to `<loc>`
/// and logs detailed JSON information to `<loc>.json`.
fn write_fingerprint(loc: &Path, fingerprint: &Fingerprint) -> CargoResult<()> {
    debug_assert_ne!(fingerprint.rustc, 0);
    // fingerprint::new().rustc == 0, make sure it doesn't make it to the file system.
    // This is mostly so outside tools can reliably find out what rust version this file is for,
    // as we can use the full hash.
    let hash = fingerprint.hash_u64();
    debug!("write fingerprint ({:x}) : {}", hash, loc.display());
    paths::write(loc, util::to_hex(hash).as_bytes())?;

    let json = serde_json::to_string(fingerprint).unwrap();
    if cfg!(debug_assertions) {
        let f: Fingerprint = serde_json::from_str(&json).unwrap();
        assert_eq!(f.hash_u64(), hash);
    }
    paths::write(&loc.with_extension("json"), json.as_bytes())?;
    Ok(())
}

/// Commits the Cargo fingerprint before updating its public API hash sidecar.
///
/// If the build is interrupted after rustc reports a new hash, the next build
/// must not compare that hash against an old Cargo fingerprint and conclude
/// that dependents can be reused.
fn write_fingerprint_and_public_api_hash(
    loc: &Path,
    fingerprint: &Fingerprint,
    public_api_hash_path: &Path,
    public_api_hash_update: PublicApiHashUpdate,
) -> CargoResult<()> {
    write_fingerprint(loc, fingerprint)?;
    match public_api_hash_update {
        PublicApiHashUpdate::Preserve => {}
        PublicApiHashUpdate::Write(public_api_hash) => {
            paths::write_atomic_no_follow(
                public_api_hash_path,
                serde_json::to_vec(&public_api_hash)?,
            )?;
        }
        PublicApiHashUpdate::Remove => {
            if public_api_hash_path.exists() {
                paths::remove_file(public_api_hash_path)?;
            }
        }
    }
    Ok(())
}

/// Prepare for work when a package starts to build
pub fn prepare_init(build_runner: &mut BuildRunner<'_, '_>, unit: &Unit) -> CargoResult<()> {
    let new1 = build_runner.files().fingerprint_dir(unit);

    if !new1.exists()
        && (!unit.mode.is_doc_test() || super::cached_doctests::enabled(build_runner.bcx, unit))
    {
        paths::create_dir_all(&new1)?;
    }

    Ok(())
}

/// Returns the location that the dep-info file will show up at
/// for the [`Unit`] specified.
pub fn dep_info_loc(build_runner: &BuildRunner<'_, '_>, unit: &Unit) -> PathBuf {
    build_runner.files().fingerprint_file_path(unit, "dep-")
}

/// Reads the value from the old fingerprint hash file and compare.
///
/// If dirty, it then restores the detailed information
/// from the fingerprint JSON file, and provides an rich dirty reason.
fn compare_old_fingerprint(
    unit: &Unit,
    old_hash_path: &Path,
    new_fingerprint: &Fingerprint,
    mtime_on_use: bool,
    forced: bool,
) -> FingerprintComparison {
    if mtime_on_use {
        // update the mtime so other cleaners know we used it
        let t = FileTime::from_system_time(SystemTime::now());
        debug!("mtime-on-use forcing {:?} to {}", old_hash_path, t);
        paths::set_file_time_no_err(old_hash_path, t);
    }

    let compare = _compare_old_fingerprint(old_hash_path, new_fingerprint);

    match compare.as_ref() {
        Ok(FingerprintComparison::Fresh) => {}
        Ok(FingerprintComparison::Dirty { reason }) => {
            info!(
                "fingerprint dirty for {}/{:?}/{:?}",
                unit.pkg, unit.mode, unit.target,
            );
            info!("    dirty: {reason:?}");
        }
        Err(e) => {
            info!(
                "fingerprint error for {}/{:?}/{:?}",
                unit.pkg, unit.mode, unit.target,
            );
            info!("    err: {e:?}");
        }
    }

    match compare {
        Ok(FingerprintComparison::Fresh) if forced => FingerprintComparison::Dirty {
            reason: DirtyReason::Forced,
        },
        Ok(cmp) => cmp,
        Err(_) => FingerprintComparison::Dirty {
            reason: DirtyReason::FreshBuild,
        },
    }
}

/// Speculatively compares a short file without waiting on a FIFO or reading unbounded data.
fn short_fingerprint_matches(path: &Path, hash: u64) -> bool {
    let mut contents = [0; 16];
    let Some(mut file) = open_regular_file_of_size(path, contents.len() as u64) else {
        return false;
    };
    file.read_exact(&mut contents).is_ok()
        && contents.as_slice() == util::to_hex(hash).as_bytes()
        && matches!(file.read(&mut [0]), Ok(0))
}

fn _compare_old_fingerprint(
    old_hash_path: &Path,
    new_fingerprint: &Fingerprint,
) -> CargoResult<FingerprintComparison> {
    let matched_on_disk = new_fingerprint
        .memoized_hash
        .lock()
        .unwrap()
        .as_mut()
        .is_some_and(|cached| std::mem::take(&mut cached.matched_on_disk));
    if matched_on_disk && new_fingerprint.fs_status.lock().unwrap().up_to_date() {
        return Ok(FingerprintComparison::Fresh);
    }
    let old_fingerprint_short = paths::read(old_hash_path)?;
    let new_hash = new_fingerprint.hash_u64();

    if util::to_hex(new_hash) == old_fingerprint_short
        && new_fingerprint.fs_status.lock().unwrap().up_to_date()
    {
        return Ok(FingerprintComparison::Fresh);
    }

    let old_fingerprint_json = paths::read(&old_hash_path.with_extension("json"))?;
    let old_fingerprint: Fingerprint = serde_json::from_str(&old_fingerprint_json)
        .with_context(|| internal("failed to deserialize json"))?;
    let mut reason = new_fingerprint.compare(&old_fingerprint);
    // A failed rebuild clears the short fingerprint, and interruption can leave the JSON
    // from an older build. Keep its explanation, but only reuse outputs from a matching pair.
    if reason.is_dependency_only()
        && old_fingerprint_short != util::to_hex(old_fingerprint.hash_u64())
    {
        reason = DirtyReason::PreviousBuildIncomplete;
    }

    Ok(FingerprintComparison::Dirty { reason })
}

/// Calculates the fingerprint of a unit thats contains no dep-info files.
fn pkg_fingerprint(bcx: &BuildContext<'_, '_>, pkg: &Package) -> CargoResult<String> {
    let source_id = pkg.package_id().source_id();
    let sources = bcx.packages.sources();

    let source = sources
        .get(source_id)
        .ok_or_else(|| internal("missing package source"))?;
    source.fingerprint(pkg)
}

/// Borrows locally reserved slots for one sequential, scoped checksum batch.
///
/// The mutable BuildRunner and its checksum cache serialize production callers;
/// every worker finishes before another batch can reuse these reservations.
#[derive(Clone, Copy)]
struct ChecksumParallelism<'a> {
    #[cfg(unix)]
    jobserver: &'a jobserver::Client,
    #[cfg(unix)]
    reserved_tokens: &'a [jobserver::Acquired],
    #[cfg(not(unix))]
    _lifetime: std::marker::PhantomData<&'a ()>,
    jobs: u32,
    #[cfg(all(test, unix))]
    workers_started: Option<&'a AtomicUsize>,
}

const MIN_PARALLEL_CHECKSUM_FILES: usize = 128;
type PrefetchedChecksums = std::vec::IntoIter<Option<Result<Checksum, StaleItem>>>;

/// Retains serial observations for mtime checks and post-script revalidation.
fn find_stale_file<I, P>(
    mtime_cache: &mut HashMap<PathBuf, FileTime>,
    checksum_cache: &mut HashMap<PathBuf, Checksum>,
    reference: &Path,
    paths: I,
    use_checksums: bool,
) -> Option<StaleItem>
where
    I: IntoIterator<Item = (P, Option<(u64, Checksum)>)>,
    P: AsRef<Path> + Sync,
{
    find_stale_file_with_parallelism(
        mtime_cache,
        checksum_cache,
        reference,
        paths,
        use_checksums,
        None,
    )
}

/// The ordered consumer selects dirty reasons and commits the checksum-cache prefix.
fn find_stale_file_with_parallelism<I, P>(
    mtime_cache: &mut HashMap<PathBuf, FileTime>,
    checksum_cache: &mut HashMap<PathBuf, Checksum>,
    reference: &Path,
    paths: I,
    use_checksums: bool,
    parallelism: Option<ChecksumParallelism<'_>>,
) -> Option<StaleItem>
where
    I: IntoIterator<Item = (P, Option<(u64, Checksum)>)>,
    P: AsRef<Path> + Sync,
{
    let reference_mtime = match paths::mtime(reference) {
        Ok(mtime) => mtime,
        Err(..) => {
            return Some(StaleItem::MissingFile {
                path: reference.to_path_buf(),
            });
        }
    };

    // Cargo omits immutable package sources when translating the dep-info. A
    // recorded checksum can still name a generated file under CARGO_HOME,
    // including a dependency artifact in a configured build directory.
    let skippable_dirs = if !use_checksums && let Ok(cargo_home) = home::cargo_home() {
        let skippable_dirs: Vec<_> = ["git", "registry"]
            .into_iter()
            .map(|subfolder| cargo_home.join(subfolder))
            .collect();
        Some(skippable_dirs)
    } else {
        None
    };
    let paths = paths.into_iter();
    let (paths, mut prefetched) = if cfg!(unix)
        && use_checksums
        && paths.size_hint().0 >= MIN_PARALLEL_CHECKSUM_FILES
        && parallelism.is_some_and(|parallelism| parallelism.jobs > 1)
    {
        let paths = paths.collect::<Vec<_>>();
        let prefetched = prefetch_checksums(&paths, checksum_cache, parallelism.unwrap());
        (itertools::Either::Left(paths.into_iter()), prefetched)
    } else {
        (itertools::Either::Right(paths), None)
    };
    let mut checksum_buffer = Vec::new();
    for (path, prior_checksum) in paths {
        let prefetched = prefetched.as_mut().and_then(Iterator::next).flatten();
        let path = path.as_ref();

        // Assuming anything in cargo_home/{git, registry} is immutable
        // (see also #9455 about marking the src directory readonly) which avoids rebuilds when CI
        // caches $CARGO_HOME/registry/{index, cache} and $CARGO_HOME/git/db across runs, keeping
        // the content the same but changing the mtime.
        if let Some(ref skippable_dirs) = skippable_dirs {
            if skippable_dirs.iter().any(|dir| path.starts_with(dir)) {
                continue;
            }
        }
        if use_checksums {
            let Some((file_len, prior_checksum)) = prior_checksum else {
                return Some(StaleItem::MissingChecksum {
                    path: path.to_path_buf(),
                });
            };
            let path_buf = path.to_path_buf();

            let path_checksum = match checksum_cache.entry(path_buf) {
                Entry::Occupied(o) => *o.get(),
                Entry::Vacant(v) => {
                    let checksum = prefetched.unwrap_or_else(|| {
                        checksum_metadata(path, file_len)?;
                        let file = File::open(path).map_err(|_| StaleItem::MissingFile {
                            path: path.to_path_buf(),
                        })?;
                        read_checksum(path, prior_checksum, file, &mut checksum_buffer)
                    });
                    match checksum {
                        Ok(checksum) => *v.insert(checksum),
                        Err(item) => return Some(item),
                    }
                }
            };
            if path_checksum == prior_checksum {
                continue;
            }
            return Some(StaleItem::ChangedChecksum {
                source: path.to_path_buf(),
                stored_checksum: prior_checksum,
                new_checksum: path_checksum,
            });
        } else {
            let path_mtime = match mtime_cache.entry(path.to_path_buf()) {
                Entry::Occupied(o) => *o.get(),
                Entry::Vacant(v) => {
                    let Ok(mtime) = paths::mtime_recursive(path) else {
                        return Some(StaleItem::MissingFile {
                            path: path.to_path_buf(),
                        });
                    };
                    *v.insert(mtime)
                }
            };

            // TODO: fix #5918.
            // Note that equal mtimes should be considered "stale". For filesystems with
            // not much timestamp precision like 1s this is would be a conservative approximation
            // to handle the case where a file is modified within the same second after
            // a build starts. We want to make sure that incremental rebuilds pick that up!
            //
            // For filesystems with nanosecond precision it's been seen in the wild that
            // its "nanosecond precision" isn't really nanosecond-accurate. It turns out that
            // kernels may cache the current time so files created at different times actually
            // list the same nanosecond precision. Some digging on #5919 picked up that the
            // kernel caches the current time between timer ticks, which could mean that if
            // a file is updated at most 10ms after a build starts then Cargo may not
            // pick up the build changes.
            //
            // All in all, an equality check here would be a conservative assumption that,
            // if equal, files were changed just after a previous build finished.
            // Unfortunately this became problematic when (in #6484) cargo switch to more accurately
            // measuring the start time of builds.
            if path_mtime <= reference_mtime {
                continue;
            }

            return Some(StaleItem::ChangedFile {
                reference: reference.to_path_buf(),
                reference_mtime,
                stale: path.to_path_buf(),
                stale_mtime: path_mtime,
            });
        }
    }

    debug!(
        "all paths up-to-date relative to {:?} mtime={}",
        reference, reference_mtime
    );
    None
}

/// Checks size before opening a cache miss, preserving the serial dirty reasons.
fn checksum_metadata(path: &Path, expected: u64) -> Result<fs::Metadata, StaleItem> {
    let metadata = fs::metadata(path).map_err(|_| StaleItem::FailedToReadMetadata {
        path: path.to_path_buf(),
    })?;
    if metadata.len() != expected {
        return Err(StaleItem::FileSizeChanged {
            path: path.to_path_buf(),
            new_size: metadata.len(),
            old_size: expected,
        });
    }
    Ok(metadata)
}

/// Reads through EOF with a buffer reused by this serial consumer or worker.
fn read_checksum(
    path: &Path,
    prior: Checksum,
    file: File,
    buffer: &mut Vec<u8>,
) -> Result<Checksum, StaleItem> {
    buffer.resize(64 * 1024, 0);
    Checksum::compute(prior.algo(), file, buffer).map_err(|_| StaleItem::UnableToReadFile {
        path: path.to_path_buf(),
    })
}

/// Rechecks the opened file because a regular input can be replaced after the path lookup.
fn open_regular_file_of_size(path: &Path, expected: u64) -> Option<File> {
    let mut options = File::options();
    options.read(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.custom_flags(libc::O_NONBLOCK | libc::O_NOCTTY);
    }
    let file = options.open(path).ok()?;
    let opened = file.metadata().ok()?;
    (opened.is_file() && opened.len() == expected).then_some(file)
}

/// Opens only regular files speculatively; uncertain reads stay in the serial path.
#[cfg(unix)]
fn prefetch_checksum(
    path: &Path,
    expected: u64,
    prior: Checksum,
    buffer: &mut Vec<u8>,
) -> Option<Result<Checksum, StaleItem>> {
    let metadata = match checksum_metadata(path, expected) {
        Ok(metadata) => metadata,
        Err(item) => return Some(Err(item)),
    };
    if !metadata.is_file() {
        return None;
    }
    let file = open_regular_file_of_size(path, expected)?;
    // A speculative nonblocking read may fail where an ordinary read succeeds.
    // Retry all read errors in the original ordered consumer.
    read_checksum(path, prior, file, buffer).ok().map(Ok)
}

/// Computes isolated results without changing the shared cache or error order.
#[cfg(unix)]
fn prefetch_checksums<P: AsRef<Path> + Sync>(
    paths: &[(P, Option<(u64, Checksum)>)],
    cache: &mut HashMap<PathBuf, Checksum>,
    parallelism: ChecksumParallelism<'_>,
) -> Option<PrefetchedChecksums> {
    let misses = paths
        .iter()
        .filter(|(path, prior)| prior.is_some() && !cache.contains_key(path.as_ref()))
        .count();
    if misses < MIN_PARALLEL_CHECKSUM_FILES {
        return None;
    }
    let all_uncached = misses == paths.len();
    let workers = (parallelism.jobs as usize).min(4).min(misses.div_ceil(64));
    let mut tokens = Vec::new();
    if parallelism.reserved_tokens.is_empty() {
        // Inherited clients keep their existing opportunistic acquisition path.
        for _ in 1..workers {
            match parallelism.jobserver.try_acquire() {
                Ok(Some(token)) => tokens.push(itertools::Either::Right(token)),
                Ok(None) | Err(_) => break,
            }
        }
    } else {
        tokens.extend(
            parallelism
                .reserved_tokens
                .iter()
                .take(workers - 1)
                .map(itertools::Either::Left),
        );
    }
    if tokens.is_empty() {
        return None;
    }

    let first_unconfirmed = AtomicUsize::new(paths.len());
    let mut results = vec![None; paths.len()];
    let chunk_size = paths.len().div_ceil(tokens.len() + 1);
    let read_chunk = |offset: usize,
                      paths: &[(P, Option<(u64, Checksum)>)],
                      results: &mut [Option<Result<Checksum, StaleItem>>]| {
        let mut buffer = Vec::new();
        for (relative, ((path, prior), result)) in paths.iter().zip(results).enumerate() {
            let index = offset + relative;
            if index > first_unconfirmed.load(Ordering::Relaxed) {
                break;
            }
            let path = path.as_ref();
            let Some((expected, prior)) = *prior else {
                first_unconfirmed.fetch_min(index, Ordering::Relaxed);
                continue;
            };
            if !all_uncached && let Some(actual) = cache.get(path) {
                if *actual != prior {
                    first_unconfirmed.fetch_min(index, Ordering::Relaxed);
                }
                continue;
            }
            *result = prefetch_checksum(path, expected, prior, &mut buffer);
            if !matches!(result.as_ref(), Some(Ok(actual)) if *actual == prior) {
                first_unconfirmed.fetch_min(index, Ordering::Relaxed);
            }
        }
    };
    std::thread::scope(|scope| {
        let mut chunks = paths.chunks(chunk_size).zip(results.chunks_mut(chunk_size));
        let (main_paths, main_results) = chunks.next().unwrap();
        for (index, ((paths, results), token)) in chunks.zip(tokens).enumerate() {
            let read_chunk = &read_chunk;
            // Failed creation leaves this chunk empty for the serial consumer.
            let _ = std::thread::Builder::new()
                .name("cargo-checksum".into())
                .spawn_scoped(scope, move || {
                    let _token = token;
                    #[cfg(test)]
                    if let Some(started) = parallelism.workers_started {
                        started.fetch_add(1, Ordering::Relaxed);
                    }
                    read_chunk((index + 1) * chunk_size, paths, results);
                });
        }
        read_chunk(0, main_paths, main_results);
    });
    if first_unconfirmed.into_inner() == paths.len() {
        cache.reserve(misses);
    }
    Some(results.into_iter())
}

#[cfg(not(unix))]
fn prefetch_checksums<P: AsRef<Path> + Sync>(
    _paths: &[(P, Option<(u64, Checksum)>)],
    _cache: &mut HashMap<PathBuf, Checksum>,
    _parallelism: ChecksumParallelism<'_>,
) -> Option<PrefetchedChecksums> {
    None
}

#[cfg(all(test, target_os = "linux"))]
mod parallel_checksum_tests {
    use super::dep_info::ChecksumAlgo;
    use super::*;
    use std::os::unix::ffi::OsStrExt;

    fn checksum(bytes: &[u8]) -> Checksum {
        Checksum::compute(ChecksumAlgo::Blake3, bytes, &mut [0; 64]).unwrap()
    }

    #[test]
    fn checksum_open_follows_symlinks_and_rejects_a_fifo_replacement() {
        let directory = tempfile::tempdir().unwrap();
        let target = directory.path().join("target");
        let link = directory.path().join("link");
        fs::write(&target, b"").unwrap();
        std::os::unix::fs::symlink(&target, &link).unwrap();
        assert!(open_regular_file_of_size(&link, 0).is_some());
        assert!(open_regular_file_of_size(&link, 1).is_none());

        let hash = 123;
        fs::write(&target, util::to_hex(hash)).unwrap();
        assert!(short_fingerprint_matches(&link, hash));
        assert!(!short_fingerprint_matches(&link, hash + 1));
        fs::write(&target, format!("{}0", util::to_hex(hash))).unwrap();
        assert!(!short_fingerprint_matches(&link, hash));

        let fifo = directory.path().join("fifo");
        let name = std::ffi::CString::new(fifo.as_os_str().as_bytes()).unwrap();
        assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
        fs::rename(fifo, target).unwrap();
        let (tx, rx) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let rejected = open_regular_file_of_size(&link, 0).is_none()
                && !short_fingerprint_matches(&link, hash);
            tx.send(rejected).unwrap();
        });
        assert!(rx.recv_timeout(std::time::Duration::from_secs(5)).unwrap());
    }

    fn fixture() -> (
        tempfile::TempDir,
        PathBuf,
        Vec<(PathBuf, Option<(u64, Checksum)>)>,
    ) {
        let directory = tempfile::tempdir().unwrap();
        let reference = directory.path().join("dep-info");
        fs::write(&reference, b"").unwrap();
        let prior = checksum(b"data");
        let paths = (0..256)
            .map(|index| {
                let path = directory.path().join(format!("{index}.rs"));
                fs::write(&path, b"data").unwrap();
                (path, Some((4, prior)))
            })
            .collect();
        (directory, reference, paths)
    }

    fn compare(
        reference: &Path,
        paths: &[(PathBuf, Option<(u64, Checksum)>)],
        initial: &HashMap<PathBuf, Checksum>,
    ) -> (Option<StaleItem>, HashMap<PathBuf, Checksum>) {
        let mut serial = initial.clone();
        let expected = find_stale_file(
            &mut HashMap::default(),
            &mut serial,
            reference,
            paths.iter().map(|(path, prior)| (path, *prior)),
            true,
        );
        let (jobserver, mut reserved_tokens) =
            crate::compiler::build_runner::create_local_jobserver(4, true).unwrap();
        assert_eq!(reserved_tokens.len(), 3);
        assert_eq!(jobserver.available().unwrap(), 0);
        let workers_started = AtomicUsize::new(0);
        let mut parallel = initial.clone();
        let actual = find_stale_file_with_parallelism(
            &mut HashMap::default(),
            &mut parallel,
            reference,
            paths.iter().map(|(path, prior)| (path, *prior)),
            true,
            Some(ChecksumParallelism {
                jobserver: &jobserver,
                reserved_tokens: &reserved_tokens,
                jobs: 4,
                workers_started: Some(&workers_started),
            }),
        );
        assert_eq!(
            serde_json::to_value(&actual).unwrap(),
            serde_json::to_value(&expected).unwrap()
        );
        assert_eq!(parallel, serial);
        assert!(workers_started.load(Ordering::Relaxed) > 0);
        assert_eq!(jobserver.available().unwrap(), 0);
        reserved_tokens.clear();
        assert_eq!(jobserver.available().unwrap(), 3);
        (actual, parallel)
    }

    #[test]
    fn parallel_checksums_prefetch_repeated_batches_and_restore_tokens() {
        let (_directory, _reference, paths) = fixture();
        let (jobserver, mut reserved_tokens) =
            crate::compiler::build_runner::create_local_jobserver(4, true).unwrap();
        assert_eq!(jobserver.available().unwrap(), 0);
        for _ in 0..2 {
            let workers_started = AtomicUsize::new(0);
            let results: Vec<_> = prefetch_checksums(
                &paths,
                &mut HashMap::default(),
                ChecksumParallelism {
                    jobserver: &jobserver,
                    reserved_tokens: &reserved_tokens,
                    jobs: 4,
                    workers_started: Some(&workers_started),
                },
            )
            .expect("eligible inputs must actually enter prefetch")
            .collect();
            assert!(workers_started.load(Ordering::Relaxed) > 0);
            // With at least one extra worker, index 128 is outside the main chunk.
            assert!(matches!(results[128], Some(Ok(_))));
            assert!(
                results.iter().all(
                    |result| matches!(result, Some(Ok(actual)) if *actual == checksum(b"data"))
                )
            );
            assert_eq!(jobserver.available().unwrap(), 0);
        }
        reserved_tokens.clear();
        assert_eq!(jobserver.available().unwrap(), 3);
        let queued_tokens: Vec<_> = (0..3).map(|_| jobserver.acquire().unwrap()).collect();
        assert_eq!(jobserver.available().unwrap(), 0);
        drop(queued_tokens);
        assert_eq!(jobserver.available().unwrap(), 3);
    }

    #[test]
    fn checksum_reservations_respect_jobs_and_checksum_policy() {
        for (jobs, checksums, expected) in [(1, true, 0), (4, false, 0), (4, true, 3), (8, true, 3)]
        {
            let (jobserver, mut reserved_tokens) =
                crate::compiler::build_runner::create_local_jobserver(jobs, checksums).unwrap();
            assert_eq!(reserved_tokens.len(), expected);
            assert_eq!(jobserver.available().unwrap(), jobs as usize - 1 - expected);
            reserved_tokens.clear();
            assert_eq!(jobserver.available().unwrap(), jobs as usize - 1);
        }
    }

    #[test]
    fn parallel_checksums_preserve_fresh_results_and_cache() {
        let (_directory, reference, paths) = fixture();
        let (reason, cache) = compare(&reference, &paths, &HashMap::default());
        assert!(reason.is_none());
        assert_eq!(cache.len(), paths.len());
    }

    #[test]
    fn parallel_checksums_preserve_first_dirty_before_a_fifo() {
        for failure in [
            "checksum",
            "size",
            "missing_checksum",
            "cargo_home_missing_checksum",
            "metadata",
        ] {
            let (_directory, reference, mut paths) = fixture();
            let mut cache = HashMap::default();
            cache.insert(paths[0].0.clone(), checksum(b"data"));
            fs::remove_file(&paths[0].0).unwrap();
            match failure {
                "checksum" => fs::write(&paths[5].0, b"edit").unwrap(),
                "size" => File::options()
                    .write(true)
                    .open(&paths[5].0)
                    .unwrap()
                    .set_len(16 * 1024 * 1024)
                    .unwrap(),
                "missing_checksum" => paths[5].1 = None,
                "cargo_home_missing_checksum" => {
                    paths[5] = (
                        home::cargo_home()
                            .unwrap()
                            .join("registry/__ohm_checksum_test_missing__"),
                        None,
                    );
                }
                "metadata" => fs::remove_file(&paths[5].0).unwrap(),
                _ => unreachable!(),
            }
            let fifo = &mut paths[192];
            fs::remove_file(&fifo.0).unwrap();
            let name = std::ffi::CString::new(fifo.0.as_os_str().as_bytes()).unwrap();
            // SAFETY: `name` is a live, NUL-terminated path and the mode is valid.
            assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
            fifo.1 = Some((0, checksum(b"")));

            let (reason, _) = compare(&reference, &paths, &cache);
            assert!(matches!(
                (failure, reason),
                ("checksum", Some(StaleItem::ChangedChecksum { .. }))
                    | ("size", Some(StaleItem::FileSizeChanged { .. }))
                    | (
                        "missing_checksum" | "cargo_home_missing_checksum",
                        Some(StaleItem::MissingChecksum { .. })
                    )
                    | ("metadata", Some(StaleItem::FailedToReadMetadata { .. }))
            ));
        }
    }
    #[test]
    fn parallel_checksums_preserve_duplicate_path_cache_semantics() {
        let (_directory, reference, mut paths) = fixture();
        let sha256 = Checksum::compute(ChecksumAlgo::Sha256, &b"data"[..], &mut [0; 64]).unwrap();
        paths[192] = (paths[5].0.clone(), Some((999, sha256)));
        let (reason, cache) = compare(&reference, &paths, &HashMap::default());
        assert!(matches!(reason, Some(StaleItem::ChangedChecksum { .. })));
        assert_eq!(cache.len(), 192);
    }
}

#[cfg(test)]
mod worktree_seed_tests {
    use super::*;

    fn fingerprint(namespace: Option<&str>, dep_info: &str) -> Fingerprint {
        let mut fingerprint = Fingerprint::new();
        fingerprint.ohm_worktree_namespace = namespace.map(PathBuf::from);
        *fingerprint.local.get_mut().unwrap() = vec![LocalFingerprint::CheckDepInfo {
            dep_info: PathBuf::from(dep_info),
            checksum: true,
        }];
        *fingerprint.fs_status.get_mut().unwrap() = FsStatus::UpToDate {
            mtimes: HashMap::default(),
            link_mtime: None,
        };
        fingerprint
    }

    #[test]
    fn seeded_dep_info_identity_survives_relocation_and_serialization() {
        let donor_path = "debug/build/workspaces/donor/compiler/pkg/unit/fingerprint/dep-lib-pkg";
        let recipient_path =
            "debug/build/workspaces/recipient/compiler/pkg/unit/fingerprint/dep-lib-pkg";
        let donor = fingerprint(Some("debug/build/workspaces/donor"), donor_path);
        let recipient = fingerprint(Some("debug/build/workspaces/recipient"), recipient_path);
        assert_eq!(donor.hash_u64(), recipient.hash_u64());
        assert!(matches!(
            recipient.compare(&donor),
            DirtyReason::NothingObvious
        ));

        let serialized = serde_json::to_string(&donor).unwrap();
        let restored: Fingerprint = serde_json::from_str(&serialized).unwrap();
        assert_eq!(restored.hash_u64(), recipient.hash_u64());
        let local = restored.local.lock().unwrap();
        assert!(matches!(
            &local[0],
            LocalFingerprint::CheckDepInfo { dep_info, .. } if dep_info == Path::new(donor_path)
        ));
    }

    #[test]
    fn seed_identity_preserves_other_paths_and_checksum_policy() {
        let donor_path = "debug/build/workspaces/donor/compiler/pkg/unit/fingerprint/dep-lib-pkg";
        let recipient_path =
            "debug/build/workspaces/recipient/compiler/pkg/unit/fingerprint/dep-lib-pkg";
        let donor = fingerprint(Some("debug/build/workspaces/donor"), donor_path);
        for other_path in [
            "release/build/workspaces/donor/compiler/pkg/unit/fingerprint/dep-lib-pkg",
            "debug/build/workspaces/donor/other-compiler/pkg/unit/fingerprint/dep-lib-pkg",
            "debug/build/workspaces/donor/compiler/pkg/other-unit/fingerprint/dep-lib-pkg",
            recipient_path,
        ] {
            let other = fingerprint(Some("debug/build/workspaces/donor"), other_path);
            assert_ne!(donor.hash_u64(), other.hash_u64());
        }
        let mut timestamp = fingerprint(Some("debug/build/workspaces/donor"), donor_path);
        if let LocalFingerprint::CheckDepInfo { checksum, .. } =
            &mut timestamp.local.get_mut().unwrap()[0]
        {
            *checksum = false;
        }
        assert_ne!(donor.hash_u64(), timestamp.hash_u64());

        // Ordinary fingerprints retain path identity and omit the new field.
        let ordinary = fingerprint(None, donor_path);
        assert_ne!(
            ordinary.hash_u64(),
            fingerprint(None, recipient_path).hash_u64()
        );
        assert!(
            serde_json::to_value(ordinary)
                .unwrap()
                .get("ohm_worktree_namespace")
                .is_none()
        );
    }
}

#[cfg(test)]
mod early_cutoff_tests {
    use super::*;
    use std::sync::Arc;

    fn rustflags(flags: &[&str]) -> Vec<String> {
        flags.iter().map(|flag| (*flag).to_owned()).collect()
    }

    #[test]
    fn public_api_hash_rustflags() {
        assert!(rustflags_enable_public_api_hash(&rustflags(&[
            "-Zpublic-api-hash",
        ])));
        assert!(rustflags_enable_public_api_hash(&rustflags(&[
            "-Z",
            "public-api-hash=yes",
        ])));
        assert!(rustflags_enable_public_api_hash(&rustflags(&[
            "-Zpublic_api_hash=yes",
        ])));
        assert!(rustflags_enable_public_api_hash(&rustflags(&[
            "-Z",
            "public_api_hash",
        ])));
        assert!(!rustflags_enable_public_api_hash(&rustflags(&[
            "-Zpublic-api-hash",
            "-Zpublic-api-hash=no",
        ])));
        assert!(!rustflags_enable_public_api_hash(&rustflags(&[
            "-Zpublic-api-hash=yes",
            "-Zpublic_api_hash=no",
        ])));
        assert!(rustflags_enable_public_api_hash(&rustflags(&[
            "-Zpublic_api_hash=no",
            "-Zpublic-api-hash=yes",
        ])));
        assert!(!rustflags_enable_public_api_hash(&rustflags(&[
            "-Z",
            "public-api-hashing",
        ])));
    }

    #[test]
    fn public_api_hash_format() {
        assert_eq!(
            PublicApiHash::new(1, "0123456789ABCDEF0123456789ABCDEF"),
            Some(PublicApiHash {
                version: 1,
                value: "0123456789abcdef0123456789abcdef".to_owned(),
            })
        );
        assert_eq!(
            PublicApiHash::new(2, "0123456789abcdef0123456789abcdef"),
            None
        );
        assert_eq!(PublicApiHash::new(1, "0123456789abcdef"), None);
        assert_eq!(
            PublicApiHash::new(1, "0123456789abcdef0123456789abcdeg"),
            None
        );
    }

    /// Creates a fingerprint with the given FsStatus and BuildState.
    fn make_fingerprint(fs_status: FsStatus, build_state: BuildState) -> Arc<Fingerprint> {
        let mut fp = Fingerprint::new();
        *fp.fs_status.get_mut().unwrap() = fs_status;
        *fp.build_state.get_mut().unwrap() = build_state;
        Arc::new(fp)
    }

    fn make_indexed_fingerprint(
        index: UnitIndex,
        fs_status: FsStatus,
        build_state: BuildState,
    ) -> Arc<Fingerprint> {
        let mut fingerprint = Fingerprint::new();
        fingerprint.index = index;
        *fingerprint.fs_status.get_mut().unwrap() = fs_status;
        *fingerprint.build_state.get_mut().unwrap() = build_state;
        Arc::new(fingerprint)
    }

    /// Creates a fingerprint that is stale due to a dependency.
    fn make_stale_due_to_dep() -> Fingerprint {
        let mut fp = Fingerprint::new();
        *fp.fs_status.get_mut().unwrap() = FsStatus::StaleDepFingerprint {
            unit: UnitIndex::default(),
        };
        fp.set_early_cutoff_candidate(true);
        fp
    }

    fn make_dep_fingerprint(fp: Arc<Fingerprint>) -> DepFingerprint {
        DepFingerprint {
            pkg_id: 0,
            name: InternedString::new("test_dep"),
            public: false,
            only_requires_rmeta: true,
            fingerprint: fp,
        }
    }

    #[test]
    fn a_short_fingerprint_from_another_build_cannot_authorize_early_cutoff() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("unit");
        let with_dependency = |rustc| {
            let mut dep = Fingerprint::new();
            dep.rustc = rustc;
            let mut fp = make_stale_due_to_dep();
            fp.rustc = 1;
            fp.deps.push(make_dep_fingerprint(Arc::new(dep)));
            fp
        };
        let previous = with_dependency(1);
        let current = with_dependency(2);
        write_fingerprint(&path, &previous).unwrap();
        // Simulate interruption after the new short hash is written, before the JSON.
        std::fs::write(&path, util::to_hex(current.hash_u64())).unwrap();
        assert!(matches!(
            _compare_old_fingerprint(&path, &current).unwrap(),
            FingerprintComparison::Dirty {
                reason: DirtyReason::PreviousBuildIncomplete
            }
        ));
    }

    #[test]
    fn restored_check_metadata_uses_the_build_script_result_generation() {
        let dir = tempfile::tempdir().unwrap();
        let stdout = dir.path().join("stdout");
        let out = dir.path().join("out");
        std::fs::create_dir(&out).unwrap();
        std::fs::write(&stdout, "").unwrap();
        let invoked = FileTime::from_unix_time(1, 0);
        filetime::set_file_mtime(&stdout, invoked).unwrap();
        let result = worktree::record_script_result(
            &dir.path().join(OHM_WORKTREE_SCRIPT_RESULT),
            &stdout,
            &out,
            &crate::compiler::BuildOutput::default(),
            None,
        )
        .unwrap()
        .unwrap();
        let generation = result.generation;
        let mut script = Fingerprint::new();
        script.outputs.push(stdout);
        *script.script_result.get_mut().unwrap() = Some(result);
        let mut dep = make_dep_fingerprint(Arc::new(script));
        dep.only_requires_rmeta = false;
        let mut check = Fingerprint::new();
        check.deps.push(dep);

        assert_eq!(restored_metadata_mtime(&check, invoked), Some(generation));
    }

    #[test]
    fn a_late_leaf_marker_blocks_transitive_native_seed_reuse() {
        let mut leaf = Fingerprint::new();
        leaf.index = UnitIndex(1);
        let leaf = Arc::new(leaf);
        let mut mid = Fingerprint::new();
        mid.index = UnitIndex(2);
        mid.deps.push(make_dep_fingerprint(Arc::clone(&leaf)));
        let mut bin = Fingerprint::new();
        bin.index = UnitIndex(3);
        bin.deps.push(make_dep_fingerprint(Arc::new(mid)));
        assert!(!bin.inherited_native_recheck());
        leaf.record_native_link_inputs(true);
        assert!(bin.inherited_native_recheck());
    }

    #[test]
    fn skipped_rlib_only_keeps_a_current_timestamp() {
        let dir = tempfile::tempdir().unwrap();
        let rmeta = dir.path().join("leaf.rmeta");
        let rlib = dir.path().join("middle.rlib");
        std::fs::write(&rmeta, "").unwrap();
        std::fs::write(&rlib, "").unwrap();
        let mut leaf = Fingerprint::new();
        leaf.outputs.push(rmeta.clone());
        let mut middle = Fingerprint::new();
        middle.deps.push(make_dep_fingerprint(Arc::new(leaf)));
        filetime::set_file_mtime(&rlib, FileTime::from_unix_time(2, 0)).unwrap();
        filetime::set_file_mtime(&rmeta, FileTime::from_unix_time(1, 0)).unwrap();
        assert!(can_preserve_skipped_output(&middle, &rlib));
        filetime::set_file_mtime(&rmeta, FileTime::from_unix_time(3, 0)).unwrap();
        assert!(!can_preserve_skipped_output(&middle, &rlib));
    }

    #[test]
    fn unit_not_stale_due_to_dep_should_not_cutoff() {
        // Unit is stale for its own reasons (Stale), not due to a dependency
        let fp = make_fingerprint(FsStatus::Stale, BuildState::Pending);
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn unit_stale_item_should_not_cutoff() {
        // Unit is stale due to StaleItem (source changed), not a dependency
        let dep = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let mut fp = Fingerprint::new();
        *fp.fs_status.get_mut().unwrap() = FsStatus::StaleItem(StaleItem::MissingFile {
            path: PathBuf::from("/some/file"),
        });
        fp.deps.push(make_dep_fingerprint(dep));
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn simultaneous_local_and_dependency_changes_are_not_candidates() {
        let mut fp = Fingerprint::new();
        *fp.fs_status.get_mut().unwrap() = FsStatus::StaleItem(StaleItem::ChangedFile {
            reference: PathBuf::from("target/dep-info"),
            reference_mtime: FileTime::zero(),
            stale: PathBuf::from("src/lib.rs"),
            stale_mtime: FileTime::from_unix_time(1, 0),
        });

        // The dependency fingerprint can differ at the same time as this
        // crate's source. Local filesystem status must take precedence.
        assert!(!is_early_cutoff_candidate(
            &fp,
            &DirtyReason::UnitDependencyInfoChanged {
                unit: UnitIndex::default(),
            },
        ));
    }

    #[test]
    fn non_dependency_dirty_reason_is_not_a_candidate() {
        let fp = make_stale_due_to_dep();
        assert!(!is_early_cutoff_candidate(&fp, &DirtyReason::Forced));
        assert!(!is_early_cutoff_candidate(
            &fp,
            &DirtyReason::ProfileConfigurationChanged,
        ));
    }

    #[test]
    fn public_api_hash_is_not_advanced_before_fingerprint_commit() {
        let temp_dir = tempfile::tempdir().unwrap();
        let public_api_hash_path = temp_dir.path().join("unit.public-api-hash");
        let old_public_api_hash =
            PublicApiHash::new(1, "11111111111111111111111111111111").unwrap();
        let old_public_api_hash_contents = serde_json::to_vec(&old_public_api_hash).unwrap();
        paths::write(&public_api_hash_path, &old_public_api_hash_contents).unwrap();

        let mut fingerprint = Fingerprint::new();
        fingerprint.rustc = 1;
        let missing_parent_fingerprint = temp_dir.path().join("missing").join("unit");
        assert!(
            write_fingerprint_and_public_api_hash(
                &missing_parent_fingerprint,
                &fingerprint,
                &public_api_hash_path,
                PublicApiHashUpdate::Write(
                    PublicApiHash::new(1, "22222222222222222222222222222222").unwrap(),
                ),
            )
            .is_err()
        );
        assert_eq!(
            fs::read(public_api_hash_path).unwrap(),
            old_public_api_hash_contents
        );
    }

    #[cfg(unix)]
    #[test]
    fn public_api_hash_replaces_a_symlink() {
        let dir = tempfile::tempdir().unwrap();
        let target = dir.path().join("target");
        let sidecar = dir.path().join("unit.public-api-hash");
        fs::write(&target, "keep").unwrap();
        std::os::unix::fs::symlink(&target, &sidecar).unwrap();
        let mut fingerprint = Fingerprint::new();
        fingerprint.rustc = 1;
        let hash = PublicApiHash::new(1, "11111111111111111111111111111111").unwrap();

        write_fingerprint_and_public_api_hash(
            &dir.path().join("unit"),
            &fingerprint,
            &sidecar,
            PublicApiHashUpdate::Write(hash),
        )
        .unwrap();
        assert_eq!(fs::read(target).unwrap(), b"keep");
        assert!(read_public_api_hash(&sidecar).is_some());
    }

    #[test]
    fn committed_short_hash_only_validates_one_current_comparison() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("lib-example");
        let fresh = || FsStatus::UpToDate {
            mtimes: HashMap::default(),
            link_mtime: None,
        };
        let mut fingerprint = Fingerprint::new();
        fingerprint.rustc = 1;
        *fingerprint.fs_status.get_mut().unwrap() = fresh();
        write_fingerprint(&path, &fingerprint).unwrap();
        let hash = fingerprint.hash_u64();
        let record_match = || {
            *fingerprint.memoized_hash.lock().unwrap() = Some(MemoizedHash {
                value: hash,
                matched_on_disk: true,
            });
        };
        let is_fresh = || {
            matches!(
                _compare_old_fingerprint(&path, &fingerprint).unwrap(),
                FingerprintComparison::Fresh
            )
        };

        record_match();
        assert!(is_fresh());
        let mut different = Fingerprint::new();
        different.rustc = 2;
        write_fingerprint(&path, &different).unwrap();
        assert!(!is_fresh());

        write_fingerprint(&path, &fingerprint).unwrap();
        record_match();
        *fingerprint.fs_status.lock().unwrap() = FsStatus::Stale;
        assert!(!is_fresh());

        *fingerprint.fs_status.lock().unwrap() = fresh();
        record_match();
        fingerprint.clear_memoized();
        paths::write(&path, b"").unwrap();
        assert!(!is_fresh());
    }

    #[test]
    fn up_to_date_unit_should_not_cutoff() {
        // Unit is already up-to-date, no early cutoff needed
        let fp = make_fingerprint(
            FsStatus::UpToDate {
                mtimes: HashMap::default(),
                link_mtime: None,
            },
            BuildState::Fresh,
        );
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn dep_pending_should_not_cutoff() {
        // Dep hasn't been built yet
        let dep = make_fingerprint(FsStatus::Stale, BuildState::Pending);
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep));
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn dep_built_changed_should_not_cutoff() {
        // Dep was built but output changed
        let dep = make_fingerprint(FsStatus::Stale, BuildState::BuiltChanged);
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep));
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn changed_or_pending_metadata_dependency_propagates_through_unchanged_public_api() {
        for state in [BuildState::BuiltChanged, BuildState::Pending] {
            let dependency = make_fingerprint(FsStatus::Stale, state);
            let mut fingerprint = make_stale_due_to_dep();
            fingerprint.deps.push(make_dep_fingerprint(dependency));

            assert!(metadata_dependency_may_have_changed(&fingerprint));
        }
    }

    #[test]
    fn previously_changed_metadata_dependency_propagates_through_unchanged_public_api() {
        let dependency = make_fingerprint(
            FsStatus::UpToDate {
                mtimes: HashMap::default(),
                link_mtime: None,
            },
            BuildState::Fresh,
        );
        let mut fingerprint = make_stale_due_to_dep();
        fingerprint.deps.push(make_dep_fingerprint(dependency));
        fingerprint
            .previously_changed_metadata_dependency
            .store(true, Ordering::Release);

        assert!(metadata_dependency_may_have_changed(&fingerprint));
    }

    #[test]
    fn changed_full_artifact_dependency_does_not_propagate_metadata_only_state() {
        let dependency = make_fingerprint(FsStatus::Stale, BuildState::BuiltChanged);
        let mut dependency = make_dep_fingerprint(dependency);
        dependency.only_requires_rmeta = false;
        let mut fingerprint = make_stale_due_to_dep();
        fingerprint.deps.push(dependency);

        assert!(!metadata_dependency_may_have_changed(&fingerprint));
    }

    #[test]
    fn unchanged_metadata_dependency_does_not_propagate_changed_state() {
        let dependency = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let mut fingerprint = make_stale_due_to_dep();
        fingerprint.deps.push(make_dep_fingerprint(dependency));

        assert!(!metadata_dependency_may_have_changed(&fingerprint));
    }

    #[test]
    fn dep_built_unchanged_should_cutoff() {
        // Dep was built but output didn't change - early cutoff!
        let dep = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep));
        assert!(can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn rebuilt_full_artifact_dependency_should_not_cutoff() {
        let dep = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let mut dep = make_dep_fingerprint(dep);
        dep.only_requires_rmeta = false;
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(dep);
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn rebuilt_library_dependency_can_relink() {
        let dependency =
            make_indexed_fingerprint(UnitIndex(1), FsStatus::Stale, BuildState::BuiltUnchanged);
        let mut fingerprint = make_stale_due_to_dep();
        fingerprint.deps.push(make_dep_fingerprint(dependency));

        assert!(can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::from_iter([UnitIndex(1)]),
        ));
    }

    #[test]
    fn rebuilt_non_library_dependency_cannot_relink() {
        let dependency =
            make_indexed_fingerprint(UnitIndex(1), FsStatus::Stale, BuildState::BuiltUnchanged);
        let mut fingerprint = make_stale_due_to_dep();
        fingerprint.deps.push(make_dep_fingerprint(dependency));

        assert!(!can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::default(),
        ));
    }

    #[test]
    fn changed_unused_package_library_can_relink_only_if_other_dependencies_are_fresh() {
        let mut fingerprint = make_stale_due_to_dep();
        let dependency =
            make_indexed_fingerprint(UnitIndex(1), FsStatus::Stale, BuildState::BuiltChanged);
        fingerprint.deps.push(make_dep_fingerprint(dependency));
        assert!(can_relink_unused_integration_dependency(
            &fingerprint,
            UnitIndex(1)
        ));
        assert!(!can_relink_unused_integration_dependency(
            &fingerprint,
            UnitIndex(2)
        ));

        let other = make_indexed_fingerprint(
            UnitIndex(2),
            FsStatus::Stale,
            BuildState::SkippedEarlyCutoff,
        );
        fingerprint.deps.push(make_dep_fingerprint(other));
        assert!(!can_relink_unused_integration_dependency(
            &fingerprint,
            UnitIndex(1)
        ));
    }

    fn fresh_relink_dependency(metadata_mtime: FileTime) -> Arc<Fingerprint> {
        make_indexed_fingerprint(
            UnitIndex(1),
            FsStatus::UpToDate {
                mtimes: HashMap::from_iter([(PathBuf::from("dep.rmeta"), metadata_mtime)]),
                link_mtime: Some(FileTime::from_unix_time(3, 0)),
            },
            BuildState::Fresh,
        )
    }

    fn stale_due_to_fresh_relink_dependency() -> Fingerprint {
        let mut fingerprint = Fingerprint::new();
        *fingerprint.fs_status.get_mut().unwrap() = FsStatus::StaleDependency {
            unit: UnitIndex(1),
            dep_mtime: FileTime::from_unix_time(3, 0),
            max_mtime: FileTime::from_unix_time(2, 0),
        };
        fingerprint.set_early_cutoff_candidate(true);
        fingerprint
    }

    #[test]
    fn fresh_library_dependency_can_relink_newer_transitive_artifacts() {
        let mut fingerprint = stale_due_to_fresh_relink_dependency();
        fingerprint
            .deps
            .push(make_dep_fingerprint(fresh_relink_dependency(
                FileTime::from_unix_time(1, 0),
            )));

        assert!(can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::from_iter([UnitIndex(1)]),
        ));
    }

    #[test]
    fn fresh_non_library_dependency_cannot_relink_newer_transitive_artifacts() {
        let mut fingerprint = stale_due_to_fresh_relink_dependency();
        fingerprint
            .deps
            .push(make_dep_fingerprint(fresh_relink_dependency(
                FileTime::from_unix_time(1, 0),
            )));

        assert!(!can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::default(),
        ));
    }

    #[test]
    fn fresh_library_dependency_with_newer_metadata_cannot_relink() {
        let mut fingerprint = stale_due_to_fresh_relink_dependency();
        fingerprint
            .deps
            .push(make_dep_fingerprint(fresh_relink_dependency(
                FileTime::from_unix_time(3, 0),
            )));

        assert!(!can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::from_iter([UnitIndex(1)]),
        ));
    }

    #[test]
    fn fresh_library_dependency_with_different_stale_unit_cannot_relink() {
        let mut fingerprint = stale_due_to_fresh_relink_dependency();
        *fingerprint.fs_status.get_mut().unwrap() = FsStatus::StaleDependency {
            unit: UnitIndex(2),
            dep_mtime: FileTime::from_unix_time(3, 0),
            max_mtime: FileTime::from_unix_time(2, 0),
        };
        fingerprint
            .deps
            .push(make_dep_fingerprint(fresh_relink_dependency(
                FileTime::from_unix_time(1, 0),
            )));

        assert!(!can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::from_iter([UnitIndex(1), UnitIndex(2)]),
        ));
    }

    #[test]
    fn rebuilt_changed_dependency_prevents_fresh_transitive_relink() {
        let mut fingerprint = stale_due_to_fresh_relink_dependency();
        fingerprint
            .deps
            .push(make_dep_fingerprint(fresh_relink_dependency(
                FileTime::from_unix_time(1, 0),
            )));
        fingerprint
            .deps
            .push(make_dep_fingerprint(make_indexed_fingerprint(
                UnitIndex(2),
                FsStatus::Stale,
                BuildState::BuiltChanged,
            )));

        assert!(!can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::from_iter([UnitIndex(1), UnitIndex(2)]),
        ));
    }

    #[test]
    fn skipped_library_dependency_can_relink_transitive_artifacts() {
        let dependency = make_indexed_fingerprint(
            UnitIndex(1),
            FsStatus::Stale,
            BuildState::SkippedEarlyCutoff,
        );
        let mut fingerprint = make_stale_due_to_dep();
        fingerprint.deps.push(make_dep_fingerprint(dependency));

        assert!(can_relink_due_to_early_cutoff(
            &fingerprint,
            &HashSet::default(),
        ));
    }

    #[test]
    fn dep_skipped_early_cutoff_should_cutoff() {
        // Dep was skipped via early cutoff - propagates!
        let dep = make_fingerprint(FsStatus::Stale, BuildState::SkippedEarlyCutoff);
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep));
        assert!(can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn dep_fresh_alone_should_not_cutoff() {
        // Dep was fresh - but we need at least one rebuilt-unchanged dep
        let dep = make_fingerprint(
            FsStatus::UpToDate {
                mtimes: HashMap::default(),
                link_mtime: None,
            },
            BuildState::Fresh,
        );
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep));
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn no_deps_should_not_cutoff() {
        // Stale due to dep but no deps - can't cutoff
        let fp = make_stale_due_to_dep();
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn mixed_deps_fresh_and_built_unchanged_should_cutoff() {
        // Some deps fresh, some rebuilt unchanged - should cutoff
        let dep_fresh = make_fingerprint(
            FsStatus::UpToDate {
                mtimes: HashMap::default(),
                link_mtime: None,
            },
            BuildState::Fresh,
        );
        let dep_unchanged = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep_fresh));
        fp.deps.push(make_dep_fingerprint(dep_unchanged));
        assert!(can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn mixed_deps_with_one_pending_should_not_cutoff() {
        // One dep still pending - can't cutoff
        let dep_unchanged = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let dep_pending = make_fingerprint(FsStatus::Stale, BuildState::Pending);
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep_unchanged));
        fp.deps.push(make_dep_fingerprint(dep_pending));
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn mixed_deps_with_one_changed_should_not_cutoff() {
        // One dep changed - can't cutoff
        let dep_unchanged = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let dep_changed = make_fingerprint(FsStatus::Stale, BuildState::BuiltChanged);
        let mut fp = make_stale_due_to_dep();
        fp.deps.push(make_dep_fingerprint(dep_unchanged));
        fp.deps.push(make_dep_fingerprint(dep_changed));
        assert!(!can_skip_due_to_early_cutoff(&fp));
    }

    #[test]
    fn transitive_early_cutoff_propagates() {
        // Scenario: A's source changed, A rebuilt with unchanged output,
        // B depends on A, B skips via early cutoff,
        // C depends on B, C should also skip via early cutoff.

        // A: rebuilt with unchanged output (not directly used in test, documents scenario)
        let _a = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);

        // B: skipped due to early cutoff (depends on A)
        let b = make_fingerprint(FsStatus::Stale, BuildState::SkippedEarlyCutoff);

        // C: stale due to dep, depends on B
        let mut c = make_stale_due_to_dep();
        c.deps.push(make_dep_fingerprint(b));

        // C should be able to skip because B is SkippedEarlyCutoff
        assert!(can_skip_due_to_early_cutoff(&c));
    }

    #[test]
    fn transitive_with_changed_dep_does_not_propagate() {
        // Scenario: A's source changed, A rebuilt with CHANGED output,
        // B depends on A, B must rebuild (output changed),
        // C depends on B, C depends on whether B's output changed.

        // A: rebuilt with changed output (not directly used in test, documents scenario)
        let _a = make_fingerprint(FsStatus::Stale, BuildState::BuiltChanged);

        // B: was stale due to A, but A changed, so B must rebuild
        // If B also has changed output:
        let b = make_fingerprint(FsStatus::Stale, BuildState::BuiltChanged);

        // C: stale due to dep, depends on B
        let mut c = make_stale_due_to_dep();
        c.deps.push(make_dep_fingerprint(b));

        // C cannot skip because B's output changed
        assert!(!can_skip_due_to_early_cutoff(&c));
    }

    #[test]
    fn transitive_chain_all_unchanged() {
        // A → B → C → D, all rebuilt with unchanged output
        // A and B not directly used in test, document the scenario
        let _a = make_fingerprint(FsStatus::Stale, BuildState::BuiltUnchanged);
        let _b = make_fingerprint(FsStatus::Stale, BuildState::SkippedEarlyCutoff);
        let c = make_fingerprint(FsStatus::Stale, BuildState::SkippedEarlyCutoff);

        // D depends on C
        let mut d = make_stale_due_to_dep();
        d.deps.push(make_dep_fingerprint(c));

        assert!(can_skip_due_to_early_cutoff(&d));
    }

    #[test]
    fn diamond_dependency_all_unchanged() {
        // Diamond: A → B, A → C, B → D, C → D
        // If A rebuilt unchanged, both B and C skip, D should also skip

        let b = make_fingerprint(FsStatus::Stale, BuildState::SkippedEarlyCutoff);
        let c = make_fingerprint(FsStatus::Stale, BuildState::SkippedEarlyCutoff);

        // D depends on both B and C
        let mut d = make_stale_due_to_dep();
        d.deps.push(make_dep_fingerprint(b));
        d.deps.push(make_dep_fingerprint(c));

        assert!(can_skip_due_to_early_cutoff(&d));
    }

    #[test]
    fn diamond_dependency_one_changed() {
        // Diamond: A → B, A → C, B → D, C → D
        // If B skipped but C had to rebuild with changed output, D cannot skip

        let b = make_fingerprint(FsStatus::Stale, BuildState::SkippedEarlyCutoff);
        let c = make_fingerprint(FsStatus::Stale, BuildState::BuiltChanged);

        // D depends on both B and C
        let mut d = make_stale_due_to_dep();
        d.deps.push(make_dep_fingerprint(b));
        d.deps.push(make_dep_fingerprint(c));

        assert!(!can_skip_due_to_early_cutoff(&d));
    }
}
