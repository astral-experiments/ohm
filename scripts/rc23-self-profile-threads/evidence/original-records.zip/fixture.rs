pub mod m0 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 17486).rotate_left(12).wrapping_mul(5);
        if x & 7 == 1 { x ^= 17487; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 34875).rotate_left(23).wrapping_mul(7);
        if x & 7 == 2 { x ^= 34876; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 52264).rotate_left(34).wrapping_mul(9);
        if x & 7 == 3 { x ^= 52265; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 69653).rotate_left(45).wrapping_mul(11);
        if x & 7 == 4 { x ^= 69654; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 87042).rotate_left(56).wrapping_mul(13);
        if x & 7 == 5 { x ^= 87043; }
    }
    x
}
}
pub mod m1 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 104431).rotate_left(4).wrapping_mul(15);
        if x & 7 == 6 { x ^= 104432; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 121820).rotate_left(15).wrapping_mul(17);
        if x & 7 == 7 { x ^= 121821; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 139209).rotate_left(26).wrapping_mul(19);
        if x & 7 == 0 { x ^= 139210; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 156598).rotate_left(37).wrapping_mul(21);
        if x & 7 == 1 { x ^= 156599; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 173987).rotate_left(48).wrapping_mul(23);
        if x & 7 == 2 { x ^= 173988; }
    }
    x
}
}
pub mod m2 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 191376).rotate_left(59).wrapping_mul(25);
        if x & 7 == 3 { x ^= 191377; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 208765).rotate_left(7).wrapping_mul(27);
        if x & 7 == 4 { x ^= 208766; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 226154).rotate_left(18).wrapping_mul(29);
        if x & 7 == 5 { x ^= 226155; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 243543).rotate_left(29).wrapping_mul(31);
        if x & 7 == 6 { x ^= 243544; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 260932).rotate_left(40).wrapping_mul(33);
        if x & 7 == 7 { x ^= 260933; }
    }
    x
}
}
pub mod m3 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 278321).rotate_left(51).wrapping_mul(35);
        if x & 7 == 0 { x ^= 278322; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 295710).rotate_left(62).wrapping_mul(37);
        if x & 7 == 1 { x ^= 295711; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 313099).rotate_left(10).wrapping_mul(39);
        if x & 7 == 2 { x ^= 313100; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 330488).rotate_left(21).wrapping_mul(41);
        if x & 7 == 3 { x ^= 330489; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 347877).rotate_left(32).wrapping_mul(43);
        if x & 7 == 4 { x ^= 347878; }
    }
    x
}
}
pub mod m4 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 365266).rotate_left(43).wrapping_mul(45);
        if x & 7 == 5 { x ^= 365267; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 382655).rotate_left(54).wrapping_mul(47);
        if x & 7 == 6 { x ^= 382656; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 400044).rotate_left(2).wrapping_mul(49);
        if x & 7 == 7 { x ^= 400045; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 417433).rotate_left(13).wrapping_mul(51);
        if x & 7 == 0 { x ^= 417434; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 434822).rotate_left(24).wrapping_mul(53);
        if x & 7 == 1 { x ^= 434823; }
    }
    x
}
}
pub mod m5 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 452211).rotate_left(35).wrapping_mul(55);
        if x & 7 == 2 { x ^= 452212; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 469600).rotate_left(46).wrapping_mul(57);
        if x & 7 == 3 { x ^= 469601; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 486989).rotate_left(57).wrapping_mul(59);
        if x & 7 == 4 { x ^= 486990; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 504378).rotate_left(5).wrapping_mul(61);
        if x & 7 == 5 { x ^= 504379; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 521767).rotate_left(16).wrapping_mul(63);
        if x & 7 == 6 { x ^= 521768; }
    }
    x
}
}
pub mod m6 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 539156).rotate_left(27).wrapping_mul(65);
        if x & 7 == 7 { x ^= 539157; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 556545).rotate_left(38).wrapping_mul(67);
        if x & 7 == 0 { x ^= 556546; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 573934).rotate_left(49).wrapping_mul(69);
        if x & 7 == 1 { x ^= 573935; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 591323).rotate_left(60).wrapping_mul(71);
        if x & 7 == 2 { x ^= 591324; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 608712).rotate_left(8).wrapping_mul(73);
        if x & 7 == 3 { x ^= 608713; }
    }
    x
}
}
pub mod m7 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 626101).rotate_left(19).wrapping_mul(75);
        if x & 7 == 4 { x ^= 626102; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 643490).rotate_left(30).wrapping_mul(77);
        if x & 7 == 5 { x ^= 643491; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 660879).rotate_left(41).wrapping_mul(79);
        if x & 7 == 6 { x ^= 660880; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 678268).rotate_left(52).wrapping_mul(81);
        if x & 7 == 7 { x ^= 678269; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 695657).rotate_left(63).wrapping_mul(83);
        if x & 7 == 0 { x ^= 695658; }
    }
    x
}
}
pub mod m8 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 713046).rotate_left(11).wrapping_mul(85);
        if x & 7 == 1 { x ^= 713047; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 730435).rotate_left(22).wrapping_mul(87);
        if x & 7 == 2 { x ^= 730436; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 747824).rotate_left(33).wrapping_mul(89);
        if x & 7 == 3 { x ^= 747825; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 765213).rotate_left(44).wrapping_mul(91);
        if x & 7 == 4 { x ^= 765214; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 782602).rotate_left(55).wrapping_mul(93);
        if x & 7 == 5 { x ^= 782603; }
    }
    x
}
}
pub mod m9 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 799991).rotate_left(3).wrapping_mul(95);
        if x & 7 == 6 { x ^= 799992; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 817380).rotate_left(14).wrapping_mul(97);
        if x & 7 == 7 { x ^= 817381; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 834769).rotate_left(25).wrapping_mul(99);
        if x & 7 == 0 { x ^= 834770; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 852158).rotate_left(36).wrapping_mul(101);
        if x & 7 == 1 { x ^= 852159; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 869547).rotate_left(47).wrapping_mul(103);
        if x & 7 == 2 { x ^= 869548; }
    }
    x
}
}
pub mod m10 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 886936).rotate_left(58).wrapping_mul(105);
        if x & 7 == 3 { x ^= 886937; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 904325).rotate_left(6).wrapping_mul(107);
        if x & 7 == 4 { x ^= 904326; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 921714).rotate_left(17).wrapping_mul(109);
        if x & 7 == 5 { x ^= 921715; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 939103).rotate_left(28).wrapping_mul(111);
        if x & 7 == 6 { x ^= 939104; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 956492).rotate_left(39).wrapping_mul(113);
        if x & 7 == 7 { x ^= 956493; }
    }
    x
}
}
pub mod m11 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 973881).rotate_left(50).wrapping_mul(115);
        if x & 7 == 0 { x ^= 973882; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 991270).rotate_left(61).wrapping_mul(117);
        if x & 7 == 1 { x ^= 991271; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1008659).rotate_left(9).wrapping_mul(119);
        if x & 7 == 2 { x ^= 1008660; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1026048).rotate_left(20).wrapping_mul(121);
        if x & 7 == 3 { x ^= 1026049; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1043437).rotate_left(31).wrapping_mul(123);
        if x & 7 == 4 { x ^= 1043438; }
    }
    x
}
}
pub mod m12 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1060826).rotate_left(42).wrapping_mul(125);
        if x & 7 == 5 { x ^= 1060827; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1078215).rotate_left(53).wrapping_mul(127);
        if x & 7 == 6 { x ^= 1078216; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1095604).rotate_left(1).wrapping_mul(129);
        if x & 7 == 7 { x ^= 1095605; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1112993).rotate_left(12).wrapping_mul(131);
        if x & 7 == 0 { x ^= 1112994; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1130382).rotate_left(23).wrapping_mul(133);
        if x & 7 == 1 { x ^= 1130383; }
    }
    x
}
}
pub mod m13 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1147771).rotate_left(34).wrapping_mul(135);
        if x & 7 == 2 { x ^= 1147772; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1165160).rotate_left(45).wrapping_mul(137);
        if x & 7 == 3 { x ^= 1165161; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1182549).rotate_left(56).wrapping_mul(139);
        if x & 7 == 4 { x ^= 1182550; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1199938).rotate_left(4).wrapping_mul(141);
        if x & 7 == 5 { x ^= 1199939; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1217327).rotate_left(15).wrapping_mul(143);
        if x & 7 == 6 { x ^= 1217328; }
    }
    x
}
}
pub mod m14 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1234716).rotate_left(26).wrapping_mul(145);
        if x & 7 == 7 { x ^= 1234717; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1252105).rotate_left(37).wrapping_mul(147);
        if x & 7 == 0 { x ^= 1252106; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1269494).rotate_left(48).wrapping_mul(149);
        if x & 7 == 1 { x ^= 1269495; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1286883).rotate_left(59).wrapping_mul(151);
        if x & 7 == 2 { x ^= 1286884; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1304272).rotate_left(7).wrapping_mul(153);
        if x & 7 == 3 { x ^= 1304273; }
    }
    x
}
}
pub mod m15 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1321661).rotate_left(18).wrapping_mul(155);
        if x & 7 == 4 { x ^= 1321662; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1339050).rotate_left(29).wrapping_mul(157);
        if x & 7 == 5 { x ^= 1339051; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1356439).rotate_left(40).wrapping_mul(159);
        if x & 7 == 6 { x ^= 1356440; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1373828).rotate_left(51).wrapping_mul(161);
        if x & 7 == 7 { x ^= 1373829; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1391217).rotate_left(62).wrapping_mul(163);
        if x & 7 == 0 { x ^= 1391218; }
    }
    x
}
}
pub mod m16 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1408606).rotate_left(10).wrapping_mul(165);
        if x & 7 == 1 { x ^= 1408607; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1425995).rotate_left(21).wrapping_mul(167);
        if x & 7 == 2 { x ^= 1425996; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1443384).rotate_left(32).wrapping_mul(169);
        if x & 7 == 3 { x ^= 1443385; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1460773).rotate_left(43).wrapping_mul(171);
        if x & 7 == 4 { x ^= 1460774; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1478162).rotate_left(54).wrapping_mul(173);
        if x & 7 == 5 { x ^= 1478163; }
    }
    x
}
}
pub mod m17 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1495551).rotate_left(2).wrapping_mul(175);
        if x & 7 == 6 { x ^= 1495552; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1512940).rotate_left(13).wrapping_mul(177);
        if x & 7 == 7 { x ^= 1512941; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1530329).rotate_left(24).wrapping_mul(179);
        if x & 7 == 0 { x ^= 1530330; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1547718).rotate_left(35).wrapping_mul(181);
        if x & 7 == 1 { x ^= 1547719; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1565107).rotate_left(46).wrapping_mul(183);
        if x & 7 == 2 { x ^= 1565108; }
    }
    x
}
}
pub mod m18 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1582496).rotate_left(57).wrapping_mul(185);
        if x & 7 == 3 { x ^= 1582497; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1599885).rotate_left(5).wrapping_mul(187);
        if x & 7 == 4 { x ^= 1599886; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1617274).rotate_left(16).wrapping_mul(189);
        if x & 7 == 5 { x ^= 1617275; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1634663).rotate_left(27).wrapping_mul(191);
        if x & 7 == 6 { x ^= 1634664; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1652052).rotate_left(38).wrapping_mul(193);
        if x & 7 == 7 { x ^= 1652053; }
    }
    x
}
}
pub mod m19 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1669441).rotate_left(49).wrapping_mul(195);
        if x & 7 == 0 { x ^= 1669442; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1686830).rotate_left(60).wrapping_mul(197);
        if x & 7 == 1 { x ^= 1686831; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1704219).rotate_left(8).wrapping_mul(199);
        if x & 7 == 2 { x ^= 1704220; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1721608).rotate_left(19).wrapping_mul(201);
        if x & 7 == 3 { x ^= 1721609; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1738997).rotate_left(30).wrapping_mul(203);
        if x & 7 == 4 { x ^= 1738998; }
    }
    x
}
}
pub mod m20 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1756386).rotate_left(41).wrapping_mul(205);
        if x & 7 == 5 { x ^= 1756387; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1773775).rotate_left(52).wrapping_mul(207);
        if x & 7 == 6 { x ^= 1773776; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1791164).rotate_left(63).wrapping_mul(209);
        if x & 7 == 7 { x ^= 1791165; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1808553).rotate_left(11).wrapping_mul(211);
        if x & 7 == 0 { x ^= 1808554; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1825942).rotate_left(22).wrapping_mul(213);
        if x & 7 == 1 { x ^= 1825943; }
    }
    x
}
}
pub mod m21 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1843331).rotate_left(33).wrapping_mul(215);
        if x & 7 == 2 { x ^= 1843332; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1860720).rotate_left(44).wrapping_mul(217);
        if x & 7 == 3 { x ^= 1860721; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1878109).rotate_left(55).wrapping_mul(219);
        if x & 7 == 4 { x ^= 1878110; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1895498).rotate_left(3).wrapping_mul(221);
        if x & 7 == 5 { x ^= 1895499; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1912887).rotate_left(14).wrapping_mul(223);
        if x & 7 == 6 { x ^= 1912888; }
    }
    x
}
}
pub mod m22 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1930276).rotate_left(25).wrapping_mul(225);
        if x & 7 == 7 { x ^= 1930277; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1947665).rotate_left(36).wrapping_mul(227);
        if x & 7 == 0 { x ^= 1947666; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1965054).rotate_left(47).wrapping_mul(229);
        if x & 7 == 1 { x ^= 1965055; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1982443).rotate_left(58).wrapping_mul(231);
        if x & 7 == 2 { x ^= 1982444; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 1999832).rotate_left(6).wrapping_mul(233);
        if x & 7 == 3 { x ^= 1999833; }
    }
    x
}
}
pub mod m23 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2017221).rotate_left(17).wrapping_mul(235);
        if x & 7 == 4 { x ^= 2017222; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2034610).rotate_left(28).wrapping_mul(237);
        if x & 7 == 5 { x ^= 2034611; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2051999).rotate_left(39).wrapping_mul(239);
        if x & 7 == 6 { x ^= 2052000; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2069388).rotate_left(50).wrapping_mul(241);
        if x & 7 == 7 { x ^= 2069389; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2086777).rotate_left(61).wrapping_mul(243);
        if x & 7 == 0 { x ^= 2086778; }
    }
    x
}
}
pub mod m24 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2104166).rotate_left(9).wrapping_mul(245);
        if x & 7 == 1 { x ^= 2104167; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2121555).rotate_left(20).wrapping_mul(247);
        if x & 7 == 2 { x ^= 2121556; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2138944).rotate_left(31).wrapping_mul(249);
        if x & 7 == 3 { x ^= 2138945; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2156333).rotate_left(42).wrapping_mul(251);
        if x & 7 == 4 { x ^= 2156334; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2173722).rotate_left(53).wrapping_mul(253);
        if x & 7 == 5 { x ^= 2173723; }
    }
    x
}
}
pub mod m25 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2191111).rotate_left(1).wrapping_mul(255);
        if x & 7 == 6 { x ^= 2191112; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2208500).rotate_left(12).wrapping_mul(257);
        if x & 7 == 7 { x ^= 2208501; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2225889).rotate_left(23).wrapping_mul(259);
        if x & 7 == 0 { x ^= 2225890; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2243278).rotate_left(34).wrapping_mul(261);
        if x & 7 == 1 { x ^= 2243279; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2260667).rotate_left(45).wrapping_mul(263);
        if x & 7 == 2 { x ^= 2260668; }
    }
    x
}
}
pub mod m26 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2278056).rotate_left(56).wrapping_mul(265);
        if x & 7 == 3 { x ^= 2278057; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2295445).rotate_left(4).wrapping_mul(267);
        if x & 7 == 4 { x ^= 2295446; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2312834).rotate_left(15).wrapping_mul(269);
        if x & 7 == 5 { x ^= 2312835; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2330223).rotate_left(26).wrapping_mul(271);
        if x & 7 == 6 { x ^= 2330224; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2347612).rotate_left(37).wrapping_mul(273);
        if x & 7 == 7 { x ^= 2347613; }
    }
    x
}
}
pub mod m27 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2365001).rotate_left(48).wrapping_mul(275);
        if x & 7 == 0 { x ^= 2365002; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2382390).rotate_left(59).wrapping_mul(277);
        if x & 7 == 1 { x ^= 2382391; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2399779).rotate_left(7).wrapping_mul(279);
        if x & 7 == 2 { x ^= 2399780; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2417168).rotate_left(18).wrapping_mul(281);
        if x & 7 == 3 { x ^= 2417169; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2434557).rotate_left(29).wrapping_mul(283);
        if x & 7 == 4 { x ^= 2434558; }
    }
    x
}
}
pub mod m28 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2451946).rotate_left(40).wrapping_mul(285);
        if x & 7 == 5 { x ^= 2451947; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2469335).rotate_left(51).wrapping_mul(287);
        if x & 7 == 6 { x ^= 2469336; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2486724).rotate_left(62).wrapping_mul(289);
        if x & 7 == 7 { x ^= 2486725; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2504113).rotate_left(10).wrapping_mul(291);
        if x & 7 == 0 { x ^= 2504114; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2521502).rotate_left(21).wrapping_mul(293);
        if x & 7 == 1 { x ^= 2521503; }
    }
    x
}
}
pub mod m29 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2538891).rotate_left(32).wrapping_mul(295);
        if x & 7 == 2 { x ^= 2538892; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2556280).rotate_left(43).wrapping_mul(297);
        if x & 7 == 3 { x ^= 2556281; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2573669).rotate_left(54).wrapping_mul(299);
        if x & 7 == 4 { x ^= 2573670; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2591058).rotate_left(2).wrapping_mul(301);
        if x & 7 == 5 { x ^= 2591059; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2608447).rotate_left(13).wrapping_mul(303);
        if x & 7 == 6 { x ^= 2608448; }
    }
    x
}
}
pub mod m30 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2625836).rotate_left(24).wrapping_mul(305);
        if x & 7 == 7 { x ^= 2625837; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2643225).rotate_left(35).wrapping_mul(307);
        if x & 7 == 0 { x ^= 2643226; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2660614).rotate_left(46).wrapping_mul(309);
        if x & 7 == 1 { x ^= 2660615; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2678003).rotate_left(57).wrapping_mul(311);
        if x & 7 == 2 { x ^= 2678004; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2695392).rotate_left(5).wrapping_mul(313);
        if x & 7 == 3 { x ^= 2695393; }
    }
    x
}
}
pub mod m31 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2712781).rotate_left(16).wrapping_mul(315);
        if x & 7 == 4 { x ^= 2712782; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2730170).rotate_left(27).wrapping_mul(317);
        if x & 7 == 5 { x ^= 2730171; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2747559).rotate_left(38).wrapping_mul(319);
        if x & 7 == 6 { x ^= 2747560; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2764948).rotate_left(49).wrapping_mul(321);
        if x & 7 == 7 { x ^= 2764949; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2782337).rotate_left(60).wrapping_mul(323);
        if x & 7 == 0 { x ^= 2782338; }
    }
    x
}
}
pub mod m32 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2799726).rotate_left(8).wrapping_mul(325);
        if x & 7 == 1 { x ^= 2799727; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2817115).rotate_left(19).wrapping_mul(327);
        if x & 7 == 2 { x ^= 2817116; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2834504).rotate_left(30).wrapping_mul(329);
        if x & 7 == 3 { x ^= 2834505; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2851893).rotate_left(41).wrapping_mul(331);
        if x & 7 == 4 { x ^= 2851894; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2869282).rotate_left(52).wrapping_mul(333);
        if x & 7 == 5 { x ^= 2869283; }
    }
    x
}
}
pub mod m33 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2886671).rotate_left(63).wrapping_mul(335);
        if x & 7 == 6 { x ^= 2886672; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2904060).rotate_left(11).wrapping_mul(337);
        if x & 7 == 7 { x ^= 2904061; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2921449).rotate_left(22).wrapping_mul(339);
        if x & 7 == 0 { x ^= 2921450; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2938838).rotate_left(33).wrapping_mul(341);
        if x & 7 == 1 { x ^= 2938839; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2956227).rotate_left(44).wrapping_mul(343);
        if x & 7 == 2 { x ^= 2956228; }
    }
    x
}
}
pub mod m34 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2973616).rotate_left(55).wrapping_mul(345);
        if x & 7 == 3 { x ^= 2973617; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 2991005).rotate_left(3).wrapping_mul(347);
        if x & 7 == 4 { x ^= 2991006; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3008394).rotate_left(14).wrapping_mul(349);
        if x & 7 == 5 { x ^= 3008395; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3025783).rotate_left(25).wrapping_mul(351);
        if x & 7 == 6 { x ^= 3025784; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3043172).rotate_left(36).wrapping_mul(353);
        if x & 7 == 7 { x ^= 3043173; }
    }
    x
}
}
pub mod m35 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3060561).rotate_left(47).wrapping_mul(355);
        if x & 7 == 0 { x ^= 3060562; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3077950).rotate_left(58).wrapping_mul(357);
        if x & 7 == 1 { x ^= 3077951; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3095339).rotate_left(6).wrapping_mul(359);
        if x & 7 == 2 { x ^= 3095340; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3112728).rotate_left(17).wrapping_mul(361);
        if x & 7 == 3 { x ^= 3112729; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3130117).rotate_left(28).wrapping_mul(363);
        if x & 7 == 4 { x ^= 3130118; }
    }
    x
}
}
pub mod m36 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3147506).rotate_left(39).wrapping_mul(365);
        if x & 7 == 5 { x ^= 3147507; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3164895).rotate_left(50).wrapping_mul(367);
        if x & 7 == 6 { x ^= 3164896; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3182284).rotate_left(61).wrapping_mul(369);
        if x & 7 == 7 { x ^= 3182285; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3199673).rotate_left(9).wrapping_mul(371);
        if x & 7 == 0 { x ^= 3199674; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3217062).rotate_left(20).wrapping_mul(373);
        if x & 7 == 1 { x ^= 3217063; }
    }
    x
}
}
pub mod m37 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3234451).rotate_left(31).wrapping_mul(375);
        if x & 7 == 2 { x ^= 3234452; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3251840).rotate_left(42).wrapping_mul(377);
        if x & 7 == 3 { x ^= 3251841; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3269229).rotate_left(53).wrapping_mul(379);
        if x & 7 == 4 { x ^= 3269230; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3286618).rotate_left(1).wrapping_mul(381);
        if x & 7 == 5 { x ^= 3286619; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3304007).rotate_left(12).wrapping_mul(383);
        if x & 7 == 6 { x ^= 3304008; }
    }
    x
}
}
pub mod m38 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3321396).rotate_left(23).wrapping_mul(385);
        if x & 7 == 7 { x ^= 3321397; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3338785).rotate_left(34).wrapping_mul(387);
        if x & 7 == 0 { x ^= 3338786; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3356174).rotate_left(45).wrapping_mul(389);
        if x & 7 == 1 { x ^= 3356175; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3373563).rotate_left(56).wrapping_mul(391);
        if x & 7 == 2 { x ^= 3373564; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3390952).rotate_left(4).wrapping_mul(393);
        if x & 7 == 3 { x ^= 3390953; }
    }
    x
}
}
pub mod m39 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3408341).rotate_left(15).wrapping_mul(395);
        if x & 7 == 4 { x ^= 3408342; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3425730).rotate_left(26).wrapping_mul(397);
        if x & 7 == 5 { x ^= 3425731; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3443119).rotate_left(37).wrapping_mul(399);
        if x & 7 == 6 { x ^= 3443120; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3460508).rotate_left(48).wrapping_mul(401);
        if x & 7 == 7 { x ^= 3460509; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3477897).rotate_left(59).wrapping_mul(403);
        if x & 7 == 0 { x ^= 3477898; }
    }
    x
}
}
pub mod m40 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3495286).rotate_left(7).wrapping_mul(405);
        if x & 7 == 1 { x ^= 3495287; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3512675).rotate_left(18).wrapping_mul(407);
        if x & 7 == 2 { x ^= 3512676; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3530064).rotate_left(29).wrapping_mul(409);
        if x & 7 == 3 { x ^= 3530065; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3547453).rotate_left(40).wrapping_mul(411);
        if x & 7 == 4 { x ^= 3547454; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3564842).rotate_left(51).wrapping_mul(413);
        if x & 7 == 5 { x ^= 3564843; }
    }
    x
}
}
pub mod m41 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3582231).rotate_left(62).wrapping_mul(415);
        if x & 7 == 6 { x ^= 3582232; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3599620).rotate_left(10).wrapping_mul(417);
        if x & 7 == 7 { x ^= 3599621; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3617009).rotate_left(21).wrapping_mul(419);
        if x & 7 == 0 { x ^= 3617010; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3634398).rotate_left(32).wrapping_mul(421);
        if x & 7 == 1 { x ^= 3634399; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3651787).rotate_left(43).wrapping_mul(423);
        if x & 7 == 2 { x ^= 3651788; }
    }
    x
}
}
pub mod m42 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3669176).rotate_left(54).wrapping_mul(425);
        if x & 7 == 3 { x ^= 3669177; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3686565).rotate_left(2).wrapping_mul(427);
        if x & 7 == 4 { x ^= 3686566; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3703954).rotate_left(13).wrapping_mul(429);
        if x & 7 == 5 { x ^= 3703955; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3721343).rotate_left(24).wrapping_mul(431);
        if x & 7 == 6 { x ^= 3721344; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3738732).rotate_left(35).wrapping_mul(433);
        if x & 7 == 7 { x ^= 3738733; }
    }
    x
}
}
pub mod m43 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3756121).rotate_left(46).wrapping_mul(435);
        if x & 7 == 0 { x ^= 3756122; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3773510).rotate_left(57).wrapping_mul(437);
        if x & 7 == 1 { x ^= 3773511; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3790899).rotate_left(5).wrapping_mul(439);
        if x & 7 == 2 { x ^= 3790900; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3808288).rotate_left(16).wrapping_mul(441);
        if x & 7 == 3 { x ^= 3808289; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3825677).rotate_left(27).wrapping_mul(443);
        if x & 7 == 4 { x ^= 3825678; }
    }
    x
}
}
pub mod m44 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3843066).rotate_left(38).wrapping_mul(445);
        if x & 7 == 5 { x ^= 3843067; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3860455).rotate_left(49).wrapping_mul(447);
        if x & 7 == 6 { x ^= 3860456; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3877844).rotate_left(60).wrapping_mul(449);
        if x & 7 == 7 { x ^= 3877845; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3895233).rotate_left(8).wrapping_mul(451);
        if x & 7 == 0 { x ^= 3895234; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3912622).rotate_left(19).wrapping_mul(453);
        if x & 7 == 1 { x ^= 3912623; }
    }
    x
}
}
pub mod m45 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3930011).rotate_left(30).wrapping_mul(455);
        if x & 7 == 2 { x ^= 3930012; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3947400).rotate_left(41).wrapping_mul(457);
        if x & 7 == 3 { x ^= 3947401; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3964789).rotate_left(52).wrapping_mul(459);
        if x & 7 == 4 { x ^= 3964790; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3982178).rotate_left(63).wrapping_mul(461);
        if x & 7 == 5 { x ^= 3982179; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 3999567).rotate_left(11).wrapping_mul(463);
        if x & 7 == 6 { x ^= 3999568; }
    }
    x
}
}
pub mod m46 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4016956).rotate_left(22).wrapping_mul(465);
        if x & 7 == 7 { x ^= 4016957; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4034345).rotate_left(33).wrapping_mul(467);
        if x & 7 == 0 { x ^= 4034346; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4051734).rotate_left(44).wrapping_mul(469);
        if x & 7 == 1 { x ^= 4051735; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4069123).rotate_left(55).wrapping_mul(471);
        if x & 7 == 2 { x ^= 4069124; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4086512).rotate_left(3).wrapping_mul(473);
        if x & 7 == 3 { x ^= 4086513; }
    }
    x
}
}
pub mod m47 {
#[inline(never)]
pub fn f0(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4103901).rotate_left(14).wrapping_mul(475);
        if x & 7 == 4 { x ^= 4103902; }
    }
    x
}
#[inline(never)]
pub fn f1(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4121290).rotate_left(25).wrapping_mul(477);
        if x & 7 == 5 { x ^= 4121291; }
    }
    x
}
#[inline(never)]
pub fn f2(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4138679).rotate_left(36).wrapping_mul(479);
        if x & 7 == 6 { x ^= 4138680; }
    }
    x
}
#[inline(never)]
pub fn f3(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4156068).rotate_left(47).wrapping_mul(481);
        if x & 7 == 7 { x ^= 4156069; }
    }
    x
}
#[inline(never)]
pub fn f4(mut x: u64) -> u64 {
    for j in 0..29u64 {
        x = std::hint::black_box(x).wrapping_add(j ^ 4173457).rotate_left(58).wrapping_mul(483);
        if x & 7 == 0 { x ^= 4173458; }
    }
    x
}
}
pub fn exercise(mut x:u64)->u64 {
x = m0::f0(x);
x = m0::f1(x);
x = m0::f2(x);
x = m0::f3(x);
x = m0::f4(x);
x = m1::f0(x);
x = m1::f1(x);
x = m1::f2(x);
x = m1::f3(x);
x = m1::f4(x);
x = m2::f0(x);
x = m2::f1(x);
x = m2::f2(x);
x = m2::f3(x);
x = m2::f4(x);
x = m3::f0(x);
x = m3::f1(x);
x = m3::f2(x);
x = m3::f3(x);
x = m3::f4(x);
x = m4::f0(x);
x = m4::f1(x);
x = m4::f2(x);
x = m4::f3(x);
x = m4::f4(x);
x = m5::f0(x);
x = m5::f1(x);
x = m5::f2(x);
x = m5::f3(x);
x = m5::f4(x);
x = m6::f0(x);
x = m6::f1(x);
x = m6::f2(x);
x = m6::f3(x);
x = m6::f4(x);
x = m7::f0(x);
x = m7::f1(x);
x = m7::f2(x);
x = m7::f3(x);
x = m7::f4(x);
x = m8::f0(x);
x = m8::f1(x);
x = m8::f2(x);
x = m8::f3(x);
x = m8::f4(x);
x = m9::f0(x);
x = m9::f1(x);
x = m9::f2(x);
x = m9::f3(x);
x = m9::f4(x);
x = m10::f0(x);
x = m10::f1(x);
x = m10::f2(x);
x = m10::f3(x);
x = m10::f4(x);
x = m11::f0(x);
x = m11::f1(x);
x = m11::f2(x);
x = m11::f3(x);
x = m11::f4(x);
x = m12::f0(x);
x = m12::f1(x);
x = m12::f2(x);
x = m12::f3(x);
x = m12::f4(x);
x = m13::f0(x);
x = m13::f1(x);
x = m13::f2(x);
x = m13::f3(x);
x = m13::f4(x);
x = m14::f0(x);
x = m14::f1(x);
x = m14::f2(x);
x = m14::f3(x);
x = m14::f4(x);
x = m15::f0(x);
x = m15::f1(x);
x = m15::f2(x);
x = m15::f3(x);
x = m15::f4(x);
x = m16::f0(x);
x = m16::f1(x);
x = m16::f2(x);
x = m16::f3(x);
x = m16::f4(x);
x = m17::f0(x);
x = m17::f1(x);
x = m17::f2(x);
x = m17::f3(x);
x = m17::f4(x);
x = m18::f0(x);
x = m18::f1(x);
x = m18::f2(x);
x = m18::f3(x);
x = m18::f4(x);
x = m19::f0(x);
x = m19::f1(x);
x = m19::f2(x);
x = m19::f3(x);
x = m19::f4(x);
x = m20::f0(x);
x = m20::f1(x);
x = m20::f2(x);
x = m20::f3(x);
x = m20::f4(x);
x = m21::f0(x);
x = m21::f1(x);
x = m21::f2(x);
x = m21::f3(x);
x = m21::f4(x);
x = m22::f0(x);
x = m22::f1(x);
x = m22::f2(x);
x = m22::f3(x);
x = m22::f4(x);
x = m23::f0(x);
x = m23::f1(x);
x = m23::f2(x);
x = m23::f3(x);
x = m23::f4(x);
x = m24::f0(x);
x = m24::f1(x);
x = m24::f2(x);
x = m24::f3(x);
x = m24::f4(x);
x = m25::f0(x);
x = m25::f1(x);
x = m25::f2(x);
x = m25::f3(x);
x = m25::f4(x);
x = m26::f0(x);
x = m26::f1(x);
x = m26::f2(x);
x = m26::f3(x);
x = m26::f4(x);
x = m27::f0(x);
x = m27::f1(x);
x = m27::f2(x);
x = m27::f3(x);
x = m27::f4(x);
x = m28::f0(x);
x = m28::f1(x);
x = m28::f2(x);
x = m28::f3(x);
x = m28::f4(x);
x = m29::f0(x);
x = m29::f1(x);
x = m29::f2(x);
x = m29::f3(x);
x = m29::f4(x);
x = m30::f0(x);
x = m30::f1(x);
x = m30::f2(x);
x = m30::f3(x);
x = m30::f4(x);
x = m31::f0(x);
x = m31::f1(x);
x = m31::f2(x);
x = m31::f3(x);
x = m31::f4(x);
x = m32::f0(x);
x = m32::f1(x);
x = m32::f2(x);
x = m32::f3(x);
x = m32::f4(x);
x = m33::f0(x);
x = m33::f1(x);
x = m33::f2(x);
x = m33::f3(x);
x = m33::f4(x);
x = m34::f0(x);
x = m34::f1(x);
x = m34::f2(x);
x = m34::f3(x);
x = m34::f4(x);
x = m35::f0(x);
x = m35::f1(x);
x = m35::f2(x);
x = m35::f3(x);
x = m35::f4(x);
x = m36::f0(x);
x = m36::f1(x);
x = m36::f2(x);
x = m36::f3(x);
x = m36::f4(x);
x = m37::f0(x);
x = m37::f1(x);
x = m37::f2(x);
x = m37::f3(x);
x = m37::f4(x);
x = m38::f0(x);
x = m38::f1(x);
x = m38::f2(x);
x = m38::f3(x);
x = m38::f4(x);
x = m39::f0(x);
x = m39::f1(x);
x = m39::f2(x);
x = m39::f3(x);
x = m39::f4(x);
x = m40::f0(x);
x = m40::f1(x);
x = m40::f2(x);
x = m40::f3(x);
x = m40::f4(x);
x = m41::f0(x);
x = m41::f1(x);
x = m41::f2(x);
x = m41::f3(x);
x = m41::f4(x);
x = m42::f0(x);
x = m42::f1(x);
x = m42::f2(x);
x = m42::f3(x);
x = m42::f4(x);
x = m43::f0(x);
x = m43::f1(x);
x = m43::f2(x);
x = m43::f3(x);
x = m43::f4(x);
x = m44::f0(x);
x = m44::f1(x);
x = m44::f2(x);
x = m44::f3(x);
x = m44::f4(x);
x = m45::f0(x);
x = m45::f1(x);
x = m45::f2(x);
x = m45::f3(x);
x = m45::f4(x);
x = m46::f0(x);
x = m46::f1(x);
x = m46::f2(x);
x = m46::f3(x);
x = m46::f4(x);
x = m47::f0(x);
x = m47::f1(x);
x = m47::f2(x);
x = m47::f3(x);
x = m47::f4(x);
x }
