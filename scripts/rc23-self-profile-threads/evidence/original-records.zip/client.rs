fn main() { for x in [11u64,18364758544493064720u64] { println!("{}",counter_fixture::exercise(x)); } }
