"""Run source-derived native clients on actual Cargo-returned archives, outside the edit pair."""

import gzip
import json
import os
from pathlib import Path
import subprocess

from receipts import batch, open_rows, reader_lineage, visit
from workload import BASE, LIB, PRIMARY, TEST, digest, git, record, require, sha, store, write

PANIC = b"index out of bounds: the len is 11 but the index is 11"


def reader(out, work, src, env, label, history, state, product, expected, driver):
    client = work / "native-reader.rs"
    binary = work / "native-reader"
    binary.unlink(missing_ok=True)
    assert product["archive"] == sha(Path(product["paths"]["archive"]))
    library = Path(product["paths"]["archive"])
    dirs = sorted({str(Path(p).parent) for files in product["dependency_products"].values() for p in files})
    cmd = ["rustc", "+ohm", str(client), "--edition=2024", "--crate-name", "renderer_native_consumer",
           "--extern", f"{LIB}={library}", *["-Ldependency=" + d for d in dirs], "-o", str(binary)]
    folder = out / "oracles" / label
    batch(folder, [visit("compile", cmd)], src, env, True)
    trace = gzip.decompress((folder / "compile/strace.gz").read_bytes())
    read = open_rows(trace, library)
    used = open_rows(trace, driver)
    lineage = reader_lineage(trace, driver.parent.parent, used, read)
    image = binary.read_bytes()
    require(image[:7] == b"\x7fELF\x02\x01\x01", (label, "native reader"))
    cases = expected["new"]
    runs = {}
    for key in cases:
        old_panic = history == "source-map" and state == "old"
        batch(folder, [visit(key, [binary, key], (101,) if old_panic else (0,))], src, env, False)
        stdout, stderr = [(folder / key / stream).read_bytes() for stream in ("stdout", "stderr")]
        if old_panic:
            require(not stdout and PANIC in stderr and b"panicked at" in stderr, (label, key, stderr))
        else:
            require(not stderr and stdout == expected[state][key], (label, key, stderr, stdout[:100]))
            if history == "notebook":
                other = "old" if state == "new" else "new"
                require(stdout != expected[other][key], (label, "stale source passes", key))
        runs[key] = {"stdout": digest(stdout), "stderr": digest(stderr), "exit": 101 if old_panic else 0}
    result = {"program": store(out / "objects", image), "source": sha(client), "archive": product["archive"],
              "returned_path": str(library), "compiler_argv": cmd, "archive_opens": read,
              "driver_opens": used, "lineage":lineage, "cases": runs}
    record(folder / "reader.json", result)
    return result


def upstream_case(out, src, env, name, should_panic, should_fail):
    """Build Ruff's literal test source in separate stores, then run just its actual named test."""
    slot = Path(env["CARGO_TARGET_DIR"]).parent
    isolated = dict(env, CARGO_TARGET_DIR=str(slot / "regression-target"),
                    CARGO_BUILD_BUILD_DIR=str(slot / "regression-shared"))
    cmd = ["cargo", "+ohm", "test", "-p", "ruff_annotate_snippets", "--test", "ruff", "--no-run",
           "--locked", "--offline", "-j4", "--message-format=json"]
    folder = out / "upstream" / name
    batch(folder, [visit("build", cmd)], src, isolated, False)
    rows = [json.loads(line) for line in (folder / "build/stdout").read_bytes().splitlines()]
    require(rows[-1] == {"reason":"build-finished","success":True}, (name, "upstream test rejected"))
    exe, = [Path(r["executable"]) for r in rows if r.get("executable") and r["target"]["kind"] == ["test"]]
    native = [exe, "--exact", "multiple_insertions", "--nocapture", "--test-threads=1"]
    batch(folder, [visit("multiple_insertions", native, (101,) if should_fail else (0,))], src, isolated, False)
    stdout, stderr = [(folder / "multiple_insertions" / n).read_bytes() for n in ("stdout","stderr")]
    require(b"running 1 test" in stdout and (b"0 passed; 1 failed" if should_fail else b"1 passed; 0 failed")
            in stdout and ((PANIC in stderr) == should_panic), (name, stdout, stderr))
    record(folder / "result.json", {"actual_program": store(out / "objects", exe.read_bytes()),
           "test_input": sha(src / TEST), "renderer_input": sha(src / (BASE + "src/renderer/source_map.rs")),
           "wanted_panic": should_panic, "wanted_failure": should_fail, "native": list(map(str, native))})


def old_original_controls(out, src, env):
    upstream_case(out, src, env, "old-declared-panic", True, False)
    path = src / TEST
    before = path.read_bytes()
    after = git(src, "show", f"{PRIMARY}:{TEST}")
    require(before != after and b'#[should_panic = "index out of bounds: the len is 11 but the index is 11"]'
            in before and b'#[test]\nfn multiple_insertions()' in after, "wrong negative program")
    try:
        path.write_bytes(after)
        upstream_case(out, src, env, "old-renderer-corrected-assertion", True, True)
    finally:
        path.write_bytes(before)
    require(path.read_bytes() == before, "test source not restored")


def wrong_reader(out, work, env, history, old, wanted):
    exe = work / "wrong-old-physical-reader"
    write(exe, (out / "objects" / old["program"]).read_bytes())
    exe.chmod(0o700)
    folder = out / "wrong-reader"
    failed = {}
    for key, desired in wanted.items():
        batch(folder, [visit(key, [exe, key], (101,) if history == "source-map" else (0,))], work, env, False)
        actual = (folder / key / "stdout").read_bytes()
        error = (folder / key / "stderr").read_bytes()
        require(actual != desired and (PANIC in error if history == "source-map" else not error),
                ("old output incorrectly passed corrected oracle", key))
        failed[key] = {"actual": digest(actual), "rejected_against": digest(desired)}
    record(folder / "result.json", {"reader": sha(exe), "cases": failed})
