"""Run one fresh, source-bound GNU Ruff library cell, with the same protocol for P, F and C."""

import argparse
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))
from workload import (BASE, CLI, HERE, PINS, ROOT, add_registry, certify, client_inputs, digest, environment, git,
                      inode, record, require, sha, stage, verify_inputs, write)
from receipts import batch, messages, native, no_product_changes, snapshot, visit
from behavior import old_original_controls, reader, upstream_case, wrong_reader


def args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--role", choices=[*ROOT, "signed-control"], required=True)
    p.add_argument("--history", choices=["source-map","notebook"], required=True)
    p.add_argument("--lane", choices=["structural","whole"], required=True)
    for n in ("work", "out", "sdk", "ruff", "registry", "proxies"):
        p.add_argument("--" + n, type=Path, required=True)
    p.add_argument("--manifest", type=Path)
    p.add_argument("--manifest-sha")
    p.add_argument("--counter", type=Path)
    p.add_argument("--counter-sha")
    a = p.parse_args()
    for n in ("work", "out", "sdk", "ruff", "registry", "proxies"):
        value = getattr(a, n)
        require(value.is_absolute() and value == value.resolve(), ("canonical path required", n, value))
    require((a.lane == "whole") == bool(a.counter), "whole lane alone requires a counter")
    if a.counter:
        require(a.counter.is_absolute() and a.counter.is_file() and not a.counter.is_symlink() and
                sha(a.counter) == a.counter_sha, "counter executable custody")
    return a


def main(a):
    out, work = a.out, a.work
    require(not work.exists() and not out.exists() and not out.is_relative_to(work)
            and not work.is_relative_to(out), "fresh, disjoint cell/receipts required")
    require(all(shutil.disk_usage(p).free > 4 * 2**30 for p in [out.parent, work.parent]), "4 GiB reserve")
    out.mkdir(mode=0o700)
    work.mkdir(mode=0o700)
    raw = out / "raw"
    try:
        verify_inputs(a.ruff)
        adapter_files = [str(f.relative_to(HERE)) for f in HERE.glob("*.py")
                         if f.name in ("arm.py","workload.py","receipts.py","behavior.py")]
        adapter = {n:sha(HERE / n) for n in sorted([*adapter_files,*PINS])}
        record(out / "workload-source.json", adapter)
        arm = certify(a)
        driver = Path(arm["driver_path"])
        record(out / "subject.json", arm)
        if a.manifest:
            write(out / "source-sdk-manifest.json", a.manifest.read_bytes())
        src = work / "source"
        subprocess.run(["git", "clone", "-q", "--no-checkout", "--shared", a.ruff, src], check=True)
        stage(src, out, a.history, "old")
        code, expected = client_inputs(a.ruff, a.history)
        write(work / "native-reader.rs", code)
        write(out / "inputs/reader.rs", code)
        for state, cases in expected.items():
            for n, content in cases.items():
                write(out / "inputs" / state / n, content)
        env = environment(work, a.sdk, a.proxies)
        registry = Path(env["CARGO_HOME"])
        record(out / "registry-old.json", add_registry(src, registry, a.registry, a.role != "signed-control"))
        record(out / "environment.json", env)
        sysroot = subprocess.check_output(["rustc","+ohm","--print","sysroot"], cwd=src, env=env).decode().strip()
        require(Path(sysroot).samefile(a.sdk), ("wrong active SDK", sysroot))
        record(out / "runtime.json", {"sysroot": sysroot, "boot":Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
                                      "os":list(os.uname()), "cpu_affinity":sorted(os.sched_getaffinity(0)),
                                      "lane":a.lane, "history":a.history, "counter":a.counter_sha,
                                      "versions":{t:subprocess.check_output([t,"+ohm","-vV"],env=env,cwd=src).decode()
                                                  for t in ("cargo","rustc")}})
        structural = a.lane == "structural"
        products, verdicts = {}, {}

        def compile_command(*v):
            batch(raw, list(v), src, env, structural, a.counter)

        def product(label):
            arts = messages(raw, label)
            physical = native(raw, label, a.sdk, driver)
            products[label] = snapshot(out, label, arts, env, physical)
            return products[label]

        def client(label, state):
            verdicts[label] = reader(out, work, src, env, label, a.history, state,
                                     products[label], expected, driver)

        def reset_store(label):
            slot = work / "slot"
            old = {p.name: list(inode(p)) for p in slot.iterdir()}
            require({"target","shared","cargo-home","home","tmp"} <= old.keys(), old)
            parked = work / ("parked-" + label)
            slot.rename(parked)
            require(environment(work, a.sdk, a.proxies) == env and not registry.exists() and
                    not (slot / "target").exists() and not (slot / "shared").exists(), label)
            record(out / ("registry-" + label + ".json"), add_registry(src, registry, a.registry,
                                                                      a.role != "signed-control"))
            record(out / ("independent-" + label + ".json"), {
                "original": old, "parked": str(parked), "logical": str(slot), "new_cargo_home": list(inode(registry))})
            require(all(inode(slot / n) != tuple(old[n]) for n in ("home","tmp","cargo-home")), label)

        compile_command(visit("old", measure=True))
        product("old")
        client("old", "old")
        if a.history == "source-map":
            old_original_controls(out, src, env)
        stage(src, out, a.history, "new")
        compile_command(visit("edit", measure=True), visit("repeat", measure=True))
        if structural:
            no_product_changes(raw, [Path(env["CARGO_TARGET_DIR"]), Path(env["CARGO_BUILD_BUILD_DIR"])])
        edit, repeat = product("edit"), product("repeat")
        for key in ("archive","rmeta","embedded_rmeta","cgu","work_products","paths"):
            require(edit[key] == repeat[key], ("contiguous pair", key))
        record(out / "edit-pair.json", {"intervening_reads": False, "states_sampled_after_first_repeat": True,
               "untraced_pair": not structural, "structural_repeat_no_product_writes": structural,
               "evidence": "own structural product-write/exec trace" if structural else
                           "both typed outputs; artifact bytes sampled at the joint endpoint only"})
        client("edit", "new")
        client("repeat", "new")
        wrong_reader(out, work, env, a.history, verdicts["old"], expected["new"])

        leaf = "source_map.rs" if a.history == "source-map" else "render.rs"
        file = src / (BASE + "src/renderer/" + leaf)
        source = file.read_bytes()
        bad = source + b"\nconst _: () = 1u8;\n"
        write(out / "inputs/invalid-membership.json", (json.dumps({
            "file": str(file.relative_to(src)), "before":digest(source), "after":digest(bad),
            "append":"\nconst _: () = 1u8;\n"}) + "\n").encode())
        def invalid(label):
            file.write_bytes(bad)
            require(file.read_bytes() == bad, label)
            try:
                compile_command(visit(label, expected=(101,)))
                diagnosis = messages(raw, label, invalid=True)
                require(all(s["file_name"].endswith(str(file.relative_to(src)))
                            for s in diagnosis["spans"] if s["is_primary"]), diagnosis)
                native(raw, label, a.sdk, driver)
                record(out / "states" / label / "diagnostic.json", diagnosis)
            finally:
                file.write_bytes(source)
            require(file.read_bytes() == source, label)
            return diagnosis
        warm_error = invalid("invalid")
        compile_command(visit("repair"), visit("repaired-repeat"))
        product("repair")
        product("repaired-repeat")
        client("repair", "new")
        reset_store("empty")
        compile_command(visit("empty"))
        product("empty")
        client("empty", "new")
        if a.history == "source-map":
            upstream_case(out, src, env, "independent-corrected", False, False)
        reset_store("empty-invalid")
        cold_error = invalid("empty-invalid")
        require(cold_error == warm_error, "warm error differs from independently empty error")
        require(not git(src, "status", "--porcelain"), "final recovered source differs")
        anchor = verdicts["empty"]
        require(verdicts["old"]["program"] != anchor["program"], "changed native behavior used an old image")
        for label in ("edit","repeat","repair"):
            require(verdicts[label]["program"] == anchor["program"] and verdicts[label]["cases"] == anchor["cases"],
                    ("corrected reader differs from independent empty", label))
            live = products[label]["cgu"]
            clean = products["empty"]["cgu"]
            require({k:v["sha256"] for k,v in live.items()} == {k:v["sha256"] for k,v in clean.items()},
                    ("corrected native CGUs differ", label))
        storage = {n:json.loads(gzip.decompress((out / "states" / n / "storage.json.gz").read_bytes()))
                   ["unique_allocated"] for n in products}
        require(shutil.disk_usage(out).free > 4 * 2**30, "output volume under reserve")
        require({p:sha(HERE / p) for p in adapter} == adapter, "workload source changed during a cell")
        record(out / "complete.json", {"history":a.history, "role":a.role, "lane":a.lane, "ordinary": CLI,
               "driver":arm["tools"][str(driver.relative_to(a.sdk))], "source":arm["source"]["commit"],
               "cold_cgu":len(products["old"]["cgu"]), "warm_cgu":len(products["edit"]["cgu"]),
               "empty_cgu":len(products["empty"]["cgu"]), "allocated": storage,
               "structural_only":structural, "consumer_corrected":anchor["program"],
               "metadata_crosscheck":"external exact native/DWARF/rmeta verdict required before scoring"})
    except BaseException:
        write(out / "refusal.txt", traceback.format_exc().encode())
        raise


if __name__ == "__main__":
    main(args())
