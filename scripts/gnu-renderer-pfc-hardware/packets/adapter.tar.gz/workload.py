"""Authenticate the two fixed Ruff source histories and their ordinary compiler environment."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tomllib

HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"
sys.path.insert(0, str(INPUTS))
import oracle as notebook

CLI = ["cargo", "+ohm", "build", "-p", "ruff_annotate_snippets", "--lib",
       "--locked", "--offline", "-j4", "--message-format=json"]
LIB = "annotate_snippets"
UNITS = {LIB, "memchr", "anstyle", "unicode_width"}
PRIMARY = "93526150df078af7dd8fc4226cdcc469539d2001"
PATCH = "9c53b5de3aae4b1832eb7ee137647dda2466f888"
ROOT = {"P": "4e7c5b1f765b24ccd585d8ddb7eeae99a02b514e",
        "F": "96e6c29c1ed9bf7229ef3b89843712139529cd10",
        "C": "b79ec99c44772853c313161bee2bbfaecc80e0de"}
SIGNED = "c79998a5cd143c445a4b2528f20953b176a65c5d"
CARGO = "9fb29f6abecad05acb6015990615c5fbb435a5907543f0bd33cf88cada4f5826"
WILD = "0d6335808b647d499f3d74993b602e64ff0625206c809bf4913c487eea380cd5"
WILD_PATH = "lib/rustlib/x86_64-unknown-linux-gnu/bin/wild-ld/ld.bfd"
BASE = "crates/ruff_annotate_snippets/"
TEST = BASE + "tests/ruff.rs"
ROSTER = json.loads((INPUTS / "roster.json").read_bytes())["source_inputs"]
BOOK = json.loads((INPUTS / "registration.json").read_bytes())
PINS = {"PLAN.md": "70076984ab6feb82a8a9eae43cb9a9c34eec7a9cc42a50305c018391c14afe66",
        "inputs/roster.json": "c4f4071e98f82e318ae656185d5d463629f54d637bd1559e6095752d62afb6e6",
        "inputs/registration.json": "3d2ae970855a5422468541650aa30759d2c283ec643ea4bb16a5e50eca8b6e96",
        "inputs/renderer.patch": "012fcde7a72bbdb761e6ba80bf485b989ba93626726ca373a3a848ce455cb5c7",
        "inputs/holdout.patch": "a5acdb9f155cb0aab4fc8f9d4d2cea468a056b95faeabb0c78a5bfe6c764ef9c",
        "inputs/worker_artifacts.py": "d1895e5f575d1259a413745c72cc31b6b6566ba88b9b35fffbc6101bd423d95e",
        "inputs/kernel.py": "d9661a99e58517690053216e823073f1a6c7644b853b85f610229590262c02e5",
        "inputs/oracle.py": "0489d64f2ea7c976fd3e0d230f9aaaa8913526db5500ae11c3f87b61a239ad9d",
        "inputs/reader.rs": "ee795b4c2c6a32a98f4a6ffebf75156dadbcb7a0651f7472d6d7b24036523522"}


def require(ok, detail):
    if not ok:
        raise RuntimeError(str(detail))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as dst:
        dst.write(data)


def record(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=1) + "\n").encode()
    write(path, gzip.compress(raw, compresslevel=4, mtime=0) if path.suffix == ".gz" else raw)


def store(pool, data):
    h = digest(data)
    p = pool / h
    if p.exists():
        require(p.is_file() and not p.is_symlink() and p.read_bytes() == data, p)
    else:
        write(p, data)
    return h


def git(repo, *args):
    return subprocess.check_output(["git", "-C", repo, *args])


def path_hashes(repo, files):
    return {rel: sha(repo / rel) for rel in files}


def verify_inputs(repo):
    require({p: sha(HERE / p) for p in PINS} == PINS, "historical input custody")
    require(git(repo, "rev-parse", PRIMARY + "^{tree}").strip() ==
            b"62d3f106c5e41f6022847f26ff8c7dc00139f7b1", "source-map root")
    require(git(repo, "diff", "--binary", "--abbrev=10", PATCH + "^", PATCH, "--",
                *sorted(ROSTER["corrected"])) == (INPUTS / "renderer.patch").read_bytes(), "primary patch")
    old, new = [BOOK["source"][s]["commit"] for s in ("old", "new")]
    require(git(repo, "rev-parse", new + "^").decode().strip() == old, "holdout parent")
    require(git(repo, "diff", "--binary", "--full-index", old, new) ==
            (INPUTS / "holdout.patch").read_bytes(), "complete holdout patch")
    for state, desc in BOOK["source"].items():
        commit = desc["commit"]
        require(git(repo, "rev-parse", commit + "^{tree}").decode().strip() == desc["tree"], state)
        require({f: digest(git(repo, "show", f"{commit}:{f}")) for f in desc["files"]} ==
                desc["files"], state)


def stage(src, out, history, state):
    if history == "source-map":
        files = ROSTER["old" if state == "old" else "corrected"]
        if state == "old":
            git(src, "switch", "-q", "--detach", PRIMARY)
            git(src, "apply", "--reverse", str(INPUTS / "renderer.patch"))
        else:
            git(src, "apply", str(INPUTS / "renderer.patch"))
        require(git(src, "rev-parse", "HEAD").decode().strip() == PRIMARY, state)
        require(set(git(src, "diff", "--name-only").decode().splitlines()) ==
                (set(files) if state == "old" else set()), state)
        require(sha(src / "Cargo.lock") ==
                "c9e345325bec5ff08dbbe3916edd39ad0c3d1c7797a8c241ae32f62754e764bf", state)
    else:
        desc = BOOK["source"][state]
        git(src, "switch", "-q", "--detach", desc["commit"])
        files = desc["files"]
        require(git(src, "rev-parse", "HEAD^{tree}").decode().strip() == desc["tree"], state)
        require(not git(src, "diff", "--name-only"), state)
    require(not git(src, "ls-files", "--others", "--exclude-standard"), (state, "source contamination"))
    require(path_hashes(src, files) == files, (history, state, "source identity"))
    files = dict(files)
    for manifest in ("Cargo.toml", BASE + "Cargo.toml"):
        git_digest = digest(git(src, "show", "HEAD:" + manifest))
        require(sha(src / manifest) == git_digest and files.get(manifest,git_digest) == git_digest,
                ("workspace manifest changed", manifest))
        files[manifest] = git_digest
    for rel in files:
        write(out / "sources" / state / rel, (src / rel).read_bytes())
    record(out / "sources" / state / "source.json", {
        "files": files, "HEAD": git(src, "rev-parse", "HEAD").decode().strip(),
        "tree": git(src, "rev-parse", "HEAD^{tree}").decode().strip(),
        "lock": sha(src / "Cargo.lock"), "status": git(src, "status", "--porcelain").decode()})


def client_inputs(repo, history):
    if history == "notebook":
        source, wants = notebook.roles(repo, BOOK)
        require(source == (INPUTS / "reader.rs").read_bytes(), "holdout client source")
        for state, cases in wants.items():
            for key, raw in cases.items():
                require((INPUTS / "expect" / state / key).read_bytes() == raw, key)
        return source, wants
    text = git(repo, "show", f"{PRIMARY}:{TEST}").decode()
    start = "#[test]\nfn multiple_insertions() {\n"
    require(text.count(start) == 1, "specific source-map test")
    body = text.split(start, 1)[1].split("\n}\n", 1)[0]
    inp = body.split("    let expected_ascii =", 1)[0]
    require(inp.count("Patch::new(") == 3 and body.count("assert_data_eq!(renderer.render(input),") == 2,
            "source-map upstream assertions")
    wants = {k: re.search(r'let expected_' + k + r' = str!\[\[r#"\n(.*?)\n"#\]\];',
                          body, re.S)[1].encode() for k in ("ascii", "unicode")}
    require(all(x.startswith(b"error[test-diagnostic]") for x in wants.values()), wants)
    code = ("use annotate_snippets::{AnnotationKind, Level, Patch, Renderer, Snippet};\n"
            "use annotate_snippets::renderer::DecorStyle;\nfn main() {\n" + inp +
            '    let mode = std::env::args().nth(1).unwrap();\n'
            '    let renderer = match mode.as_str() { "ascii" => Renderer::plain(), '
            '"unicode" => Renderer::plain().decor_style(DecorStyle::Unicode), _ => unreachable!() };\n'
            '    print!("{}", renderer.render(input));\n}\n')
    return code.encode(), {"old": {}, "new": wants}


def add_registry(src, cargo_home, seed, complete):
    """Copy private sparse index entries and checksum-authenticated .crate archives only."""
    cargo_home.mkdir()
    lock = tomllib.loads((src / "Cargo.lock").read_text())
    rows = {p["name"] + "-" + p["version"]: (p["name"], p["checksum"])
            for p in lock["package"] if "checksum" in p}
    roots = [p for p in (seed / "cache").iterdir() if p.is_dir()]
    require(len(roots) == 1, ("expected one registry", roots))
    origin = roots[0]
    index = seed / "index" / origin.name
    dst = cargo_home / "registry"
    ci = dst / "index" / origin.name
    ca = dst / "cache" / origin.name
    ca.mkdir(parents=True)
    ci.mkdir(parents=True)
    shutil.copyfile(index / "config.json", ci / "config.json")
    actual = {}
    for artifact, (name, expected) in sorted(rows.items()):
        crate = origin / (artifact + ".crate")
        prefix = (str(len(name)) if len(name) < 3 else
                  "3/" + name[0] if len(name) == 3 else name[:2] + "/" + name[2:4])
        key = Path(".cache") / prefix / name
        if (index / key).is_file() and not (ci / key).exists():
            (ci / key).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(index / key, ci / key)
        if crate.is_file():
            shutil.copyfile(crate, ca / crate.name)
            actual[artifact] = sha(ca / crate.name)
            require(actual[artifact] == expected, (crate, "unchecked registry input"))
    if complete:
        require(len(actual) == len(rows), ("incomplete hosted Cargo.lock registry", len(actual), len(rows)))
    require(not (dst / "src").exists(), "registry already extracted")
    return {"available": actual, "locked": len(rows), "complete": len(actual) == len(rows),
            "name": origin.name, "physical": list(inode(cargo_home))}


def inode(path):
    s = path.stat()
    return s.st_dev, s.st_ino


def environment(work, sdk, proxies):
    slot = work / "slot"
    for name in ("home", "tmp"):
        (slot / name).mkdir(parents=True, exist_ok=True)
    rustup = work / ".rustup"
    alias = rustup / "toolchains" / "ohm"
    alias.parent.mkdir(parents=True, exist_ok=True)
    if not alias.exists():
        alias.symlink_to(sdk, target_is_directory=True)
    require(alias.resolve() == sdk.resolve(), "SDK layout")
    actual = (proxies / "rustup").stat()
    for n in ("cargo", "rustc", "rustdoc"):
        require(os.path.samestat((proxies / n).stat(), actual), ("not an authentic rustup proxy", n))
    return {"HOME": str(slot / "home"), "USER": os.environ.get("USER", "runner"),
            "PATH": os.pathsep.join([str(proxies), "/usr/local/bin", "/usr/bin", "/bin"]),
            "RUSTUP_HOME": str(rustup), "RUSTUP_AUTO_INSTALL": "0", "TMPDIR": str(slot / "tmp"),
            "CARGO_HOME": str(slot / "cargo-home"), "CARGO_TARGET_DIR": str(slot / "target"),
            "CARGO_BUILD_BUILD_DIR": str(slot / "shared"), "CARGO_NET_OFFLINE": "true",
            "CARGO_CACHE_AUTO_CLEAN_FREQUENCY": "never", "CARGO_TERM_COLOR": "never",
            "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC"}


def certify(a):
    sdk = a.sdk.resolve()
    (driver,) = (sdk / "lib").glob("librustc_driver-*.so")
    key = str(driver.relative_to(sdk))
    required = [key, "bin/rustc", "bin/rustdoc", "bin/cargo", WILD_PATH]
    selected = {p: sha(sdk / p) for p in required}
    require(selected["bin/cargo"] == CARGO and selected[WILD_PATH] == WILD, "Cargo #301 or signed Wild mismatch")
    if a.role == "signed-control":
        require(not a.manifest and not a.manifest_sha and a.lane == "structural", "signed-only control")
        require(selected[key] == "dae4f8dc64b2b2ac9dc04dfe2cfad633d6af1a87da2dfc532e757ffe758680e3"
                and selected["bin/rustc"] == "f7663fb7dec7e5c7ea613a85ff1d6e4c00bf97b8c50534f17e5c95cd599712b9",
                "wrong signed compiler")
        source = {"commit": SIGNED}
    else:
        require(a.manifest and sha(a.manifest) == a.manifest_sha, "unmatched source qualification seal")
        m = json.loads(a.manifest.read_bytes())
        require(m["attempt"] in (1, "1") and len(m["qa"]) == 40 and
                m["signed_provenance"] == SIGNED and m["review_base"] == ROOT["P"], "source qualification")
        require({k: v["source"]["commit"] for k, v in m["roles"].items()} == ROOT, "unregistered sources")
        require(m["driver"] == key and len(m["files"]) == m["common_member_count"] + 1, "SDK surface")
        expected = dict(m["files"])
        expected[key] = m["roles"][a.role]["driver"]
        physical = {str(p.relative_to(sdk)) for p in sdk.rglob("*") if p.is_file() or p.is_symlink()}
        require(physical == set(expected), "unregistered SDK file")
        for n, (h, size, mode) in expected.items():
            p = sdk / n
            require(not p.is_symlink() and p.stat().st_size == size and stat.S_IMODE(p.stat().st_mode) == mode
                    and sha(p) == h, ("installed SDK byte/mode", n))
        source = m["roles"][a.role]["source"]
    unique = {}
    for p in (sdk, *sdk.rglob("*")):
        s = p.lstat()
        unique[(s.st_dev, s.st_ino)] = s.st_blocks * 512
    return {"role": a.role, "source": source, "driver_path": str(driver), "tools": selected,
            "inputs": {p: list(inode(sdk / p)) for p in required}, "sdk_allocated": sum(unique.values()),
            "manifest_sha": a.manifest_sha}
