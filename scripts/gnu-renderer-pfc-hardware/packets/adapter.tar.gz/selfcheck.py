"""Validate fixed inputs, both compiler trace grammars and the no-intervening-read counter contract."""

import json
import os
from pathlib import Path
import stat
import sys
import tempfile

sys.path.insert(0,str(Path(__file__).resolve().parent))
from workload import client_inputs, require, verify_inputs
from receipts import batch, exec_details, joined, visit
from kernel import read_execs


def refuses(f):
    try:
        f()
    except (RuntimeError, ValueError, TypeError, KeyError, SyntaxError):
        return
    raise AssertionError("fixture incorrectly passed")


def traces():
    env = '["HOME=/private", "K=a=b"]'
    raw = (f'19 execve("/rustc", ["rustc", "--crate-name", "fixture"], {env} <unfinished ...>\n'
           '20 clone(child_stack=NULL, flags=CLONE_THREAD|CLONE_FS) = 30\n'
           '19 <... execve resumed>) = 0\n').encode()
    n, = exec_details(raw)
    assert n == (19,"/rustc",["rustc","--crate-name","fixture"],["HOME=/private","K=a=b"])
    # The archived signed holdout used the original pointer-form observer. Both agree on the process.
    old = raw.replace(env.encode(), b"0x12345 /* 2 vars */")
    rows, overlap = read_execs(b"\n".join(l for l in old.splitlines() if b"execve" in l))
    assert rows == [n[:3]] and overlap == 1
    refuses(lambda:exec_details(raw.replace(b'"K=a=b"',b'"CI=true"')))
    refuses(lambda:exec_details(raw.replace(b'"K=a=b"',b'"HOME=else"')))
    refuses(lambda:exec_details(raw.replace(b'"--crate-name"',b'...')))
    refuses(lambda:list(joined(raw.split(b'19 <...')[0])))


def sequential_counter():
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        helper = root / "test-counter"
        helper.write_text("#!/usr/bin/python3\nimport os,sys,subprocess,pathlib\n"
                          "code=subprocess.run(sys.argv[2:]).returncode\n"
                          "pathlib.Path(sys.argv[1]).open('x').write('fixture, not PMU')\n"
                          "sys.exit(code)\n")
        helper.chmod(stat.S_IRWXU)
        physical = root / "ordinary-input"
        stdout = root / "receipt"
        edit = [sys.executable,"-IB","-c",
                "from pathlib import Path; import sys; Path(sys.argv[1]).open('xb').write(b'changed');"
                " print('edited')", str(physical)]
        repeat = [sys.executable,"-IB","-c",
                  "from pathlib import Path; import sys; assert Path(sys.argv[1]).read_bytes()==b'changed';"
                  " print('repeat')", str(physical)]
        batch(stdout,[visit("edit",edit,measure=True),visit("repeat",repeat,measure=True)],
              root,{"PATH":"/usr/bin:/bin"},False,helper)
        e, r = [json.loads((stdout/k/"terminal.json").read_bytes()) for k in ("edit","repeat")]
        assert e["status"] == r["status"] == 0 and e["end_mono_ns"] <= r["begin_mono_ns"]
        for label, literal in [("edit",b"edited\n"),("repeat",b"repeat\n")]:
            c = stdout / label
            assert (c/"stdout").read_bytes() == literal and not (c/"stderr").read_bytes()
            assert (c/"pmu.json").read_text() == "fixture, not PMU" and not (c/"strace.gz").exists()
        refuses(lambda:batch(root/"forbidden",[visit("x",edit,measure=True)],root,{},True,helper))


if __name__=="__main__":
    repo=Path(sys.argv[1]).resolve()
    verify_inputs(repo)
    for h in ("source-map","notebook"):
        body, states=client_inputs(repo,h)
        assert body and set(states)=={"old","new"} and all(states["new"].values())
    traces()
    sequential_counter()
    print("both complete historical source inputs, registered clients, process/credential/truncation refusals, "
          "adjacent independent whole-command FDs, and no simultaneous trace/counter")
