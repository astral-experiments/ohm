"""Record exact Cargo streams, physical process inputs, and the returned object ownership."""

from contextlib import ExitStack
import ast
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import time

from workload import CLI, LIB, UNITS, digest, inode, record, require, sha, store, write
from worker_artifacts import archive

PROCESS = "execve,execveat,open,openat,clone,clone3,fork,vfork"
MUTATIONS = ("creat,rename,renameat,renameat2,unlink,unlinkat,link,linkat,truncate,"
             "ftruncate,write,writev,pwrite64,pwritev,copy_file_range,sendfile,splice,mmap,utimensat,fallocate")


def batch(out, visits, cwd, env, traced, counter=None):
    """Preopen all output FDs. Between enrolled commands only wait and launch the next command."""
    prepared = []
    statuses = []
    with ExitStack() as stack:
        for label, args, expected, measure in visits:
            folder = out / label
            folder.mkdir(parents=True)
            cmd = list(map(str, args))
            if traced:
                calls = PROCESS + ("," + MUTATIONS if label == "repeat" else "")
                cmd = ["strace", "-f", "-qq", "-yy", "-v", "-s", "65535", "-e", "trace=" + calls,
                       "-o", str(folder / "strace.raw"), *cmd]
            if measure and counter:
                require(not traced, "a scored command cannot carry strace")
                cmd = [str(counter), str(folder / "pmu.json"), *cmd]
            record(folder / "started.json", {"command": list(map(str, args)), "launch": cmd, "cwd": str(cwd)})
            prepared.append((cmd, expected, stack.enter_context((folder / "stdout").open("xb")),
                             stack.enter_context((folder / "stderr").open("xb"))))
        for cmd, expected, stdout, stderr in prepared:
            before = time.monotonic_ns()
            result = subprocess.run(cmd, cwd=cwd, env=env, stdout=stdout, stderr=stderr, timeout=300)
            statuses.append((result.returncode, before, time.monotonic_ns()))
            if result.returncode not in expected:
                break
    for (label, _, _, _), (status, begin, end) in zip(visits, statuses):
        folder = out / label
        record(folder / "terminal.json", {"status": status, "begin_mono_ns": begin, "end_mono_ns": end})
        trace = folder / "strace.raw"
        if trace.exists():
            raw = trace.read_bytes()
            write(folder / "strace.gz", gzip.compress(raw, compresslevel=3, mtime=0))
            trace.unlink()
    require(len(statuses) == len(visits) and
            all(p[0] in spec[2] for p, spec in zip(statuses, visits)),
            [(s[0], (out / spec[0] / "stderr").read_bytes()[-700:]) for s, spec in zip(statuses, visits)])


def visit(label, args=CLI, expected=(0,), measure=False):
    return label, args, expected, measure


def messages(raw, label, invalid=False):
    rows = [json.loads(line) for line in (raw / label / "stdout").read_bytes().splitlines()]
    require(rows and rows[-1] == {"reason": "build-finished", "success": not invalid}, (label, rows[-1:]))
    errors = [r for r in rows if r.get("message", {}).get("level") == "error"]
    if invalid:
        require(len(errors) == 1 and errors[0]["target"]["name"] == LIB, (label, errors))
        m = errors[0]["message"]
        require(m["code"]["code"] == "E0308" and m["message"] == "mismatched types", (label, m))
        primary, = [s for s in m["spans"] if s["is_primary"]]
        require(len(primary["text"]) == 1 and primary["text"][0]["text"] == "const _: () = 1u8;", primary)
        return {"code": m["code"]["code"], "message": m["message"], "spans": m["spans"],
                "target": errors[0]["target"]["name"]}
    require(not errors, (label, errors))
    arts = [r for r in rows if r["reason"] == "compiler-artifact"]
    require(len(arts) == 4 and {a["target"]["name"] for a in arts} == UNITS, (label, arts))
    require(all(a["target"]["kind"] == ["lib"] and a["executable"] is None for a in arts), (label, "non-lib"))
    dirty = {a["target"]["name"] for a in arts if not a["fresh"]}
    wanted = {"old": UNITS, "empty": UNITS, "edit": {LIB}, "repeat": set(), "repaired-repeat": set()}
    if label in wanted:
        require(dirty == wanted[label], (label, dirty, wanted[label]))
    else:
        require(label == "repair" and dirty <= {LIB}, (label, dirty))
    return arts


def open_rows(trace, path):
    target = "<" + str(path.resolve()) + ">"
    return [f"{pid} {line}" for pid,line in joined(trace) if line.startswith(("open(", "openat(")) and
            "O_RDONLY" in line and not re.search(r"O_(WRONLY|RDWR|CREAT|TRUNC)",line) and
            re.search(r"= \d+<[^>]+>$", line) and line.endswith(target)]


def joined(trace):
    pending = {}
    for raw in trace.decode().splitlines():
        m = re.fullmatch(r"(\d+)\s+(.*)", raw)
        require(m, raw)
        pid, line = int(m[1]), m[2]
        if line.endswith(" <unfinished ...>"):
            require(pid not in pending, raw)
            pending[pid] = line.removesuffix(" <unfinished ...>")
            continue
        m = re.fullmatch(r"<\.\.\. (\w+) resumed>(.*)", line)
        if m:
            head = pending.pop(pid)
            require(head.startswith(m[1] + "("), raw)
            line = head + m[2]
        yield pid, line
    require(not pending, ("unterminated syscalls", pending))


def exec_details(trace):
    """Decode complete successful execve rows, including Cargo's actual ordered compiler environment."""
    events = []
    for pid, line in joined(trace):
        if not line.startswith(("execve(", "execveat(")) or not re.search(r"\)\s+= 0$", line):
            continue
        require(line.startswith("execve("), "unclassified successful execveat: " + line)
        call = re.sub(r"\s+= 0$", "", line)[len("execve"):]
        path, argv, raw_env = ast.literal_eval(call)
        require(isinstance(path,str) and isinstance(argv,list) and all(isinstance(s,str) for s in argv)
                and isinstance(raw_env,list) and all(isinstance(s,str) and "=" in s for s in raw_env),
                ("truncated process", pid))
        env = dict(s.split("=",1) for s in raw_env)
        require(len(env) == len(raw_env) and not ({"GH_TOKEN","GITHUB_TOKEN","CI","TF_BUILD",
                "RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER"} & env.keys()),
                ("ambient override or duplicate environment field", pid, list(env)))
        events.append((pid,path,argv,raw_env))
    return events


def parent_edges(trace):
    children = {}
    for pid, line in joined(trace):
        m = re.match(r"(?:clone3?|vfork|fork)\(.*\)\s+= (\d+)$", line)
        if m:
            child = int(m[1])
            require(child not in children, ("duplicate child", child))
            children[child] = (pid, "CLONE_THREAD" in line)
    return children


def descends(children, pid, owner, threads=False):
    seen = set()
    while pid != owner and pid in children and (not threads or children[pid][1]):
        require(pid not in seen, pid)
        seen.add(pid)
        pid = children[pid][0]
    return pid == owner


def reader_lineage(trace, sdk, loaded, opened):
    """Allow the actual rustc's own threads to read the rlib; identify separate linker descendants."""
    children = parent_edges(trace)
    owner, = [pid for pid, file, argv, _ in exec_details(trace) if "--crate-name" in argv and
              argv[argv.index("--crate-name")+1] == "renderer_native_consumer"
              and Path(file).samefile(sdk / "bin/rustc")]
    require(any(int(s.split()[0]) == owner for s in loaded), ("wrong driver owner", owner))
    pids = {int(s.split()[0]) for s in opened}
    require(pids and all(descends(children,p,owner) for p in pids) and
            any(descends(children,p,owner,True) for p in pids),
            ("actual rustc must read returned archive", owner, pids, children))
    return {"leader":owner, "compiler_readers":sorted(p for p in pids if descends(children,p,owner,True)),
            "other_descendant_readers":sorted(p for p in pids if not descends(children,p,owner,True))}


def native(raw, label, sdk, driver):
    folder = raw / label
    path = folder / "strace.gz"
    if not path.exists():
        return None
    trace = gzip.decompress(path.read_bytes())
    events = exec_details(trace)
    overlaps = len(re.findall(rb"^\d+\s+<\.\.\. execve(?:at)? resumed>", trace, re.M))
    compilers, linkers = [], []
    opened = open_rows(trace, driver)
    for pid, path, args, raw_env in events:
        if "--crate-name" in args and "--print" not in args and any(v.startswith("--emit=") for v in args):
            require(Path(path).samefile(sdk / "bin/rustc"), (label, path))
            lineage = [line for line in opened if int(line.split()[0]) == pid]
            require(lineage, (label, "actual rustc missing selected driver", pid, str(driver)))
            cwds = {m[1] for line in lineage if (m := re.search(r"openat\(AT_FDCWD<([^>]+)>", line))}
            require(len(cwds) == 1, (label, "kernel working directory", cwds))
            compilers.append({"pid": pid, "path": path, "argv": args, "environment":raw_env,
                              "cwd":cwds.pop(), "name": args[args.index("--crate-name") + 1],
                              "driver_opens": lineage})
        if Path(path).name in ("ld", "ld.bfd", "ld.lld", "rust-lld", "wild"):
            linkers.append({"pid": pid, "path": path, "argv": args})
    actual = {c["name"] for c in compilers}
    expected = {"old": UNITS, "empty": UNITS, "edit": {LIB}, "repeat": set(), "repaired-repeat": set(),
                "invalid": {LIB}, "empty-invalid": UNITS}
    require(not linkers and len(compilers) == len(actual), (label, actual, linkers))
    if label in expected:
        require(actual == expected[label], (label, "physical rustcs", actual, expected[label]))
    else:
        require(label == "repair" and actual <= {LIB}, (label, actual))
    for row in compilers:
        if row["name"] == LIB:
            require(any(v.startswith("incremental=") or v.startswith("-Cincremental=") for v in row["argv"])
                    and "--emit=dep-info,metadata,link" in row["argv"]
                    and "--target" not in row["argv"], (label, row["argv"]))
    result = {"compilers": compilers, "linkers": linkers, "overlapping_execs": overlaps}
    record(folder / "native.json", result)
    return result


def no_product_changes(raw, roots):
    """A fresh structural repeat must not write, rename or replace any registered rlib or rmeta."""
    tr = gzip.decompress((raw / "repeat" / "strace.gz").read_bytes()).decode()
    bad = []
    roots = tuple(str(r) for r in roots)
    for pid, text in joined(tr.encode()):
        if not (".rlib" in text or ".rmeta" in text) or not any(p in text for p in roots):
            continue
        syscall = text.split("(", 1)[0]
        if syscall in ("execve", "execveat"):
            continue
        if syscall in ("open", "openat") and not re.search(r"O_(?:WRONLY|RDWR|CREAT|TRUNC)", text):
            continue
        if syscall == "mmap" and not ("MAP_SHARED" in text and "PROT_WRITE" in text):
            continue
        if syscall == "write" and re.match(r"write\([12]<", text):
            continue
        bad.append(text)
    require(not bad, ("repeat product mutation", bad[:4]))


def dependency_metadata(out, label, arts, native_proof):
    """Bind Cargo's three returned .rmeta files to the input FDs held by the actual renderer rustc."""
    files = {}
    for unit in arts:
        name = unit["target"]["name"]
        if name == LIB:
            continue
        path, = [Path(p) for p in unit["filenames"] if p.endswith(".rmeta")]
        require(path.is_file() and not path.is_symlink(), (label, path))
        with path.open("rb") as stream:
            before = os.fstat(stream.fileno())
            data = stream.read()
            after = os.fstat(stream.fileno())
        def stamp(st):
            return (st.st_dev,st.st_ino,st.st_mtime_ns,st.st_ctime_ns,st.st_size)
        require(stamp(before)==stamp(after)==stamp(path.stat()) and len(data)==before.st_size,
                ("changed external metadata during capture", label,path))
        files[name] = {"path":str(path),"sha256":store(out/"objects",data),"bytes":len(data),
                       "dev":before.st_dev,"ino":before.st_ino,"allocated":before.st_blocks*512}
    require(files.keys() == UNITS - {LIB}, ("incomplete externs", label))
    roots = [r for r in (native_proof or {}).get("compilers",()) if r["name"]==LIB]
    if roots:
        root, = roots
        trace = gzip.decompress((out/"raw"/label/"strace.gz").read_bytes())
        edges = parent_edges(trace)
        args = root["argv"]
        externs = [args[i+1].split("=",1) for i,v in enumerate(args) if v=="--extern"]
        require(not any(v.startswith("--extern=") for v in args) and
                len(externs)==len(files) and dict(externs)=={n:r["path"] for n,r in files.items()},
                ("kernel rustc input differs from Cargo rmeta",label,externs))
        for row in files.values():
            reads = [s for s in open_rows(trace,Path(row["path"])) if
                     descends(edges,int(s.split()[0]),root["pid"],True)]
            require(reads, ("selected rustc never opened declared crate metadata",label,row["path"]))
            row["compiler_opens"] = reads
    return files


def snapshot(out, label, arts, env, native_proof):
    folder, pool = out / "states" / label, out / "objects"
    owner, = [a for a in arts if a["target"]["name"] == LIB]
    rlib, = [Path(p) for p in owner["filenames"] if p.endswith(".rlib")]
    rmeta, = [Path(p) for p in owner["filenames"] if p.endswith(".rmeta")]
    roots = {"target": Path(env["CARGO_TARGET_DIR"]), "shared": Path(env["CARGO_BUILD_BUILD_DIR"])}
    require(all(p.is_file() and any(p.is_relative_to(r) for r in roots.values()) for p in [rlib, rmeta]),
            (rlib, rmeta))
    sessions = [s for root in roots.values() for s in root.rglob("work-products.bin")
                if s.parent.parent.name.startswith(LIB + "-") and not s.parent.name.endswith("-working")]
    session, = sessions
    index = session.read_bytes()
    lib_raw = rlib.read_bytes()
    members = archive(lib_raw)
    cgu = {}
    for long_name, obj in members.items():
        if not long_name.endswith(".rcgu.o"):
            continue
        name = long_name.split(".")[-4] + ".o"
        path = session.parent / name
        require(name not in cgu and name.encode() in index and not path.is_symlink() and
                path.read_bytes() == obj, (label, long_name, path))
        s = path.stat()
        cgu[name] = {"sha256": store(pool, obj), "dev": s.st_dev, "ino": s.st_ino, "logical": s.st_size,
                     "allocated": s.st_blocks * 512, "nlink": s.st_nlink, "member": long_name}
    require(cgu and set(cgu) == {p.name for p in session.parent.glob("*.o")}, (label, "unmatched native CGU"))
    row = {"archive": store(pool, lib_raw), "rmeta": store(pool, rmeta.read_bytes()),
           "embedded_rmeta": store(pool, members["lib.rmeta"]), "work_products": store(pool, index),
           "fresh": owner["fresh"], "paths": {"archive": str(rlib), "rmeta": str(rmeta),
                                             "session": str(session), "roots": {k: str(p) for k,p in roots.items()}},
           "cgu": cgu, "state": label,
           "dependency_products": {r["target"]["name"]: r["filenames"] for r in arts},
           "dependency_rmeta":dependency_metadata(out,label,arts,native_proof),
           "metadata_and_native_index": {n: [digest(b),len(b)] for n,b in members.items()},
           "semantic_files": {n: sha(session.parent / n) for n in ("dep-graph.bin", "query-cache.bin")}}
    record(folder / "state.json", row)
    rows, unique = [], {}
    for name, root in roots.items():
        for path in [root, *sorted(root.rglob("*"))]:
            st = path.lstat()
            blocks = st.st_blocks * 512
            require(unique.setdefault((st.st_dev,st.st_ino),blocks) == blocks, (label, path))
            rel = str(Path(name) / path.relative_to(root))
            rows.append([rel,st.st_dev,st.st_ino,st.st_nlink,st.st_size,blocks])
    record(folder / "storage.json.gz", {"rows": rows, "roots": row["paths"]["roots"],
           "unique_allocated": sum(unique.values()), "unique_inodes": len(unique)})
    return row
