# One ordinary GNU Ruff renderer library cell

This adapter measures or traces the unchanged Cargo command below on an isolated native GNU/Linux host. Each cell enrolls one compiler and one of two Ruff histories. The numerical decision, calibration and cross-cell native/DWARF/metadata proof are separate. The registered plan is in [PLAN.md](PLAN.md).

~~~sh
cargo +ohm build -p ruff_annotate_snippets --lib --locked --offline -j4 --message-format=json
~~~

## Inputs

* Obtain the terminal qualified three-compiler source transfer. Pin its official job, attempt, checkout, original ZIP digest and the digest of its internal manifest independently. Use that source job's unmodified restore.py to restore one complete SDK to the chosen logical location. The adapter verifies the entire installed regular-file roster, modes, sizes and hashes against that exact manifest. Only the compiler driver varies across P, F and C. All use the same Cargo #301 and signed Wild.
* The Ruff Git seed must contain 93526150df078af7dd8fc4226cdcc469539d2001, the parent and child of 9c53b5de3aae4b1832eb7ee137647dda2466f888, and the complete 03989bfe060d0ed48dd9ea7d0c99a35c12b9c323 and 68d556d0630ecb8367cf041c3e857aa917799c43 trees. Fetch them before the worker starts. The adapter clones the local seed into the cell and verifies both historical patches against Git. The primary starts from the reversed full two-file patch on the registered checkout. The notebook starts at the complete old commit. [Source-map edit](https://github.com/astral-sh/ruff/commit/9c53b5de3aae4b1832eb7ee137647dda2466f888) · [Notebook edit](https://github.com/astral-sh/ruff/commit/68d556d0630ecb8367cf041c3e857aa917799c43)
* Pass a local registry directory containing one sparse index and the union of checksum-matching locked crates from both checkouts. There are 498 checksummed packages in the primary lock and 501 in the notebook lock. Each hosted installation copies its complete lock, creates an independent Cargo home and lets Cargo extract its sources normally. The separate signed-only local rehearsal permits a subset. Original Cargo stdout names every package actually built. The supplied rustup proxy directory must contain cargo, rustc and rustdoc backed by the actual rustup inode.
* The work and result directories must initially be absent, on filesystems with more than 4 GiB free. Use exactly the same absolute source, SDK, work, targets and output paths for all compilers on a worker. Result folders may be different. Park the previous cell's work and SDK before reusing its paths. Per-role stores remain independent. The matching source transfer is shared across all cells.

The historical dev profiles differ. The source-map library receives opt-level 1 and exercises both proposed compiler conditions. The notebook library uses the compiler default opt-level 0. Both placement changes require exactly level 1. The notebook is a real ordinary-workflow safety and overhead control. The structural reopener checks these actual flags on every physical renderer compiler.

## Run a cell

Set each uppercase shell variable to its acquired local path or immutable digest. Historical input self-checks run without a compiler.

~~~sh
sha256sum --strict --check SHA256SUMS
python3 -IB selfcheck.py "$RUFF_GIT_SEED"

python3 -IB arm.py --role P --history source-map --lane structural \
  --work "$WORK" --out "$OUT" --sdk "$SDK" \
  --manifest "$TRANSFER/manifest.json" --manifest-sha "$TRANSFER_MANIFEST_SHA" \
  --ruff "$RUFF_GIT_SEED" --registry "$REGISTRY_SEED/registry" --proxies "$RUSTUP_PROXY_DIR"
~~~

Run the same cell with --role F or C and --history notebook as assigned. For a separately enrolled counter cell, supply --lane whole --counter "$PLAIN" --counter-sha "$PLAIN_SHA". The caller independently authenticates, compiles and calibrates the inherited whole-process plain counter. Its interface is plain OUTPUT.json COMMAND ARG ... . The counter runs on old cold, edit and first unchanged. Each has a separate raw ABI file, stdout, stderr and process exit. No traced ordinary command is counted.

Both edit-pair FDs are prepared before either Cargo starts. After the edit completes, the same process immediately launches the first repeat. It inspects products, output bytes and traces only after the repeat. In a structural cell the complete kernel trace also proves the fresh repeat does not write, rename or replace an rlib or rmeta anywhere in either store. In a counted cell, the artifacts belong to the joint endpoint. The separate matched structural flank supplies the per-command compiler and input evidence.

The cell then exercises an invalid library source, its repair, an independently empty corrected build and an independently empty invalid build. Three independent private Cargo homes, targets and build directories use the same logical names. Real upstream named tests use separate proof targets. The test suite, native clients and readback run outside counters.

## Raw evidence and replay

* raw/PHASE contains the ordinary command and launch, both original streams and the exit. Whole cells also retain the counter file for the three registered commands. Structural cells retain the complete compressed kernel trace and native.json. Each selected rustc row has its actual PID, physical executable, ordered argv, ordered actual environment, kernel-observed working directory and opens of the specific role driver. Cargo-provided jobserver descriptors refer to that historical process. Their numeric values are not reusable handles.
* states/PHASE/state.json resolves each returned archive, separate rmeta, embedded rmeta, completed work-products index, ordered members and each physical CGU. objects/SHA256 holds the full original bytes. Each CGU comes from the actual completed session, occurs in its work-products index and equals the corresponding archive member. states/PHASE/storage.json.gz lists every path in target and shared with device, inode, link count, logical bytes and st_blocks times 512. The total counts each inode once across both roots. Invalid phases retain the typed E0308 and primary source span. subject.json records the SDK's allocation separately.
* oracles/PHASE contains the native consumer compiler trace, including the actual opens of Cargo's returned rlib by the selected rustc or its worker thread. Child linker reads are reported separately. The consumption test uses genuine source-derived inputs and byte-literal outputs. The old renderer really panics on two source-map renderings. The original upstream test declares that panic expected. Installing only the corrected test source next to the old renderer makes that actual named test fail. The corrected test passes without the panic. For notebooks, all four old snapshots differ from their corrected counterparts. The wrong-old-reader witness reopens the retained old executable on the new expectations.
* Editing and replaying a repaired source leaves the original native closure in work/parked-empty. The complete independently clean corrected closure is in work/parked-empty-invalid and the current slot contains the independently invalid attempt. The working tree is corrected when the cell returns. In the structural lane, a separate mono-placement consumer may copy the corresponding captured closure and use the actual old/edit compiler environment and cwd after the ordinary lane has closed.

For an exact mono-placement replay, use dependency_rmeta in each state.json. Each of the three entries records the full bytes in the content store, the original path, physical identity and size. Where the structural command executes the renderer rustc, its literal three --extern arguments must agree with those paths, and a read-only kernel FD open from the rustc or its own worker thread must exist for each. The fresh repeat retains the files without attributing reads to a compiler that did not run.

~~~sh
python3 -IB reopen.py "$OUT"
~~~

This verifies the content store and typed verdicts and reexecutes the retained ordinary-library readers from memory. The three authentic upstream test ELFs additionally need the absolute workspace manifests that snapbox resolves from its compile-time CARGO_MANIFEST_DIR. To independently execute them, park the original source and run the command below in the original owned work directory. The reader rehydrates only the exact archived manifests, renderer and test source at that now-vacant location for each test. It removes its own temporary symlink. Restore the parked source for further analysis.

~~~sh
mv -- "$WORK/source" "$WORK/source-before-offline-replay"
python3 -IB reopen.py "$OUT" --upstream-files --upstream-work "$WORK"
mv -- "$WORK/source-before-offline-replay" "$WORK/source"
~~~

Only a successful complete.json plus this ordinary structural proof, the independent registered native/DWARF/metadata proof, both official source gates and paired numerical gates can admit a performance claim. The adapter keeps all original bytes on mismatches. In particular, a matching executable alone cannot qualify differing Rust metadata.
