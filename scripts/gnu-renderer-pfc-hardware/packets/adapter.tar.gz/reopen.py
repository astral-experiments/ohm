"""Reopen one completed ordinary Ruff cell offline from its original Cargo/ELF/file evidence."""

import argparse
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from workload import BASE, CLI, HERE, LIB, ROOT, SIGNED, TEST, UNITS, digest, require, sha
from receipts import descends, exec_details, messages, no_product_changes, open_rows, parent_edges
from behavior import PANIC
from worker_artifacts import archive


def load(p):
    b = p.read_bytes()
    return json.loads(gzip.decompress(b) if p.suffix == ".gz" else b)


def execute(binary, args):
    fd = os.memfd_create("verified-renderer-reader")
    try:
        with os.fdopen(os.dup(fd), "wb") as f:
            f.write(binary)
        os.fchmod(fd, 0o700)
        return subprocess.run([f"/proc/self/fd/{fd}", *args], env={"PATH":"/usr/bin:/bin","LC_ALL":"C.UTF-8"},
                              pass_fds=(fd,), capture_output=True, timeout=15)
    finally:
        os.close(fd)


def verify_structural_processes(out, raw, label, history):
    captured = load(raw / label / "native.json")
    tr = gzip.decompress((raw / label / "strace.gz").read_bytes())
    context = load(out / "environment.json")
    driver = Path(load(out / "subject.json")["driver_path"])
    # Original FD target strings are canonical kernel paths, even after that filesystem is gone.
    permit = {str(driver.parent.parent / "bin/rustc"), str(Path(context["RUSTUP_HOME"]) / "toolchains/ohm/bin/rustc")}
    actual = []
    for pid,path,argv,env in exec_details(tr):
        require(Path(path).name not in {"ld","ld.bfd","ld.lld","wild","rust-lld"}, (label, "unexpected native link"))
        if "--crate-name" in argv and "--print" not in argv and any(x.startswith("--emit=") for x in argv):
            require(path in permit, (label, "unexpected rustc",path))
            actual.append((pid,path,argv,env))
    seen = captured["compilers"]
    require(not captured["linkers"] and actual == [(r["pid"],r["path"],r["argv"],r["environment"])
                                                  for r in seen], (label, "stored process manifest"))
    wanted = {"old":UNITS, "edit":{LIB}, "repeat":set(), "empty":UNITS, "invalid":{LIB},
              "empty-invalid":UNITS,"repaired-repeat":set()}
    names = {r["name"] for r in seen}
    require(len(names)==len(seen) and (names == wanted[label] if label in wanted else
            label == "repair" and names <= {LIB}), (label,names))
    loaded = open_rows(tr, driver)
    for r in seen:
        require([row for row in loaded if int(row.split()[0]) == r["pid"]] == r["driver_opens"] and
                r["driver_opens"] and all("AT_FDCWD<"+r["cwd"]+">" in s for s in r["driver_opens"]),label)
        if r["name"] == LIB:
            argv = r["argv"]
            opts = [opt for i,a in enumerate(argv) if a == "-C" and i+1<len(argv) and
                    (opt:=argv[i+1]).startswith("opt-level=")]
            require(not any(a.startswith("-Copt-level=") for a in argv) and
                    opts == (["opt-level=1"] if history=="source-map" else []) and
                    "--target" not in argv and argv.count("-Zohm-caller-local-cgus")==1 and
                    any(a.startswith("incremental=") for a in argv) and "--emit=dep-info,metadata,link" in argv,
                    (history,label,"wrong codegen treatment profile",opts))


def upstream_from_archived_source(out, result, role, private_work):
    """snapbox::current_rs! locates a manifest above its compile-time absolute directory."""
    folder = out / "upstream" / role
    logical = Path(load(folder / "build/started.json")["cwd"])
    require(logical.is_absolute() and logical.name == "source" and logical.parent.is_dir()
            and logical.parent.stat().st_uid == os.getuid() and not os.path.lexists(logical),
            ("park the original owned training source before independent upstream program replay",logical))
    if private_work is None:
        require(subprocess.check_output(["findmnt","-T",logical.parent,"-no","FSTYPE"]).strip() == b"tmpfs",
                ("use a disposable tmpfs or pass the original private --upstream-work", logical))
    else:
        require(private_work.resolve(strict=True) == logical.parent and private_work == logical.parent and
                private_work.stat().st_mode & 0o777 == 0o700 and
                sha(private_work / "native-reader.rs") == sha(out/"inputs/reader.rs"),
                ("physical private source root or captured client source does not match", private_work))
    state = "new" if role == "independent-corrected" else "old"
    test_state = "old" if role == "old-declared-panic" else "new"
    orig = out / "sources"
    with tempfile.TemporaryDirectory(dir=logical.parent, prefix="signed-snapbox-") as temp:
        tree = Path(temp)
        for rel,src in [("Cargo.toml",state),(BASE+"Cargo.toml",state),
                        (BASE+"src/renderer/source_map.rs",state),(TEST,test_state)]:
            dest = tree / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes((orig / src / rel).read_bytes())
            require(sha(dest) == load(orig / src / "source.json")["files"][rel], rel)
        require(sha(tree/TEST) == result["test_input"] and sha(tree/(BASE+"src/renderer/source_map.rs")) ==
                result["renderer_input"], "wrong mixed source for literal upstream test")
        logical.symlink_to(tree, target_is_directory=True)
        try:
            return execute((out / "objects" / result["actual_program"]).read_bytes(), result["native"][1:])
        finally:
            require(logical.is_symlink() and logical.resolve() == tree, logical)
            logical.unlink()


def reopen(out, execute_readers=True, upstream_files=False, private_work=None):
    require(not (out / "refusal.txt").exists(), "prior gate refused")
    result = load(out / "complete.json")
    runtime = load(out / "runtime.json")
    subject = load(out / "subject.json")
    raw = out / "raw"
    pool = out / "objects"
    require(result["ordinary"] == CLI and result["history"] == runtime["history"]
            and result["role"] == subject["role"], "mismatched enrollment")
    if (out / "workload-source.json").is_file():
        app = load(out / "workload-source.json")
        require({p:sha(HERE / p) for p in app} == app, "worker source changed")
    require(result["source"] == subject["source"]["commit"] == {**ROOT, "signed-control": SIGNED}[result["role"]],
            "different compiler")
    for f in pool.iterdir():
        require(f.is_file() and not f.is_symlink() and sha(f) == f.name, ("physical object digest mismatch", f))
    oldnew = {state:{p.name:p.read_bytes() for p in (out / "inputs" / state).glob("*")}
              for state in ("old","new")}
    for state in ("old","new"):
        folder = out / "sources" / state
        source = load(folder / "source.json")
        require({n:sha(folder / n) for n in source["files"]} == source["files"], state)
    require(load(out / "registry-old.json")["available"] == load(out / "registry-empty.json")["available"] ==
            load(out / "registry-empty-invalid.json")["available"], "registry changed across independent empties")
    if result["role"] != "signed-control":
        require(sha(out / "source-sdk-manifest.json") == subject["manifest_sha"] and
                load(out / "registry-old.json")["complete"], "hosted input admission")
    working = {}
    for label in ("old","edit","repeat","invalid","repair","repaired-repeat","empty","empty-invalid"):
        invalid = label in {"invalid","empty-invalid"}
        require(load(raw / label / "terminal.json")["status"] == (101 if invalid else 0), label)
        launched = load(raw / label / "started.json")
        require(launched["command"] == CLI and launched["launch"][-len(CLI):] == CLI, label)
        roster = messages(raw, label, invalid=invalid)
        if invalid:
            require(load(out / "states" / label / "diagnostic.json") == roster, label)
            continue
        row = load(out / "states" / label / "state.json")
        require({x["target"]["name"]:x["filenames"] for x in roster} == row["dependency_products"], label)
        own, = [r for r in roster if r["target"]["name"] == LIB]
        require(own["fresh"] == row["fresh"] and row["paths"]["archive"] in own["filenames"] and
                row["paths"]["rmeta"] in own["filenames"], (label, "physical output names"))
        members = archive((pool / row["archive"]).read_bytes())
        require(row["metadata_and_native_index"] == {n:[digest(b),len(b)] for n,b in members.items()}, label)
        require(row["embedded_rmeta"] == digest(members["lib.rmeta"]) and (pool / row["rmeta"]).is_file(), label)
        native = {n.split(".")[-4] + ".o":(n,b) for n,b in members.items() if n.endswith(".rcgu.o")}
        require(len(native) == sum(n.endswith(".rcgu.o") for n in members) and native.keys() == row["cgu"].keys(), label)
        deposit = (pool / row["work_products"]).read_bytes()
        for name, obj in row["cgu"].items():
            long, b = native[name]
            require(name.encode() in deposit and long == obj["member"] and len(b) == obj["logical"] and
                    (pool / obj["sha256"]).read_bytes() == b, (label,name))
        ledger = load(out / "states" / label / "storage.json.gz")
        physical = {}
        for path,dev,ino,nlink,size,blocks in ledger["rows"]:
            require(path.split("/",1)[0] in {"target","shared"} and
                    physical.setdefault((dev,ino),(nlink,size,blocks)) == (nlink,size,blocks), (label,path))
        require(ledger["unique_allocated"] == sum(v[2] for v in physical.values()) == result["allocated"][label],
                (label, "complete allocated store"))
        require(all((s["nlink"],s["logical"],s["allocated"]) == physical[s["dev"],s["ino"]]
                    for s in row["cgu"].values()), (label, "CGUs in physically counted stores"))
        dep = row["dependency_rmeta"]
        require(dep.keys()==UNITS-{LIB}, (label,"missing external crate"))
        for name, obj in dep.items():
            require(obj["path"] in row["dependency_products"][name] and obj["path"].endswith(".rmeta")
                    and (pool/obj["sha256"]).stat().st_size==obj["bytes"] and
                    physical[obj["dev"],obj["ino"]][1:]==(obj["bytes"],obj["allocated"]),
                    (label,"external metadata ownership",name))
        if result["lane"] == "structural":
            native = load(raw/label/"native.json")["compilers"]
            roots = [r for r in native if r["name"]==LIB]
            if roots:
                root,=roots
                argv=root["argv"]
                externs=[argv[i+1].split("=",1) for i,a in enumerate(argv) if a=="--extern"]
                require(len(externs)==len(dep) and dict(externs)=={k:o["path"] for k,o in dep.items()},label)
                tr=gzip.decompress((raw/label/"strace.gz").read_bytes())
                edges=parent_edges(tr)
                for obj in dep.values():
                    rows=[s for s in open_rows(tr,Path(obj["path"])) if
                          descends(edges,int(s.split()[0]),root["pid"],True)]
                    require(rows==obj["compiler_opens"] and rows,(label,obj["path"]))
            else:
                require(all("compiler_opens" not in o for o in dep.values()), label)
        working[label] = row
    require(load(out / "states/invalid/diagnostic.json") == load(out / "states/empty-invalid/diagnostic.json"),
            "diagnostic differs across original valid/empty targets")
    timed = result["lane"] == "whole"
    for label in ("old","edit","repeat","empty","invalid","repair","repaired-repeat","empty-invalid"):
        par = raw / label
        sampled = timed and label in {"old","edit","repeat"}
        require((par / "pmu.json").is_file() == sampled and (par / "strace.gz").exists() == (not timed), label)
        if not timed:
            verify_structural_processes(out,raw,label,result["history"])
    witness = load(out / "edit-pair.json")
    require(not witness["intervening_reads"] and witness["states_sampled_after_first_repeat"] and
            witness["structural_repeat_no_product_writes"] == (not timed), witness)
    require(load(raw / "edit" / "terminal.json")["end_mono_ns"] <=
            load(raw / "repeat" / "terminal.json")["begin_mono_ns"], "reversed edit/repeat")
    if not timed:
        no_product_changes(raw, [Path(v) for v in working["repeat"]["paths"]["roots"].values()])
    for k in ("archive","rmeta","cgu","work_products","paths"):
        require(working["edit"][k] == working["repeat"][k], ("fresh changed",k))
    for label in ("old","edit","repeat","repair","empty"):
        state = "old" if label == "old" else "new"
        folder = out / "oracles" / label
        obs = load(folder / "reader.json")
        require(obs["archive"] == working[label]["archive"] and obs["returned_path"] == working[label]["paths"]["archive"]
                and obs["source"] == sha(out / "inputs/reader.rs"), label)
        require(obs["lineage"]["compiler_readers"] and obs["archive_opens"] and obs["driver_opens"], label)
        prior = [key for key in oldnew["new"]]
        require(set(prior) == obs["cases"].keys(), (label, "reader cases"))
        for key in prior:
            rc = 101 if label == "old" and result["history"] == "source-map" else 0
            stdout, stderr = [(folder / key / name).read_bytes() for name in ("stdout","stderr")]
            case = obs["cases"][key]
            require(load(folder / key / "terminal.json")["status"] == case["exit"] == rc and
                    [digest(stdout),digest(stderr)] == [case["stdout"],case["stderr"]], (label,key))
            require((not stdout and PANIC in stderr) if rc else (not stderr and stdout == oldnew[state][key]),
                    (label,key,"literal expected behavior"))
            if execute_readers:
                p = execute((pool / obs["program"]).read_bytes(), [key])
                require(p.returncode == rc and p.stdout == stdout and
                        (PANIC in p.stderr if rc else p.stderr == stderr), (label,key,"offline replay"))
        if label != "old":
            require(obs["program"] == result["consumer_corrected"], label)
    wrong = load(out / "wrong-reader/result.json")
    require(wrong["reader"] == load(out / "oracles/old/reader.json")["program"], "wrong ELF control")
    for key, case in wrong["cases"].items():
        b = (out / "wrong-reader" / key / "stdout").read_bytes()
        require(digest(b) == case["actual"] and case["rejected_against"] == digest(oldnew["new"][key])
                and b != oldnew["new"][key], key)
    if result["history"] == "source-map":
        for label, code, panic in [("old-declared-panic",0,True),("old-renderer-corrected-assertion",101,True),
                                   ("independent-corrected",0,False)]:
            info = load(out / "upstream" / label / "result.json")
            run = out / "upstream" / label / "multiple_insertions"
            require(load(run / "terminal.json")["status"] == code and
                    ((PANIC in (run / "stderr").read_bytes()) == panic), label)
            if upstream_files:
                p = upstream_from_archived_source(out, info, label, private_work)
                require(p.returncode == code and b"running 1 test" in p.stdout and (PANIC in p.stderr) == panic,
                        (label, "offline native upstream test"))
    return {"role":result["role"],"history":result["history"],"lane":result["lane"],
            "objects":len(list(pool.iterdir())), "storage":result["allocated"],"states":len(working),
            "diagnostics":2,"native_readers_reexecuted":execute_readers,
            "actual_ordinary_rustc_opt_level":None if timed else (1 if result["history"]=="source-map" else 0),
            "upstream_native_reexecuted_with_full_source_inputs":upstream_files and result["history"]=="source-map"}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("receipt",type=Path)
    p.add_argument("--no-exec",action="store_true")
    p.add_argument("--upstream-files",action="store_true",
                   help="reopen three snapbox test ELFs in a private tmpfs at their now-vacant captured source path")
    p.add_argument("--upstream-work",type=Path,
                   help="allow the original owned 0700 work directory with its verified native-reader source")
    a=p.parse_args()
    require(not (a.no_exec and a.upstream_files), "runtime replay was disabled")
    require(not a.upstream_work or a.upstream_files, "explicit --upstream-files required")
    print(json.dumps(reopen(a.receipt.resolve(), not a.no_exec,a.upstream_files,a.upstream_work),indent=2,sort_keys=True))
