use annotate_snippets::{AnnotationKind, Level, Patch, Renderer, Snippet};
use annotate_snippets::renderer::DecorStyle;
fn case_0(unicode: bool) -> String {
    let source = "First line\r\nSecond oops line";
    let input = &[
        Level::ERROR.primary_title("oops").element(
            Snippet::source(source)
                .path("foo.ipynb")
                .cell_index(Some(1))
                .annotation(AnnotationKind::Primary.span(19..23).label("oops")),
        ),
        Level::HELP
            .secondary_title("remove the entry")
            .element(
                Snippet::source(source)
                    .path("foo.ipynb")
                    .cell_index(Some(1))
                    .patch(Patch::new(19..24, "")),
            )
            .element(
                Snippet::source(source)
                    .path("foo.ipynb")
                    .cell_index(Some(1))
                    .patch(Patch::new(23..28, "")),
            ),
    ];
    let renderer = Renderer::plain();
    if unicode { renderer.decor_style(DecorStyle::Unicode) } else { renderer }.render(input)
}
fn case_1(unicode: bool) -> String {
    let source = "First line\r\nSecond oops line";
    let input = &[
        Level::ERROR.primary_title("oops").element(
            Snippet::source(source)
                .path("foo.ipynb")
                .cell_index(Some(1))
                .annotation(AnnotationKind::Primary.span(19..23).label("oops")),
        ),
        Level::HELP
            .secondary_title("remove the entry")
            .element(
                Snippet::source(source)
                    .path("foo.ipynb")
                    .cell_index(Some(1))
                    .patch(Patch::new(19..24, "")),
            )
            .element(
                Snippet::source(source)
                    .path("foo.ipynb")
                    .cell_index(Some(2))
                    .patch(Patch::new(23..28, "")),
            ),
    ];
    let renderer = Renderer::plain();
    if unicode { renderer.decor_style(DecorStyle::Unicode) } else { renderer }.render(input)
}
fn main() { let key = std::env::args().nth(1).unwrap(); let output = match key.as_str() {
    "patch_with_primary_path_cell-ascii" => case_0(false),
    "patch_with_primary_path_cell-unicode" => case_0(true),
    "patch_with_primary_path_incrementing_cell-ascii" => case_1(false),
    "patch_with_primary_path_incrementing_cell-unicode" => case_1(true),
    _ => panic!("unenrolled case"),
}; print!("{output}"); }
