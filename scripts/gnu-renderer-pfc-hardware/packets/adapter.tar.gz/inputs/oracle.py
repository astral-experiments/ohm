"""Derive exact public Rust inputs and literal expected snapshots from the registered committed test code."""
from pathlib import Path
import hashlib,json,re,subprocess
def H(d):return hashlib.sha256(d).hexdigest()
def roles(repo,reg):
 p='crates/ruff_annotate_snippets/tests/ruff.rs';roles={};inputs={}
 for state in ('old','new'):
  entry=reg['source'][state];source=subprocess.check_output(['git','-C',repo,'show',entry['commit']+':'+p]);assert H(source)==entry['files'][p];text=source.decode();expected={}
  for name in reg['typed_cases']:
   marker='#[test]\nfn '+name+'() {\n';assert text.count(marker)==1
   body=text.split(marker,1)[1].split('\n}\n',1)[0]
   inp,check=body.split('    let expected_ascii = ',1)
   assert 'let source = "First line\\r\\nSecond oops line";' in inp and inp.count('Snippet::source(source)')==3 and inp.count('.patch(Patch::new(')==2
   assert inputs.setdefault(name,inp)==inp
   for mode in ('ascii','unicode'):
    m=re.search(r'let expected_'+mode+r' = str!\[\[r#"\n(.*?)\n"#\]\];',body, re.S);assert m
    expected[name+'-'+mode]=m[1].encode()
   assert body.count('assert_data_eq!(renderer.render(input),')==2
  roles[state]=expected
  assert len(expected)==4
 assert roles['old'].keys()==roles['new'].keys() and all(roles['old'][k]!=roles['new'][k] for k in roles['old'])
 code='use annotate_snippets::{AnnotationKind, Level, Patch, Renderer, Snippet};\nuse annotate_snippets::renderer::DecorStyle;\n'
 for i,(name,inp) in enumerate(inputs.items()):
  code+=f'fn case_{i}(unicode: bool) -> String {{\n'+inp+'    let renderer = Renderer::plain();\n    if unicode { renderer.decor_style(DecorStyle::Unicode) } else { renderer }.render(input)\n}\n'
 code+='fn main() { let key = std::env::args().nth(1).unwrap(); let output = match key.as_str() {\n'
 for i,name in enumerate(inputs):
  for mode in ('ascii','unicode'):code+=f'    "{name}-{mode}" => case_{i}({str(mode=="unicode").lower()}),\n'
 code+='    _ => panic!("unenrolled case"),\n}; print!("{output}"); }\n'
 return code.encode(),roles
if __name__=='__main__':
 q=Path(__file__).resolve().parent;reg=json.loads((q.parent/'registration.json').read_bytes());code,roles_=roles('/home/dev-user/code/oss/ruff',reg);(q/'reader.rs').write_bytes(code)
 for state,by_case in roles_.items():
  for key,val in by_case.items():
   f=q/'expect'/state/key;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(val)
 print('registered literal snapshots',[(s,{k:len(v) for k,v in d.items()}) for s,d in roles_.items()])
