"""Verify an untraced measured cell using only its own products and an independently traced kernel witness."""
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from native_elf import digest,require,sha
from oracle import load_cell,main
from cell_safety import CLI,consumer_verdicts,inspect as inspect_structural

UNITS={"annotate_snippets","memchr","anstyle","unicode_width"}
PHASES=("old","edit","repeat","repair","repaired-repeat","empty","invalid","empty-invalid")
SCORED=("old","edit","repeat")
EXPECTED={"old":UNITS,"edit":{"annotate_snippets"},"repeat":set(),"empty":UNITS,"repaired-repeat":set()}
def read(p):return json.loads(p.read_bytes())


def typed(d,phase):
    raw=(d/"stdout").read_bytes().splitlines()
    rows=[json.loads(x)for x in raw]
    invalid=phase in ("invalid","empty-invalid")
    require(rows and rows[-1]=={"reason":"build-finished","success":not invalid},"wrong complete typed Cargo result")
    arts=[a for a in rows if a["reason"]=="compiler-artifact"]
    if invalid:return {}
    require(len(arts)==len(UNITS) and {a["target"]["name"] for a in arts}==UNITS,"typed four-unit graph differs")
    targets={}
    for a in arts:
        t=a["target"]; name=t["name"]
        require(t["kind"]==["lib"] and t["crate_types"]==["lib"] and a["executable"] is None,"not ordinary Rust library selection")
        targets[name]=[t["kind"],t["crate_types"],t["edition"],a["features"],a["profile"],a["fresh"]]
    dirty={n for n,v in targets.items()if not v[-1]}
    require(dirty==EXPECTED[phase] if phase in EXPECTED else dirty<={"annotate_snippets"},"wrong typed dirty/fresh decisions")
    return targets


def pmu_event(raw,term):
    keys={"start","stop","instructions","enabled","running","event_errno","code","user_us","system_us"}
    require(set(raw)==keys and all(type(v)is int for v in raw.values()),"unknown whole-command PMU schema")
    require(raw["instructions"]>0 and raw["running"]==raw["enabled"]>0 and raw["event_errno"]==raw["code"]==term["status"]==0
            and min(raw["user_us"],raw["system_us"])>=0,"zero, multiplexed or unsuccessful whole counter")
    require(term["begin_mono_ns"]<=raw["start"]<raw["stop"]<=term["end_mono_ns"],"PMU window outside genuine Cargo visit")


def counter_launch(launch,outfile,role,history,phase):
    require(len(launch)==len(CLI)+2 and launch[2:]==CLI,"foreign measured launch")
    record=Path(launch[1]); observer=Path(launch[0])
    require(record.is_absolute()and observer.is_absolute()and ".." not in record.parts and ".." not in observer.parts
            and record.parts[-5:]==("cells",role+"-"+history,"raw",phase,"pmu.json")
            and observer==record.parents[4]/"observers/plain","PMU paths are not original same-cell plain observer")
    require(outfile.name==record.name,"wrong reopened PMU record")


def check_source(root):
    result={}
    for phase in ("old","new"):
        base=root/"sources"/phase;manifest=read(base/"source.json")
        names=manifest["files"]
        require(all(not Path(v).is_absolute() and ".." not in Path(v).parts for v in names),"unsafe retained source path")
        geometry={p.relative_to(base).as_posix() for p in base.rglob("*") if p.is_file()}
        require(geometry==set(names)|{"source.json"} and all(sha((base/f).read_bytes())==h for f,h in names.items()),
                "live role source disagrees with original recorded tree or manifest")
        result[phase]=manifest
    return result


def inspect(path,history,states,structural_root):
    done=read(path/"complete.json"); body=read(path/"subject.json"); rt=read(path/"runtime.json");role=done["role"]
    require(role in ("P","F","C") and done["history"]==rt["history"]==history and done["lane"]==rt["lane"]=="whole"
            and done["structural_only"] is False and done["ordinary"]==CLI and body["role"]==role and
            done["source"]==body["source"]["commit"],"wrong scored role, source, history or lane")
    for phase,field in (("old","cold_cgu"),("edit","warm_cgu"),("empty","empty_cgu")):
        require(done[field]==len(states[phase].objects),"measured physical partition count disagrees")
    witness=structural_root/(role+"-"+history)
    require(witness.resolve()!=path.resolve(),"kernel witness is the measured cell")
    wsubject=read(witness/"subject.json"); wrun=read(witness/"runtime.json")
    require(wrun["lane"]=="structural" and wrun["counter"] is None and wrun["boot"]!=rt["boot"]
            and wrun["versions"]==rt["versions"],"borrowed kernel witness lacks distinct physical qualification boot")
    pairs=read(path/"edit-pair.json")
    require(pairs["intervening_reads"] is False and pairs["states_sampled_after_first_repeat"] and pairs["untraced_pair"]
            and pairs["structural_repeat_no_product_writes"] is False,"measured pair misclassified as native trace or interrupted")
    for key in ("source","tools","manifest_sha","role"):
        require(body[key]==wsubject[key],"measured SDK/source mismatch with independent control: "+key)
    for f in ("source-sdk-manifest.json","workload-source.json"):
        require((path/f).read_bytes()==(witness/f).read_bytes(),"different acquisition registration between studies: "+f)
    manifest=read(path/"source-sdk-manifest.json")
    require(sha((path/"source-sdk-manifest.json").read_bytes())==body["manifest_sha"] and
            manifest["roles"][role]["driver"][0]==done["driver"]==body["tools"][manifest["driver"]] and
            manifest["roles"][role]["source"]==body["source"], "source-bound compiler driver is not the admitted subject")
    require(check_source(witness)==check_source(path),"full historical source membership or identity differs")
    for phase in ("old","empty","empty-invalid"):
        a=read(path/("registry-"+phase+".json"));b=read(witness/("registry-"+phase+".json"))
        require(a["complete"] is True and b["complete"] is True and
                len(a["available"])==a["locked"] and all(a[k]==b[k] for k in ("available","locked","name")),
                "matched-boot registry is not the exact complete locked cohort")
    observer=path.parent.parent/"observers/plain"
    counter_spec=read(path.parent.parent/"observer.json")
    require(not observer.is_symlink() and observer.is_file() and sha(observer.read_bytes())==rt["counter"]==counter_spec["bins"]["plain"]
            and counter_spec["ref"]=="8a659140df8ab27fd6a8cc61f5eb38717b3f8bbc" and
            counter_spec["abi"]["type"]=="PERF_TYPE_HARDWARE" and counter_spec["abi"]["config"]=="PERF_COUNT_HW_INSTRUCTIONS" and
            all(counter_spec["abi"][k]==1 for k in ("inherit","disabled","enable_on_exec","exclude_kernel","exclude_hv")),
            "wrong physical whole-command observer or calibration scope")
    evidence={};windows={}
    for phase in PHASES:
        d=path/"raw"/phase;start=read(d/"started.json"); t=read(d/"terminal.json")
        require(start["command"]==CLI and not (d/"strace.gz").exists() and not (d/"native.json").exists()
                and t["status"]==(101 if phase in ("invalid","empty-invalid") else 0)
                and t["begin_mono_ns"]<t["end_mono_ns"],"false exec or wrong status in measured cell")
        measured=typed(d,phase); observed=typed(witness/"raw"/phase,phase)
        require(all(v[:-1]==observed[n][:-1] for n,v in measured.items()) and measured.keys()==observed.keys(),"scored typed graph disagrees with structural graph")
        p=d/"pmu.json";require(p.exists()==(phase in SCORED),"unexpected or missing PMU evidence")
        if phase in SCORED:
            counter_launch(start["launch"],p,role,history,phase);pval=read(p);pmu_event(pval,t)
            windows[phase]=[t["begin_mono_ns"],t["end_mono_ns"]]
        else:require(start["launch"]==CLI,"independent correctness control was counted or interposed")
        evidence[phase]={"start":sha((d/"started.json").read_bytes()),"end":sha((d/"terminal.json").read_bytes()),
                         "typed":digest(measured),"raw_stdout":sha((d/"stdout").read_bytes()),
                         "pmu":sha(p.read_bytes()) if p.exists() else None}
    require(windows["old"][1]<windows["edit"][0]<windows["edit"][1]<=windows["repeat"][0],"wrong whole window order")
    ws,*_=load_cell(witness,history); wres=inspect_structural(witness,history,ws)
    require(wres["role"]==role and wres["source"]==done["source"] and wres["driver"]==done["driver"],"kernel witness is not the corresponding measured source role")
    live=consumer_verdicts(path,history,states)
    require(live["actual_reruns"]==wres["actual_reruns"] and live["complete_error"]==wres["complete_error"],
            "measured cell native behavior or error differs from traced subject")
    return {"role":role,"source":done["source"],"driver":done["driver"],"registered_argv":CLI,**live,
            "distinct_structural_boot":wrun["boot"],"whole_boot":rt["boot"],"measurements":evidence,
            "kernel_witness":{"scope":"separate structural installation; never a per-measured-process count",
                              "source":wres["source"],"driver":wres["driver"],"compilation_level":wres["observed_renderer_opt_level"],
                              "complete":sha((witness/"complete.json").read_bytes()),"edit_native_sha256":sha((witness/"raw/edit/native.json").read_bytes())}}

if __name__=="__main__":main(whole_inspector=inspect)
