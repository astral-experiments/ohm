"""Read the supplemental Cargo JSON, rerun the four original ELFs, and recheck the changed placements."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run import BLOBS, CARGO, SIGNED, fixture, require


def read(where, role, driver):
    for src in BLOBS:
        fixture(src)
    result = json.loads((where/"result.json").read_bytes())
    require(result["role"] == role and result["driver"] == driver and result["fixtures"] == BLOBS and result["cargo"] == CARGO, "wrong source/tool identity")
    require(role in ("signed","P","F","C") and (role != "signed" or driver == SIGNED), "wrong role")
    states = result["states"]
    require(set(states) == {"old","edit","repeat","repair","empty","revert"}, "incomplete state sequence")
    require(states["old"] == states["revert"], "rollback did not regenerate the original executable")
    require(all(states[phase] == states["empty"] for phase in ("edit","repeat","repair")), "edited outputs differ from independent clean")
    totals = 0
    bodies = set()
    for phase, bins in states.items():
        old = phase in ("old","revert")
        expected = {"closures":"18/19/26\n" if old else "43/19/26\n",
                    "forwarders":'Before("text")/manual\n' if old else "manual(clone/text)/manual\n"}
        events = [json.loads(line) for line in gzip.decompress((where/(phase+".stdout.gz")).read_bytes()).splitlines()]
        actual = {e["target"]["name"] for e in events if e["reason"]=="compiler-artifact" and e.get("executable")}
        require(actual == set(expected) == set(bins), "ordinary Cargo returned wrong binaries")
        require(len([e for e in events if e["reason"]=="build-finished" and e["success"]]) == 1, "missing Cargo success")
        if phase=="repeat":
            require(all(e["fresh"] for e in events if e["reason"]=="compiler-artifact"), "first repeat was not clean")
        for name, details in bins.items():
            h = details["elf_sha256"]
            raw = gzip.decompress((where/"objects"/(h+".gz")).read_bytes())
            require(hashlib.sha256(raw).hexdigest()==h and raw.startswith(b"\x7fELF"),"retained binary corrupt")
            fd = os.memfd_create("verified-gnu-membership")
            try:
                with os.fdopen(os.dup(fd),"wb") as handle:
                    handle.write(raw)
                os.fchmod(fd,0o500)
                v = subprocess.run([f"/proc/self/fd/{fd}"], pass_fds=(fd,), capture_output=True)
            finally:
                os.close(fd)
            require(v.returncode==0 and v.stdout.decode()==expected[name]==details["output"] and not v.stderr,"stale native output")
            totals += 1
            bodies.add(h)
    require(len(bodies)==4 and {p.stem for p in (where/"objects").glob("*.gz")}==bodies,"wrong original native payload inventory")
    error = [json.loads(line) for line in gzip.decompress((where/"invalid.stdout.gz").read_bytes()).splitlines()]
    error_codes = [e["message"]["code"]["code"] for e in error if e["reason"]=="compiler-message" and e["message"]["level"]=="error" and e["message"].get("code")]
    require(set(error_codes)=={"E0308"} and result["rejected"][0]==101, "wrong ill-typed edit verdict")
    require(any(e["reason"]=="build-finished" and not e["success"] for e in error),"Cargo accepted invalid edit")
    for phase in ("old","edit"):
        for name, query in result["placement"][phase].items():
            package = "closures" if name=="concrete-glue" else "forwarders"
            rows = gzip.decompress((where/(phase+"-mono-"+package+".stdout.gz")).read_bytes()).decode().splitlines()
            require(rows.count(query)==1, "placement evidence absent or ambiguous")
            loc = query.split(" @@ ",1)[1]
            if package=="closures":
                require(("-callable.drop-" in loc)==(phase=="old" and role=="C"),"unexpected callable family")
                require(phase=="old" or ("::Zip<" in query and "-fallback.cgu[" in loc), "mixed closure owners lost fallback")
            else:
                require((".ohm-derived[" in loc)==(phase=="old" and role in ("F","C")), "manual and derived roles confused")
    print(json.dumps({"role":role,"elfs":len(bodies),"native_verdicts":totals,"ill_typed_errors":error_codes,"result_sha256":hashlib.sha256((where/"result.json").read_bytes()).hexdigest()},sort_keys=True))


if __name__=="__main__":
    read(Path(sys.argv[1]), sys.argv[2], sys.argv[3])
