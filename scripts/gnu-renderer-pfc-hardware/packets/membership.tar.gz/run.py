"""Exercise a derive-to-manual and single-to-mixed closure edit on a single installed Ohm SDK."""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess


HERE = Path(__file__).resolve().parent
BLOBS = {"forwarders":"7f728b151244b1b9f31477ab758b22a9186503f0",
         "reader":"a4e8f1ffba2ff7b82c60918bb45cdb60e3f3dad4",
         "closures":"6879c6a62f89472ceba5eac064178825f7edb7a1"}
CARGO = "9fb29f6abecad05acb6015990615c5fbb435a5907543f0bd33cf88cada4f5826"
SIGNED = "dae4f8dc64b2b2ac9dc04dfe2cfad633d6af1a87da2dfc532e757ffe758680e3"
CLI = ["+ohm","build","--workspace","--offline","--locked","--message-format=json","-j2"]
ORIGINAL_MAIN = """    assert_eq!(scoped(black_box(5)), 18);
    assert_eq!(mixed(black_box(5)), 19);
    assert_eq!(higher_ranked(black_box(5)), 26);"""
PRINT = '    println!("{}/{}/{}", scoped(black_box(5)), mixed(black_box(5)), higher_ranked(black_box(5)));'
DIRECT = "    let mut p = Packet((0..n).map(|x| x + 1), Box::new(seed()));\n    let answer = p.0.by_ref().sum::<usize>() + *p.1;"
MIXED = """    let left_and_right = (0..n).map(|x| x + 1).zip((0..n).map(left()));
    let mut p = Packet(left_and_right, Box::new(seed()));
    let answer = p.0.by_ref().map(|(a, b)| a + b + 2).sum::<usize>() + *p.1;"""
MANUAL = """
#[automatically_derived]
impl Clone for Derived {
    #[inline]
    fn clone(&self) -> Self {
        let Self::Before(s) = self;
        Self::Before(format!("clone/{s}"))
    }
}

#[automatically_derived]
impl Debug for Derived {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let Self::Before(s) = self;
        write!(f, "manual({s})")
    }
}
"""


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def fixture(name):
    raw = (HERE / "source" / (name + ".rs")).read_bytes()
    got = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\x00" + raw).hexdigest()
    require(got == BLOBS[name], "wrong checked-in fixture " + name)
    return raw.decode()


def once(source, old, new):
    require(source.count(old) == 1, "fixture mutation is not unique")
    return source.replace(old,new)


def run(args):
    sdk, root, out = args.sdk.resolve(strict=True), args.work.absolute(), args.out.absolute()
    require(not root.exists() and not out.exists() and root != out, "fresh workspace and receipt directories required")
    require(not out.is_relative_to(root) and not root.is_relative_to(out), "receipt and workspace must be separate")
    driver, = (sdk / "lib").glob("librustc_driver*.so")
    require(re.fullmatch(r"[a-f0-9]{64}",args.driver) and sha(driver) == args.driver, "wrong physical driver")
    require(sha(sdk/"bin/cargo") == CARGO and (args.role != "signed" or args.driver == SIGNED), "wrong ordinary Cargo or signed rustc")
    proxy = shutil.which("cargo")
    require(proxy and os.path.samefile(proxy,shutil.which("rustup")), "expected rustup proxy")
    out.mkdir(); (out/"objects").mkdir()
    root.mkdir(); src = root/"workspace"; src.mkdir()
    for package in ("forwarders","closures"):
        (src/package/"src").mkdir(parents=True)
        (src/package/"Cargo.toml").write_text(f'[package]\nname = "{package}"\nversion = "0.0.0"\nedition = "2024"\n')
    (src/"Cargo.toml").write_text('[workspace]\nmembers = ["forwarders","closures"]\nresolver = "3"\n[profile.dev]\nopt-level = 1\ndebug = 0\ncodegen-units = 64\nincremental = true\n')
    rustup = root/"rustup"; (rustup/"toolchains").mkdir(parents=True); (rustup/"toolchains/ohm").symlink_to(sdk)
    logical = root/"slot"; logical.mkdir()
    names = {"CARGO_TARGET_DIR":"target","CARGO_BUILD_BUILD_DIR":"build","CARGO_HOME":"cargo-home","HOME":"home","TMPDIR":"tmp"}
    def new_slot():
        for sub in names.values():
            (logical/sub).mkdir()
    new_slot()
    env = {"PATH":str(Path(proxy).parent)+":/usr/local/bin:/usr/bin:/bin","RUSTUP_HOME":str(rustup),
           "RUSTUP_AUTO_INSTALL":"0","CARGO_NET_OFFLINE":"true","CARGO_TERM_COLOR":"never","LANG":"C","LC_ALL":"C","TZ":"UTC"}
    env.update({k:str(logical/v) for k,v in names.items()})
    original_lib = fixture("forwarders")
    original_bin = once(fixture("closures"), ORIGINAL_MAIN, PRINT)
    edited_lib = once(once(original_lib,"#[derive(Clone, Debug)]\n",""), "pub fn value()", MANUAL + "\npub fn value()")
    edited_bin = once(original_bin, DIRECT, MIXED)
    (src/"forwarders/src/main.rs").write_text(fixture("reader"))
    def source(is_edit):
        (src/"forwarders/src/lib.rs").write_text(edited_lib if is_edit else original_lib)
        (src/"closures/src/main.rs").write_text(edited_bin if is_edit else original_bin)
    def invoke(arguments, label, overrides=None):
        v = subprocess.run([proxy,*arguments],cwd=src,env={**env,**(overrides or {})},capture_output=True)
        (out/(label+".stdout.gz")).write_bytes(gzip.compress(v.stdout,compresslevel=5,mtime=0))
        (out/(label+".stderr.gz")).write_bytes(gzip.compress(v.stderr,compresslevel=5,mtime=0))
        return v
    source(False)
    require(invoke(["+ohm","generate-lockfile","--offline"],"lock").returncode == 0, "could not lock fixture")
    result = {"role":args.role, "driver":args.driver,"cargo":CARGO,"fixtures":BLOBS,"states":{},"placement":{}}
    def record(label, build, edited):
        require(build.returncode == 0, label + ": Cargo failed " + build.stderr.decode(errors="replace")[-600:])
        events = [json.loads(l) for l in build.stdout.splitlines()]
        require(sum(e["reason"]=="build-finished" and e["success"] for e in events)==1,"missing typed success")
        bins = {e["target"]["name"]:Path(e["executable"]) for e in events if e["reason"]=="compiler-artifact" and e.get("executable")}
        require(set(bins)=={"forwarders","closures"},"wrong returned executables")
        expected = {"forwarders":'manual(clone/text)/manual\n' if edited else 'Before("text")/manual\n',"closures":"43/19/26\n" if edited else "18/19/26\n"}
        outputs = {}
        for name,p in bins.items():
            require(p.is_relative_to(logical/"target"),"wrong binary path")
            v = subprocess.run([p],env=env,cwd=src,capture_output=True)
            require(v.returncode==0 and v.stdout==expected[name].encode() and not v.stderr, f"{label} {name} produced {v.stdout!r} {v.stderr!r}")
            h = sha(p); destination = out/"objects"/(h+".gz")
            if not destination.exists():
                destination.write_bytes(gzip.compress(p.read_bytes(),compresslevel=5,mtime=0))
            outputs[name] = {"output":v.stdout.decode(),"elf_sha256":h}
        result["states"][label] = outputs
    def inspect(label, edit):
        extras = {"CARGO_TARGET_DIR":str(root/("inspect-target-"+label)), "CARGO_BUILD_BUILD_DIR":str(root/("inspect-cache-"+label))}
        checks = {}
        for package,target in (("forwarders","--lib"),("closures","--bin=closures")):
            ar = ["+ohm","rustc","--offline","--locked","-p",package,target,"--","-Zprint-mono-items","-Zhuman-readable-cgu-names"]
            proc = invoke(ar,label+"-mono-"+package,extras)
            require(proc.returncode==0,"could not inspect ordinary placement")
            rows = proc.stdout.decode().splitlines()
            if package=="forwarders":
                for item in ("<&Derived as std::fmt::Debug>::fmt","<std::vec::Vec<Derived> as std::clone::Clone>::clone"):
                    found = [l for l in rows if l.startswith("MONO_ITEM fn "+item+" @@ ")]
                    require(len(found)==1,"cannot identify forwarder "+item)
                    require((".ohm-derived[" in found[0]) == (args.role in ("F","C") and not edit), "wrong ordinary forwarding placement: "+found[0])
                    checks[item] = found[0]
            else:
                clue = "::drop_glue::<Packet<std::iter::" + ("Zip<" if edit else "Map<")
                found = [l for l in rows if clue in l]
                require(len(found)==1,"cannot identify changed closure glue "+clue)
                assigned = found[0].split(" @@ ",1)[1]
                require(("-callable.drop-" in assigned) == (args.role=="C" and not edit),"wrong ordinary closure owner: "+found[0])
                require(not edit or "-fallback.cgu[" in assigned,"mixed owners received a special placement: "+found[0])
                checks["concrete-glue"] = found[0]
        result["placement"][label]=checks
    old = invoke(CLI,"old"); record("old",old,False); inspect("old",False)
    source(True)
    edited = invoke(CLI,"edit"); repeat = invoke(CLI,"repeat")
    record("edit",edited,True); record("repeat",repeat,True); inspect("edit",True)
    for name in ("forwarders","closures"):
        require(result["states"]["old"][name] != result["states"]["edit"][name],"stale old binary would pass")
    invalid = once(edited_bin,"let answer = p.0.by_ref().map(","let answer: String = p.0.by_ref().map(")
    (src/"closures/src/main.rs").write_text(invalid)
    bad = invoke(CLI,"invalid")
    errors = [json.loads(l) for l in bad.stdout.splitlines()]
    codes = [e["message"]["code"]["code"] for e in errors if e["reason"]=="compiler-message" and e["message"].get("code")]
    require(bad.returncode==101 and "E0308" in codes and any(e["reason"]=="build-finished" and not e["success"] for e in errors),"invalid edit was accepted or returned a different error")
    result["rejected"] = [bad.returncode,codes]
    source(True); record("repair",invoke(CLI,"repair"),True)
    closed = root/"closed"; closed.mkdir()
    for name in names.values():
        (logical/name).rename(closed/name)
    new_slot(); record("empty",invoke(CLI,"empty"),True)
    for name in ("edit","repeat","repair"):
        require(result["states"][name] == result["states"]["empty"],name+" products must byte-match an independent same-path build")
    source(False); record("revert",invoke(CLI,"revert"),False)
    (out/"result.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(args.role, "verified", len(result["states"]), "native output pairs", result["rejected"], flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("sdk","work","out"):
        p.add_argument("--"+name,type=Path,required=True)
    p.add_argument("--role",choices=("signed","P","F","C"),required=True)
    p.add_argument("--driver",required=True)
    run(p.parse_args())
