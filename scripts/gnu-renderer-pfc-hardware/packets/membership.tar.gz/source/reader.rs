extern crate forwarders;

use std::fmt::{self, Debug};

use forwarders::{Derived, Generic, Manual};

struct Render<'a>(&'a Derived);

impl Debug for Render<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        forwarders::debug_derived(&self.0, f)
    }
}

fn main() {
    let mut target = vec![Generic(String::from("old"))];
    forwarders::inherited(&mut target, &vec![Generic(String::from("new"))]);
    assert_eq!(target[0].0, "new");
    let values = forwarders::clone_derived(&vec![forwarders::value()]);
    let manual = forwarders::clone_manual(&vec![Manual(String::from("manual"))]);
    println!("{:?}/{}", Render(&values[0]), manual[0].0);
}
