use std::fmt::{self, Debug};

#[derive(Clone, Debug)]
pub enum Derived {
    Before(String),
}

pub fn value() -> Derived {
    Derived::Before(String::from("text"))
}

pub struct Manual(pub String);

#[automatically_derived]
impl Clone for Manual {
    #[inline]
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}

#[automatically_derived]
impl Debug for Manual {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Debug::fmt(&self.0, f)
    }
}

pub fn clone_derived(values: &Vec<Derived>) -> Vec<Derived> {
    values.clone()
}

pub fn clone_manual(values: &Vec<Manual>) -> Vec<Manual> {
    values.clone()
}

pub fn debug_derived(value: &&Derived, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    <&Derived as Debug>::fmt(value, f)
}

pub fn debug_manual(value: &&Manual, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    <&Manual as Debug>::fmt(value, f)
}

#[derive(Clone)]
pub struct Generic<T>(pub T);

pub fn inherited(target: &mut Vec<Generic<String>>, source: &Vec<Generic<String>>) {
    Clone::clone_from(target, source);
}
