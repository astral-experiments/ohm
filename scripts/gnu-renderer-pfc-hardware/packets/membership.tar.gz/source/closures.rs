#![cfg_attr(linkage_control, feature(linkage))]

use std::hint::black_box;

struct Packet<T>(T, Box<usize>);

#[inline(never)]
pub fn scoped(n: usize) -> usize {
    fn seed() -> usize {
        3
    }
    let mut p = Packet((0..n).map(|x| x + 1), Box::new(seed()));
    let answer = p.0.by_ref().sum::<usize>() + *p.1;
    drop(black_box(p));
    answer
}

#[inline(never)]
fn left() -> impl Fn(usize) -> usize {
    |x| x + 1
}

#[inline(never)]
fn right() -> impl Fn(usize) -> usize {
    |x| x * 2
}

#[inline(never)]
pub fn mixed(n: usize) -> usize {
    let p = Packet((left(), right()), Box::new(3));
    let answer = p.0.0(n) + p.0.1(n) + *p.1;
    drop(black_box(p));
    answer
}

struct Borrowed<F>(F, Box<usize>);

#[inline(never)]
fn another_key() -> impl for<'a> Fn(&'a usize) -> usize {
    |n| *n + 2
}

#[inline(never)]
pub fn higher_ranked(n: usize) -> usize {
    fn key<F: for<'a> Fn(&'a usize) -> usize>(f: F) -> F {
        f
    }

    let local = key(|n| *n + 1);
    let one = Borrowed(local, Box::new(3));
    let mixed = Borrowed((local, another_key()), Box::new(4));
    let answer = one.0(&n) + *one.1 + mixed.0.0(&n) + mixed.0.1(&n) + *mixed.1;
    drop(black_box((one, mixed)));
    answer
}

#[cfg(linkage_control)]
#[linkage = "weak"]
#[unsafe(no_mangle)]
pub static CALLABLE_FAMILY_SENTINEL: usize = 17;

fn main() {
    assert_eq!(scoped(black_box(5)), 18);
    assert_eq!(mixed(black_box(5)), 19);
    assert_eq!(higher_ranked(black_box(5)), 26);
}
