"""Verify actual held Rust mono inventories against the signed Ruff old/new admissions."""
import argparse
from collections import Counter,defaultdict
import gzip
import json
from pathlib import Path
import re
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from native_elf import sha,require,Refusal


def unpack(path):
    b=path.read_bytes()
    return gzip.decompress(b)if b[:2]==b"\x1f\x8b" else b


def rows(raw):
    result={}
    for line in raw.decode().splitlines():
        require(line.startswith(("MONO_ITEM fn ","MONO_ITEM static ")) and " @@ " in line,"unsupported mono row")
        n,where=line.removeprefix("MONO_ITEM fn ").split(" @@ ")
        loc=[]
        for tok in where.split():
            c,flag=re.fullmatch(r"(.+)\[([A-Za-z]+)\]",tok).groups()
            c=re.sub(r"\.[0-9a-f]{16}(?=-|\.)",".<crate>",c)
            loc.append((c,flag))
        require(n not in result and len(set(loc))==len(loc),"duplicate typed row")
        result[n]=sorted(loc)
    return result


def call_bucket(c):
    return bool(re.search(r"-callable[.-]drop-[0-9a-f]{16}$",c))


def verify(lane,phase,raw,rules):
    p=rows(unpack(HERE/("mono-signed-"+phase+".gz")))
    current=rows(raw);r=rules[phase]
    require(p.keys()==current.keys(),"typed mono inventory changed")
    if lane=="P":
        require(p==current,"signed default placements changed")
    owners={}
    forward={}
    for name,family in r["call"].items():
        if lane=="C":
            row=current[name]
            require(len(row)==1 and call_bucket(row[0][0]) and row[0][1]==p[name][0][1],"wrong exclusive callable placement "+name)
            value=row[0][0]; require(owners.setdefault(family,value)==value,"one lexical family split across buckets")
    for name in r["derived"]:
        donor,flag=p[name][0]; row=current[name]; expected=donor+".ohm-derived"
        require(len(p[name])==1 and flag=="External" and row==([(expected,flag)] if lane!="P" else p[name]),"wrong derived forwarding root")
        if lane!="P":forward[expected]=donor
    require(lane!="C" or len(set(owners.values()))==len(owners)==2,"callable owners collide")
    mapped={v:"callable."+k for k,v in owners.items()}|{k:"derived."+v for k,v in forward.items()}
    installed={c for cs in current.values() for c,_ in cs};baseline={c for cs in p.values()for c,_ in cs}
    require(installed-baseline==set(mapped) and not baseline-installed and len(installed)==r["expected_counts"][lane][0],"unexpected or missing CGU")
    moved_roots=set(r["derived"] if lane!="P" else ()) | (set(r["call"]) if lane=="C" else set())
    known_families={p[n][0][0] for n in moved_roots}
    for name,now in current.items():
        was=p[name]
        # Every new global root has been independently named. All original unit
        # placements outside donors remain exact; extra copies require local linkage.
        if name not in moved_roots and (any(flag!="Internal" for _,flag in was) or any(flag!="Internal" for _,flag in now)):
            require(now==was,"unknown externally visible root changed home")
        require(set((c,k)for c,k in was if c not in known_families)==set((c,k)for c,k in now if c not in known_families and c not in mapped),
                "changed unaffected signed home")
    counts=Counter(mapped.get(c,c)for cs in current.values()for c,_ in cs)
    require(sum(counts.values())==r["expected_counts"][lane][1],"unexpected native placement total")
    for name,expected in r["unit_sizes"][lane].items():
        require(counts[name]==expected,"unexpected per-CGU member count "+name)
    return {"phase":phase,"role":lane,"unique_typed_items":len(current),"partitions":len(counts),"full_mono_placements":sum(counts.values()),
            "callable_roots":len(r["call"]) if lane=="C" else 0,"derived_roots":len(r["derived"]) if lane!="P" else 0,
            "actual_cgu_labels":mapped,"complete_stdout":sha(raw),"exact_sizes_for_changed_and_donor_units":r["unit_sizes"][lane]}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--role",choices=["P","F","C"],required=True);p.add_argument("--phase",choices=["old","edit"],required=True);p.add_argument("--stdout",required=True,type=Path);p.add_argument("--out",required=True,type=Path)
    a=p.parse_args();rules=json.loads(gzip.decompress((HERE/"mono-witnesses.json.gz").read_bytes()))
    res=verify(a.role,a.phase,unpack(a.stdout),rules);data=(json.dumps(res,sort_keys=True)+"\n").encode()
    if a.out.exists():require(a.out.read_bytes()==data,"different prior mono receipt")
    else:a.out.write_bytes(data)


if __name__=="__main__":main()
