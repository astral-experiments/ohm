"""Independent exact native and source witnesses for two ordinary Ruff edits on x86-64 GNU."""
import argparse
from collections import Counter, defaultdict
from functools import lru_cache
import gzip
import json
from pathlib import Path
import re
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from native_elf import Object, Refusal, digest, members, require, sha
from signed import HISTORIES
from cell_safety import inspect as inspect_cell
import layout


@lru_cache(maxsize=512)
def decoded(payload):
    return Object(payload)


def canonical_names(names):
    raw=sorted(names)
    p=subprocess.run(["c++filt","-s","rust"],input=("\n".join(raw)+"\n").encode(),capture_output=True,check=True)
    require(not p.stderr, "demangler diagnostic")
    translated=p.stdout.decode().splitlines()
    # Used only to look up enrolled line/native witnesses across installations.
    # All cross-role equivalence checks below retain each unmodified symbol identity.
    return {a:re.sub(r"(?<=\w)\[[0-9a-f]{1,16}\](?=::|[>,])","",b)
            for a,b in zip(raw,translated,strict=True)}


def index_table(data, entries, objects):
    n=struct.unpack_from(">I",data)[0]
    off=4+4*n
    require(off<len(data), "truncated GNU archive symbol index")
    names=data[off:].split(b"\0")
    require(len(names)>=n+1 and all(names[:n]) and not any(names[n:]), "bad archive symbol-index names")
    targets={pos:(name,obj) for (name,body,head,padding,pos) in entries
             for obj in [objects.get(sha(body))] if obj is not None}
    result=[]
    for i in range(n):
        pos=struct.unpack_from(">I",data,4+i*4)[0]
        require(pos in targets, "symbol index names a non-object header")
        archive_name,obj=targets[pos]; name=names[i].decode()
        require(any(sn==name and sec!=0 and (st>>4)!=0 for sn,st,_,sec,_,_ in obj.symbols),
                "symbol index does not address the actual defining member")
        result.append((name,archive_name))
    return result


def storage_check(ledger,state,label):
    unique={};paths={}
    for path,dev,ino,nlink,size,allocated in ledger["rows"]:
        p=Path(path)
        require(not p.is_absolute() and p.parts[0] in ("target","shared") and ".." not in p.parts and path not in paths, "storage path")
        key=(dev,ino)
        require(unique.setdefault(key,[size,allocated,nlink])==[size,allocated,nlink], "inconsistent hardlink metadata")
        paths[path]=key
    total=sum(x[1] for x in unique.values())
    require(total==ledger["unique_allocated"], "deduplicated target/shared allocation")
    states={str(Path(p).parent) for p in paths if p.endswith("/work-products.bin") and
            Path(p).parent.parent.name.startswith("annotate_snippets-")}
    all_session_dirs={str(q) for p in paths for q in [Path(p),Path(p).parent]
                      if q.name.startswith("s-") and q.parent.name.startswith("annotate_snippets-")
                      and not q.name.endswith(".lock")}
    require(states==all_session_dirs,"unindexed extra renderer session")
    finalized={p for p in states if not p.endswith("-working")}
    working=states-finalized
    require(len(finalized)==1 and (not working or label in ("repair","repaired-repeat") and len(working)==1),
            "duplicate or working renderer session outside signed failure flank")
    root=finalized.pop()
    expected=state["cgu"]
    real={Path(p).name:k for p,k in paths.items() if str(Path(p).parent)==root and p.endswith(".o")}
    require(real=={n:(r["dev"],r["ino"]) for n,r in expected.items()}, "completed work-product inode membership")
    abandoned=[]
    for w in working:
        observed={Path(p).name:k for p,k in paths.items() if str(Path(p).parent)==w and p.endswith(".o")}
        require(observed==real,"failed session retained independent or mutated native object")
        residual={k for p,k in paths.items() if str(Path(p).parent)==w and not p.endswith(".o")}
        current={k for p,k in paths.items() if str(Path(p).parent)==root}
        abandoned.append({"objects":len(observed),"object_bytes_counted_twice":0,
                          "private_non_object_allocated":sum(unique[k][1] for k in residual-current),
                          "working_index_inode":paths[w+"/work-products.bin"]})
    products={}
    for suffix in (".rlib",".rmeta"):
        linked={k for p,k in paths.items() if Path(p).name.startswith("libannotate_snippets") and p.endswith(suffix)}
        require(len(linked)==1,"independent duplicate or missing renderer "+suffix)
        k,=linked
        products[suffix]={"names":sum(1 for p,v in paths.items() if v==k),"allocated":unique[k][1],"distinct_inodes":1}
    return {"deduplicated_allocated":total,"paths":len(paths),"inodes":len(unique),"failed_working":abandoned,"renderer_products":products,
            "renderer_sessions":1,"renderer_object_inodes":len(set(real.values())),
            "renderer_object_allocated":sum(unique[k][1] for k in set(real.values()))}


class State:
    def __init__(self,state,read):
        self.state=state
        self.arc=read(state["archive"]);self.meta=read(state["rmeta"]);self.wp=read(state["work_products"])
        require(sha(self.arc)==state["archive"] and sha(self.meta)==state["rmeta"] and sha(self.wp)==state["work_products"],"whole archive, metadata and work-product receipt")
        require(self.meta.startswith(b"rust\0\0\0\n"), "unsupported rmeta version")
        self.entries=members(self.arc)
        nms=[i[0] for i in self.entries]
        require(nms[:4]==["/","//","lib.rmeta","lib.rmeta-link"] and all(n.endswith(".rcgu.o") for n in nms[4:]), "unhandled GNU archive member")
        self.aux={n:b for n,b,*_ in self.entries[:4]}
        self.embedded=self.aux["lib.rmeta"]
        require(sha(self.embedded)==state["embedded_rmeta"],"embedded rmeta digest")
        elf=decoded(self.embedded)
        i,=(i for i,n in enumerate(elf.names) if n==".rmeta")
        require(elf.section(i)==self.meta,"embedded rmeta and external metadata diverge")
        link=decoded(self.aux["lib.rmeta-link"])
        li,=(j for j,n in enumerate(link.names) if n==".rmeta-link")
        self.linkdata=link.section(li)
        self.objects={}; self.archive_names={};self.locations=defaultdict(list)
        self.counts={};self.by_raw={}
        for name,body,_,_,_ in self.entries[4:]:
            mt=re.fullmatch(r"(.+)\.([0-9a-z]+)\.([0-9a-z]{7})\.rcgu\.o",name)
            require(mt is not None, "unhandled object member naming")
            leaf=mt[2]+".o";record=state["cgu"][leaf]
            h=sha(body)
            require(h==record["sha256"] and read(h)==body and len(body)==record["logical"] and self.wp.count(leaf.encode())==1,
                    "actual indexed workspace object must equal archive member")
            require(leaf not in self.objects and self.linkdata.count(name.encode())==1, "duplicate or missing object membership")
            self.objects[leaf]=decoded(body)
            self.by_raw[h]=self.objects[leaf];self.archive_names[leaf]=name
            for symbol in self.objects[leaf].functions:
                self.locations[symbol].append((leaf,self.objects[leaf]))
        require(set(state["cgu"])==set(self.objects), "exact archive/work-product inventory")
        self.symbol_index=index_table(self.aux["/"],self.entries,self.by_raw)
        self.canon=canonical_names(self.locations)
        self.lookup=defaultdict(list)
        for name,locs in self.locations.items():
            self.lookup[self.canon[name]].extend((name,leaf,obj) for leaf,obj in locs)

    def projection(self):
        functions={}
        for name,defs in self.locations.items():
            views=[]
            for leaf,obj in defs:
                fun=obj.function(name)
                views.append({"body":fun[0],"size":fun[1],"binding":fun[2],"visibility":fun[3],
                              "relocations":digest(fun[4]),"lines":digest(obj.lines.get(name,[])),
                              "relocation_count":len(fun[4]),"line_count":len(obj.lines.get(name,[]))})
            functions[name]=views
        return functions

    def basics(self):
        obj=self.objects
        return {"rlib":sha(self.arc),"rlib_size":len(self.arc),"rmeta":sha(self.meta),"rmeta_size":len(self.meta),
                "embedded":sha(self.embedded),"work_products":sha(self.wp),"cgu":{n:self.state["cgu"][n]["sha256"] for n in sorted(obj)},
                "partition_count":len(obj),"raw_symbols":len(self.locations),"defined_function_instances":sum(map(len,self.locations.values())),
                "function_line_sequences":sum(len(e.lines) for e in obj.values()),"decoded_rows":sum(len(rs) for e in obj.values() for rs in e.lines.values()),
                "raw_sections":sum(len(e.h) for e in obj.values()),"allocated_inode_bytes":sum(v[0] for v in
                    {(r["dev"],r["ino"]):(r["allocated"],r["logical"]) for r in self.state["cgu"].values()}.values())}


def metadata_envelope(state):
    meta=state.meta
    node=struct.unpack_from("<Q",meta,8)[0]
    require(16<node<len(meta), "rmeta root pointer outside payload")
    return {"size":len(meta),"sha256":sha(meta),"root_position":node,"prefix_version":meta[:8].hex(),
            "pre_root_sha256":sha(meta[16:node]),"root_to_trailer_sha256":sha(meta[node:])}


def aligned_names(a,b):
    require(set(a.archive_names)==set(b.archive_names), "different native partition within one source role's clean build")
    noun=[]
    for leaf,name in a.archive_names.items():
        other=b.archive_names[leaf]; l=name.rsplit(".",3);r=other.rsplit(".",3)
        require(l[0]==r[0] and l[2:]==r[2:], "member name changed outside invocation nonce")
        noun.append((l[1],r[1]))
    require(len(set(noun))==1, "mixed invocation suffix")
    return noun[0]


def warm_clean(a,b,history):
    require({k:o.raw for k,o in a.objects.items()}=={k:o.raw for k,o in b.objects.items()},
            "own-mode incremental and empty complete native objects differ")
    old,new=aligned_names(a,b)
    suffix=lambda s:(s+".rcgu.o").encode()
    for n in ("//","lib.rmeta-link"):
        before,after=a.aux[n],b.aux[n]
        require(before.count(suffix(old))==after.count(suffix(new))==len(a.objects),"invocation name membership")
        require(before.replace(suffix(old),suffix(new))==after and after.replace(suffix(new),suffix(old))==before,
                "non-invertible archive name or rmeta-link payload")
    # Parse every archive offset back to an actual symbol definition before comparing.
    canon=lambda s:[(name,member.rsplit(".",3)[0]) for name,member in s.symbol_index]
    require(canon(a)==canon(b), "semantic GNU archive index diverged")
    # Explicit reconstruction accounts for every original byte, including GNU 60-byte
    # member headers, changing metadata length/offsets, symbol index and name tables.
    for s in (a,b):
        require(b"!<arch>\n"+b"".join(h+body+pad for _,body,h,pad,_ in s.entries)==s.arc,"complete archive round trip")
    difference=a.meta!=b.meta
    if history=="notebook":
        require(not difference and a.embedded==b.embedded, "new notebook rmeta variance")
        require(a.arc.replace(suffix(old),suffix(new))==b.arc and b.arc.replace(suffix(new),suffix(old))==a.arc,
                "notebook archive bytes outside exact nonce replacements")
    return {"complete_objects_equal":len(a.objects),"metadata_equal":not difference,
            "before_rmeta":metadata_envelope(a),"after_rmeta":metadata_envelope(b),
            "whole_nonce_only":a.arc.replace(suffix(old),suffix(new))==b.arc,
            "literal_nonce":[old,new],"changed_aux":[n for n in a.aux if a.aux[n]!=b.aux[n]],
            "resolved_index_definitions":len(a.symbol_index)}


def physical_delta(left,right,source,oldtext,newtext):
    require(len(left)==len(right),"changed number of rows in enrolled unchanged-body function")
    selected=[]
    for i,(a,b) in enumerate(zip(left,right)):
        if a==b:
            continue
        require(a[0:2]==b[0:2] and a[1]==source and a[3:]==b[3:],"source row changes address, path or flags")
        oldline,newline=a[2],b[2]
        require(0<oldline<=len(oldtext) and 0<newline<=len(newtext) and oldtext[oldline-1]==newtext[newline-1],
                "line does not resolve to authenticated equal source text")
        selected.append([i,a[0],oldline,newline,*a[3:],sha(oldtext[oldline-1])])
    return selected


def anchors(history,old,edit,src,witness):
    spec=HISTORIES[history]
    require([sha(x) for x in src]==spec["hash"],"historical source bytes")
    oldlines,newlines=[v.splitlines() for v in src]
    lines={}
    for item in witness["line"]:
        name=item["name"]; av=old.lookup.get(name,[]);bv=edit.lookup.get(name,[])
        require(av and bv, "missing enrolled debug symbol "+name)
        # If a private function is placed multiple times, all present variants must
        # have an exact partner. No observer picks a single favorable copy.
        versions=[]
        for q in (av,bv):
            variants={}
            for sym,leaf,obj in q:
                if sym not in obj.lines: continue
                data=tuple(obj.lines[sym]); body=obj.function(sym)[0]
                variants[(body,data)]=variants.get((body,data),0)+1
            require(variants,"no line program for enrolled named function")
            versions.append(variants)
        unmatched=set(versions[1]); successes=0; annotated=0
        for (body,a),copies in versions[0].items():
            matches=[]
            for key in unmatched:
                bbody,b=key
                if body!=bbody:continue
                try: diff=physical_delta(a,b,spec["file"],oldlines,newlines)
                except Refusal:continue
                if diff==item["deltas"]:matches.append(key)
            require(len(matches)==1,"stale or unexpected relocated line program for "+name)
            key=matches[0];unmatched.remove(key); successes+=1;annotated+=len(a)
        require(not unmatched,"new unresolved line-program copy")
        lines[name]={"distinct_bodies":successes,"verified_old_rows":annotated,"changed_rows":len(item["deltas"]),
                     "nonterminal_changes":sum(not r[-2] for r in item["deltas"])}
    native=[]
    for name in witness["changed_native"]:
        a={obj.function(sym)[0] for sym,leaf,obj in old.lookup.get(name,[])}
        b={obj.function(sym)[0] for sym,leaf,obj in edit.lookup.get(name,[])}
        require(a and b and a.isdisjoint(b),"stale historic native function "+name)
        refs_a={digest(obj.function(sym)[4]) for sym,leaf,obj in old.lookup[name]}
        refs_b={digest(obj.function(sym)[4]) for sym,leaf,obj in edit.lookup[name]}
        native.append({"name":name,"before":sorted(a),"after":sorted(b),"before_relocations":sorted(refs_a),"after_relocations":sorted(refs_b)})
    return {"line_programs":lines,"changed_native":native}


def detailed_delta(a,b):
    changes={}
    for key in sorted(a.objects.keys()|b.objects.keys()):
        x=a.objects.get(key);y=b.objects.get(key)
        if x is not None and y is not None and x.raw==y.raw:continue
        def section_map(obj):
            count=Counter();res={}
            for entry in (obj.sections if obj else []):
                n=entry[0];i=count[n];count[n]+=1;res[(n,i)]=entry[1:]
            return res
        p,q=section_map(x),section_map(y)
        rows=[(key[0],key[1],p.get(key),q.get(key))for key in sorted(p.keys()|q.keys()) if p.get(key)!=q.get(key)]
        changes[key]={"old_obj":sha(x.raw) if x else None,"new_obj":sha(y.raw) if y else None,
                      "sections":rows}
    return changes


def compare_projections(x,y):
    a=x.projection();b=y.projection()
    delta={}
    for symbol in sorted(a.keys()|b.keys()):
        l=a.get(symbol,[]);r=b.get(symbol,[])
        lc=Counter(digest(s) for s in l);rc=Counter(digest(s) for s in r)
        if lc!=rc:
            delta[symbol]={"old":l,"new":r}
    return delta


def bytes_change(a,b):
    prefix=next((i for i,(x,y) in enumerate(zip(a,b)) if x!=y),min(len(a),len(b)))
    suffix=0
    while suffix<min(len(a),len(b))-prefix and a[-1-suffix]==b[-1-suffix]:
        suffix+=1
    return {"prefix_equal":prefix,"suffix_equal":suffix,"before_middle_bytes":len(a)-prefix-suffix,
            "after_middle_bytes":len(b)-prefix-suffix,"after_root_pointer_first_differing":next(
            (i for i in range(16,min(len(a),len(b))) if a[i]!=b[i]),None)}


def verify_sources(cell,history):
    spec=HISTORIES[history]
    src=[(cell/"sources"/stage/spec["file"]).read_bytes() for stage in ("old","new")]
    require([sha(b) for b in src]==spec["hash"],"old/new source roles or bytes differ")
    return src


def load_cell(path,history):
    sources=verify_sources(path,history);states={};captures={};storage={};receipts={}
    def get(h):
        require(isinstance(h,str) and re.fullmatch(r"[a-f0-9]{64}",h), "invalid CAS name")
        f=path/"objects"/h;require(f.is_file() and not f.is_symlink(),"nonregular CAS object")
        b=f.read_bytes();require(sha(b)==h,"corrupt CAS file")
        return b
    for label in ("old","edit","repeat","empty","repair"):
        stage=path/"states"/label;man=stage/"state.json";record=json.loads(man.read_bytes())
        states[label]=State(record,get);captures[label]=record
        lfile=stage/"storage.json.gz";ledger=json.loads(gzip.decompress(lfile.read_bytes()))
        storage[label]=storage_check(ledger,record,label)
        receipts[label]={"state":sha(man.read_bytes()),"allocation":sha(lfile.read_bytes())}
        reader=path/"oracles"/label/"reader.json"
        require(reader.is_file(),"missing consumer receipt "+label)
        receipts[label]["reader"]=sha(reader.read_bytes())
    return states,sources,storage,receipts


def evaluate(history,states,sources,witness,storage=None):
    old=states["old"]; edit=states["edit"]; repeat=states["repeat"];empty=states["empty"]
    require(edit.arc==repeat.arc and edit.meta==repeat.meta and edit.wp==repeat.wp and
            edit.state["cgu"]==repeat.state["cgu"], "first unchanged changed raw artifacts or physical objects")
    require(sha(old.meta)!=sha(edit.meta),"real edit must change metadata")
    result={"signed_source_hashes":[sha(x)for x in sources],
            "states":{k:v.basics() for k,v in states.items()},
            "source_and_native_changes":anchors(history,old,edit,sources,witness),
            "own_mode":warm_clean(edit,empty,history),
            "metadata_original_delta":bytes_change(edit.meta,empty.meta)}
    if "repair" in states:
        repair=states["repair"]
        result["own_mode_repair"]=warm_clean(repair,empty,history)
        require(repair.meta in (edit.meta,empty.meta),"repair generated an unexplained third rmeta payload")
        result["repair_witness"]=anchors(history,old,repair,sources,witness)
    if storage:result["storage"]=storage
    cast={};typed={}
    for phase,state in states.items():
        key=tuple(sorted((leaf,sha(obj.raw)) for leaf,obj in state.objects.items()))
        if key not in cast:
            fields,_=layout.feature(state)
            cast[key]={"all_records":digest(fields),"categories":{n:sum(c.values()) for n,c in sorted(fields.items())}}
        typed[phase]=cast[key]
    result["complete_typed_projections"]=typed
    result["changed_partitions"]=len(detailed_delta(old,edit))
    return result


def compare_meta(x,y,labels):
    for label in labels:
        require(x[label].meta==y[label].meta, "new per-role raw metadata divergence at "+label)
        require(x[label].embedded==y[label].embedded, "new per-role embedded metadata divergence at "+label)


def sections_without_layout(s):
    # Exact section contents and geometry. Equal across member reordering.
    # This deliberately flags residual layout changes instead of dropping all
    # .debug_*, .strtab, .symtab or internal names. Multiple occurrences are counted.
    return Counter(digest(sec) for obj in s.objects.values() for sec in obj.sections)


def compare(states_by_role):
    parent=states_by_role["P"];details={};problems=[]
    for label,states in states_by_role.items():
        if label=="P":continue
        for phase in parent:
            a,b=parent[phase],states[phase];delta=compare_projections(a,b)
            sec_a,sec_b=sections_without_layout(a),sections_without_layout(b)
            sorted_raw=lambda s:sorted(sha(v.raw) for v in s.objects.values())
            # If member names alone changed, all raw member bodies still round-trip
            # exactly. New codec/data from a repartition needs explicit attribution.
            exact_raw=sorted_raw(a)==sorted_raw(b)
            rows=detailed_delta(a,b)
            meta_equal=a.meta==b.meta and a.embedded==b.embedded
            details[label+"/"+phase]={"equal_complete_metadata":meta_equal,"metadata_delta":bytes_change(a.meta,b.meta),
                "equal_complete_native_member_multiset":exact_raw,"old_partitions":len(a.objects),"new_partitions":len(b.objects),
                "defined_function_differences":delta,"complete_section_differences":rows,
                "section_multiset":{"old_only":sum((sec_a-sec_b).values()),"new_only":sum((sec_b-sec_a).values())}}
            if not meta_equal:
                problems.append(label+"/"+phase+" unaccounted rmeta bytes")
            if not exact_raw:
                typed=layout.compare(a,b)
                details[label+"/"+phase]["typed_layout"]=typed
                if not typed["equal"]:
                    problems.append(label+"/"+phase+" unexplained typed native or debug records: "+", ".join(sorted(typed["differing_records"])))
            elif delta:
                problems.append(label+"/"+phase+" inconsistent raw native projections")
    return details,problems


def output(path,obj):
    data=(json.dumps(obj,sort_keys=True,separators=(",",":"))+"\n").encode()
    if path.suffix==".gz":data=gzip.compress(data,compresslevel=6,mtime=0)
    if path.exists():require(path.read_bytes()==data,"refuse to overwrite a different receipt")
    else:path.write_bytes(data)


def main(whole_inspector=None):
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest="cmd",required=True)
    for cmd in ("role","compare"):
        t=sub.add_parser(cmd);t.add_argument("--history",choices=HISTORIES,required=True);t.add_argument("--out",type=Path,required=True)
        if whole_inspector is not None:t.add_argument("--structural-root",type=Path,required=True)
        if cmd=="role":t.add_argument("--cell",required=True,type=Path)
        else:
            t.add_argument("--parent",required=True,type=Path);t.add_argument("--role",action="append",required=True)
    args=p.parse_args()
    frozen=HERE/"witnesses.json";witness=json.loads(frozen.read_bytes())[args.history]
    paths={"P":args.cell if args.cmd=="role" else args.parent}
    if args.cmd=="compare":
        for arg in args.role:
            k,sep,v=arg.partition("=");require(sep and k in ("F","C") and k not in paths,"expected F=DIR and C=DIR")
            paths[k]=Path(v)
        require(set(paths)=={"P","F","C"},"all three subjects required")
    report={"history":args.history,"oracle_witness":sha(frozen.read_bytes()),"roles":{},"accepted":False}
    try:
        data={}
        for role,path in paths.items():
            states,src,alloc,refs=load_cell(path,args.history)
            result={"state_receipts":refs,"body":evaluate(args.history,states,src,witness,alloc)}
            report["roles"][role]=result
            if whole_inspector is None:
                result["independent_runtime"]=inspect_cell(path,args.history,states)
            else:
                result["independent_runtime"]=whole_inspector(path,args.history,states,args.structural_root)
            actual=result["independent_runtime"]["role"]
            result["subject_role"]=actual
            if actual== "signed-control":
                require(result["independent_runtime"]["source"]=="c79998a5cd143c445a4b2528f20953b176a65c5d","unexpected signed source")
            else:
                exact={"P":"4e7c5b1f765b24ccd585d8ddb7eeae99a02b514e",
                       "F":"51e72261c0b36dfd49c078b35732956d6b950e8e","C":"11876886792274b44a9a37567fbac57bf843a24c"}
                require(actual in exact and result["independent_runtime"]["source"]==exact[actual],"wrong source for enrolled role")
            count=118 if args.history=="notebook" else {"signed-control":42,"P":42,"F":44,"C":46}[actual]
            require(all(len(s.objects)==count for s in states.values()),"observed partition count outside registered source and role")
            if args.cmd=="role" and role!=actual:
                report["roles"][actual]=report["roles"].pop(role)
            if args.cmd=="compare":
                require(actual==role,"input cell is not the named P/F/C role")
            data[role]=states
        if args.cmd=="compare":
            details,problems=compare(data);report.update(cross_role=details,pending=problems)
            costs={}
            for role in ("F","C"):
                for phase in ("edit","empty"):
                    x=report["roles"]["P"]["body"]["storage"][phase]["deduplicated_allocated"]
                    y=report["roles"][role]["body"]["storage"][phase]["deduplicated_allocated"]
                    costs[role+"/"+phase]={"P":x,"subject":y,"delta":y-x,"ratio":y/x,
                        "one_observation_within_2MiB_and_5pct":y-x<=2*2**20 and 100*y<=105*x}
                before=report["roles"]["P"]["independent_runtime"]
                after=report["roles"][role]["independent_runtime"]
                for name in ("actual_reruns","complete_error"):
                    if before[name]!=after[name]:problems.append(role+" disagrees on "+name)
            report["storage_observations"]=costs
            require(not problems,"new whole-output divergences remain unexplained")
        report["accepted"]=True
    except (AssertionError,KeyError,OSError,Refusal,ValueError) as ex:
        report["refusal"]=str(ex) or type(ex).__name__;output(args.out,report)
        raise SystemExit("refused: "+report["refusal"])
    output(args.out,report)


if __name__=="__main__":main()
