"""Adapt two existing, independently acquired signed histories without writing their raw bodies."""
import gzip
import io
import json
from pathlib import Path
import subprocess
import tarfile

from native_elf import members, require, sha

HISTORIES = {
    "source-map": {
        "file":"crates/ruff_annotate_snippets/src/renderer/source_map.rs",
        "git":["9c53b5de3aae4b1832eb7ee137647dda2466f888^","93526150df078af7dd8fc4226cdcc469539d2001"],
        "hash":["039cdafb24a352bf1b6f707ad1b9bcccea8eba4b1be13c810a065579c1836566","f466e84cbf6bc3d1ac7280685bb73fe3813565801c0ea7fe054926f384a59fb1"]},
    "notebook": {
        "file":"crates/ruff_annotate_snippets/src/renderer/render.rs",
        "git":["03989bfe060d0ed48dd9ea7d0c99a35c12b9c323","68d556d0630ecb8367cf041c3e857aa917799c43"],
        "hash":["21f1474979f5c5c610503d8bbec7e34081a7b256060e2275140d8cb80d4a97ce","e4cc6403f33b82cbbfa0194edbd9edb10fc1dcbbd9203e573bb321572a20a249"]}
}


def load(history, directory, ruff):
    spec=HISTORIES[history]
    src=[subprocess.check_output(["git","-C",ruff,"show",rev+":"+spec["file"]]) for rev in spec["git"]]
    require(list(map(sha,src))==spec["hash"], "historical source bytes")
    states={}
    cas={}
    if history=="source-map":
        raw=directory/"libmap/normal"
        evidence=json.loads(gzip.decompress((raw/"native.json.gz").read_bytes()))
        t=subprocess.check_output(["zstd","-qdc",raw/"payloads.tar.zst"])
        with tarfile.open(fileobj=io.BytesIO(t),mode="r:") as ar:
            for member in ar:
                body=ar.extractfile(member).read()
                require(member.isfile() and sha(body)==member.name and member.name not in cas,"signed CAS")
                cas[member.name]=body
        for label,r in evidence["states"].items():
            arc=b"!<arch>\n"+b"".join(bytes.fromhex(h)+cas[v]+bytes.fromhex(p) for n,v,sz,h,p in r["members"])
            require(sha(arc)==r["rlib_sha"], "signed archive reconstruction")
            cas[sha(arc)]=arc
            session,=r["sessions"]
            cg={}
            for n,v,stats,indexed in session["files"]:
                require(indexed, "signed work-product membership")
                cg[n]={"sha256":v,"dev":stats[0],"ino":stats[1],"logical":stats[2],"allocated":stats[6]}
            states[label]={"archive":sha(arc),"rmeta":r["rmeta"],"embedded_rmeta":next(v for n,v,*_ in r["members"] if n=="lib.rmeta"),"work_products":session["work_products"],"cgu":cg}
        provenance={p.name:sha(p.read_bytes()) for p in (raw/"native.json.gz",raw/"payloads.tar.zst")}
    else:
        raw=directory/"raw"
        evidence=json.loads((raw/"result.json").read_bytes())
        for label,r in evidence["states"].items():
            for k,suffix in (("rlib","rlib"),("rmeta","rmeta"),("work_products","work-products")):
                v=r[k];body=gzip.decompress((raw/(v+"."+suffix+".gz")).read_bytes())
                require(sha(body)==v, "signed holdout CAS")
                cas[v]=body
            for n,body,*_ in members(cas[r["rlib"]]):
                cas[sha(body)]=body
            cg={}
            for v,n in r["cgu"].items():
                d,i,a=r["working_objects"][v]
                cg[n]={"sha256":v,"dev":d,"ino":i,"logical":len(cas[v]),"allocated":a}
            states[label]={"archive":r["rlib"],"rmeta":r["rmeta"],"embedded_rmeta":next(v for n,v,*_ in r["members"] if n=="lib.rmeta"),"work_products":r["work_products"],"cgu":cg}
        provenance={"result.json":sha((raw/"result.json").read_bytes()),"registration.json":sha((directory.parent/"registration.json").read_bytes())}
    return states,cas.__getitem__,src,provenance
