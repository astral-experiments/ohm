"""Decode the line-tables-only GNU Rust DWARF4 schema actually used in these fixtures."""
from functools import lru_cache
import struct
from native_elf import require,Refusal,digest,string


@lru_cache(maxsize=512)
def projected(obj,leaf):
    indexes={n:i for i,n in enumerate(obj.names) if n.startswith(".debug_")}
    require(set(indexes)<={".debug_abbrev",".debug_info",".debug_str",".debug_ranges",".debug_line",".debug_aranges"},
            "unsupported debug section, cannot declare equivalence")
    data={n:obj.section(i) for n,i in indexes.items()}
    edges={n:{at:(kind,sid,add) for at,kind,sid,add in obj.edges[i]} for n,i in indexes.items()}
    used={n:set() for n in indexes}
    spans={n:set() for n in (".debug_str",".debug_ranges")}
    def target(sec,pc):
        if sec not in obj.ranges:return [obj.names[sec],pc]
        fs=obj.ranges[sec];require(len(fs)==1,"overlapping range owners")
        begin,end,name=fs[0];require(begin<=pc<=end,"relocated source endpoint outside emitted function")
        return [name,pc-begin]
    def real(section,at,value,expect=None):
        if at not in edges[section]:return value
        code,sid,add=edges[section][at];name,kind,vis,sec,base,size=obj.symbols[sid]
        require(value==0 and (expect is None or code==expect) and 0<sec<len(obj.h),"unsupported debug address fixup")
        used[section].add(at)
        return target(sec,base+add)
    def leb(buf,i):
        x=shift=0
        while i<len(buf):
            char=buf[i];i+=1;x|=(char&127)<<shift;shift+=7
            if char<128:return x,i
            require(shift<=70,"bad abbreviation length")
        raise Refusal("truncated abbreviation")
    def ranges(start):
        buf=data[".debug_ranges"];result=[];i=start
        while i+16<=len(buf):
            a,b=struct.unpack_from("<QQ",buf,i);lo=real(".debug_ranges",i,a,1);hi=real(".debug_ranges",i+8,b,1)
            spans[".debug_ranges"].update(range(i,i+16));i+=16
            if (lo,hi)==(0,0):return result
            result.append([lo,hi])
        raise Refusal("unterminated range list")
    def debug_string(pos):
        buf=data[".debug_str"];ret=string(buf,pos);end=buf.index(0,pos)+1
        spans[".debug_str"].update(range(pos,end))
        return ret
    def leftovers(buf,covered):
        blocks=[];i=0
        while i<len(buf):
            if i in covered:i+=1;continue
            j=i+1
            while j<len(buf) and j not in covered:j+=1
            blocks.append(buf[i:j].hex());i=j
        return blocks
    abbr=data[".debug_abbrev"];table={};i=0
    while i<len(abbr):
        code,i=leb(abbr,i)
        if code==0:
            require(i==len(abbr),"unexpected second abbr table")
            break
        tag,i=leb(abbr,i);children=abbr[i];i+=1;attrs=[]
        while True:
            attr,i=leb(abbr,i);form,i=leb(abbr,i)
            if (attr,form)==(0,0):break
            require(attr and form,"invalid abbreviation");attrs.append((attr,form))
        require(code not in table and children in (0,1),"invalid abbreviation index")
        table[code]=(tag,children,attrs)
    buf=data[".debug_info"];length,version,aboff,pointer=struct.unpack_from("<IHIB",buf,0)
    require(length==len(buf)-4 and version==4 and pointer==8 and real(".debug_info",6,aboff,10)==[".debug_abbrev",0],"unknown compilation unit")
    sizes={1:8,5:2,6:4,7:8,11:1,14:4,19:4,23:4}
    nodes={};used_abbrev=set();i=11
    def read_die():
        nonlocal i
        offset=i;code,i=leb(buf,i)
        if not code:return None
        tag,children,attrs=table[code];used_abbrev.add(code);out=[]
        for attr,form in attrs:
            require(form in sizes,"unsupported DWARF4 form "+hex(form))
            width=sizes[form];pos=i;require(i+width<=len(buf),"truncated DIE");v=int.from_bytes(buf[i:i+width],"little");i+=width
            if form==14:
                dest=real(".debug_info",pos,v,10);require(isinstance(dest,list)and dest[0]==".debug_str","strp without debug_str")
                v=debug_string(dest[1])
            elif form==1:
                v=real(".debug_info",pos,v,1)
            elif form==23:
                dest=real(".debug_info",pos,v,10);require(isinstance(dest,list),"section pointer without relocation")
                if dest[0]==".debug_ranges":v=ranges(dest[1])
                elif dest==[".debug_line",0]:v="this-verified-line-program"
                else:raise Refusal("unsupported DIE section pointer")
            elif form==19:
                require(pos not in edges[".debug_info"],"relocated DW_FORM_ref4");v=("reference",v)
            elif attr in (0x58,0x3a):
                require(len(obj.file_table)==1 and 0<v<=len(obj.file_table[0][1]),"unknown line file index")
                v=obj.file_table[0][1][v-1]
            elif pos in edges[".debug_info"]:
                raise Refusal("unhandled numeric DIE relocation")
            out.append([attr,v])
        descendants=[]
        if children:
            while (child:=read_die()) is not None:descendants.append(child)
        node=(tag,out,descendants);nodes[offset]=node
        return node
    root=read_die();require(root is not None and i==len(buf)and root[0]==0x11,"entire DIE tree")
    require(used_abbrev==set(table),"unused abbreviation schema")
    def normalize(node,chain=()):
        key,attrs,kids=node
        result=[]
        for name,val in attrs:
            if isinstance(val,tuple) and val and val[0]=="reference":
                off=val[1]
                require(off in nodes and off not in chain,"DWARF reference cycle")
                val=["ref",normalize(nodes[off],chain+(off,))]
            result.append((name,val))
        return [key,result,[normalize(n,chain)for n in kids]]
    tag,attrs,children=root;common=[];cu_extent=[];limits={}
    for attr,value in attrs:
        if attr==3:
            prefix,sep,ident=value.rpartition("/@/")
            require(sep and ident==leaf.removesuffix(".o"),"DW_AT_name is not this physical CGU")
            value=prefix+"/@/<verified member>"
        if attr in (0x55,0x11,0x12):limits[attr]=value
        else:common.append((attr,value))
    if 0x55 in limits:
        require(limits.keys()=={0x55,0x11} and limits[0x11]==0,"unexpected CU range base")
        cu_extent=limits[0x55]
    elif limits:
        require(limits.keys()=={0x11,0x12} and isinstance(limits[0x11],list) and isinstance(limits[0x12],int),"unexpected CU low/high form")
        name,base=limits[0x11];cu_extent=[[[name,base],[name,base+limits[0x12]]]]
    ar=data[".debug_aranges"];lo,ver,cu,width,seg=struct.unpack_from("<IHIBB",ar)
    require(lo+4==len(ar)and ver==2 and width==8 and seg==0 and ar[12:16] == b"\xff"*4 and
            real(".debug_aranges",6,cu,10)==[".debug_info",0],"malformed aranges")
    addresses=[]
    for j in range(16,len(ar),16):
        addr,length=struct.unpack_from("<QQ",ar,j);addr=real(".debug_aranges",j,addr,1)
        if (addr,length)==(0,0):require(j+16==len(ar),"early end of aranges")
        else:addresses.append([addr,length])
    if ".debug_ranges" in indexes:
        remainder=leftovers(data[".debug_ranges"],spans[".debug_ranges"])
    else:remainder=[]
    for sec in indexes:
        if sec==".debug_line":continue  # The separately checked line reader consumes every set-address fixup.
        require(used[sec]==set(edges[sec]),"unconsumed physical relocation in "+sec)
    return {"cu":common,"cu_extent":cu_extent,"aranges":addresses,
            "subprograms":[normalize(ch)for ch in children],
            "unclaimed_str":leftovers(data[".debug_str"],spans[".debug_str"]),
            "unclaimed_ranges":remainder,"counts":{"dies":len(nodes),"abbrs":len(table)},
            "file_table":obj.file_table}
