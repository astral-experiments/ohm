"""Read signed x86-64 ELF relocations and DWARF4 line programs at function-relative PCs."""
from collections import defaultdict
import hashlib
import json
from pathlib import PurePosixPath
import re
import struct


class Refusal(ValueError):
    pass


def require(ok, why):
    if not ok:
        raise Refusal(why)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def string(data, at):
    return data[at:data.index(0, at)].decode()


def members(data):
    require(data[:8] == b"!<arch>\n", "not a GNU archive")
    offset = 8
    names = None
    result = []
    while offset < len(data):
        header = data[offset:offset+60]
        require(len(header) == 60 and header[58:] == b"`\n", "GNU archive header")
        name = header[:16].decode().strip()
        size = int(header[48:58])
        start = offset + 60
        end = start + size
        body = data[start:end]
        require(len(body) == size, "truncated archive member")
        if name == "//":
            names = body
        elif re.fullmatch(r"/[0-9]+", name):
            loc = int(name[1:])
            require(names is not None and (loc == 0 or names[loc-1:loc] == b"\n"), "bad GNU name offset")
            name = names[loc:names.index(b"/\n", loc)].decode()
        elif name not in ("/", "/SYM64/"):
            require(not name.startswith("#1/"), "unsupported BSD long name")
            name = name.removesuffix("/")
        result.append((name, body, header, data[end:end+size%2], offset))
        offset = end + size%2
    require(offset == len(data), "archive length")
    return result


class Object:
    def __init__(self, raw):
        require(raw[:7] == b"\x7fELF\x02\x01\x01", "not x86_64 ELF")
        hdr = struct.unpack_from("<HHIQQQIHHHHHH", raw, 16)
        require(hdr[:3] == (1, 62, 1) and hdr[10] == 64 and hdr[5]+64*hdr[11] == len(raw), "unsupported ELF geometry")
        require(raw[:16]==b"\x7fELF\x02\x01\x01"+b"\0"*9 and hdr[3:5]==(0,0)
                and hdr[6:10]==(0,64,0,0), "unexpected relocatable ELF header or ABI flags")
        self.h = [struct.unpack_from("<IIQQQQIIQQ",raw,hdr[5]+64*i) for i in range(hdr[11])]
        self.raw = raw
        covered=64
        for h in sorted((h for h in self.h if h[1]!=8 and h[5]),key=lambda h:h[4]):
            require(covered<=h[4] and h[4]+h[5]<=hdr[5] and not any(raw[covered:h[4]]),
                    "overlap, nonzero padding or invalid section extent")
            covered=h[4]+h[5]
        require(not any(raw[covered:hdr[5]]),"nonzero padding before section table")
        names = self.section(hdr[12])
        self.names = [string(names, h[0]) for h in self.h]
        si, = (i for i,h in enumerate(self.h) if h[1] == 2)
        st = self.h[si]
        require(st[9] == 24 and self.h[st[6]][1] == 3, "bad symbol table")
        strs = self.section(st[6])
        self.symbols = [(string(strs,a),t,v,s,x,z) for a,t,v,s,x,z in struct.iter_unpack("<IBBHQQ",self.section(si))]
        require(self.symbols[0]==("",0,0,0,0,0) and all(st>>4==0 for _,st,*_ in self.symbols[:st[7]])
                and all(st>>4!=0 for _,st,*_ in self.symbols[st[7]:]),"symbol-table local/nonlocal boundary")
        self.functions = {}
        self.ranges = defaultdict(list)
        self.edges = defaultdict(list)
        for name, kind, vis, sec, start, size in self.symbols:
            if kind & 15 == 2 and 0 < sec < len(self.h):
                require(name and name not in self.functions and self.h[sec][2] & 4 and start+size <= self.h[sec][5], "function map")
                self.functions[name] = (sec,start,size,kind,vis)
                self.ranges[sec].append((start,start+size,name))
        for i,h in enumerate(self.h):
            if h[1] not in (4,9):
                continue
            require(h[1] == 4 and h[9] == 24 and h[6] == si, "unhandled relocation format")
            for at, ref, addend in struct.iter_unpack("<QQq", self.section(i)):
                require(at < self.h[h[7]][5], "relocation offset")
                self.edges[h[7]].append((at,ref&0xffffffff,ref>>32,addend))
        for entries in self.edges.values():
            entries.sort()
        self.sections = [[n,h[1],h[2],h[3],h[5],h[8],h[9],sha(self.section(i))]
                         for i,(n,h) in enumerate(zip(self.names,self.h))]
        self.lines, self.file_table = self.line_program()

    def section(self, i):
        h = self.h[i]
        if h[1] == 8:
            return b""
        body = self.raw[h[4]:h[4]+h[5]]
        require(len(body) == h[5], "section length")
        return body

    def function(self, name):
        sec, start, size, kind, vis = self.functions[name]
        edges = []
        for off,code,dest,add in self.edges.get(sec,()):
            if start <= off < start+size:
                sn,sk,sv,ss,so,sz = self.symbols[dest]
                target = self.names[ss] if 0 < ss < len(self.names) else ss
                edges.append([off-start,code,sn,sk,sv,target,so,sz,add])
        return [sha(self.section(sec)[start:start+size]),size,kind,vis,edges]

    def line_program(self):
        ids = [i for i,n in enumerate(self.names) if n == ".debug_line"]
        if not ids:
            require(not any(n in (".zdebug_line",".rel.debug_line",".rela.debug_line") for n in self.names), "unhandled compressed/relocated lines")
            return {}, []
        sec, = ids
        data = self.section(sec)
        ptr = 0

        def uint(n, signed=False):
            nonlocal ptr
            require(ptr+n <= len(data), "truncated line program")
            value = int.from_bytes(data[ptr:ptr+n],"little",signed=signed)
            ptr += n
            return value

        def var(signed=False):
            value = shift = 0
            while True:
                b = uint(1); value |= (b&127) << shift; shift += 7
                require(shift <= 70, "oversized LEB")
                if b < 128:
                    return value-(1<<shift) if signed and b&64 else value

        def cstr():
            nonlocal ptr
            s = string(data,ptr); ptr = data.index(0,ptr)+1
            return s

        line_reloc = {loc:(kind,idx,add) for loc,kind,idx,add in self.edges[sec]}
        require(len(line_reloc) == len(self.edges[sec]), "multiple set-address relocations")
        seen = set()
        sequences = defaultdict(list)
        tables = []
        while ptr < len(data):
            length = uint(4); end_unit = ptr+length
            require(length < 0xfffffff0 and end_unit <= len(data) and uint(2) == 4, "expected DWARF4 line unit")
            header_len = uint(4); instructions = ptr+header_len
            min_step,max_ops,default_stmt,line_base,line_range,base = uint(1),uint(1),uint(1),uint(1,True),uint(1),uint(1)
            require(min_step and max_ops == 1 and base == 13 and line_range, "unsupported line program header")
            std_arg_lengths = list(uint(1) for _ in range(base-1))
            require(std_arg_lengths == [0,1,1,1,1,0,0,0,1,0,0,1], "unknown standard line opcodes")
            dirs = [""]
            while (name := cstr()):
                dirs.append(name)
            files = [None]
            while (name := cstr()):
                di,mod,size = var(),var(),var()
                require(di<len(dirs), "line file directory")
                files.append((str(PurePosixPath(dirs[di])/name),mod,size))
            require(ptr == instructions, "line header end")
            tables.append([dirs,files[1:]])
            owners = ()
            pc,file,line,column,isa,disc,flags = 0,1,1,0,0,0,default_stmt
            while ptr < end_unit:
                op = uint(1)
                emit = stop = False
                if op == 0:
                    size = var(); end = ptr+size; ext = uint(1)
                    if ext == 1:
                        emit = stop = True
                    elif ext == 2:
                        require(not owners and size==9 and ptr in line_reloc and ptr not in seen, "set_address lacks physical relocation")
                        seen.add(ptr)
                        typ,idx,add = line_reloc[ptr]
                        _,_,_,target,value,_ = self.symbols[idx]
                        require(typ == 1 and 0 < target < len(self.h) and self.h[target][2]&4 and uint(8)==0, "unexpected line relocation target")
                        pc = value+add
                        owners = [(n,lo,hi) for lo,hi,n in self.ranges[target] if lo <= pc < hi]
                        require(owners, "line sequence has no defined function")
                    elif ext == 4:
                        disc = var()
                    else:
                        raise Refusal(f"unsupported extended line opcode {ext}")
                    require(ptr==end, "extended instruction length")
                elif op >= base:
                    pc += ((op-base)//line_range)*min_step
                    line += line_base+(op-base)%line_range
                    emit = True
                elif op == 1: emit = True
                elif op == 2: pc += min_step*var()
                elif op == 3: line += var(True)
                elif op == 4: file = var()
                elif op == 5: column = var()
                elif op == 6: flags ^= 1
                elif op == 7: flags |= 2
                elif op == 8: pc += min_step*((255-base)//line_range)
                elif op == 9: pc += uint(2)
                elif op == 10: flags |= 4
                elif op == 11: flags |= 8
                elif op == 12: isa = var()
                if emit:
                    require(owners and 0 < file < len(files) and line >= 0, "unbound line row")
                    for name,begin,end in owners:
                        require(begin <= pc <= end, "line program exceeds its function")
                        sequences[name].append((pc-begin,files[file][0],line,column,isa,disc,flags,stop))
                    flags &= 1; disc = 0
                if stop:
                    owners=()
                    pc,file,line,column,isa,disc,flags = 0,1,1,0,0,0,default_stmt
            require(not owners and ptr==end_unit, "unterminated line sequence")
        require(seen==set(line_reloc), "unconsumed debug_line relocation")
        return dict(sequences),tables
