"""Compare real ELF/DWARF semantic records independently of how rustc partitions the crate."""
from collections import Counter,defaultdict
import struct
from native_elf import digest,require,sha
from dwarf4 import projected


def data_ref(obj,edge,origin=0):
    loc,typ,idx,add=edge
    name,kind,vis,sec,at,size=obj.symbols[idx]
    section=obj.names[sec] if 0<sec<len(obj.names) else sec
    return [loc-origin,typ,name,kind,vis,section,at,size,add]


def strtab(obj,index):
    raw=obj.section(index);points=[]
    ss=struct.unpack_from("<H",obj.raw,62)[0]
    if ss==index:points.extend(h[0] for h in obj.h)
    for k,h in enumerate(obj.h):
        if h[1]==2 and h[6]==index:
            points.extend(x[0] for x in struct.iter_unpack("<IBBHQQ",obj.section(k)))
    coverage=bytearray(len(raw))
    for pos in set(points):
        end=raw.index(0,pos)+1;coverage[pos:end]=b"\1"*(end-pos)
    gaps=[];i=0
    while i<len(raw):
        if coverage[i]:i+=1;continue
        j=i
        while j<len(raw) and not coverage[j]:j+=1
        gaps.append(raw[i:j].hex());i=j
    return gaps


def unwind(obj,index):
    raw=obj.section(index);edges=obj.edges[index];cie={};fde=[];i=0;seen=set()
    while i<len(raw):
        n=struct.unpack_from("<I",raw,i)[0]
        if n==0:
            require(i+4==len(raw),"early EH terminator")
            break
        end=i+4+n
        require(n>=4 and end<=len(raw),"EH record bounds")
        ident=struct.unpack_from("<I",raw,i+4)[0]
        refs=[]
        for edge in edges:
            if i<=edge[0]<end:refs.append(data_ref(obj,edge,i));seen.add(edge)
        if ident==0:
            cie[i]=[raw[i+8:end].hex(),refs]
        else:
            ci=i+4-ident
            require(ci in cie,"EH frame references unknown CIE")
            fde.append([digest(cie[ci]),raw[i+8:end].hex(),refs])
        i=end
    require(len(seen)==len(edges),"unconsumed EH frame relocation")
    return list(cie.values()),fde


def feature(state):
    counts=defaultdict(Counter);examples={}
    def emit(category,value):
        k=digest(value);counts[category][k]+=1;examples.setdefault((category,k),value)
    for leaf,obj in state.objects.items():
        dbg=projected(obj,leaf)
        emit("cu_options",dbg["cu"])
        for item in dbg["cu_extent"]:emit("cu_extent",item)
        for item in dbg["aranges"]:emit("debug_aranges",item)
        for item in dbg["subprograms"]:emit("debug_subprogram",item)
        for item in dbg["unclaimed_str"]:emit("unclaimed_debug_strings",item)
        for item in dbg["unclaimed_ranges"]:emit("unclaimed_debug_ranges",item)
        for directories,files in dbg["file_table"]:
            for directory in directories:emit("source_directories",directory)
            for f in files:emit("source_files",f)
        for name in obj.functions:
            # Bind on mangled link identity, including actual (not erased) crate IDs.
            # Every placement, alias, flag, instruction and relocation is observed.
            v=obj.function(name);line=obj.lines.get(name,[])
            emit("private_function" if v[2]>>4==0 else "nonlocal_function",[name,*v,line])
        for name,kind,vis,sec,at,size in obj.symbols:
            t=kind&15
            if (name,kind,vis,sec,at,size)==("",0,0,0,0,0):
                continue
            if t==4:
                require(name==leaf.removesuffix(".o") and sec==65521 and at==size==0,"unidentified STT_FILE")
            elif t==3:
                require(not name and kind==3 and vis==at==size==0 and 0<sec<len(obj.h),"unhandled STT_SECTION")
            elif t!=2 or not(0<sec<len(obj.h)):
                emit("undefined_symbol" if sec==0 else "static_symbol",[name,kind,vis,obj.names[sec] if 0<sec<len(obj.h) else sec,at,size])
        for i,h in enumerate(obj.h):
            n=obj.names[i];kind=h[1];flags=h[2];buf=obj.section(i)
            if kind==0:
                require(not any(h),"nonempty null section");continue
            if n.startswith(".debug_"):
                require(kind==1 and (flags,h[3],h[6],h[7],h[8],h[9])==
                        ((48,0,0,0,1,1) if n==".debug_str" else (0,0,0,0,1,0)) and obj.names.count(n)==1,
                        "duplicate or unsupported DWARF section geometry")
                continue  # Its values and fixups were parsed above by projected() and Object.line_program().
            if kind==2:
                require(n==".symtab" and (flags,h[3],h[8],h[9])==(0,0,8,24) and obj.names[h[6]]==".strtab","unexpected ELF symbol-table type");continue
            if kind==3:
                require(n==".strtab" and (flags,h[3],h[6],h[7],h[8],h[9])==(0,0,0,0,1,0),"unknown ELF string table geometry")
                for v in strtab(obj,i):emit("unreferenced_string_table_bytes",v)
                continue
            if kind==4:
                require(n==".rela"+obj.names[h[7]] and obj.names[h[6]]==".symtab" and
                        flags in (64,512) and (h[3],h[8],h[9])==(0,8,24),"unknown relocation geometry or target")
                if flags==512:
                    groups=[set(v[0] for v in struct.iter_unpack("<I",obj.section(g)[4:])) for g,gh in enumerate(obj.h) if gh[1]==17]
                    require(sum(i in members and h[7] in members for members in groups)==1,
                            "SHF_GROUP relocation and target do not belong to the same physical COMDAT")
                continue  # Attached to the machine, allocated, DWARF or EH record its header designates.
            if kind==17:
                words=list(struct.iter_unpack("<I",buf));sg=obj.symbols[h[7]]
                emit("comdat",[sg[0],sg[1],sg[2],words[0][0],[obj.names[w[0]] for w in words[1:]]])
                continue
            if n==".eh_frame":
                require(kind==0x70000001 and (flags,h[3],h[6],h[7],h[8],h[9])==(2,0,0,0,8,0),"unexpected EH encoding")
                cie,rows=unwind(obj,i)
                for v in cie:emit("cie",v)
                for v in rows:emit("fde",v)
                continue
            if flags&4:
                if h[5]==0:require(not obj.edges[i] and n==".text","unknown empty executable section")
                else:
                    # Attest all bytes; any padding, overlapping aliases, or orphan
                    # instruction are explicit residuals, never silently discarded.
                    spans=sorted((a,b,sym)for a,b,sym in obj.ranges[i])
                    if len(spans)!=1 or spans[0][:2]!=(0,len(buf)):
                        emit("unowned_or_overlapping_exec",[n,sha(buf),spans])
                    labels=[v[2] for v in spans]
                    emit("executable_section",[n,kind,flags,h[3],h[5],h[8],h[9],labels,sha(buf)])
                continue
            if n==".note.GNU-stack":
                require(kind==1 and flags==0 and not buf and not obj.edges[i],"executable stack or unexpected note")
                continue
            if n==".comment":
                require(kind==1 and flags==48 and not obj.edges[i] and buf.endswith(b"\0"), "bad comment section")
                emit("compiler_comment",buf.hex());continue
            emit("remaining_section",[n,kind,flags,h[3],h[5],h[8],h[9],sha(buf),[data_ref(obj,e) for e in obj.edges[i]]])
    return counts,examples


# Repetition of a file-header string or exact CIE between CUs changes only its
# declared storage. A complete source/subprogram/region/code/static invariant
# still has to match before any repeated value attests a layout transition.
SET_EQ={"cu_options","source_directories","source_files","compiler_comment","cie","undefined_symbol"}


def compare(parent,child):
    a,ae=feature(parent);b,be=feature(child);differences={};redundancy={}
    for cat in sorted(a.keys()|b.keys()):
        m,n=a[cat],b[cat]
        if m==n:continue
        if cat in SET_EQ and m.keys()==n.keys():
            redundancy[cat]=[sum(m.values()),sum(n.values())]
            continue
        left=m-n;right=n-m
        differences[cat]={"parent_occurrences":sum(left.values()),"child_occurrences":sum(right.values()),
                          "parent_records":{k:[v,ae[cat,k]] for k,v in sorted(left.items())},
                          "child_records":{k:[v,be[cat,k]] for k,v in sorted(right.items())}}
    return {"equal":not differences,"typed_records":{k:[sum(a[k].values()),sum(b[k].values())] for k in sorted(a.keys()|b.keys())},
            "same_values_repeated_across_CUs":redundancy,"differing_records":differences}
