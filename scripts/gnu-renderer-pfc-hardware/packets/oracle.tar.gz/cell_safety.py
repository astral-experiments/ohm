"""Reopen actual Cargo errors and run the dynamically linked consumers from the custody CAS."""
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
from native_elf import require,sha
from signed import HISTORIES

PHASES=("old","edit","repeat","repair","empty")
CLI=["cargo","+ohm","build","-p","ruff_annotate_snippets","--lib","--locked","--offline","-j4","--message-format=json"]


def inspect(path,history,states):
    read_json=lambda p:json.loads(p.read_bytes())
    terminal=read_json(path/"complete.json");subject=read_json(path/"subject.json")
    require(terminal["history"]==history and terminal["structural_only"] and terminal["lane"]=="structural"
            and terminal["ordinary"]==CLI and terminal["source"]==subject["source"]["commit"],"normal complete structural subject required")
    for label,key in (("old","cold_cgu"),("edit","warm_cgu"),("empty","empty_cgu")):
        require(len(states[label].objects)==terminal[key],"observed partition count differs")
    native_json=read_json(path/"raw/edit/native.json")
    renderer,=(row for row in native_json["compilers"] if row["name"]=="annotate_snippets")
    av=renderer["argv"]
    level=[av[k+1]for k,v in enumerate(av[:-1]) if v=="-C" and av[k+1].startswith("opt-level=")]
    require(level==(["opt-level=1"] if history=="source-map" else []) and not native_json["linkers"],
            "normal renderer compiler opt-level or edit linker roster changed")
    require(all(not x.startswith(("-Zprint-mono-items","-Zhuman-readable-cgu","-Zverbose-internals"))for x in av),
            "observer flags on ordinary compile")
    pair=read_json(path/"edit-pair.json")
    require(pair["intervening_reads"] is False and pair["states_sampled_after_first_repeat"]
            and pair["structural_repeat_no_product_writes"] and not pair["untraced_pair"],"requires contiguous ordinary edit/repeat")
    return {"role":terminal["role"],"source":terminal["source"],"driver":terminal["driver"],
            "registered_argv":CLI,"observed_renderer_opt_level":level or ["default O0"],
            **consumer_verdicts(path,history,states)}


def consumer_verdicts(path,history,states):
    """Run the native consumers and re-open errors only from this cell's own actual artifacts."""
    read_json=lambda p:json.loads(p.read_bytes())
    normalized=lambda raw: re.sub(rb"\A\nthread 'main' \([0-9]+\) panicked at ",b"\nthread 'main' (PID) panicked at ",raw)
    rows={};images={}
    for label in PHASES:
        base=path/"oracles"/label;r=read_json(base/"reader.json")
        body=(path/"objects"/r["program"]).read_bytes()
        require(sha(body)==r["program"] and body[:7]==b"\x7fELF\x02\x01\x01" and
                sha((path/"inputs/reader.rs").read_bytes())==r["source"] and r["archive"]==sha(states[label].arc),"consumer custody")
        require(r["returned_path"]==states[label].state["paths"]["archive"] and
                "annotate_snippets="+r["returned_path"] in r["compiler_argv"],"consumer did not receive returned archive")
        trace=gzip.decompress((base/"compile/strace.gz").read_bytes())
        for s in r["driver_opens"]+r["archive_opens"]:
            require(s.encode() in trace,"claimed return FD absent in real trace")
        require(r["lineage"]["compiler_readers"] and r["lineage"]["leader"],"missing compiler reader lineage")
        fd=os.memfd_create("verified-renderer-consumer",os.MFD_CLOEXEC | getattr(os,"MFD_EXEC",0x10));os.write(fd,body);os.fchmod(fd,0o700)
        try:
            results={}
            for case,v in sorted(r["cases"].items()):
                stdout=(base/case/"stdout").read_bytes();stderr=(base/case/"stderr").read_bytes()
                require(sha(stdout)==v["stdout"] and sha(stderr)==v["stderr"],"original captured consumer streams")
                run=subprocess.run([f"/proc/self/fd/{fd}",case],pass_fds=(fd,),capture_output=True,timeout=10,
                                   env={"PATH":"/usr/bin:/bin","LC_ALL":"C","RUST_BACKTRACE":"0"})
                require(run.returncode==v["exit"] and run.stdout==stdout,"native consumer result")
                if label=="old" and history=="source-map":
                    require(v["exit"]==101 and not stdout and b"index out of bounds: the len is 11 but the index is 11" in stderr and
                            normalized(stderr)==normalized(run.stderr),"physical old panic, allowing only numeric PID")
                else:
                    role="old" if label=="old" else "new"
                    wanted=(path/"inputs"/role/case).read_bytes()
                    require(v["exit"]==0 and not stderr and not run.stderr and stdout==wanted,"source-backed fixed native output")
                results[case]=[v["exit"],sha(stdout),sha(normalized(stderr))]
            rows[label]=results
        finally:os.close(fd)
        images[label]=sha(body)
    require(images["old"]!=images["empty"] and len({images[k] for k in PHASES if k!="old"})==1,"corrected warm/independently-empty whole consumer")
    wrong=read_json(path/"wrong-reader/result.json")
    require(wrong["reader"]==images["old"] and wrong["cases"].keys()==rows["old"].keys(),"wrong historical native reader identity")
    for case,v in wrong["cases"].items():
        require(v["actual"]==rows["old"][case][1] and v["rejected_against"]==rows["empty"][case][1] and
                v["actual"]!=v["rejected_against"],"wrong native executable accepted as corrected")
    expected=HISTORIES[history]["file"];diags={}
    for label in ("invalid","empty-invalid"):
        d=read_json(path/"states"/label/"diagnostic.json")
        require(d["code"]=="E0308" and d["message"]=="mismatched types" and any(x["is_primary"] and x["file_name"]==expected for x in d["spans"]),"wrong compiler diagnostic")
        events=[json.loads(l) for l in (path/"raw"/label/"stdout").read_bytes().splitlines()]
        m,=(e["message"] for e in events if e.get("reason")=="compiler-message" and (e.get("message",{}).get("code") or {}).get("code")=="E0308")
        require(events[-1]=={"reason":"build-finished","success":False} and m["spans"]==d["spans"] and m["message"]==d["message"],"mismatching raw diagnostic")
        terminal_=read_json(path/"raw"/label/"terminal.json")
        require(101 in [terminal_.get(k) for k in ("status",)],"missing cargo exit 101")
        diags[label]=d
    require(diags["invalid"]==diags["empty-invalid"],"different cold/warm invalid diagnostics")
    return {"state_consumers":images,"actual_reruns":rows,"complete_error":diags["invalid"],
            "certified_receipts":{n:sha((path/n).read_bytes()) for n in ("subject.json","runtime.json","complete.json","edit-pair.json","independent-empty.json","independent-empty-invalid.json","wrong-reader/result.json")}}
